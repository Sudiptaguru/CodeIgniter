<?php
namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\EmailModel;
use Config\Services;

class SendScheduledEmails extends BaseCommand
{
    protected $group = 'Email';
    protected $name = 'email:send_scheduled';
    protected $description = 'Send scheduled emails';

    public function run(array $params)
    {
        $emailModel = new EmailModel();
        $emails = $emailModel->where('schedule_date <=', date('Y-m-d'))
                             ->where('schedule_time <=', date('H:i:s'))
                             ->findAll();

        if ($emails) {
            $emailConfig = config('Email');

            foreach ($emails as $emailData) {
                $email = Services::email();
                
                $email->initialize($emailConfig);

                $email->setTo($emailData['email']);
                $email->setSubject($emailData['subject']);
                $email->setMessage($emailData['message']);

                if ($email->send()) {
                    $emailModel->delete($emailData['id']);
                } else {
                    CLI::write('Failed to send email to: ' . $emailData['email'], 'red');
                }
            }
        } else {
            CLI::write('No scheduled emails to send at this time.', 'yellow');
        }
    }
}
?>
