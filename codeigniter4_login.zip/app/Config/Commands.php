<?php
protected $commands = [
    'email:send_scheduled' => \App\Commands\SendScheduledEmails::class,
];
?>