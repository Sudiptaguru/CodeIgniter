<?php

function asset($path)
{
    return base_url($path);
}
