<!DOCTYPE html>
<html>
<head>
    <title>Add Image</title>
</head>
<body>
    <h1>Add Image</h1>
    <?php if (session()->has('errors')): ?>
        <div style="color: red;">
            <?php foreach (session('errors') as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <form method="post" action="<?= base_url('images/store') ?>" enctype="multipart/form-data">
        <label>Title</label>
        <input type="text" name="title"><br><br>
        <?php if (isset(session('errors')['title'])): ?>
                <div style="color: red;">
                    <?= session('errors')['title'] ?>
                </div>
            <?php endif; ?>
        <label>Image</label>
        <input type="file" name="image">
        <?php if (isset(session('errors')['image'])): ?>
                <div style="color: red;">
                    <?= session('errors')['image'] ?>
                </div>
            <?php endif; ?>
        <br><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>
