<!DOCTYPE html>
<html>
<head>
    <title>GuzzleHTTP Example</title>
</head>
<body>
    <h1>GuzzleHTTP Example</h1>
    <?php if (isset($data)): ?>
        <pre><?php print_r($data); ?></pre>
    <?php endif; ?>
</body>
</html>
