<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedule Email</title>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.13.18/jquery.timepicker.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.13.18/jquery.timepicker.min.js"></script>
</head>
<body>
    <form action="<?= base_url('schedule-email') ?>" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="subject">Subject:</label>
        <input type="text" id="subject" name="subject" required><br><br>
        
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea><br><br>
        
        <label for="schedule_date">Date:</label>
        <input type="text" id="schedule_date" name="schedule_date" required><br><br>
        
        <label for="schedule_time">Time:</label>
        <input type="text" id="schedule_time" name="schedule_time" required><br><br>
        
        <input type="submit" value="Schedule Email">
    </form>

    <script>
        $(function() {
            $("#schedule_date").datepicker({
                dateFormat: 'yy-mm-dd'
            });
            $("#schedule_time").timepicker({
                timeFormat: 'HH:mm',
                interval: 30,
                minTime: '00:00',
                maxTime: '23:30',
                dynamic: false,
                dropdown: true,
                scrollbar: true
            });
        });
    </script>
</body>
</html>
