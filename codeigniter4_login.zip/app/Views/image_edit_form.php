<!DOCTYPE html>
<html>
<head>
    <title>Edit Image</title>
</head>
<body>
    <h1>Edit Image</h1>
    <form method="post" action="<?= base_url('images/update/' . $image['id']) ?>" enctype="multipart/form-data">
        <input type="hidden" name="old_image" value="<?= $image['image'] ?>">
        <label>Title</label>
        <input type="text" name="title" value="<?= $image['title'] ?>" required><br><br>
        <label>Image</label>
        <input type="file" name="image"><br><br>
        <img src="<?= base_url('uploads/' . $image['image']) ?>" width="100"><br><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
