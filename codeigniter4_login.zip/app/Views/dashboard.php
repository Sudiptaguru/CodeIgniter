<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>Dashboard</h1>
    <p>Welcome, <?= session()->get('username') ?>!</p>
    <a href="<?= base_url('auth/logout') ?>">Logout</a>
</body>
</html>
