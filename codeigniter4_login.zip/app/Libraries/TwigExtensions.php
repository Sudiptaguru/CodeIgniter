<?php

namespace App\Libraries;

use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class TwigExtensions extends AbstractExtension
{
    public function getFunctions()
    {
        return [
            new TwigFunction('base_url', [$this, 'base_url']),
        ];
    }

    public function base_url($path = '')
    {
        return base_url($path);
    }
}
