<?php

namespace App\Libraries;

class AssetTwigExtension
{
    public static function asset($path)
    {
        return base_url($path);
    }
}
