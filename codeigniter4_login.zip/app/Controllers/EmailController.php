<?php

namespace App\Controllers;

use App\Models\EmailModel;
use CodeIgniter\Controller;

class EmailController extends Controller
{
    public function scheduleEmailForm()
    {
        return view('schedule_email_form'); // This should be a view with your form
    }

    public function scheduleEmail()
    {
        $emailModel = new EmailModel();

        $data = [
            'email' => $this->request->getPost('email'),
            'subject' => $this->request->getPost('subject'),
            'message' => $this->request->getPost('message'),
            'scheduled_datetime' => $this->request->getPost('scheduled_datetime'),
        ];

        $emailModel->save($data);

        return redirect()->to('/email/schedule')->with('message', 'Email scheduled successfully!');
    }
}
