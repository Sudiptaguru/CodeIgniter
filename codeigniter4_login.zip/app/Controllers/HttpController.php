<?php

// app/Controllers/HttpController.php

namespace App\Controllers;

use App\Controllers\BaseController;
use GuzzleHttp\Client;

class HttpController extends BaseController
{
    public function index()
    {
        // Create a GuzzleHTTP client
        $client = new Client(['verify' => false]);

        try {
            // Make a GET request
            $response = $client->get('https://jsonplaceholder.typicode.com/posts/1');
            // Get the response body as a string
            $body = $response->getBody()->getContents();
            // Parse JSON response
            $data = json_decode($body);
            print_r($data); exit;

            return view('http_view', ['data' => $data]);
        } catch (\GuzzleHttp\Exception\GuzzleException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    public function guzzlepost()
    {
        // Create a new Guzzle client instance
        $client = new Client(['verify' => false]);

        try {
            $data = [
                'key' => 'value',
                'another_key' => 'another_value'
            ];
            // Make a GET request
            $response = $client->post('https://api.yourbaseapiserver.com/incidents.xml', [
                'json' => $data // Set the data as JSON in the request body
            ]);
            // Get the response body as a string
            $body = $response->getBody()->getContents();
            // Parse JSON response
            $data = json_decode($body);
            print_r($data);
            exit;

            return view('http_view', ['data' => $data]);
        } catch (\GuzzleHttp\Exception\GuzzleException $e) {
            return "Error: " . $e->getMessage();
        }
    }
}
