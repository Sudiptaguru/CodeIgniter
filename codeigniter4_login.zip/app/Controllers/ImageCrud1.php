<?php
namespace App\Controllers;

use App\Models\ImageModel;
use CodeIgniter\Controller;

class ImageCrud extends Controller
{
    public function index()
    {
        return view('image_list');
    }

    public function fetchAll()
    {
        $model = new ImageModel();
        $data['images'] = $model->findAll();
        return $this->response->setJSON($data);
    }

    public function store()
    {
        $model = new ImageModel();
        $file = $this->request->getFile('image');

        if ($file->isValid() && !$file->hasMoved()) {
            $imageName = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads', $imageName);

            $model->save([
                'title' => $this->request->getPost('title'),
                'image' => $imageName
            ]);
            return $this->response->setJSON(['status' => 'success']);
        }

        return $this->response->setJSON(['status' => 'error']);
    }

    public function edit($id)
    {
        $model = new ImageModel();
        $data['image'] = $model->find($id);
        return $this->response->setJSON($data);
    }

    public function update($id)
    {
        $model = new ImageModel();
        $file = $this->request->getFile('image');
        $imageName = $this->request->getPost('old_image');

        if ($file->isValid() && !$file->hasMoved()) {
            $imageName = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads', $imageName);
        }

        $model->update($id, [
            'title' => $this->request->getPost('title'),
            'image' => $imageName
        ]);
        return $this->response->setJSON(['status' => 'success']);
    }

    public function delete($id)
    {
        $model = new ImageModel();
        $image = $model->find($id);
        unlink(WRITEPATH . 'uploads/' . $image['image']);
        $model->delete($id);
        return $this->response->setJSON(['status' => 'success']);
    }
}
?>