<?php
namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class Auth extends Controller
{
    public function register()
    {
        helper(['form']);
        $data = [];

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'username' => 'required|min_length[3]|max_length[20]|is_unique[users.username]',
                'email'    => 'required|valid_email|is_unique[users.email]',
                'password' => 'required|min_length[8]|max_length[255]',
                'password_confirm' => 'matches[password]'
            ];

            if ($this->validate($rules)) {
                $model = new UserModel();
                $model->save([
                    'username' => $this->request->getPost('username'),
                    'email'    => $this->request->getPost('email'),
                    'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT)
                ]);

                return redirect()->to('/auth/login');
            } else {
                $data['validation'] = $this->validator;
            }
        }

        return view('register', $data);
    }

    public function login()
    {
        helper(['form']);
        $data = [];

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'email'    => 'required|valid_email',
                'password' => 'required|min_length[8]|max_length[255]',
            ];

            if ($this->validate($rules)) {
                $model = new UserModel();
                $user = $model->where('email', $this->request->getPost('email'))->first();

                if ($user) {
                    if (password_verify($this->request->getPost('password'), $user['password'])) {
                        $session = session();
                        $session->set([
                            'id'       => $user['id'],
                            'username' => $user['username'],
                            'email'    => $user['email'],
                            'logged_in'=> true,
                        ]);

                        return redirect()->to('/dashboard');
                    } else {
                        $data['error'] = 'Password is incorrect.';
                    }
                } else {
                    $data['error'] = 'Email does not exist.';
                }
            } else {
                $data['validation'] = $this->validator;
            }
        }

        return view('login', $data);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }
}
