<?php

namespace App\Controllers;

use CodeIgniter\CodeIgniter;
use App\Libraries\EzerApi;
use App\Libraries\EmailMarketingApi;
use App\Libraries\DomainResellerAPI;
use App\Libraries\MyLibrary;

class AjaxController extends BaseController
{
    protected $myLibrary;

    public function __construct() {
        $this->myLibrary = new MyLibrary();
        $this->ezapi_client = new EzerAPI();
    }

    // public function __construct()
    // {
    //     $this->ezapi_client = new EzerAPI(); // create an instance of EzerAPI Library
    //     $this->emapi_client = new EmailMarketingApi(); // create an instance of EmailMarketingApi Library
    //     //$this->ezutil_client = new EzerUtility(); // create an instance of EzerUtility Library
    //     $this->session = session();
    //     $this->accessToken = $this->session->get('accessToken');
    //     $this->customerData = $this->session->get('customerData');
    //     helper('text', 'filesystem');
    // }

    public function auth_signin()
    {
        $user_email = $this->request->getVar('user_email', FILTER_SANITIZE_EMAIL);
        $user_password = $this->request->getVar('user_password');
        $data = [
            'email' => $user_email,
            'password' => $user_password
        ];

        $api_response = $this->ezapi_client->authEmailSignin($data);
        print_r($api_response);
        //var_dump($api_response);
        //exit;
        if ($api_response->status == 1) {
            $isPlanActive = $api_response->data->isPlanActive; //FALSE or TRUE
            $currentPlanID = $api_response->data->currentPlanID; //ID or TRNULLUE
            $ses_data = [
                'id' => $api_response->data->id,
                'username' => $api_response->data->username,
                'email' => $api_response->data->email,
                // 'user_status' => $api_response->status,
                // 'country_calling_code' => $api_response->data->country_calling_code,
                // 'accessToken' => $api_response->data->accessToken,
                // 'profile_image_path' => $api_response->data->profile_image_path,
                // 'customerData' => $api_response->data->customer_details,
                // 'isLoggedIn' => TRUE,
                // 'isPlanActive' => $isPlanActive,
                // 'user_role' => $api_response->data->roles[1],
                // 'currentPlanID' => $currentPlanID,
                // 'isPersonalPlan' => $this->ezutility->checkPersonalPlan($currentPlanID)
            ];

            $this->session->set($ses_data);
            //Prepare Response Data 
            $this->data['redirect_to'] = '/dashboard';
            $this->status = $api_response->status;
            $this->message = $api_response->message;
            $this->responseCode = $api_response->responseCode;
            //Send Ajax Response
            // $this->sendResponse($this->status, $this->message, $this->responseCode, $this->data);
        }

        /*else if ($api_response->status == 3) {
            $ses_data = [
                'email' => $user_email
            ];

            $this->session->set($ses_data);
            //Prepare Response Data 
            $this->data['redirect_to'] = '/verify-email';
            $this->status = $api_response->status;
            $this->message = $api_response->message;
            $this->responseCode = $api_response->responseCode;
            //Send Ajax Response
            $this->sendResponse($this->status, $this->message, $this->responseCode);

        }*/ else {
            //Prepare Response Data 
            $this->status = $api_response->status;
            $this->message = $api_response->message;
            $this->responseCode = $api_response->responseCode;
            //Send Ajax Response
            // $this->sendResponse($this->status, $this->message, $this->responseCode);
        }
    }

    public function mylibrary() {
        // Use library methods
        $result = $this->myLibrary->myMethod();

        // Pass data to the view
        $data['result'] = $result;

        // Load the view
        echo $this->twig->render('my_view.html', $data);
    }
}
