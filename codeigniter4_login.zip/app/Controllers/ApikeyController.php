<?php

namespace App\Controllers;
use App\Libraries\CurlLibrary;
use App\Controllers\BaseController;

class ApikeyController extends BaseController
{
    protected $CurlLibrary;

    public function __construct() {
        $this->CurlLibrary = new CurlLibrary();
    }
    public function getrequest()
    {
        $data1 = $this->CurlLibrary->myMethod();
        $data2 = get_object_vars($data1);
        print_r($data2);
        $first_name = $data1->first_name;
        $last_name = $data1->last_name;
        $data = [
            // 'page' => 'header',
            'title' => 'CodeIgniter 4 with Twig',
            'content' => 'Hello from Twig!',
            'first_name' => $first_name,
            'last_name' => $last_name
        ];
        echo $this->twig->render('curl_template.html', $data);
    }

    public function postrequest(){
        $apiURL = 'http://localhost:8000/apidata.php?request=2';
        $client = \Config\Services::curlrequest();

        $postData = array(
            'first_name' => "Yogesh",
            'last_name' => "singh",
            'email' => "yogesh@makitweb.com",
        );

        // Send request
        $response = $client->post($apiURL,['debug' => true,'json' => $postData]);

        // Read response
        $code = $response->getStatusCode();
        $reason = $response->getReason();

        if($code == 200){ // Success

            // Read data 
            $body = json_decode($response->getBody());

            $first_name = $body->first_name;
            $last_name = $body->last_name;
            $email = $body->email;

            echo "first_name : ".$first_name."<br>";
            echo "last_name : ".$last_name."<br>";
            echo "email : ".$email."<br>";

        }else{
            echo "failed";
            die;
        }

    }
}
