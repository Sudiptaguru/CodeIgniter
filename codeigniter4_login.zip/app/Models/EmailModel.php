<?php
namespace App\Models;

use CodeIgniter\Model;

class EmailModel extends Model
{
    protected $table = 'emails';
    protected $allowedFields = ['email', 'subject', 'message', 'schedule_date', 'schedule_time'];
}

?>