<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

 //    public function __construct() 
    // {
 //        parent:: __construct();

 //        $this->load->helper('url','form');
 //        $this->load->library("pagination");
    //  $this->load->model('StudentModel');
 //    }
    // public function add(){
    //     $this->load->view('addUser');
    // }
    // function registerUser(){
    //     $data = $insertArray = array();
    //         $insertArray = array(
    //             'name'=> $this->input->post('user'),
    //             'email'=> $this->input->post('email'),
    //             'course'=>$this->input->post('course'),
    //         );
            

            

    //     // $this->load->model('HomeModel');
    //     // $insert = $this->HomeModel->insert($insertArray);
    //         // if($insert){ 
    //                 // $this->session->set_userdata('success_msg', 'Your account registration has been successful. Please login to your account.'); 
    //         //     }
    //     $data['user'] = $insertArray;

    //     $status = $this->StudentModel->register($insertArray);

    //         if($status == true){
    //             $data['message'] = "
    //              <font color='green'>
    //              Successfully Data Inserted </font>";
    //         }else{
    //             $data['message'] = "
    //             <font color='red'>
    //             Please Try Again,Data is not inserted </font>";
    //         }
    //         $this->load->view('addUser',$data);
    //     redirect('Student/index');
    // }

    public function index() 
    {
        $config = array();
        // $config["base_url"] = base_url().'Student/index';
        $config["base_url"] = base_url().'Student/index';
        $config["total_rows"] = $this->StudentModel->get_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        
        $page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
        
        $data["links"] = $this->pagination->create_links();

        $data['student'] = $this->StudentModel->get_students($config["per_page"], $page);
        $this->load->view('pagination', $data);
    }
    public function edit()
    {
         $id=$this->uri->segment(3); 
         $this->load->model('StudentModel');
         $data['user']= $this->StudentModel->get_data($id);
         
         // echo "<pre>";
         // print_r($data);die();

//---------------------- adding update form to fetch data in form------------------------
   

    
        $this->load->view('update_admin_view',$data);
        // $this->load->view('admin_user_add', $data);
   
    }
   
    public function update_user() 
    {   
   
     $id=$this->input->post('id');
   
   
   //----------------------file upload code------------------
   
   
   //-------------------file upload code end here----------------------------------------
   
   
       $this->load->model('StudentModel');
       $course = $this->input->post('course');
       if(!empty($course)){
      $course = implode(',',$course);
    }
       $data = [
           // 'table_name' => 'admin_user', // pass the real table name
           'name' => $this->input->post('name'),
           'email' => $this->input->post('email'),
           'course' => $course
       ];
       if($this->StudentModel->upddata($data,$id)) 
       {    
           // echo("update successful");
           redirect('Student');
   
       }
       else
       {
           echo("update not successful");
       }
   
   }
   
    public function delete_row($id='')
    {  
        $this->load->model('StudentModel');
        $id=$this->uri->segment(3);
        $this->StudentModel->delete_data($id);
        redirect('Student');
    }


  // public function edit_status()
  // {
  //   // print_r($_POST);die();

  //   $id= $this->input->post('id'); 
  //   $status = $this->input->post('status');
    
  //    $this->load->model('Admin_user_model');
   
  //      if($this->Admin_user_model->update_status($status,$id)) 
  //      {  
  //          echo '1';
  //      }
  //      else
  //      {
  //          echo '0';
  //      }
    
  // }

   
}
?>