
 <div class="content-wrapper">
 
<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <form action="<?php echo base_url('Admin_user/add_user'); ?>" method="post"  enctype="multipart/form-data">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" value="">
                  </div>
                 
              </div>
              <div class="row">
              <div class="col-md-6">
                 
                 <div class="form-group">
                    <label for="mobile">Course</label>
                    <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile" value="">
                  </div>
              </div>
            </div>
            
            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
</div>        
</section>
</div> 

