
       
        <!DOCTYPE html>
<html lang="en">
    <head>
       <style type="text/css">
       .green1
    {
        color: #4CAF50;
        
    }
    .red1
    {
         color: red; 
    }
    </style>
        <meta charset="utf-8">
        <title>Trycatch Classes php training in mumbai</title>
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">


    </head>
    <body>

        <div class="container">
            <div class="row jumbotron">
    <a href="<?php echo base_url(); ?>">View All</a>
                </div>
            
            
            <div class="row jumbotron">
                <form method="POST" action="" id="frm_submit">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required="">
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" value="" required="">
                  </div>
                 
              </div>
              <div class="row">
              <div class="col-md-6">
                 
                 <div class="form-group">
                    <label for="course">Course</label>
                    <input type="checkbox" name="course[]" value="php">PHP
                    <input type="checkbox" name="course[]" value="android">ANDROID
                    <input type="checkbox" name="course[]" value="iphone">IPHONE 
                    <input type="checkbox" name="course[]" value="java">JAVA
                  </div>
              </div>
            </div>
            
            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
            
            <div class="row">
                <div class="alert alert-dismissable alert-success"  style="display: none">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Data inserted successfully</strong>
                </div>
                
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
        <script>
            $(document).ready(function (){
                $("body").on('click', '.btn-add-more', function (e) {
            e.preventDefault();
            var $sr = ($(".jdr1").length + 1);
            var rowid = Math.random();
            var $html = '<tr class="jdr1" id="' + rowid + '">' +
                    '<td><span class="btn btn-sm btn-default">' + $sr + '</span><input type="hidden" name="count[]" value="'+Math.floor((Math.random() * 10000) + 1)+'"></td>' +
                    '<td><input type="text" name="jdate[]" placeholder="Date" class="form-control input-sm datepicker"></td>' +
                    '<td><input type="text" name="jtype[]" placeholder="Travel by" class="form-control input-sm"></td>' +
                    '<td><input type="text" name="jpassanger[]" placeholder="Paasenger count" class="form-control input-sm"></td>' +
                    '<td><input type="text" name="jfrom[]" placeholder="Depart from" class="form-control input-sm"></td>' +
                    '<td><input type="text" name="jto[]" placeholder="Destination" class="form-control input-sm"></td>' +
                    '<td><input type="text" name="jticket_no[]" placeholder="Ticket No." class="form-control input-sm"></td>' +
                    '<td><input type="text" name="jamount[]" placeholder="Amount" class="form-control input-sm"></td>' +
                    '</tr>';
            $("#table-details").append($html);

        });
        $("body").on('click', '.btn-remove-detail-row', function (e) {
            e.preventDefault();
            if($("#table-details tr:last-child").attr('id') != 'row1'){
                $("#table-details tr:last-child").remove();
            }
            
        });
        $("body").on('focus', ' .datepicker', function () {
            $(this).datepicker({
                dateFormat: "yy-mm-dd"
            });
        });
        
        $("#frm_submit").on('submit', function (e) {
            e.preventDefault();
            $.ajax({
                url: '<?php echo base_url() ?>Admin_user/add_user',
                type: 'POST',
                data: $("#frm_submit").serialize()
            }).always(function (response){
                var r = (response.trim());
                if(r == 1){
                    $(".alert-success").show();
                }
                else{
                    $(".alert-success").show();
                }
            });
        });
            });
        </script>
    </body>
</html>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
