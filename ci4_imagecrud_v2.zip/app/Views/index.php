<!-- app/Views/index.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image CRUD - Index</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 100px;
        }

        .no-image {
            width: 200px;
            height: 150px;
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            text-align: center;
            line-height: 150px;
            color: #aaa;
        }
    </style>
</head>
<body>
    <h1>Image CRUD - Index</h1>
    <a href="/images/add" class="btn btn-primary">Add Image</a>

    <h2>Images</h2>
    <table id="imageTable" class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="imageList"></tbody>
    </table>

    <script>
        $(document).ready(function() {
            function fetchImages() {
                $.get('/images/fetch', function(data) {
                    $('#imageList').empty();
                    data.forEach(function(image) {
                        let imagePreview = image.file_name 
                            ? `<img src="/uploads/${image.file_name}" alt="${image.title}">` 
                            : `<div class="no-image">No Image</div>`;
                        
                        $('#imageList').append(`
                            <tr>
                                <td>${image.title}</td>
                                <td>${imagePreview}</td>
                                <td>
                                    <a href="/images/edit/${image.id}" class="btn btn-info btn-sm">Edit</a>
                                    <button class="btn btn-danger btn-sm" onclick="deleteImage(${image.id})">Delete</button>
                                </td>
                            </tr>
                        `);
                    });
                });
            }

            fetchImages();

            window.deleteImage = function(id) {
                $.ajax({
                    url: `/images/${id}`,
                    type: 'DELETE',
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                        } else {
                            alert('Delete failed');
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>
