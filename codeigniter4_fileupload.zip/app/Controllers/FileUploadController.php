<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;

class FileUploadController extends Controller
{
    public function index()
    {
        return view('file_upload');
    }

    public function upload()
    {
        $validationRule = [
            'file' => [
                'label' => 'File',
                'rules' => 'uploaded[file]|max_size[file,1024]|ext_in[file,jpg,jpeg,png,pdf]',
            ],
        ];

        if (!$this->validate($validationRule)) {
            return $this->response->setJSON([
                'status' => 'error',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $file = $this->request->getFile('file');
        if ($file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move( 'uploads', $newName);

            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'File uploaded successfully',
                'filePath' => base_url('uploads/' . $newName)
            ]);
        }

        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'File upload failed'
        ]);
    }
}
