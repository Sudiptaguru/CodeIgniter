<!DOCTYPE html>
<html>
<head>
    <title>File Upload with Modal</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <h1>Upload a File</h1>

    <div id="errors" style="color: red;"></div>
    <div id="message" style="color: green;"></div>

    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#uploadModal">
        Upload Image
    </button>

    <!-- Modal -->
    <div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadModalLabel">Upload Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="fileUploadForm" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <input type="file" name="file" />
                        <input type="hidden" name="filePath" id="filePath" value="">
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#fileUploadForm').on('submit', function(e) {
                e.preventDefault();

                var formData = new FormData(this);

                $.ajax({
                    url: '<?= site_url('fileupload/upload') ?>',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        $('#errors').html('');
                        $('#message').html('');

                        if (response.status == 'error') {
                            $.each(response.errors, function(key, value) {
                                $('#errors').append('<p>' + value + '</p>');
                            });
                        } else {
                            $('#message').html(response.message);
                            $('#filePath').val(response.filePath);
                            $('#uploadModal').modal('hide');
                        }
                    },
                    error: function() {
                        $('#message').html('An error occurred while uploading the file.');
                    }
                });
            });
        });
    </script>
</body>
</html>
