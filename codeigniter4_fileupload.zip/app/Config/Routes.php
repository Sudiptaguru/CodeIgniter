<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('fileupload', 'FileUploadController::index');
$routes->post('fileupload/upload', 'FileUploadController::upload');