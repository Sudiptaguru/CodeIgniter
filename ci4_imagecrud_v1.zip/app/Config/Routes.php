<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Define routes for image CRUD operations.
$routes->get('images', 'Images::index');
$routes->post('images/upload', 'Images::upload');
$routes->delete('images/(:num)', 'Images::delete/$1');
$routes->get('images/fetch', 'Images::fetch');
$routes->get('images/get/(:num)', 'Images::get/$1'); // Get a single image
$routes->post('images/update', 'Images::update');    // Update an image