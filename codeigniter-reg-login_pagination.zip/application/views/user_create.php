<h2>Add New User</h2>
<!-- Display the error message if the email already exists -->
<?php if (isset($error)) : ?>
    <p style="color:red;"><?php echo $error; ?></p>
<?php endif; ?>
<form method="post" action="">
    <label>Name:</label>
    <input type="text" name="name" required>
    <br>
    <label>Email:</label>
    <input type="email" name="email" required>
    <br>
    <input type="submit" name="submit" value="Save">
</form>
