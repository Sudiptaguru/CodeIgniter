<h2><?php echo 'Add New User'; ?></h2>

<?php if (isset($error)) : ?>
    <p style="color:red;"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="<?php echo isset($user) && isset($user->id) ? base_url('user/update/' . $user->id) : base_url('user/store'); ?>">
    <div>
        <label>Name:</label>
        <input type="text" name="name" value="">
        <!-- Validation error for name -->
        <?php echo form_error('name', '<p style="color:red;">', '</p>'); ?>
    </div>
    
    <div>
        <label>Email:</label>
        <input type="email" name="email" value="">
        <!-- Validation error for email -->
        <?php echo form_error('email', '<p style="color:red;">', '</p>'); ?>
    </div>

    <div>
        <input type="submit" name="submit" value="<?php echo isset($user) && isset($user->id) ? 'Update' : 'Save'; ?>">
    </div>
</form>
