<h2>Edit User</h2>

<?php if (isset($error)) : ?>
    <p style="color:red;"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="<?php echo base_url('user/update/' . $user->user_id); ?>">
    <div>
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo set_value('name', isset($user) ? $user->name : ''); ?>">
        <!-- Validation error for name -->
        <?php echo form_error('name', '<p style="color:red;">', '</p>'); ?>
    </div>
    
    <div>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo set_value('email', isset($user) ? $user->email : ''); ?>">
        <!-- Validation error for email -->
        <?php echo form_error('email', '<p style="color:red;">', '</p>'); ?>
    </div>

    <div>
        <input type="submit" name="submit" value="Update">
    </div>
</form>
