<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<style>
	.pagination-container {
		text-align: left; /* Align pagination links to the left */
	}

	.pagination-container .pagination {
		margin: 0; /* Remove margin if needed */
	}
</style>
<h2>User List</h2>
<a href="<?php echo base_url('user/create'); ?>">Add New User</a>

<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user->user_id; ?></td>
                <td><?php echo $user->name; ?></td>
                <td><?php echo $user->email; ?></td>
                <td>
                    <a href="<?php echo base_url('user/edit/'.$user->user_id); ?>">Edit</a>
                    <a href="<?php echo base_url('user/delete/'.$user->user_id); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div>
<?php echo $pagination_links; ?>
</div>
