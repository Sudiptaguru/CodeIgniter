<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    
    // Fetch all users
    public function get_paginated_users($limit, $offset) {
        $this->db->limit($limit, $offset);
        $query = $this->db->get('users'); // Assuming the table name is 'users'
        return $query->result();
    }

    // Get the total number of users
    public function get_total_users() {
        return $this->db->count_all('users'); // Total count of users
    }

    // Insert a new user
    public function insert_user($data) {
        return $this->db->insert('users', $data);
    }

    // Get a specific user by ID
    public function get_user_by_id($id) {
        $query = $this->db->get_where('users', array('user_id ' => $id));
        return $query->row();
    }

    // Update user information
    public function update_user($id, $data) {
        $this->db->where('user_id ', $id);
        return $this->db->update('users', $data);
    }

    // Delete a user
    public function delete_user($id) {
        $this->db->where('user_id ', $id);
        return $this->db->delete('users');
    }

	public function get_user_by_email($email) {
        $query = $this->db->get_where('users', array('email' => $email));
        return $query->row();
    }

    // Fetch user by email excluding a specific ID (for update)
    public function get_user_by_email_excluding_id($email, $id) {
        $this->db->where('email', $email);
        $this->db->where('user_id !=', $id);
        $query = $this->db->get('users');
        return $query->row();
    }
	public function check_email($email, $id)
	{
		// Check if the email already exists in the database, except for the current user
		$this->db->where('email', $email);
		$this->db->where('id !=', $id); // Exclude the current user's ID
		$query = $this->db->get('users'); // 'users' is the table name

		if ($query->num_rows() > 0) {
			// If email exists, set the error message
			$this->form_validation->set_message('check_email', 'The {field} field must contain a unique value.');
			return FALSE;
		} else {
			return TRUE;
		}
	}
}
