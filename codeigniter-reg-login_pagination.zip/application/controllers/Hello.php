<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hello extends MY_Controller {
    public function __construct() {
        parent::__construct();
        if ( !class_exists('session') ) {
            $this->load->library('session');
        }
    }
    public function index() {
        $this->load->view('header');
        $this->load->view('hello');
        $this->load->view('footer');
    }

}
