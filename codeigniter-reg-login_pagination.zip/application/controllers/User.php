<?php
class User extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library(['form_validation', 'session', 'pagination']);
		$this->load->database();
		$this->load->model('User_model');
	}

	// Display all users
	public function index()
	{
		$config = array();
		$config['base_url'] = base_url('user/index');
		$config['total_rows'] = $this->User_model->get_total_users();
		$config['per_page'] = 5;
		$config['uri_segment'] = 3;

		// Bootstrap 4 Pagination settings
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li class="page-item">';
		$config['first_tag_close'] = '</li>';
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li class="page-item">';
		$config['last_tag_close'] = '</li>';
		$config['next_link'] = '&raquo;';
		$config['next_tag_open'] = '<li class="page-item">';
		$config['next_tag_close'] = '</li>';
		$config['prev_link'] = '&laquo;';
		$config['prev_tag_open'] = '<li class="page-item">';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li class="page-item">';
		$config['num_tag_close'] = '</li>';
		$config['attributes'] = array('class' => 'page-link');

		$this->pagination->initialize($config);
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

		$data['users'] = $this->User_model->get_paginated_users($config['per_page'], $page);
		$data['pagination_links'] = $this->pagination->create_links();

		$this->load->view('user_list', $data);
	}

	// Show the form for creating a new user
	public function create()
	{
		$this->load->view('user_form');
	}

	// Store a newly created user in the database
	public function store()
	{
		// Set validation rules
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]', [
			'is_unique' => 'This email is already registered.'
		]);

		// Run the validation
		if ($this->form_validation->run() == FALSE) {
			// Validation failed, load the form again with validation errors
			$this->load->view('user_form');
		} else {
			// Validation passed, proceed with user creation
			$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email')
			);
			$this->User_model->insert_user($data);
			redirect('user');
		}
	}

	// Show the form for editing the specified user
	public function edit($id)
	{
		$data['user'] = $this->User_model->get_user_by_id($id);
		$this->load->view('user_form', $data);
	}

	// Update the specified user in the database
	public function update($id)
	{
		// Set validation rules
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_check_email[' . $id . ']');

		// Run the validation
		if ($this->form_validation->run() == FALSE) {
			// Validation failed, reload the form with errors
			$data['user'] = $this->User_model->get_user_by_id($id);
			$this->load->view('user_form', $data);
		} else {
			// Validation passed, update the user
			$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email')
			);
			$this->User_model->update_user($id, $data);
			redirect('user');
		}
	}

	// Custom callback to check if email is unique
	public function check_email($email, $id)
	{
		$user = $this->User_model->get_user_by_email($email);

		if ($user && $user->user_id != $id) {
			$this->form_validation->set_message('check_email', 'The email is already taken by another user.');
			return FALSE;
		}
		return TRUE;
	}

	// Delete the specified user from the database
	public function delete($id)
	{
		$this->User_model->delete_user($id);
		redirect('user');
	}
}
