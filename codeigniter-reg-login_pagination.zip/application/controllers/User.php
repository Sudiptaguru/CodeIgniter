<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		//load the required helpers and libraries
		$this->load->helper('url');
		$this->load->library(['form_validation', 'session', 'pagination']);
		$this->load->database();

		//load our Register model here
		$this->load->model('User_model');
	}

	// Display all users
	public function index() {
		// Pagination configuration
		$config = array();
		$config['base_url'] = base_url('user/index');
		$config['total_rows'] = $this->User_model->get_total_users(); // Total number of users
		$config['per_page'] = 5;
		$config['uri_segment'] = 3;
	
		// Bootstrap 4 Pagination settings
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
	
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li class="page-item">';
		$config['first_tag_close'] = '</li>';
	
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li class="page-item">';
		$config['last_tag_close'] = '</li>';
	
		$config['next_link'] = '&raquo;';
		$config['next_tag_open'] = '<li class="page-item">';
		$config['next_tag_close'] = '</li>';
	
		$config['prev_link'] = '&laquo;';
		$config['prev_tag_open'] = '<li class="page-item">';
		$config['prev_tag_close'] = '</li>';
	
		$config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close'] = '</a></li>';
	
		$config['num_tag_open'] = '<li class="page-item">';
		$config['num_tag_close'] = '</li>';
	
		$config['attributes'] = array('class' => 'page-link');
	
		// Initialize pagination
		$this->pagination->initialize($config);
	
		// Determine the page offset
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
	
		// Fetch users for the current page
		$data['users'] = $this->User_model->get_paginated_users($config['per_page'], $page);
		
		// Pass the pagination links to the view
		$data['pagination_links'] = $this->pagination->create_links();
	
		// Load the view
		$this->load->view('user_list', $data);
	}

	// Add a new user
	public function create()
	{
		if ($this->input->post('submit')) {
			$email = $this->input->post('email');

			// Check if the email already exists
			$existing_user = $this->User_model->get_user_by_email($email);

			if ($existing_user) {
				// Email already exists, handle the error
				$data['error'] = 'Email already exists!';
				$this->load->view('user_create', $data);
			} else {
				// Insert the new user if email is unique
				$data = array(
					'name' => $this->input->post('name'),
					'email' => $email
				);
				$this->User_model->insert_user($data);
				redirect('user');
			}
		} else {
			$this->load->view('user_create');
		}
	}

	// Edit an existing user
	public function edit($id)
	{
		if ($this->input->post('submit')) {
			$email = $this->input->post('email');

			// Fetch the user by email but exclude the current user ID from the check
			$existing_user = $this->User_model->get_user_by_email_excluding_id($email, $id);

			if ($existing_user) {
				// Email already exists for another user, handle the error
				$data['error'] = 'Email already exists!';
				$data['user'] = $this->User_model->get_user_by_id($id);
				$this->load->view('user_edit', $data);
			} else {
				// Update the user if email is unique or unchanged
				$data = array(
					'name' => $this->input->post('name'),
					'email' => $email
				);
				$this->User_model->update_user($id, $data);
				redirect('user');
			}
		} else {
			$data['user'] = $this->User_model->get_user_by_id($id);
			$this->load->view('user_edit', $data);
		}
	}

	// Delete a user
	public function delete($id)
	{
		$this->User_model->delete_user($id);
		redirect('user');
	}
}
