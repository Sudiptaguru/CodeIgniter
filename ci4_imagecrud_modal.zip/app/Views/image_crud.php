<!-- app/Views/image_crud.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image CRUD</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .error-message {
            color: red;
            font-size: 0.9em;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 100px;
        }

        #imagePreview {
            max-width: 200px;
            display: block;
            margin-top: 10px;
        }

        .no-image {
            width: 200px;
            height: 150px;
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            text-align: center;
            line-height: 150px;
            color: #aaa;
        }
    </style>
</head>
<body>
    <h1>Image CRUD</h1>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#imageModal" onclick="openModal()">Add Image</button>

    <!-- Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Add/Edit Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="imageForm">
                        <input type="hidden" name="id" id="imageId"> <!-- Hidden field to store image ID for editing -->
                        <div class="form-group">
                            <label for="imageTitle">Title</label>
                            <input type="text" class="form-control" name="title" id="imageTitle" placeholder="Title">
                            <div id="titleError" class="error-message"></div> <!-- Placeholder for title errors -->
                        </div>
                        <div class="form-group">
                            <label for="imageFile">Image</label>
                            <input type="file" class="form-control-file" name="image" id="imageFile">
                            <div id="imageError" class="error-message"></div> <!-- Placeholder for image errors -->
                            <img id="imagePreview" src="" alt="Image preview" style="display: none;"> <!-- Image preview element -->
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" id="resetButton">Reset</button> <!-- Reset button -->
                    </form>
                </div>
            </div>
        </div>
    </div>

    <h2>Images</h2>
    <table id="imageTable" class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="imageList"></tbody>
    </table>

    <script>
        $(document).ready(function() {
            function fetchImages() {
                $.get('/images/fetch', function(data) {
                    $('#imageList').empty();
                    data.forEach(function(image) {
                        let imagePreview = image.file_name 
                            ? `<img src="/uploads/${image.file_name}" alt="${image.title}">` 
                            : `<div class="no-image">No Image</div>`;
                        
                        $('#imageList').append(`
                            <tr>
                                <td>${image.title}</td>
                                <td>${imagePreview}</td>
                                <td>
                                    <button class="btn btn-info btn-sm" onclick="editImage(${image.id})">Edit</button>
                                    <button class="btn btn-danger btn-sm" onclick="deleteImage(${image.id})">Delete</button>
                                </td>
                            </tr>
                        `);
                    });
                });
            }

            fetchImages();

            $('#imageForm').submit(function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                var id = $('#imageId').val(); // Get the ID from the hidden field
                var url = id ? '/images/update' : '/images/upload'; // Use update URL if ID is present

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                            $('#imageForm')[0].reset(); // Reset the form
                            $('#imageId').val(''); // Clear the ID
                            $('#imagePreview').attr('src', '').hide(); // Clear and hide image preview
                            $('.error-message').empty(); // Clear validation errors
                            $('#imageModal').modal('hide'); // Close the modal
                        } else {
                            // Clear previous errors
                            $('.error-message').empty();
                            // Show validation errors
                            if (response.errors) {
                                if (response.errors.title) {
                                    $('#titleError').text(response.errors.title);
                                }
                                if (response.errors.image) {
                                    $('#imageError').text(response.errors.image);
                                }
                            } else {
                                alert(response.message || 'Operation failed');
                            }
                        }
                    }
                });
            });

            $('#imageFile').change(function() {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#imagePreview').attr('src', e.target.result).show();
                    };
                    reader.readAsDataURL(file);
                } else {
                    $('#imagePreview').attr('src', '').hide();
                }
            });

            $('#resetButton').click(function() {
                $('#imageForm')[0].reset(); // Reset the form fields
                $('#imageId').val(''); // Clear the ID
                $('#imagePreview').attr('src', '').hide(); // Clear and hide image preview
                $('.error-message').empty(); // Clear validation errors
            });

            window.deleteImage = function(id) {
                $.ajax({
                    url: `/images/${id}`,
                    type: 'DELETE',
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                        } else {
                            alert('Delete failed');
                        }
                    }
                });
            }

            window.editImage = function(id) {
                $.get(`/images/get/${id}`, function(data) {
                    $('#imageId').val(data.id);
                    $('#imageTitle').val(data.title);
                    // Update preview with current image or hide it if there's no image
                    if (data.file_name) {
                        $('#imagePreview').attr('src', `/uploads/${data.file_name}`).show();
                    } else {
                        $('#imagePreview').attr('src', '').hide();
                    }
                    $('#imageModal').modal('show'); // Show the modal for editing
                    $('.error-message').empty(); // Clear validation errors
                });
            }

            window.openModal = function() {
                $('#imageModal').modal('show'); // Show the modal for adding
                $('#imageForm')[0].reset(); // Reset the form fields
                $('#imageId').val(''); // Clear the ID
                $('#imagePreview').attr('src', '').hide(); // Clear and hide image preview
                $('.error-message').empty(); // Clear validation errors
            }
        });
    </script>
</body>
</html>