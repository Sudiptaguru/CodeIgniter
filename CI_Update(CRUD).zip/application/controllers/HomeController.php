<?php
require APPPATH.'libraries/REST_Controller.php';
class HomeController extends CI_Controller{
    function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        $this->load->model('HomeModel');
    } 
    
    public function index(){
        $this->load->view('addUser');
    }

    function registerUser(){
        $data = $insertArray = array();
            $insertArray = array(
                'name'=> $this->input->post('user'),
                'email'=> $this->input->post('email'),
                'password'=>md5($this->input->post('password')),
                'address'=>$this->input->post('address'),
                'phone'=>$this->input->post('phone'),
            );
            

            

        // $this->load->model('HomeModel');
        // $insert = $this->HomeModel->insert($insertArray);
            // if($insert){ 
                    // $this->session->set_userdata('success_msg', 'Your account registration has been successful. Please login to your account.'); 
            //     }
        $data['user'] = $insertArray;

        $status = $this->HomeModel->register($insertArray);

            if($status == true){
                $data['message'] = "
                 <font color='green'>
                 Successfully Data Inserted </font>";
            }else{
                $data['message'] = "
                <font color='red'>
                Please Try Again,Data is not inserted </font>";
            }
            $this->load->view('addUser',$data);
        redirect('HomeController/viewUser');
    }

    function viewUser(){
        $this->load->model('HomeModel');
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        $this->load->view('viewUsers',$data);
    }
    
    function deleteUser($userId){
        $this->load->model('HomeModel');
        $status = $this->HomeModel->delete_user($userId);

        if($status == true){
            $data['message'] = "<font color='green'>Successfully Deleted</font>";
        }else{
            $data['message'] = "<font color='red'> Not deleted,Please Try Again </font>";
        }
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        $this->load->view('viewUsers',$data);
    }

    function editUser($userId){
       
        $this->load->model('HomeModel');
        $data['user'] = $this->HomeModel->getSingleUser($userId);
        $this->load->view('updateForm',$data);
    }

    function updateUser(){
        $this->load->model('HomeModel');
        
            $setArray = [
                'name' => $this->input->post('name'),
                'phone' => $this->input->post('phone'),
                'address' => $this->input->post('add'),
                // 'otp' => rand(1111,9999)
                 
            ];
            $userId = $this->input->post('userId');
            $status = $this->HomeModel->update_User($setArray,$userId);
            
            if($status == true){
                $data['message'] = "<font color='green'>
                Successfully Updated </font>";
            }else{
                $data['message'] = "<font color='red'> Not upadted,Please Try Again </font>";
            }
            $data['userinfo'] = $this->HomeModel->getAllUsers();
            $this->load->view('viewUsers',$data);
        
    }
}

?>