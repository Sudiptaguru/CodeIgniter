<?php
class HelloController extends CI_Controller 
{
public function __construct()
{
	//call CodeIgniter's default Constructor
	parent::__construct();
	
	//load database libray manually
	$this->load->database();
	
	//load Model
	$this->load->model('HelloModel');
}

	public function savedata()
	{
		//load registration view form
		$this->load->view('HelloView');
	
		//Check submit button 
		if($this->input->post('submitbtn'))
		{
		//get form's data and store in local varable
		$name=$this->input->post('user');
		$email=$this->input->post('email');
		$pass=$this->input->post('password');
		$address=$this->input->post('add'); 
		$phone=$this->input->post('phone');
		
//call saverecords method of Hello_Model and pass variables as parameter
		$this->HelloModel->saverecords($name,$email,$pass,$address,$phone);		
		echo "<h3>Records Inserted Successfully</h3>";
		}
		
	}
}
?>