<?php

class HomeModel extends CI_Model{
    function __construct() { 
        // Set table name 
        $this->table = 'reg'; 
    }
    function register($insertArray){
        
        if($this->db->insert('reg',$insertArray)){
            return true;
        }else{
            return false;
        }
    }
    // public function insert($data = array()) { 
    //     if(!empty($data)){ 
    //         // Add created and modified date if not included 
    //         if(!array_key_exists("created", $data)){ 
    //             $data['created'] = date("Y-m-d H:i:s"); 
    //             // $data['created'] = rand(11,99); 
    //         } 
    //         // if(!array_key_exists("modified", $data)){ 
    //         //     $data['modified'] = date("Y-m-d H:i:s"); 
    //         // } 
             
    //         // Insert member data 
    //         $insert = $this->db->insert($this->table, $data); 
             
    //         // Return the status 
    //         // return $insert?$this->db->insert_id():false; 
    //     } 
    //     return false; 
    // }

    function getAllUsers(){
       
        $response = $this->db->get('reg');
        // --fetch user data--
        $data = $response->result_array();   
        return $data;
    }
    
    function delete_user($userId){
        
        $this->db->where('id',$userId);
        if($this->db->delete('reg')){
            return true;
        }else{
            return false;
        }
    }

    function getSingleUser($userId){
        
        $this->db->where('id',$userId);
        $data = $this->db->get('reg');
        return $data->row_array();
    }

    function update_User($setArray, $userId){
        $this->db->set($setArray);
        $this->db->where('id',$userId);
        if($this->db->update('reg')){
            return true;
        }else{
            return false;
        }
    }
    // public function editProfile($userId,$data){
    //     $this->db->where('id',$userId);
    //     $this->db->update('userId',$data);
    //     return true;
    // }
    // public function get_user_info($userid){
    //     $this->db->where('id',$userid);
    //     $get_data=$this->db->get('user');
    //     return $getdata->row();
    // }
    public function get_count() 
    {
        return $this->db->count_all("reg");
    }

    public function get_students($limit, $start) 
    {
        $this->db->limit($limit, $start);
        $query = $this->db->get("reg");
        return $query->result();
    }
    // public function get_count() 
    // {
    //     return $this->db->count_all("reg");
    // }

    // public function get_students($limit, $start) 
    // {
    //     $this->db->limit($limit, $start);
    //     $query = $this->db->get("reg");
    //     return $query->result();
    // }
}

?>