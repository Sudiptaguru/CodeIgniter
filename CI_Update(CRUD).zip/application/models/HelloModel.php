<?php
class HelloModel extends CI_Model 
{
	function saverecords($name,$email,$pass,$address,$phone)
	{
	$query="INSERT INTO reg VALUES('','$name','$email','$pass','$address','$phone')";
	$this->db->query($query);
	}
}
?>