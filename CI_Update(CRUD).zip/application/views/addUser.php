<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>CRUD Operation</title>
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">


    </head>
    <body>
        <div class="container">
            <div class="row jumbotron">
               <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url('view'); ?>">View User</a>
                </div>
            
            <div class="row">
                <div class="alert alert-dismissable alert-success" style="display: none">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Data inserted successfully</strong>.
                </div>
                
                <div class="alert alert-dismissable alert-danger"  style="display: none">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Sorry something went wrong</strong>
                </div>
            </div>
            <div class="row jumbotron">
    <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
    <form action="<?php echo base_url('registration'); ?>" method="POST">
    <td>Name :</td> 
        <td><input type="text" name="user" required=""></td>
        <br><br>
        <td>Email-ID :</td> 
        <td><input type="text" name="email" required=""></td>
        <br><br>
    <td>Password :</td> 
        <td><input type="password" name="password" required="" ></td>
        <br><br>
    <td>Address :</td> 
        <td><input type="text" name="address" required="" ></td>
        <br><br>
    <td>Phone :</td> 
        <td><input type="number" name="phone" required="" ></td>
        <br><br>
        <input type="submit" name="submitbtn" value="INSERT">
        <input type="reset" name="resetbtn" value="REFRESH">
        <br>
    </form>
</div>
            
            <div class="row">
                <div class="alert alert-dismissable alert-success" style="display: none">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Data inserted successfully</strong>.
                </div>
                
                <div class="alert alert-dismissable alert-danger"  style="display: none">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Sorry something went wrong</strong>
                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    </body>
</html>