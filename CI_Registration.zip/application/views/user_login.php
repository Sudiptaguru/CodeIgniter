<div class="container">
    <h2>Login to Your Account</h2>
	
    <!-- Status message -->
    <?php  
        if(!empty($success_msg)){ 
            echo '<p class="status-msg success">'.$success_msg.'</p>'; 
        }elseif(!empty($error_msg)){ 
            echo '<p class="status-msg error">'.$error_msg.'</p>'; 
        } 
    ?> 
	
    <!-- Login form -->
    <div class="regisFrm">
        <form action="<?php echo base_url('user_controller/login_check') ?>" method="POST">
        
            <div class="form-group">
            <label> Username: </label>
                <input type="email" name="email" placeholder="EMAIL">
                <span style='color:red'><?php echo form_error('email'); ?>
            </span>
            </div> 
            <br> 
        
            <div class="form-group">
            <label> Password: </label>
                <input type="password" name="password" placeholder="PASSWORD">
               <span style='color:red'><?php echo form_error('password'); ?>
            </span>
            </div>
           <br>
            <div class="send-button">
                <input type="submit" name="loginSubmit" value="LOGIN">
            </div>
        </form>

        <p>Don't have an account? <a href="<?php echo base_url('index.php/user_controller/registration'); ?>">Register</a></p>
    </div>
</div>