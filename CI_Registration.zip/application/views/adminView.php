
<style type="text/css">
       .green1
    {
        color: #4CAF50;
        
    }
    .red1
    {
         color: red; 
    }
    </style>
<div class="container">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <a href="<?php echo base_url('departmentAdd'); ?>">
                  <p>Add New</p>
                </a>
            <h1>View Automobile</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>


 <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
             
    <div class="card">
              <div class="card-header">
                <h3 class="card-title"></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- <table id="myTable" class="display table" width="100%" > -->
                <table id="myTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>SL No.</th>
                    <th>Automobile Name</th>
                    <th>Automobile Type</th>
                    <th>Brand Select</th>
                    <th>Automobile Image</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php

                    $i=1;
                    foreach ($test as $row)
                     {
                       $id=$row->id;

                       if($row->status==1)
                           {
                             $status_color='green1';
                             // $status='green1';
                           }
                           else
                           {
                            $status_color='red1'; 
                           }
                  ?>
                  
                  <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $row->automobile_name;?></td>
                    <td><?php echo $row->automobile_type;?> </td>
                    <td><?php echo $row->brand_name;?></td>
                    <td>
                      <img style="width: 70px;height: 70px; border-radius: 50%;" src="<?php echo base_url('uploads/'.$row->profile_pic); ?>" id="image_disp" class="img-thumbnail">
                    </td>
                    <td>

                      <?php 
                        echo ($row->status==1)?'Active':'Inactive';
                      ?>
                      
               <a href="javascript:void(0)" onclick="ChangeStatus(<?php echo $id; ?>,<?php if($row->status==1){ echo "0"; }else{ echo "1"; } ?>);" style="font-size: 40px;line-height: 0; background-color: "><br><i class="fa fa-toggle-on <?php echo $status_color; ?>" aria-hidden="true"></i> 
                </a> 
              </td>
                    <td><a href="<?php echo base_url('departmentView/edit/'.$id);?>" ><i class="fas fa-edit"></i></a> &nbsp; <a  href="<?php echo base_url('departmentView/delete_row/'.$id);?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fas fa-trash-alt" style="color: red;"></i></a></td>
                  </tr>
                  <?php 
                    $i++;
                    }
                  ?>
                
                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 </div>
 <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
  <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
function ChangeStatus(id,val)
   {
   var re_confirm = confirm("Are you sure ?");
   if(re_confirm){
       $("#cstm-opcty").css('opacity','0.5');
   $.ajax({
   url: "<?php echo base_url('departmentView/edit_status');?>",
   method:'POST',
   data:{id:id,status:val},
   success: function(data)
   {
    // alert(data);
       $("#cstm-opcty").css('opacity','1');
      if(data==1)
      {
       location.reload();
      }

   }
   });
   }
   }



 </script> 
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">