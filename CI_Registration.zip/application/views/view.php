<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<!-- <h1>Name of the worker is <?php echo $n; ?></h1> -->
<!-- <h1>Welcome</h1> -->
<h3>
		<!-- <?php $name=$this->session->userdata('first_name'); ?>
		<?php $email=$this->session->userdata('email'); ?>
		First Name:<?php echo $name; ?><br>
			Email:<?php echo $email; ?><br>
			<a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a> -->
</h3>
</body>
</html>

   