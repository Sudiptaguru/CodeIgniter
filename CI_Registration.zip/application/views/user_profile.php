<?php
$id=$profile[0]->id;
//print_r($_SESSION);
//session_destroy();
?>

<div class="container">
    <!-- <h2>Welcome!</h2> -->

    <div class="regisFrm">

        Hello &nbsp;<b><?php echo $profile[0]->first_name; ?></b><br>
        <b>Name:</b><?php echo $profile[0]->first_name.' '.$profile[0]->last_name; ?><br>
        <b>Email:</b><?php echo $profile[0]->email; ?><br>
        <b>Status:</b><?php 
                        echo ($profile[0]->status==1)?'Active':'Inactive';
                      ?><a href="javascript:void(0)" onclick="ChangeStatus(<?php echo $id; ?>,<?php if($profile[0]->status==1){ echo "0"; }else{ echo "1"; } ?>);"><button>click here</button>
                </a><br>
        <a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a>

       <!--  <p><b>File: </b> <img src="<?php echo $user['file']; ?>"></p> -->
    </div>
</div>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<!-- <h1>Name of the worker is <?php echo $n; ?></h1> -->
<!-- <h1>Welcome</h1>
<h3>
		<?php $name=$this->session->userdata('name'); ?>
		<?php $email=$this->session->userdata('email'); ?>
		Name:<?php echo $name; ?><br>
			Email:<?php echo $email; ?><br>
			<a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a>
</h3> -->
</body>
</html>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
  <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
function ChangeStatus(id,val)
   {
   var re_confirm = confirm("Are you sure ?");
   if(re_confirm){
       $("#cstm-opcty").css('opacity','0.5');
   $.ajax({
   url: "<?php echo base_url('adminController/edit_status');?>",
   method:'POST',
   data:{id:id,status:val},
   success: function(data)
   {
    // alert(data);
       $("#cstm-opcty").css('opacity','1');
      if(data==1)
      {
       location.reload();
      }

   }
   });
   }
   }



 </script> 
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
   