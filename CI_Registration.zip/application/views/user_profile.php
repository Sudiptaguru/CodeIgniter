<?php

//print_r($_SESSION);
//session_destroy();
?>

<div class="container">
    <!-- <h2>Welcome!</h2> -->

    <div class="regisFrm">

        Hello &nbsp;<b><?php echo $profile[0]->first_name; ?></b><br>
        <b>Name:</b><?php echo $profile[0]->first_name.' '.$profile[0]->last_name; ?><br>
        <b>Email:</b><?php echo $profile[0]->email; ?><br>
        
        <a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a>

       <!--  <p><b>File: </b> <img src="<?php echo $user['file']; ?>"></p> -->
    </div>
</div>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<!-- <h1>Name of the worker is <?php echo $n; ?></h1> -->
<!-- <h1>Welcome</h1>
<h3>
		<?php $name=$this->session->userdata('name'); ?>
		<?php $email=$this->session->userdata('email'); ?>
		Name:<?php echo $name; ?><br>
			Email:<?php echo $email; ?><br>
			<a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a>
</h3> -->
</body>
</html>

   