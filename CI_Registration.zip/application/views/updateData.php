
 <div class="container">
 
 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Automobile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add User</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Create User</h3>
          </div>
          <!-- /.card-header -->
          <form action="<?php echo base_url('departmentView/update_user'); ?>" method="post"  enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $this->uri->segment(3); ?>">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Automobile Name</label>
                    <input type="" class="form-control" id="" name="automobile_name" placeholder="Enter Automobile Name" value="<?php echo $user[0]->automobile_name; ?>">
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                   <label for="">Automobile Type</label>
                    <input type="" class="form-control" id="" name="automobile_type" placeholder="Enter Automobile Type" value="<?php echo $user[0]->automobile_type; ?>">
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label>Brand Select</label>
                  <select class="form-control" name="brand_name">
                    <option value="Select">Select</option>
                    <option value="AUDI">AUDI</option>
                    <option value="BMW">BMW</option>
                    <option value="VOLVO">VOLVO</option> 
                  </select>
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="profile_pic">Profile Picture</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <!-- <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic" onchange ="show_pictures(this.value)"> -->
                        <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic"  onchange="readURL(this);" value="">
                        <label class="custom-file-label" for="profile_pic">Choose file</label>
                      </div>
                    </div>
                  </div>
              </div>
                        <?php if($user[0]->profile_pic!='') {?>
                        <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('uploads/'.$user[0]->profile_pic); ?>" id="image_disp" class="img-thumbnail">
                <?php } else {?>
                  <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('asset/banner/180.png'); ?>" id="image_disp" class="img-thumbnail">
                <?php } ?>
            </div>
            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
</div>        
</section>
</div> 


<!-------------- image showing just after uploading------------------- -->

<script type="text/javascript">
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#image_disp')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>