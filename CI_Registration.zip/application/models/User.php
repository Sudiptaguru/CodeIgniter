<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class User extends CI_Model{ 
    function __construct() { 
        // Set table name 
        $this->table = 'users'; 
    }      
   
    /* 
     * Insert user data into the database 
     * @param $data data to be inserted 
     */ 
    public function insert($data = array()) { 
        if(!empty($data)){ 
            // Add created and modified date if not included 
            if(!array_key_exists("created", $data)){ 
                $data['created'] = date("Y-m-d H:i:s"); 
            } 
            // if(!array_key_exists("modified", $data)){ 
            //     $data['modified'] = date("Y-m-d H:i:s"); 
            // } 
             
            // Insert member data 
            $insert = $this->db->insert($this->table, $data); 
             
            // Return the status 
            return $insert?$this->db->insert_id():false; 
        } 
        return false; 
    } 
    public function get_data($id=0)
    {
        if($id==0)
        {
            $query = $this->db->get('users')->result();
            return $query;
        }
        else
        {
            $this->db->where('id',$id);
            $query = $this->db->get('users')->result();
            return $query;
        }
        
    }


    public function upddata($data,$id)       
    {
        extract($data); 
        $this->db->where('id', $id);
        // $this->db->update($table_name, array('full_name' => $full_name, 'email' =>$email, 'mobile' =>$mobile, 'status' =>$status, 'user_role' =>$user_role, 'profile_pic'=>$profile_pic));
        $this->db->update('users', $data);
        return true;
    }

    public function delete_data($id)
    {
        $this -> db -> where('id', $id);
        $this -> db -> delete('users');
    }

    public function update_status($status,$id)
    {
        $this->db->query("UPDATE users SET status = '$status' WHERE id = '$id' ");
        return true;
    }

    function getAllUsers(){
        $query=$this->db->query("select * from users");
        return $query->result();
       
        // $response = $this->db->get('users');
        // // --fetch user data--
        // $data = $response->result_array();   
        // return $data;
    }
    public function login( $data ) {

        $condition = "email= '".$data['email']."' AND password= '".$data['password']."' AND status='1'  ";
        $this->db->select( '*' );
        $this->db->from( 'users' );
        $this->db->where( $condition );
        $query = $this->db->get();
        if ( $query->num_rows() == 1 ) {
            return $query->result();
        } else {
            return false;
        }

    }
    function login_check($data)
    {
        $condition = "email= '".$data['email']."' AND password= '".$data['password']."' ";
        $this->db->select( '*' );
        $this->db->from( 'users' );
        $this->db->where( $condition );
        $query = $this->db->get();
        if ( $query->num_rows() == 1 ) {
            return $query->result();
        } else {
            return false;
        }
        /*$email= $data['email'];
        $password= $data['password'];
        $this->db->where('email',$email);
        $this->db->where('password',$password);
        $qry=$this->db->get($this->table);
        $row= $qry->num_rows();
        return $row;*/
    }
    function get_user($user_id)
    {
        $condition = "id= '".$user_id."' ";
        $this->db->select( '*' );
        $this->db->from( 'users' );
        $this->db->where( $condition );
        $query = $this->db->get()->result();
        return $query;
    }
    // public function checkData($details){
    //     $row=$this->db->get_where("users",$details);
    //     return $row->result();
    // }
    
     // function getRows($params = array()){ 
     //    $this->db->select('*'); 
     //    $this->db->from($this->table); 
         
     //    if(array_key_exists("conditions", $params)){ 
     //        foreach($params['conditions'] as $key => $val){ 
     //            $this->db->where($key, $val); 
     //        } 
     //    } 
         
     //    if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){ 
     //        $result = $this->db->count_all_results(); 
     //    }else{ 
     //        if(array_key_exists("id", $params) || $params['returnType'] == 'single'){ 
     //            if(!empty($params['id'])){ 
     //                $this->db->where('id', $params['id']); 
     //            } 
     //            $query = $this->db->get(); 
     //            $result = $query->row_array(); 
     //        }else{ 
     //         $this->db->order_by('id', 'desc'); 
                // if(array_key_exists("start",$params) && array_key_exists("limit",$params)){ 
                //     $this->db->limit($params['limit'],$params['start']); 
                // }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){ 
                //     $this->db->limit($params['limit']); 
                // } 
                 
    //             $query = $this->db->get(); 
    //             $result = ($query->num_rows() > 0)?$query->result_array():FALSE; 
    //         } 
    //     } 
         
    //     // Return fetched data 
    //     return $result; 
    // } 
}