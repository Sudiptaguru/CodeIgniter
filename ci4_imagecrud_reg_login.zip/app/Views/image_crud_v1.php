<!-- app/Views/image_crud.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image CRUD</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .error-message {
            color: red;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <h1>Image CRUD</h1>
    <form id="imageForm">
        <input type="hidden" name="id" id="imageId"> <!-- Hidden field to store image ID for editing -->
        <div>
            <input type="text" name="title" id="imageTitle" placeholder="Title">
            <div id="titleError" class="error-message"></div> <!-- Placeholder for title errors -->
        </div>
        <div>
            <input type="file" name="image" id="imageFile">
            <div id="imageError" class="error-message"></div> <!-- Placeholder for image errors -->
        </div>
        <button type="submit">Submit</button>
    </form>

    <h2>Images</h2>
    <div id="imageList"></div>

    <script>
        $(document).ready(function() {
            function fetchImages() {
                $.get('/images/fetch', function(data) {
                    $('#imageList').empty();
                    data.forEach(function(image) {
                        $('#imageList').append(`
                            <div>
                                <h3>${image.title}</h3>
                                <img src="/uploads/${image.file_name}" width="100">
                                <button onclick="editImage(${image.id})">Edit</button>
                                <button onclick="deleteImage(${image.id})">Delete</button>
                            </div>
                        `);
                    });
                });
            }

            fetchImages();

            $('#imageForm').submit(function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                var id = $('#imageId').val(); // Get the ID from the hidden field
                var url = id ? '/images/update' : '/images/upload'; // Use update URL if ID is present

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                            $('#imageForm')[0].reset(); // Reset the form
                            $('#imageId').val(''); // Clear the ID
                            $('.error-message').empty(); // Clear validation errors
                        } else {
                            // Clear previous errors
                            $('.error-message').empty();
                            // Show validation errors
                            if (response.errors) {
                                if (response.errors.title) {
                                    $('#titleError').text(response.errors.title);
                                }
                                if (response.errors.image) {
                                    $('#imageError').text(response.errors.image);
                                }
                            } else {
                                alert(response.message || 'Operation failed');
                            }
                        }
                    }
                });
            });

            window.deleteImage = function(id) {
                $.ajax({
                    url: `/images/${id}`,
                    type: 'DELETE',
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                        } else {
                            alert('Delete failed');
                        }
                    }
                });
            }

            window.editImage = function(id) {
                $.get(`/images/get/${id}`, function(data) {
                    $('#imageId').val(data.id);
                    $('#imageTitle').val(data.title);
                    // No need to change the file input as file changes should be handled by user
                    $('.error-message').empty(); // Clear validation errors
                });
            }
        });
    </script>
</body>
</html>
