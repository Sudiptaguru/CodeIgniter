<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image CRUD - Edit</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .error-message {
            color: red;
            font-size: 0.9em;
        }

        #imagePreview {
            max-width: 200px;
            display: block;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <h1>Image CRUD - Edit</h1>
    <a href="/images" class="btn btn-secondary">Back to Index</a>

    <h2>Edit Image</h2>
    <form id="imageForm">
        <input type="hidden" name="id" id="imageId" value="<?= esc($image['id']) ?>">
        <div class="form-group">
            <label for="imageTitle">Title</label>
            <input type="text" class="form-control" name="title" id="imageTitle" placeholder="Title" value="<?= esc($image['title']) ?>">
            <div id="titleError" class="error-message"></div>
        </div>
        <div class="form-group">
            <label for="imageFile">Image</label>
            <input type="file" class="form-control-file" name="image" id="imageFile">
            <div id="imageError" class="error-message"></div>
            <img id="imagePreview" src="<?= base_url('uploads/' . esc($image['file_name'])) ?>" alt="Image preview" style="display: <?= $image['file_name'] ? 'block' : 'none' ?>;">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

    <script>
        $(document).ready(function () {
            $('#imageFile').change(function () {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#imagePreview').attr('src', e.target.result).show();
                    };
                    reader.readAsDataURL(file);
                } else {
                    $('#imagePreview').attr('src', '').hide();
                }
            });

            $('#imageForm').submit(function (e) {
                e.preventDefault();
                var formData = new FormData(this);

                $.ajax({
                    url: '/images/update',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (response) {
                        if (response.status === 'success') {
                            window.location.href = '/images'; // Redirect to the index page
                        } else {
                            $('.error-message').empty();
                            if (response.errors) {
                                if (response.errors.title) {
                                    $('#titleError').text(response.errors.title);
                                }
                                if (response.errors.image) {
                                    $('#imageError').text(response.errors.image);
                                }
                            } else {
                                alert(response.message || 'Operation failed');
                            }
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>
