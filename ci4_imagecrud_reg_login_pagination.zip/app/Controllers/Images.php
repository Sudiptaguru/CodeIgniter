<?php
namespace App\Controllers;

use App\Models\ImageModel;
use CodeIgniter\Controller;

class Images extends Controller
{
    public function index()
    {
        $imageModel = new ImageModel();

        // Define how many images per page
        $perPage = 5;

        // Get paginated images using paginate() method
        $data['images'] = $imageModel->paginate($perPage);

        // Load pagination links using pager instance
        $data['pager'] = $imageModel->pager;

        return view('index', $data);
    }

    public function add()
    {
        return view('add_edit');
    }

    public function edit($id)
    {
        $model = new ImageModel();
        $data['image'] = $model->find($id);
        if (!$data['image']) {
            return redirect()->to('/images');
        }
        
        // Debugging
        // var_dump($data['image']);
        // exit;

        return view('add_edit', $data);
    }

    public function upload()
    {
        $model = new ImageModel();
        $validation =  \Config\Services::validation();

        $file = $this->request->getFile('image');
        $title = $this->request->getPost('title');

        // Set validation rules
        $validation->setRules([
            'title' => 'required|min_length[3]',
            'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON(['status' => 'error', 'errors' => $validation->getErrors()]);
        }

        if ($file->isValid() && !$file->hasMoved()) {
            $fileName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads', $fileName);

            $model->save([
                'file_name' => $fileName,
                'title'     => $title,
                'uploaded_at' => date('Y-m-d H:i:s')
            ]);
            return $this->response->setJSON(['status' => 'success']);
        }
        return $this->response->setJSON(['status' => 'error']);
    }

    public function delete($id)
    {
        $model = new ImageModel();
        $image = $model->find($id);
        if ($image) {
            unlink(ROOTPATH . 'public/uploads/' . $image['file_name']);
            $model->delete($id);
            return $this->response->setJSON(['status' => 'success']);
        }
        return $this->response->setJSON(['status' => 'error']);
    }

    public function fetch()
    {
        $model = new ImageModel();
        $images = $model->findAll();
        return $this->response->setJSON($images);
    }

    public function get($id)
    {
        $model = new ImageModel();
        $image = $model->find($id);
        
        if (!$image) {
            return $this->response->setStatusCode(404)->setBody(json_encode(['status' => 'error', 'message' => 'Image not found']));
        }
        
        return $this->response->setJSON($image);
    }

    public function update()
    {
        $model = new ImageModel();
        $id = $this->request->getPost('id');
        $title = $this->request->getPost('title');
        
        $validation = \Config\Services::validation();

        // Set validation rules
        $validation->setRules([
            'title' => 'required|min_length[3]',
            'image' => 'max_size[image,1024]|is_image[image]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON(['status' => 'error', 'errors' => $validation->getErrors()]);
        }

        $image = $model->find($id);
        if (!$image) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Image not found']);
        }

        $file = $this->request->getFile('image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $fileName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads', $fileName);
            
            // Remove old file
            if ($image['file_name']) {
                unlink(ROOTPATH . 'public/uploads/' . $image['file_name']);
            }
            
            $image['file_name'] = $fileName;
        }

        $image['title'] = $title;
        $model->save($image);
        return $this->response->setJSON(['status' => 'success']);
    }
}
