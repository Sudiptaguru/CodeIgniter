<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image CRUD - Index</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 100px;
        }

        .no-image {
            width: 200px;
            height: 150px;
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            text-align: center;
            line-height: 150px;
            color: #aaa;
        }

        /* Custom Pagination Styles */
        .pagination {
            display: flex;
            justify-content: flex-start;
            /* Align pagination to the left */
            padding-left: 0;
            list-style: none;
            border-radius: 0.25rem;
        }

        .pagination li {
            display: inline;
        }

        .pagination li a,
        .pagination li span {
            position: relative;
            display: block;
            padding: 0.5rem 0.75rem;
            margin-left: 5px;
            /* Adjust margin between the pagination buttons */
            line-height: 1.25;
            color: #007bff;
            background-color: #fff;
            border: 1px solid #dee2e6;
            border-radius: 0.25rem;
            text-decoration: none;
        }

        .pagination li a:hover {
            background-color: #f8f9fa;
            /* Add hover effect */
            border-color: #ddd;
            color: #0056b3;
        }

        .pagination li.active a,
        .pagination li.active span {
            z-index: 1;
            color: #fff;
            background-color: #007bff;
            border-color: #007bff;
        }

        .pagination li.disabled span {
            color: #6c757d;
            background-color: #fff;
            border-color: #dee2e6;
            pointer-events: none;
            /* Disable the link */
        }
    </style>
</head>

<body>
    <h1>Image CRUD - Index</h1>
    <a href="/images/add" class="btn btn-primary mb-3">Add Image</a>

    <h2>Images</h2>
    <table id="imageTable" class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($images)): ?>
                <?php foreach ($images as $image): ?>
                    <tr>
                        <td><?= esc($image['title']) ?></td>
                        <td>
                            <?php if ($image['file_name']): ?>
                                <img src="/uploads/<?= esc($image['file_name']) ?>" alt="<?= esc($image['title']) ?>">
                            <?php else: ?>
                                <div class="no-image">No Image</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="/images/edit/<?= esc($image['id']) ?>" class="btn btn-info btn-sm">Edit</a>
                            <button class="btn btn-danger btn-sm" onclick="deleteImage(<?= $image['id'] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No images found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination Links -->
    <div>
        <nav aria-label="Page navigation">
            <?= $pager->links('default', 'bootstrap_pagination') ?>
        </nav>
    </div>

    <script>
        $(document).ready(function() {
            window.deleteImage = function(id) {
                if (confirm('Are you sure you want to delete this image?')) {
                    $.ajax({
                        url: `/images/${id}`,
                        type: 'DELETE',
                        success: function(response) {
                            if (response.status === 'success') {
                                location.reload(); // Reload the page after deletion
                            } else {
                                alert('Delete failed');
                            }
                        }
                    });
                }
            }
        });
    </script>
</body>

</html>