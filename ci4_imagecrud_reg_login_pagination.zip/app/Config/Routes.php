<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Define routes for image CRUD operations.
$routes->get('images', 'Images::index');
$routes->get('images/add', 'Images::add');
$routes->get('images/edit/(:num)', 'Images::edit/$1');
$routes->post('images/upload', 'Images::upload');
$routes->post('images/update', 'Images::update');
$routes->delete('images/(:num)', 'Images::delete/$1');
$routes->get('images/fetch', 'Images::fetch');
$routes->get('images/get/(:num)', 'Images::get/$1');

$routes->get('/register', 'AuthController::register');
$routes->post('/registerUser', 'AuthController::registerUser');
$routes->get('/login', 'AuthController::login');
$routes->post('/loginUser', 'AuthController::loginUser');
$routes->get('/logout', 'AuthController::logout');
$routes->get('/dashboard', 'DashboardController::index', ['filter' => 'auth']); // Example dashboard route
