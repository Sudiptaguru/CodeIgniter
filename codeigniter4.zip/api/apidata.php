<?php

$request = 0;
if(isset($_GET['request'])){
    $request = $_GET['request'];
}

// GET request
if($request == 1){
    $response = array();

    $response['first_name'] = 'Arjun';
    $response['last_name'] = 'singh';
    $response['email'] = 'arjun@makitweb.com';

    echo json_encode($response);
    die;
}

// POST request
if($request == 2){
    // Read POST data
    $data = json_decode(file_get_contents("php://input"));

    $first_name = $data->first_name;
    $last_name = $data->last_name;
    $email = $data->email;

    $response['first_name'] = $first_name;
    $response['last_name'] = $last_name;
    $response['email'] = $email;

    echo json_encode($response);
    die;
}