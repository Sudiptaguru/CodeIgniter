// $(function () {
//     'use strict';
//     //Remove localstroge items 
//     localStorage.removeItem("OnLoadToast");

//     var pageLoginForm = $('.auth-login-form');

//     // jQuery Validation
//     // --------------------------------------------------------------------
//     if (pageLoginForm.length) {
//         pageLoginForm.validate({
//             /*
//             * ? To enable validation onkeyup
//             onkeyup: function (element) {
//               $(element).valid();
//             },*/
//             /*
//             * ? To enable validation on focusout
//             onfocusout: function (element) {
//               $(element).valid();
//             }, */
//             rules: {
//                 'user_email': {
//                     required: true,
//                     email: true
//                 },
//                 'user_password': {
//                     required: true
//                 }
//             },
//             submitHandler: function (form) {
//                 $.ajax({
//                     type: "POST",
//                     url: "/api/auth_login",
//                     dataType: "json",
//                     data: $(form).serialize(),
//                     beforeSend: function () {
//                         $("button[type=button]").addClass('disabled');
//                         Swal.fire({
//                             title: 'Please wait...',
//                             html: 'We are validating your account.',
//                             allowEscapeKey: false,
//                             allowOutsideClick: false,
//                             didOpen: () => {
//                                 Swal.showLoading()
//                             }
//                         });
//                     },
//                     success: function (response) {
//                         console.log(response);
//                         if (response.status == 1) {
//                             window.location.href = response.data['redirect_to'];
//                             console.log(response);
//                         }
//                         //else if (response.status == 3) { 
//                         //	window.location.href = response.data['redirect_to']; 
//                         //	console.log(response);
//                         //}
//                         else {
//                             Swal.fire({
//                                 title: 'Error ' + response.responseCode + '!',
//                                 text: response.message,
//                                 icon: 'error',
//                                 customClass: {
//                                     confirmButton: 'btn btn-primary'
//                                 },
//                                 buttonsStyling: false
//                             });
//                         }
//                     }
//                 });
//                 return false; // required to block normal submit since you used ajax 
//             }
//         });
//     }
// });

$(() => {
    // function will get executed 
    // on click of submit button
    $(".auth-login-form").on("submit", function (event) {
        var form = $("#formId");
        // alert(form);
        var url = form.attr('action');
        $.ajax({
            type: "POST",
            url: "/api/auth_login",
            data: form.serialize(),
            success: function (data) {

                // Ajax call completed successfully
                alert("Form Submited Successfully");
            },
            error: function (data) {

                // Some error in ajax call
                alert("some Error");
            }
        });
    });
});

function myFunction() {
    alert("The form was submitted");
}

function myFun() {
    document.getElementById("demo").innerHTML = "Hello World";
}