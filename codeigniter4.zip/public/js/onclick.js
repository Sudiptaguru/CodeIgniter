function myFunction() {
    document.getElementById("demo").innerHTML = "Hello World";
}