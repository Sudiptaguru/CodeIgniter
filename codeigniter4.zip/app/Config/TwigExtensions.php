<?php

namespace Config;

use App\Libraries\AssetTwigExtension;
use Twig\Extension\DefaultExtension;

class TwigExtensions extends DefaultExtension
{
    public function getFunctions()
    {
        return [
            new \Twig\TwigFunction('asset', [AssetTwigExtension::class, 'asset']),
        ];
    }
}
