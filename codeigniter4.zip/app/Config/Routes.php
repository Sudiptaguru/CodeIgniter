<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('welcome', 'WelcomeController::index');
$routes->get('my-library', 'WelcomeController::mylibrary');
$routes->get('my-helper', 'PageController::index');
$routes->get('helper', 'Home::myhelper');
$routes->get('testjs', 'MyController::testjs');
$routes->get('ajaxlibraries', 'AjaxController::mylibrary');

// Filter
$routes->get("allcred", "AdminController::allcred");
$routes->get("login", "AdminController::login");
$routes->get('/api/auth_login', 'AdminController::loginAuth');
$routes->get('getcurl', 'ApikeyController::getrequest');
$routes->get('postcurl', 'ApikeyController::postrequest');
$routes->get('testarray', 'MyController::testarray');
$routes->get('guzzleget', 'HttpController::index');
$routes->get('guzzlepost', 'HttpController::guzzlepost');
// Filter on single route
$routes->get("admin/profile", "AdminController::profile", ["filter" => "myauth"]);

// Filter on route group
$routes->group("admin", ["filter" => "myauth"] , function($routes){

    $routes->post("sales", "AdminController::sales");
    $routes->put("transactions", "ApiController::transactions");
});

$routes->get('images', 'ImageCrud::index');
$routes->get('images/create', 'ImageCrud::create');
$routes->post('images/store', 'ImageCrud::store');
$routes->get('images/edit/(:num)', 'ImageCrud::edit/$1');
$routes->post('images/update/(:num)', 'ImageCrud::update/$1');
$routes->get('images/delete/(:num)', 'ImageCrud::delete/$1');

// $routes->get('images', 'ImageCrud::index');
// $routes->get('images/fetchAll', 'ImageCrud::fetchAll');
// $routes->post('images/store', 'ImageCrud::store');
// $routes->get('images/edit/(:num)', 'ImageCrud::edit/$1');
// $routes->post('images/update/(:num)', 'ImageCrud::update/$1');
// $routes->get('images/delete/(:num)', 'ImageCrud::delete/$1');