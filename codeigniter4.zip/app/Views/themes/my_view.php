<!-- app/Views/my_view.php -->
<!DOCTYPE html>
<html>
<head>
    <title>My View</title>
</head>
<body>
    <h1>My View</h1>
    <!-- Display data from the controller -->
</body>
</html>
