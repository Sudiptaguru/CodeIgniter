<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>CodeIgniter 4 Helper Functions</title>
	<meta name="description" content="The small framework with powerful features">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
</head>
<body>
	<h1>CodeIgniter 4 Helper Functions</h1>
	
	<?php echo $months; ?>
	<?php echo $years; ?>
</body>
</html>