<!DOCTYPE html>
<html>
<head>
    <title>Image List</title>
</head>
<body>
    <h1>Image List</h1>
    <a href="<?= base_url('images/create') ?>">Add Image</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($images as $image): ?>
            <tr>
                <td><?= $image['id'] ?></td>
                <td><?= $image['title'] ?></td>
                <td><img src="<?= base_url('uploads/' . $image['image']) ?>" width="100"></td>
                <td>
                    <a href="<?= base_url('images/edit/' . $image['id']) ?>">Edit</a>
                    <a href="<?= base_url('images/delete/' . $image['id']) ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
