<!DOCTYPE html>
<html>
<head>
    <title>Image List</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Image List</h1>
    <button onclick="showCreateForm()">Add Image</button>
    <div id="imageForm"></div>
    <table border="1" id="imageTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <script>
        function fetchImages() {
            $.ajax({
                url: '<?= base_url('images/fetchAll') ?>',
                method: 'GET',
                success: function(response) {
                    let tableBody = '';
                    response.forEach(image => {
                        tableBody += `
                            <tr>
                                <td>${image.id}</td>
                                <td>${image.title}</td>
                                <td><img src="<?= base_url('uploads') ?>/${image.image}" width="100"></td>
                                <td>
                                    <button onclick="editImage(${image.id})">Edit</button>
                                    <button onclick="deleteImage(${image.id})">Delete</button>
                                </td>
                            </tr>
                        `;
                    });
                    $('#imageTable tbody').html(tableBody);
                }
            });
        }

        function showCreateForm() {
            $('#imageForm').html(`
                <h1>Add Image</h1>
                <form id="createForm" enctype="multipart/form-data">
                    <label>Title</label>
                    <input type="text" name="title" required><br><br>
                    <label>Image</label>
                    <input type="file" name="image" required><br><br>
                    <button type="submit">Save</button>
                </form>
            `);

            $('#createForm').submit(function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: '<?= base_url('images/store') ?>',
                    method: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                            $('#imageForm').html('');
                        }
                    }
                });
            });
        }

        function editImage(id) {
            $.ajax({
                url: '<?= base_url('images/edit') ?>/' + id,
                method: 'GET',
                success: function(response) {
                    $('#imageForm').html(`
                        <h1>Edit Image</h1>
                        <form id="editForm" enctype="multipart/form-data">
                            <input type="hidden" name="old_image" value="${response.image}">
                            <label>Title</label>
                            <input type="text" name="title" value="${response.title}" required><br><br>
                            <label>Image</label>
                            <input type="file" name="image"><br><br>
                            <img src="<?= base_url('uploads') ?>/${response.image}" width="100"><br><br>
                            <button type="submit">Update</button>
                        </form>
                    `);

                    $('#editForm').submit(function(e) {
                        e.preventDefault();
                        let formData = new FormData(this);
                        $.ajax({
                            url: '<?= base_url('images/update') ?>/' + id,
                            method: 'POST',
                            data: formData,
                            contentType: false,
                            processData: false,
                            success: function(response) {
                                if (response.status === 'success') {
                                    fetchImages();
                                    $('#imageForm').html('');
                                }
                            }
                        });
                    });
                }
            });
        }

        function deleteImage(id) {
            if (confirm('Are you sure you want to delete this image?')) {
                $.ajax({
                    url: '<?= base_url('images/delete') ?>/' + id,
                    method: 'GET',
                    success: function(response) {
                        if (response.status === 'success') {
                            fetchImages();
                        }
                    }
                });
            }
        }

        $(document).ready(function() {
            fetchImages();
        });
    </script>
</body>
</html>
