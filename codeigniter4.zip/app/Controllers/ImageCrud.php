<?php
namespace App\Controllers;

use App\Models\ImageModel;
use CodeIgniter\Controller;

class ImageCrud extends Controller
{
    public function index()
    {
        $model = new ImageModel();
        $data['images'] = $model->findAll();
        return view('image_list', $data);
    }

    public function create()
    {
        return view('image_form');
    }

    // public function store()
    // {
    //     $model = new ImageModel();
    //     $file = $this->request->getFile('image');
        
    //     if ($file->isValid() && !$file->hasMoved()) {
    //         $imageName = $file->getRandomName();
    //         $file->move(WRITEPATH . 'uploads', $imageName);

    //         $model->save([
    //             'title' => $this->request->getPost('title'),
    //             'image' => $imageName
    //         ]);
    //         return redirect()->to(base_url('images'));
    //     }
    // }

    public function store()
    {
        $model = new ImageModel();
        $file = $this->request->getFile('image');
        
        // Define validation rules
        $validationRules = [
            'title' => [
                'label' => 'Title',
                'rules' => 'required|min_length[3]|max_length[255]|is_unique[images.title]',
                'errors' => [
                    'is_unique' => 'The title must be unique.'
                ]
            ],
            'image' => [
                'uploaded[image]',
                'mime_in[image,image/jpg,image/jpeg,image/png]',
                'max_size[image,2048]'
            ]
        ];
        
        if (!$this->validate($validationRules)) {
            // Validation failed
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        if ($file->isValid() && !$file->hasMoved()) {
            $imageName = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads', $imageName);

            $model->save([
                'title' => $this->request->getPost('title'),
                'image' => $imageName
            ]);

            return redirect()->to(base_url('images'))->with('message', 'Image uploaded successfully');
        }

        // If file is not valid or has moved, return with error
        return redirect()->back()->withInput()->with('error', 'The file is invalid or has already been moved.');
    }

    public function edit($id)
    {
        $model = new ImageModel();
        $data['image'] = $model->find($id);
        return view('image_edit_form', $data);
    }

    public function update($id)
    {
        $model = new ImageModel();
        $file = $this->request->getFile('image');
        $imageName = $this->request->getPost('old_image');

        if ($file->isValid() && !$file->hasMoved()) {
            $imageName = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads', $imageName);
        }

        $model->update($id, [
            'title' => $this->request->getPost('title'),
            'image' => $imageName
        ]);
        return redirect()->to(base_url('images'));
    }

    public function delete($id)
    {
        $model = new ImageModel();
        $image = $model->find($id);
        unlink(WRITEPATH . 'uploads/' . $image['image']);
        $model->delete($id);
        return redirect()->to(base_url('images'));
    }
}
?>