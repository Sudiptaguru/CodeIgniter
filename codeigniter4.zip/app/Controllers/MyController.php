<?php

namespace App\Controllers;

use App\Libraries\TwigService;
use App\Libraries\TwigExtensions;
use App\Libraries\MyLibrary;
use CodeIgniter\Controller;
use App\Controllers\BaseController;

class MyController extends BaseController
{
    protected $filters = ['myfilter'];

    public function index()
    {
        // $this->filter('myfilter');
        echo $this->twig->render('helper_view.html');
        // Your controller logic
    }

    public function testjs()
    {
        $loader = new \Twig\Loader\FilesystemLoader(APPPATH . 'Views/test');
        $twig = new \Twig\Environment($loader);

        $twig->addExtension(new TwigExtensions());

        echo $twig->render('testjs.html');
    }
}
