<?php

namespace App\Controllers;

use App\Libraries\MyLibrary;
use CodeIgniter\Controller;
use App\Libraries\EzerApi;
use App\Controllers\BaseController;

class AdminController extends BaseController
{
    protected $filters = ['myfilter'];
    protected $ezapi_client;
    private $session;

    public function __construct()
    {
        $this->session = session();
        $this->ezapi_client = new EzerAPI();
        $this->request = service('request');
    }

    public function login()
    {
        // $this->filter('myfilter');
        echo $this->twig->render('login.html');
    }
    public function allcred()
    {
        $data = [
            0 => [
                'email' => 'admin@gmail.com',
                'password' => '123456'
            ],
            1 => [
                'email' => 'hello@gmail.com',
                'password' => '123456'
            ]
        ];
        print_r($data);
    }

    public function loginAuth()
    {
        $user_email = $this->request->getVar('user_email', FILTER_SANITIZE_EMAIL);
        $user_password = $this->request->getVar('user_password');
        $data = [
            'email' => 'admin@gmail.com',
            'password' => '123456'
        ];
        print_r($data); exit;
        $api_response = $this->ezapi_client->authEmailSignin($data);
        // print_r($api_response);
        // exit;
        //var_dump($api_response);
        //exit;
        if ($api_response->status == 1) {
            $isPlanActive = $api_response->data->isPlanActive; //FALSE or TRUE
            $currentPlanID = $api_response->data->currentPlanID; //ID or TRNULLUE
            $ses_data = [
                'id' => $api_response->data->id,
                'username' => $api_response->data->username,
                'email' => $api_response->data->email,
                // 'user_status' => $api_response->status,
                // 'country_calling_code' => $api_response->data->country_calling_code,
                // 'accessToken' => $api_response->data->accessToken,
                // 'profile_image_path' => $api_response->data->profile_image_path,
                // 'customerData' => $api_response->data->customer_details,
                // 'isLoggedIn' => TRUE,
                // 'isPlanActive' => $isPlanActive,
                // 'user_role' => $api_response->data->roles[1],
                // 'currentPlanID' => $currentPlanID,
                // 'isPersonalPlan' => $this->ezutility->checkPersonalPlan($currentPlanID)
            ];

            $this->session->set($ses_data);
            return redirect()->route('');
            //Prepare Response Data 
            // $this->data['redirect_to'] = '/dashboard';
            // $this->status = $api_response->status;
            // $this->message = $api_response->message;
            // $this->responseCode = $api_response->responseCode;
            //Send Ajax Response
            // $this->sendResponse($this->status, $this->message, $this->responseCode, $this->data);
        }

        /*else if ($api_response->status == 3) {
            $ses_data = [
                'email' => $user_email
            ];

            $this->session->set($ses_data);
            //Prepare Response Data 
            $this->data['redirect_to'] = '/verify-email';
            $this->status = $api_response->status;
            $this->message = $api_response->message;
            $this->responseCode = $api_response->responseCode;
            //Send Ajax Response
            $this->sendResponse($this->status, $this->message, $this->responseCode);

        }*/ else {
            //Prepare Response Data 
            // $this->status = $api_response->status;
            // $this->message = $api_response->message;
            // $this->responseCode = $api_response->responseCode;
            //Send Ajax Response
            // $this->sendResponse($this->status, $this->message, $this->responseCode);
        }
    }
}
