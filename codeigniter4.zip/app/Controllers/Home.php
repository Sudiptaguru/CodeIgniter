<?php

namespace App\Controllers;

class Home extends BaseController {
	
    public function index() {
		//helper(['month_year']);
		//Or for single helper
		helper('month_year');
		
		$data['months'] = generate_months();
		$data['years'] = generate_years();
		
        return view('welcome_message', $data);
    }
    public function myhelper() {
        // Load the custom helper
        helper('custom');

        // Use the custom function
        $message = custom_function();

        // Pass data to the view
        echo $this->twig->render('helper_view.html', ['message' => $message]);
    }
	
}