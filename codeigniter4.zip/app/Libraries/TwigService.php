<?php namespace App\Libraries;

use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class TwigService
{
    protected $twig;

    public function __construct()
    {
        $loader = new FilesystemLoader(APPPATH . 'Views');
        $this->twig = new Environment($loader);
    }

    public function render($view, $data = [])
    {
        echo $this->twig->render($view, $data);
    }
}
