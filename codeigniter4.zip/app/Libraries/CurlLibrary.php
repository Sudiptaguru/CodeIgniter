<?php
namespace App\Libraries;

class CurlLibrary {
    public function myMethod() {
        $apiURL = 'http://localhost:8000/apidata.php?request=1';

        // Instance
        $client = \Config\Services::curlrequest();

        // Send request
        $response = $client->get($apiURL, ['debug' => true]);
        return json_decode($response->getBody());
        // Read response
        // $code = $response->getStatusCode();
        // // print_r($code); exit;
        // $reason = $response->getReason(); // OK

        // if ($code == 200) { // Success

        //     // Read data 
        //     $body = json_decode($response->getBody());

        //     $first_name = $body->first_name;
        //     $last_name = $body->last_name;
        //     $email = $body->email;

        //     echo "first_name : " . $first_name . "<br>";
        //     echo "last_name : " . $last_name . "<br>";
        //     echo "email : " . $email . "<br>";
        // } else {
        //     echo "failed";
        //     die;
        // }
    }
}

