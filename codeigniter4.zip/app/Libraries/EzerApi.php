<?php
namespace App\Libraries;

class EzerApi {
    // protected $api_endpoint;

    // public function __construct()
    // {
    //     $this->api_endpoint = getenv('APP_API_ENDPOINT');
    // }
    public function authEmailSignin($data)
    {
        $client = \Config\Services::curlrequest();
        $headers = [
            "Accept" => "application/x-www-form-urlencoded"
        ];
        // $url = $this->api_endpoint . "/auth/email-signin";
        $url = "/auth/email-signin";
        $response = $client->request('POST', $url, ['form_params' => $data, 'headers' => $headers, 'http_errors' => false, 'verify' => false, 'user_agent' => $_SERVER['HTTP_USER_AGENT']]);

        return json_decode($response->getBody());
        //print_r(json_decode($response->getBody()));
    }
}

