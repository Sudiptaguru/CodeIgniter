<?php
namespace App\Libraries;

class MyLibrary {
    public function myMethod() {
        return 'Hello from MyLibrary!';
    }
}

