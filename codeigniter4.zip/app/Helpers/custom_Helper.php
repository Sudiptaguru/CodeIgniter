<?php

if(!function_exists('custom_function')) {
	function custom_function() {
		return 'This is a custom function from the helper.';
	}
}
