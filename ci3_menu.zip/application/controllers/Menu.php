<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Menu_model'); // Load the model
    }

    public function index() {
        // Fetch menu data from the database
        $menu_data = $this->Menu_model->get_menu_with_subpages();
        
        // Pass the data to the view
        $data['menu_data'] = $menu_data;
        $this->load->view('menu_view', $data);
    }
}
