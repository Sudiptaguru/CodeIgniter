<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>

  <body>
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#">WebSiteName</a>
        </div>
        <ul class="nav navbar-nav">
          <!-- Dynamic Menu Generation -->
          <?php foreach ($menu_data as $menu_item): ?>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <?= $menu_item['title'] ?> <span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <?php foreach ($menu_item['subpages'] as $subpage): ?>
                  <li><a href="<?= $subpage['url'] ?>"><?= $subpage['name'] ?></a></li>
                <?php endforeach; ?>
              </ul>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </nav>

    <div class="container">
      <h3>Navbar With Dropdown</h3>
      <p>This example generates the dropdown menu dynamically using data from the controller.</p>
    </div>
  </body>
</html>
