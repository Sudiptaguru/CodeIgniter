<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Ensure the database is loaded
    }

    public function get_menu_with_subpages() {
        // Fetch all menu items with their subpages, ordered by menu_order and subpages_order
        $this->db->select('menu.id, menu.title, subpages.name, subpages.url');
        $this->db->from('menu');
        $this->db->join('subpages', 'subpages.menu_id = menu.id');
        $this->db->order_by('menu.menu_order', 'ASC');
        $this->db->order_by('subpages.subpages_order', 'ASC');
        $query = $this->db->get();

        $menu_data = [];
        foreach ($query->result() as $row) {
            $menu_data[$row->id]['title'] = $row->title;
            $menu_data[$row->id]['subpages'][] = [
                'name' => $row->name,
                'url' => $row->url
            ];
        }

        return $menu_data;
    }
}
