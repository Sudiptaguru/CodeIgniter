<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


if ( ! function_exists('test_method'))
{

    function mail_config($params){
       $params['config']=email_settings();
       sendmail($params);
       return 1;
    } 

    function registration_mail($params){
       $params['config']=email_settings();
       sendmail($params);
       return 1;
    } 

    function forgotpassword_mail($params){
       $params['config']=email_settings();
       sendmail($params);
       return 1; 
    } 

    function email_settings(){
        $config=array();
        $config['protocol']     = 'smtp';
        $config['smtp_host']    = 'ssl://mail.met-technologies.com';
        //$config['smtp_host']  = 'ssl://mail.fitser.com';
        $config['smtp_port']    = '465';        
        $config['smtp_user']    = 'devfitser@met-technologies.com';
        $config['smtp_pass']    = 'SARYD^z(B${F';
        //$config['smtp_user']  = 'test1@fitser.com';
        //$config['smtp_pass']  = 'Test123@';
        $config['charset']      = 'utf-8';
        $config['newline']      = "\r\n";
        $config['mailtype']     = 'html'; // or html
        $config['validation']   = TRUE; // bool whether to validate email or not     
        return $config; 

    } 


    function email_settingsV2(){
        $config=array();
        $config['protocol']     = 'smtp';
        $config['smtp_host']    = 'ssl://mail.met-technologies.com';
        //$config['smtp_host']  = 'ssl://mail.fitser.com';
        $config['smtp_port']    = '465';        
        $config['smtp_user']    = 'devfitser@met-technologies.com';
        $config['smtp_pass']    = 'SARYD^z(B${F';
        //$config['smtp_user']  = 'test1@fitser.com';
        //$config['smtp_pass']  = 'Test123@';
        $config['charset']      = 'utf-8';
        $config['newline']      = "\r\n";
        $config['mailtype']     = 'text'; // or html
        $config['validation']   = TRUE; // bool whether to validate email or not     
        return $config; 
    } 


    function invoice_mail($params){
        $params['config']=email_settingsV2();
        sendmail($params);
        return 1; 
    }  

    function sendmail($params){     
        $obj =get_object();
        $obj->load->library('email');
        $obj->email->initialize($params['config']);
        $obj->email->from('developer.net@met-technologies.com',$params['from']); 
        $obj->email->to($params['to']); 
        $obj->email->subject($params['subject']);
        $obj->email->message($params['message']);

        if($params['filepath']!=''){
          $obj->email->attach($params['filepath']);  
        }
 
        $obj->email->set_crlf( "\r\n" );
        $response =  $obj->email->send(); 
        // print_r($response);
        //  echo $obj->email->print_debugger();
        return $obj->email->send(); 
        //$obj->email->send(); 
        // echo $obj->email->print_debugger();exit();

    }

    function get_user_role_type(){
      $user_role=get_object()->session->userdata('user_role');
      return $user_role;
    } 

    function get_object(){
      $obj =& get_instance();
      return $obj;
    }

    //Get value 
    function getVal($tbl, $find, $match, $fetch){
        $ci=& get_instance();
        //$ci->load->database(); 
        $ci->db->select($fetch);
        $ci->db->where($find, $match);
        $query = $ci->db->get($tbl);
        //echo $ci->db->last_query();exit(); 
        $row = $query->row_array();               
        return $row[$fetch];               
    }

    //Get list from table
    function getList($tbl){  
        $ci=& get_instance();
        $ci->db->select('*');        
        $query = $ci->db->get($tbl);        
        return $query->result_array();                      
    }

    //Insert into table 
    function add($tbl, $data){                
        $ci=& get_instance();
        $ci->db->insert($tbl, $data);        
        //echo $ci->db->last_query();//exit(); 
        $insert_id = $ci->db->insert_id();
        return $insert_id;        
    }

    //Update into table         
    function update($tbl, $data, $condition){                
        $ci=& get_instance();
        $ci->db->where($condition);        
        $ci->db->update($tbl, $data);        
        //echo $ci->db->last_query();//exit();         
        return true;        
    }

    //Get list from table
    function getListV2($tbl, $condition='', $field=''){  
        $ci=& get_instance();
        if($field){        
            $ci->db->select($field);        
        }else{
            $ci->db->select('*');        
        }

        if(!empty($condition)){
            $ci->db->where($condition);                    
        }

        $query = $ci->db->get($tbl);        
        //echo $ci->db->last_query();//exit();  
        return $query->result_array();                      
    }

    //Course Category List    
    function categoryTree($parent_id = 0, $sub_mark = '', $selected_category=''){
        $ci=& get_instance();
        $query = $ci->db->query("SELECT * FROM categories WHERE parent_id = $parent_id ORDER BY category_name ASC");
        if($query->num_rows() > 0){

            foreach ($query->result_array() as $key => $row) {
                $selected = '';
                if($selected_category==$row['category_id']){
                    $selected = 'selected="selected"';
                }                   
                echo '<option value="'.$row['category_id'].'" '.$selected.'>'.$sub_mark.$row['category_name'].'</option>';                
                categoryTree($row['category_id'], $sub_mark.'---', $selected_category);
            }
        }
    }

}