<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    // public $data =  array();
        
	public function __construct() {
		parent::__construct();
		$this->CI = & get_instance();
		// $this->load->model('mcommon');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
	}

	// protected function is_logged_in_submitter() {
	// 	return $this->session->userdata('submitter_details') ? 1 : 0;
	// }
	// protected function is_logged_in_company() {
	// 	return $this->session->userdata('company_details') ? 1 : 0;
	// }
	// protected function is_logged_in_reviewer() {
	// 	return $this->session->userdata('reviewer_details') ? 1 : 0;
	// }
	// protected function is_logged_in_contributor() {
	// 	return $this->session->userdata('contributor_details') ? 1 : 0;
	// }
 //    protected function is_logged_in_admin() {
 //        return $this->session->userdata('admin_details') ? 1 : 0;
 //    }
 //    ///Added By Somnath On 24-02-2021//
 //    protected function addLeadingZero($value, $threshold = 2) {
 //        return sprintf('%0' . $threshold . 's', $value);
 //    }

    // protected function commonFileArrayUpload($path = '', $images = array(),$fileTypes = '')
    // {
    //     $file_names= array();
    //     $upPath = FCPATH . $path;
    //     if (!file_exists($upPath)) {
    //         mkdir($upPath, 0777, true);
    //     }
    //     if ($fileTypes == '') {
    //         $fileTypes = 'gif|jpg|png|jpeg|JPEG|JPG|GIF|PNG';
    //     }
    //     $config = array(
    //         'upload_path' => $upPath,
    //         'allowed_types' =>  $fileTypes,
    //         'overwrite' => TRUE,
    //         'max_size' => "8192000",
    //         /*'max_height' => "1536",
    //         'max_width' => "2048",*/
    //         'encrypt_name' => TRUE
    //     );
    //     $this->load->library('upload', $config);
    //     for ($p = 0; $p < count($images['name']); $p++) {
    //         if ($images['name'][$p] != '') {
    //             $_FILES['file']['name']     = $images['name'][$p];
    //             $_FILES['file']['type']     = $images['type'][$p];
    //             $_FILES['file']['tmp_name'] = $images['tmp_name'][$p];
    //             $_FILES['file']['error']    = $images['error'][$p];
    //             $_FILES['file']['size']     = $images['size'][$p];
    //             $config['file_name']        = time() . $images['name'][$p];
    //             $this->upload->initialize($config);
    //             if ($this->upload->do_upload('file')) {
    //                 $imageDetailArray = $this->upload->data();
    //                $file_names[] =$imageDetailArray['file_name'] ;
    //                 // $this->cm->insert($db, array($dbColmn => $dbVal, "image" => $imageDetailArray['file_name']));
    //             }else{
    //                  print_r( $this->upload->display_errors());
    //             }
    //         }
    //     }
    //     return $file_names;
    // }

    // protected function commonFileUpload($path = '', $imageName = '', $imageInputName = '', $fileTypes = '', $oldImage = '')
    // {
    //     if ($fileTypes == '') {
    //         $fileTypes = 'gif|jpg|png|jpeg|JPEG|JPG|GIF|PNG';
    //     }
    //     $pro_image = '';
    //     $upPath = FCPATH . $path;
    //     if (!file_exists($upPath)) {
    //         mkdir($upPath, 0777, true);
    //     }
    //     $config = array(
    //         'upload_path' => $upPath,
    //         'allowed_types' => $fileTypes,
    //         'overwrite' => true,
    //         'max_size' => "8192000",
    //         /*'max_height' => "1536",
    //         'max_width' => "2048",*/
    //         'encrypt_name' => true,
    //     );

    //     $config['file_name'] = time() . $imageName;
    //      $this->load->library('upload', $config);
    //     $this->upload->initialize($config);
       
    //     if ($this->upload->do_upload($imageInputName)) {
    //         $imageDetailArray = $this->upload->data();
    //         $pro_image = $imageDetailArray['file_name'];
    //         if ($oldImage != '') {
    //             if (file_exists($upPath . $oldImage)) {
    //                 unlink($upPath . $oldImage);
    //             }
    //         }
    //     } else {
    //         $pro_image = $this->upload->display_errors();
    //     }
    //     // print_r($pro_image);
    //     return $pro_image;
    // }








	//Not used

	protected function redirect_guest() {		
		if (!$this->session->userdata('admin')) {
			redirect('admin/', 'refresh');
		}
	}
	protected function is_logged_in_user() {
		return $this->session->userdata('front_end_user') ? 1 : 0;
	}
	protected function redirect_guest_user() {
		if (!$this->session->userdata('front_end_user')) {
			redirect('index', 'refresh');
		}
	}
	
	protected function admin_view($view,$data) {
		 $this->load->view('admin/layouts/header',$data); 
	     $this->load->view($view,$data); 
	     $this->load->view('admin/layouts/footer');
	}
	protected function frontend_load_view($data) {
		$this->load->view('front/layouts/header');
		$this->load->view($data['content'],$data);
		$this->load->view('front/layouts/footer');
	}
	
	protected function frontend_before_login_load_view($data) {
		$this->load->view('front/layouts/login_header');
		$this->load->view($data['content'],$data);
		$this->load->view('front/layouts/login_footer');
	}

	/** added by Ishani **/
	///chk user id validity
	public function check_valid_user($user_id = false)
	{
		if (!$user_id) {
			$user_id = $this->session->userdata('front_end_user')['id'];
			
		}
		$userDB = $this->db->query("SELECT user_master.*,user_groups.name FROM user_master JOIN user_groups ON user_master.group_id=user_groups.group_id WHERE user_master.id='" . $user_id . "' AND user_master.status=1")->result_array();
		if (!empty($userDB)) {

			return $userDB;
		} else {
			return false;
		}
	}


}

class Public_Controller extends CI_Controller{

    public $data =  array();
    public $sitename;
	
	   
    function __construct(){
        parent::__construct();
        $this ->  sitename = "WITFT";
        //$this ->  sitename =  $this -> config -> item('sitename');
        $this->form_validation->set_error_delimiters('<div class="error" style="color:#721c24;">', '</div>');
		$this -> load -> model('User_m');
		
		$controller = strtolower($this->router->fetch_class());
		
		if ($controller != 'home'){
			if (!$this-> User_m -> loggedin()){
				redirect(base_url('Home'));
			}
			
		}
		
    }
	
	function userID(){
		if (!empty($_SESSION['user_id'])){
			$uid = $_SESSION['user_id'];
			return $uid;
		}
		else {
			
		}return FALSE;
	}
	
	function isProvider(){
		if (!empty($_SESSION['user_id'])){
			$gid = $_SESSION['group_id'];
			return $gid == 2;
	     }
			 return FALSE;
		 }
	

}
