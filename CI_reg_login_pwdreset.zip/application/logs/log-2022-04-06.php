<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-06 03:33:30 --> Config Class Initialized
INFO - 2022-04-06 03:33:30 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:33:30 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:33:30 --> Utf8 Class Initialized
INFO - 2022-04-06 03:33:30 --> URI Class Initialized
INFO - 2022-04-06 03:33:30 --> Router Class Initialized
INFO - 2022-04-06 03:33:31 --> Output Class Initialized
INFO - 2022-04-06 03:33:31 --> Security Class Initialized
DEBUG - 2022-04-06 03:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:33:31 --> Input Class Initialized
INFO - 2022-04-06 03:33:31 --> Language Class Initialized
INFO - 2022-04-06 03:33:31 --> Loader Class Initialized
INFO - 2022-04-06 03:33:31 --> Helper loaded: url_helper
INFO - 2022-04-06 03:33:31 --> Helper loaded: form_helper
INFO - 2022-04-06 03:33:31 --> Helper loaded: common_helper
INFO - 2022-04-06 03:33:31 --> Helper loaded: util_helper
INFO - 2022-04-06 03:33:31 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:33:31 --> Form Validation Class Initialized
INFO - 2022-04-06 03:33:31 --> Controller Class Initialized
INFO - 2022-04-06 03:33:31 --> Model Class Initialized
INFO - 2022-04-06 03:33:31 --> Model Class Initialized
INFO - 2022-04-06 03:33:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:33:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:33:31 --> Final output sent to browser
DEBUG - 2022-04-06 03:33:31 --> Total execution time: 0.1471
INFO - 2022-04-06 03:33:36 --> Config Class Initialized
INFO - 2022-04-06 03:33:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:33:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:33:36 --> Utf8 Class Initialized
INFO - 2022-04-06 03:33:36 --> URI Class Initialized
INFO - 2022-04-06 03:33:36 --> Router Class Initialized
INFO - 2022-04-06 03:33:36 --> Output Class Initialized
INFO - 2022-04-06 03:33:36 --> Security Class Initialized
DEBUG - 2022-04-06 03:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:33:36 --> Input Class Initialized
INFO - 2022-04-06 03:33:36 --> Language Class Initialized
INFO - 2022-04-06 03:33:36 --> Loader Class Initialized
INFO - 2022-04-06 03:33:36 --> Helper loaded: url_helper
INFO - 2022-04-06 03:33:36 --> Helper loaded: form_helper
INFO - 2022-04-06 03:33:36 --> Helper loaded: common_helper
INFO - 2022-04-06 03:33:36 --> Helper loaded: util_helper
INFO - 2022-04-06 03:33:36 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:33:36 --> Form Validation Class Initialized
INFO - 2022-04-06 03:33:36 --> Controller Class Initialized
INFO - 2022-04-06 03:33:36 --> Model Class Initialized
INFO - 2022-04-06 03:33:36 --> Config Class Initialized
INFO - 2022-04-06 03:33:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:33:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:33:36 --> Utf8 Class Initialized
INFO - 2022-04-06 03:33:36 --> URI Class Initialized
INFO - 2022-04-06 03:33:36 --> Router Class Initialized
INFO - 2022-04-06 03:33:36 --> Output Class Initialized
INFO - 2022-04-06 03:33:36 --> Security Class Initialized
DEBUG - 2022-04-06 03:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:33:36 --> Input Class Initialized
INFO - 2022-04-06 03:33:36 --> Language Class Initialized
INFO - 2022-04-06 03:33:36 --> Loader Class Initialized
INFO - 2022-04-06 03:33:36 --> Helper loaded: url_helper
INFO - 2022-04-06 03:33:36 --> Helper loaded: form_helper
INFO - 2022-04-06 03:33:36 --> Helper loaded: common_helper
INFO - 2022-04-06 03:33:36 --> Helper loaded: util_helper
INFO - 2022-04-06 03:33:36 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:33:36 --> Form Validation Class Initialized
INFO - 2022-04-06 03:33:36 --> Controller Class Initialized
INFO - 2022-04-06 03:33:36 --> Model Class Initialized
INFO - 2022-04-06 03:33:36 --> Model Class Initialized
INFO - 2022-04-06 03:33:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:33:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:33:36 --> Final output sent to browser
DEBUG - 2022-04-06 03:33:36 --> Total execution time: 0.0649
INFO - 2022-04-06 03:33:39 --> Config Class Initialized
INFO - 2022-04-06 03:33:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:33:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:33:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:33:39 --> URI Class Initialized
INFO - 2022-04-06 03:33:39 --> Router Class Initialized
INFO - 2022-04-06 03:33:39 --> Output Class Initialized
INFO - 2022-04-06 03:33:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:33:40 --> Input Class Initialized
INFO - 2022-04-06 03:33:40 --> Language Class Initialized
INFO - 2022-04-06 03:33:40 --> Loader Class Initialized
INFO - 2022-04-06 03:33:40 --> Helper loaded: url_helper
INFO - 2022-04-06 03:33:40 --> Helper loaded: form_helper
INFO - 2022-04-06 03:33:40 --> Helper loaded: common_helper
INFO - 2022-04-06 03:33:40 --> Helper loaded: util_helper
INFO - 2022-04-06 03:33:40 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:33:40 --> Form Validation Class Initialized
INFO - 2022-04-06 03:33:40 --> Controller Class Initialized
INFO - 2022-04-06 03:33:40 --> Model Class Initialized
INFO - 2022-04-06 03:33:40 --> Model Class Initialized
INFO - 2022-04-06 03:33:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:33:40 --> Final output sent to browser
DEBUG - 2022-04-06 03:33:40 --> Total execution time: 0.0776
INFO - 2022-04-06 03:33:40 --> Config Class Initialized
INFO - 2022-04-06 03:33:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:33:40 --> Config Class Initialized
INFO - 2022-04-06 03:33:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:33:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:33:40 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:33:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:33:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:33:40 --> URI Class Initialized
INFO - 2022-04-06 03:33:40 --> URI Class Initialized
INFO - 2022-04-06 03:33:40 --> Router Class Initialized
INFO - 2022-04-06 03:33:40 --> Router Class Initialized
INFO - 2022-04-06 03:33:40 --> Output Class Initialized
INFO - 2022-04-06 03:33:40 --> Output Class Initialized
INFO - 2022-04-06 03:33:40 --> Security Class Initialized
INFO - 2022-04-06 03:33:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:33:40 --> Input Class Initialized
INFO - 2022-04-06 03:33:40 --> Input Class Initialized
INFO - 2022-04-06 03:33:40 --> Language Class Initialized
INFO - 2022-04-06 03:33:40 --> Language Class Initialized
ERROR - 2022-04-06 03:33:40 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-06 03:33:40 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-06 03:34:04 --> Config Class Initialized
INFO - 2022-04-06 03:34:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:04 --> URI Class Initialized
INFO - 2022-04-06 03:34:04 --> Router Class Initialized
INFO - 2022-04-06 03:34:04 --> Output Class Initialized
INFO - 2022-04-06 03:34:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:04 --> Input Class Initialized
INFO - 2022-04-06 03:34:04 --> Language Class Initialized
INFO - 2022-04-06 03:34:04 --> Loader Class Initialized
INFO - 2022-04-06 03:34:04 --> Helper loaded: url_helper
INFO - 2022-04-06 03:34:04 --> Helper loaded: form_helper
INFO - 2022-04-06 03:34:04 --> Helper loaded: common_helper
INFO - 2022-04-06 03:34:04 --> Helper loaded: util_helper
INFO - 2022-04-06 03:34:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:34:04 --> Form Validation Class Initialized
INFO - 2022-04-06 03:34:04 --> Controller Class Initialized
INFO - 2022-04-06 03:34:04 --> Model Class Initialized
INFO - 2022-04-06 03:34:04 --> Model Class Initialized
INFO - 2022-04-06 03:34:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:34:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:34:04 --> Final output sent to browser
DEBUG - 2022-04-06 03:34:04 --> Total execution time: 0.1623
INFO - 2022-04-06 03:34:08 --> Config Class Initialized
INFO - 2022-04-06 03:34:08 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:08 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:08 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:08 --> URI Class Initialized
INFO - 2022-04-06 03:34:08 --> Router Class Initialized
INFO - 2022-04-06 03:34:08 --> Output Class Initialized
INFO - 2022-04-06 03:34:08 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:08 --> Input Class Initialized
INFO - 2022-04-06 03:34:08 --> Language Class Initialized
INFO - 2022-04-06 03:34:08 --> Loader Class Initialized
INFO - 2022-04-06 03:34:08 --> Helper loaded: url_helper
INFO - 2022-04-06 03:34:08 --> Helper loaded: form_helper
INFO - 2022-04-06 03:34:08 --> Helper loaded: common_helper
INFO - 2022-04-06 03:34:08 --> Helper loaded: util_helper
INFO - 2022-04-06 03:34:08 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:34:08 --> Form Validation Class Initialized
INFO - 2022-04-06 03:34:08 --> Controller Class Initialized
INFO - 2022-04-06 03:34:08 --> Model Class Initialized
INFO - 2022-04-06 03:34:08 --> Model Class Initialized
INFO - 2022-04-06 03:34:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:34:08 --> Final output sent to browser
DEBUG - 2022-04-06 03:34:08 --> Total execution time: 0.0654
INFO - 2022-04-06 03:34:08 --> Config Class Initialized
INFO - 2022-04-06 03:34:08 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:08 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:08 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:08 --> URI Class Initialized
INFO - 2022-04-06 03:34:08 --> Router Class Initialized
INFO - 2022-04-06 03:34:08 --> Output Class Initialized
INFO - 2022-04-06 03:34:08 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:08 --> Input Class Initialized
INFO - 2022-04-06 03:34:08 --> Language Class Initialized
INFO - 2022-04-06 03:34:08 --> Loader Class Initialized
INFO - 2022-04-06 03:34:08 --> Helper loaded: url_helper
INFO - 2022-04-06 03:34:08 --> Helper loaded: form_helper
INFO - 2022-04-06 03:34:08 --> Helper loaded: common_helper
INFO - 2022-04-06 03:34:08 --> Helper loaded: util_helper
INFO - 2022-04-06 03:34:08 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:34:09 --> Form Validation Class Initialized
INFO - 2022-04-06 03:34:09 --> Controller Class Initialized
INFO - 2022-04-06 03:34:09 --> Model Class Initialized
INFO - 2022-04-06 03:34:09 --> Model Class Initialized
INFO - 2022-04-06 03:34:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:34:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:34:09 --> Final output sent to browser
DEBUG - 2022-04-06 03:34:09 --> Total execution time: 0.0611
INFO - 2022-04-06 03:34:13 --> Config Class Initialized
INFO - 2022-04-06 03:34:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:13 --> URI Class Initialized
INFO - 2022-04-06 03:34:13 --> Router Class Initialized
INFO - 2022-04-06 03:34:13 --> Output Class Initialized
INFO - 2022-04-06 03:34:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:13 --> Input Class Initialized
INFO - 2022-04-06 03:34:13 --> Language Class Initialized
INFO - 2022-04-06 03:34:13 --> Loader Class Initialized
INFO - 2022-04-06 03:34:13 --> Helper loaded: url_helper
INFO - 2022-04-06 03:34:13 --> Helper loaded: form_helper
INFO - 2022-04-06 03:34:13 --> Helper loaded: common_helper
INFO - 2022-04-06 03:34:13 --> Helper loaded: util_helper
INFO - 2022-04-06 03:34:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:34:13 --> Form Validation Class Initialized
INFO - 2022-04-06 03:34:13 --> Controller Class Initialized
INFO - 2022-04-06 03:34:13 --> Model Class Initialized
INFO - 2022-04-06 03:34:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:34:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:34:13 --> Final output sent to browser
DEBUG - 2022-04-06 03:34:13 --> Total execution time: 0.1078
INFO - 2022-04-06 03:34:13 --> Config Class Initialized
INFO - 2022-04-06 03:34:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:13 --> Config Class Initialized
INFO - 2022-04-06 03:34:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:13 --> URI Class Initialized
INFO - 2022-04-06 03:34:13 --> Config Class Initialized
INFO - 2022-04-06 03:34:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:34:13 --> Router Class Initialized
DEBUG - 2022-04-06 03:34:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:13 --> Output Class Initialized
INFO - 2022-04-06 03:34:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:13 --> URI Class Initialized
INFO - 2022-04-06 03:34:13 --> Security Class Initialized
INFO - 2022-04-06 03:34:13 --> Router Class Initialized
DEBUG - 2022-04-06 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:13 --> Input Class Initialized
INFO - 2022-04-06 03:34:13 --> Language Class Initialized
INFO - 2022-04-06 03:34:13 --> Output Class Initialized
INFO - 2022-04-06 03:34:13 --> Security Class Initialized
ERROR - 2022-04-06 03:34:13 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:13 --> Input Class Initialized
INFO - 2022-04-06 03:34:13 --> URI Class Initialized
INFO - 2022-04-06 03:34:13 --> Language Class Initialized
INFO - 2022-04-06 03:34:13 --> Config Class Initialized
INFO - 2022-04-06 03:34:13 --> Router Class Initialized
INFO - 2022-04-06 03:34:13 --> Hooks Class Initialized
ERROR - 2022-04-06 03:34:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:13 --> Output Class Initialized
INFO - 2022-04-06 03:34:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:13 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:13 --> Input Class Initialized
INFO - 2022-04-06 03:34:13 --> URI Class Initialized
INFO - 2022-04-06 03:34:13 --> Language Class Initialized
INFO - 2022-04-06 03:34:13 --> Router Class Initialized
ERROR - 2022-04-06 03:34:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:13 --> Output Class Initialized
INFO - 2022-04-06 03:34:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:13 --> Input Class Initialized
INFO - 2022-04-06 03:34:13 --> Language Class Initialized
ERROR - 2022-04-06 03:34:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:44 --> Config Class Initialized
INFO - 2022-04-06 03:34:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:44 --> URI Class Initialized
INFO - 2022-04-06 03:34:44 --> Router Class Initialized
INFO - 2022-04-06 03:34:44 --> Output Class Initialized
INFO - 2022-04-06 03:34:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:44 --> Input Class Initialized
INFO - 2022-04-06 03:34:44 --> Language Class Initialized
INFO - 2022-04-06 03:34:44 --> Loader Class Initialized
INFO - 2022-04-06 03:34:44 --> Helper loaded: url_helper
INFO - 2022-04-06 03:34:44 --> Helper loaded: form_helper
INFO - 2022-04-06 03:34:44 --> Helper loaded: common_helper
INFO - 2022-04-06 03:34:44 --> Helper loaded: util_helper
INFO - 2022-04-06 03:34:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:34:44 --> Form Validation Class Initialized
INFO - 2022-04-06 03:34:44 --> Controller Class Initialized
INFO - 2022-04-06 03:34:44 --> Model Class Initialized
INFO - 2022-04-06 03:34:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:34:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:34:44 --> Final output sent to browser
DEBUG - 2022-04-06 03:34:44 --> Total execution time: 0.0715
INFO - 2022-04-06 03:34:44 --> Config Class Initialized
INFO - 2022-04-06 03:34:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:34:44 --> Config Class Initialized
INFO - 2022-04-06 03:34:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:44 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:34:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:44 --> URI Class Initialized
INFO - 2022-04-06 03:34:44 --> URI Class Initialized
INFO - 2022-04-06 03:34:44 --> Router Class Initialized
INFO - 2022-04-06 03:34:44 --> Output Class Initialized
INFO - 2022-04-06 03:34:44 --> Router Class Initialized
INFO - 2022-04-06 03:34:44 --> Security Class Initialized
INFO - 2022-04-06 03:34:44 --> Output Class Initialized
DEBUG - 2022-04-06 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:44 --> Input Class Initialized
INFO - 2022-04-06 03:34:44 --> Security Class Initialized
INFO - 2022-04-06 03:34:44 --> Language Class Initialized
DEBUG - 2022-04-06 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:44 --> Input Class Initialized
ERROR - 2022-04-06 03:34:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:44 --> Language Class Initialized
ERROR - 2022-04-06 03:34:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:44 --> Config Class Initialized
INFO - 2022-04-06 03:34:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:34:44 --> Config Class Initialized
INFO - 2022-04-06 03:34:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:44 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:34:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:44 --> URI Class Initialized
INFO - 2022-04-06 03:34:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:44 --> Router Class Initialized
INFO - 2022-04-06 03:34:44 --> URI Class Initialized
INFO - 2022-04-06 03:34:44 --> Output Class Initialized
INFO - 2022-04-06 03:34:44 --> Router Class Initialized
INFO - 2022-04-06 03:34:44 --> Security Class Initialized
INFO - 2022-04-06 03:34:44 --> Output Class Initialized
DEBUG - 2022-04-06 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:44 --> Security Class Initialized
INFO - 2022-04-06 03:34:44 --> Input Class Initialized
INFO - 2022-04-06 03:34:44 --> Language Class Initialized
DEBUG - 2022-04-06 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:44 --> Input Class Initialized
INFO - 2022-04-06 03:34:44 --> Language Class Initialized
ERROR - 2022-04-06 03:34:44 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:34:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:47 --> Config Class Initialized
INFO - 2022-04-06 03:34:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:47 --> URI Class Initialized
INFO - 2022-04-06 03:34:47 --> Router Class Initialized
INFO - 2022-04-06 03:34:47 --> Output Class Initialized
INFO - 2022-04-06 03:34:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:47 --> Input Class Initialized
INFO - 2022-04-06 03:34:47 --> Language Class Initialized
INFO - 2022-04-06 03:34:47 --> Loader Class Initialized
INFO - 2022-04-06 03:34:47 --> Helper loaded: url_helper
INFO - 2022-04-06 03:34:47 --> Helper loaded: form_helper
INFO - 2022-04-06 03:34:47 --> Helper loaded: common_helper
INFO - 2022-04-06 03:34:47 --> Helper loaded: util_helper
INFO - 2022-04-06 03:34:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:34:47 --> Form Validation Class Initialized
INFO - 2022-04-06 03:34:47 --> Controller Class Initialized
INFO - 2022-04-06 03:34:47 --> Model Class Initialized
INFO - 2022-04-06 03:34:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:34:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:34:47 --> Final output sent to browser
DEBUG - 2022-04-06 03:34:47 --> Total execution time: 0.0713
INFO - 2022-04-06 03:34:47 --> Config Class Initialized
INFO - 2022-04-06 03:34:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:34:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:47 --> URI Class Initialized
INFO - 2022-04-06 03:34:47 --> Router Class Initialized
INFO - 2022-04-06 03:34:47 --> Output Class Initialized
INFO - 2022-04-06 03:34:47 --> Config Class Initialized
INFO - 2022-04-06 03:34:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:34:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:47 --> Input Class Initialized
DEBUG - 2022-04-06 03:34:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:47 --> Language Class Initialized
INFO - 2022-04-06 03:34:47 --> URI Class Initialized
ERROR - 2022-04-06 03:34:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:47 --> Router Class Initialized
INFO - 2022-04-06 03:34:47 --> Output Class Initialized
INFO - 2022-04-06 03:34:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:47 --> Config Class Initialized
INFO - 2022-04-06 03:34:47 --> Input Class Initialized
INFO - 2022-04-06 03:34:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:34:47 --> Language Class Initialized
DEBUG - 2022-04-06 03:34:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:47 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:34:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:47 --> URI Class Initialized
INFO - 2022-04-06 03:34:47 --> Router Class Initialized
INFO - 2022-04-06 03:34:47 --> Config Class Initialized
INFO - 2022-04-06 03:34:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:34:47 --> Output Class Initialized
DEBUG - 2022-04-06 03:34:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:34:47 --> Security Class Initialized
INFO - 2022-04-06 03:34:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:34:47 --> URI Class Initialized
DEBUG - 2022-04-06 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:47 --> Input Class Initialized
INFO - 2022-04-06 03:34:47 --> Router Class Initialized
INFO - 2022-04-06 03:34:47 --> Language Class Initialized
INFO - 2022-04-06 03:34:47 --> Output Class Initialized
ERROR - 2022-04-06 03:34:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:34:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:34:47 --> Input Class Initialized
INFO - 2022-04-06 03:34:47 --> Language Class Initialized
ERROR - 2022-04-06 03:34:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:35:01 --> Config Class Initialized
INFO - 2022-04-06 03:35:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:01 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:01 --> URI Class Initialized
INFO - 2022-04-06 03:35:01 --> Router Class Initialized
INFO - 2022-04-06 03:35:01 --> Output Class Initialized
INFO - 2022-04-06 03:35:01 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:01 --> Input Class Initialized
INFO - 2022-04-06 03:35:01 --> Language Class Initialized
INFO - 2022-04-06 03:35:01 --> Loader Class Initialized
INFO - 2022-04-06 03:35:01 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:01 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:01 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:01 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:01 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:01 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:01 --> Controller Class Initialized
INFO - 2022-04-06 03:35:01 --> Model Class Initialized
INFO - 2022-04-06 03:35:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:35:02 --> Config Class Initialized
INFO - 2022-04-06 03:35:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:02 --> URI Class Initialized
INFO - 2022-04-06 03:35:02 --> Router Class Initialized
INFO - 2022-04-06 03:35:02 --> Output Class Initialized
INFO - 2022-04-06 03:35:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:02 --> Input Class Initialized
INFO - 2022-04-06 03:35:02 --> Language Class Initialized
INFO - 2022-04-06 03:35:02 --> Loader Class Initialized
INFO - 2022-04-06 03:35:02 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:02 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:02 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:02 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:02 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:02 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:02 --> Controller Class Initialized
INFO - 2022-04-06 03:35:02 --> Model Class Initialized
INFO - 2022-04-06 03:35:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:35:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:35:02 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:02 --> Total execution time: 0.0615
INFO - 2022-04-06 03:35:02 --> Config Class Initialized
INFO - 2022-04-06 03:35:02 --> Hooks Class Initialized
INFO - 2022-04-06 03:35:02 --> Config Class Initialized
INFO - 2022-04-06 03:35:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:35:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:02 --> URI Class Initialized
INFO - 2022-04-06 03:35:02 --> URI Class Initialized
INFO - 2022-04-06 03:35:02 --> Router Class Initialized
INFO - 2022-04-06 03:35:02 --> Router Class Initialized
INFO - 2022-04-06 03:35:02 --> Output Class Initialized
INFO - 2022-04-06 03:35:02 --> Output Class Initialized
INFO - 2022-04-06 03:35:02 --> Security Class Initialized
INFO - 2022-04-06 03:35:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:02 --> Input Class Initialized
INFO - 2022-04-06 03:35:02 --> Input Class Initialized
INFO - 2022-04-06 03:35:02 --> Language Class Initialized
INFO - 2022-04-06 03:35:02 --> Language Class Initialized
ERROR - 2022-04-06 03:35:02 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:35:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:35:02 --> Config Class Initialized
INFO - 2022-04-06 03:35:02 --> Config Class Initialized
INFO - 2022-04-06 03:35:02 --> Hooks Class Initialized
INFO - 2022-04-06 03:35:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:35:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:02 --> URI Class Initialized
INFO - 2022-04-06 03:35:02 --> URI Class Initialized
INFO - 2022-04-06 03:35:02 --> Router Class Initialized
INFO - 2022-04-06 03:35:02 --> Router Class Initialized
INFO - 2022-04-06 03:35:02 --> Output Class Initialized
INFO - 2022-04-06 03:35:02 --> Output Class Initialized
INFO - 2022-04-06 03:35:02 --> Security Class Initialized
INFO - 2022-04-06 03:35:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:02 --> Input Class Initialized
INFO - 2022-04-06 03:35:02 --> Input Class Initialized
INFO - 2022-04-06 03:35:02 --> Language Class Initialized
INFO - 2022-04-06 03:35:02 --> Language Class Initialized
ERROR - 2022-04-06 03:35:02 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:35:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:35:05 --> Config Class Initialized
INFO - 2022-04-06 03:35:05 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:05 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:05 --> URI Class Initialized
INFO - 2022-04-06 03:35:05 --> Router Class Initialized
INFO - 2022-04-06 03:35:05 --> Output Class Initialized
INFO - 2022-04-06 03:35:05 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:05 --> Input Class Initialized
INFO - 2022-04-06 03:35:06 --> Language Class Initialized
INFO - 2022-04-06 03:35:06 --> Loader Class Initialized
INFO - 2022-04-06 03:35:06 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:06 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:06 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:06 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:06 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:06 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:06 --> Controller Class Initialized
INFO - 2022-04-06 03:35:06 --> Model Class Initialized
INFO - 2022-04-06 03:35:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:35:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:35:06 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:06 --> Total execution time: 0.0714
INFO - 2022-04-06 03:35:06 --> Config Class Initialized
INFO - 2022-04-06 03:35:06 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:06 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:06 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:06 --> URI Class Initialized
INFO - 2022-04-06 03:35:06 --> Router Class Initialized
INFO - 2022-04-06 03:35:06 --> Output Class Initialized
INFO - 2022-04-06 03:35:06 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:06 --> Input Class Initialized
INFO - 2022-04-06 03:35:06 --> Language Class Initialized
INFO - 2022-04-06 03:35:06 --> Loader Class Initialized
INFO - 2022-04-06 03:35:06 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:06 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:06 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:06 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:06 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:06 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:06 --> Controller Class Initialized
INFO - 2022-04-06 03:35:06 --> Model Class Initialized
INFO - 2022-04-06 03:35:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:35:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:35:06 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:06 --> Total execution time: 0.0655
INFO - 2022-04-06 03:35:08 --> Config Class Initialized
INFO - 2022-04-06 03:35:08 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:08 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:08 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:08 --> URI Class Initialized
INFO - 2022-04-06 03:35:08 --> Router Class Initialized
INFO - 2022-04-06 03:35:08 --> Output Class Initialized
INFO - 2022-04-06 03:35:08 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:08 --> Input Class Initialized
INFO - 2022-04-06 03:35:08 --> Language Class Initialized
INFO - 2022-04-06 03:35:08 --> Loader Class Initialized
INFO - 2022-04-06 03:35:08 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:08 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:08 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:08 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:08 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:08 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:08 --> Controller Class Initialized
INFO - 2022-04-06 03:35:08 --> Model Class Initialized
INFO - 2022-04-06 03:35:08 --> Model Class Initialized
INFO - 2022-04-06 03:35:08 --> Config Class Initialized
INFO - 2022-04-06 03:35:08 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:08 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:08 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:08 --> URI Class Initialized
INFO - 2022-04-06 03:35:08 --> Router Class Initialized
INFO - 2022-04-06 03:35:08 --> Output Class Initialized
INFO - 2022-04-06 03:35:08 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:08 --> Input Class Initialized
INFO - 2022-04-06 03:35:08 --> Language Class Initialized
INFO - 2022-04-06 03:35:08 --> Loader Class Initialized
INFO - 2022-04-06 03:35:08 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:08 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:08 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:08 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:08 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:08 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:08 --> Controller Class Initialized
INFO - 2022-04-06 03:35:08 --> Model Class Initialized
INFO - 2022-04-06 03:35:08 --> Model Class Initialized
INFO - 2022-04-06 03:35:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:35:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:35:08 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:08 --> Total execution time: 0.0714
INFO - 2022-04-06 03:35:10 --> Config Class Initialized
INFO - 2022-04-06 03:35:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:10 --> URI Class Initialized
INFO - 2022-04-06 03:35:10 --> Router Class Initialized
INFO - 2022-04-06 03:35:10 --> Output Class Initialized
INFO - 2022-04-06 03:35:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:10 --> Input Class Initialized
INFO - 2022-04-06 03:35:10 --> Language Class Initialized
INFO - 2022-04-06 03:35:10 --> Loader Class Initialized
INFO - 2022-04-06 03:35:10 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:10 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:10 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:10 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:10 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:10 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:10 --> Controller Class Initialized
INFO - 2022-04-06 03:35:10 --> Model Class Initialized
INFO - 2022-04-06 03:35:10 --> Model Class Initialized
INFO - 2022-04-06 03:35:10 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:35:10 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:10 --> Total execution time: 0.0746
INFO - 2022-04-06 03:35:29 --> Config Class Initialized
INFO - 2022-04-06 03:35:29 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:29 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:29 --> URI Class Initialized
INFO - 2022-04-06 03:35:29 --> Router Class Initialized
INFO - 2022-04-06 03:35:29 --> Output Class Initialized
INFO - 2022-04-06 03:35:29 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:29 --> Input Class Initialized
INFO - 2022-04-06 03:35:29 --> Language Class Initialized
INFO - 2022-04-06 03:35:29 --> Loader Class Initialized
INFO - 2022-04-06 03:35:29 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:29 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:29 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:29 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:29 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:29 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:29 --> Controller Class Initialized
INFO - 2022-04-06 03:35:29 --> Model Class Initialized
INFO - 2022-04-06 03:35:29 --> Model Class Initialized
INFO - 2022-04-06 03:35:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:35:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:35:30 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:30 --> Total execution time: 0.1605
INFO - 2022-04-06 03:35:57 --> Config Class Initialized
INFO - 2022-04-06 03:35:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:35:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:35:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:35:57 --> URI Class Initialized
INFO - 2022-04-06 03:35:57 --> Router Class Initialized
INFO - 2022-04-06 03:35:57 --> Output Class Initialized
INFO - 2022-04-06 03:35:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:35:57 --> Input Class Initialized
INFO - 2022-04-06 03:35:57 --> Language Class Initialized
INFO - 2022-04-06 03:35:57 --> Loader Class Initialized
INFO - 2022-04-06 03:35:57 --> Helper loaded: url_helper
INFO - 2022-04-06 03:35:57 --> Helper loaded: form_helper
INFO - 2022-04-06 03:35:57 --> Helper loaded: common_helper
INFO - 2022-04-06 03:35:57 --> Helper loaded: util_helper
INFO - 2022-04-06 03:35:57 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:35:57 --> Form Validation Class Initialized
INFO - 2022-04-06 03:35:57 --> Controller Class Initialized
INFO - 2022-04-06 03:35:57 --> Model Class Initialized
INFO - 2022-04-06 03:35:57 --> Model Class Initialized
INFO - 2022-04-06 03:35:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:35:57 --> Final output sent to browser
DEBUG - 2022-04-06 03:35:57 --> Total execution time: 0.0733
INFO - 2022-04-06 03:36:17 --> Config Class Initialized
INFO - 2022-04-06 03:36:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:17 --> URI Class Initialized
INFO - 2022-04-06 03:36:17 --> Router Class Initialized
INFO - 2022-04-06 03:36:17 --> Output Class Initialized
INFO - 2022-04-06 03:36:17 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:17 --> Input Class Initialized
INFO - 2022-04-06 03:36:17 --> Language Class Initialized
INFO - 2022-04-06 03:36:17 --> Loader Class Initialized
INFO - 2022-04-06 03:36:17 --> Helper loaded: url_helper
INFO - 2022-04-06 03:36:17 --> Helper loaded: form_helper
INFO - 2022-04-06 03:36:17 --> Helper loaded: common_helper
INFO - 2022-04-06 03:36:17 --> Helper loaded: util_helper
INFO - 2022-04-06 03:36:17 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:36:17 --> Form Validation Class Initialized
INFO - 2022-04-06 03:36:17 --> Controller Class Initialized
INFO - 2022-04-06 03:36:17 --> Model Class Initialized
INFO - 2022-04-06 03:36:17 --> Model Class Initialized
INFO - 2022-04-06 03:36:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:36:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:36:17 --> Final output sent to browser
DEBUG - 2022-04-06 03:36:17 --> Total execution time: 0.1639
INFO - 2022-04-06 03:36:19 --> Config Class Initialized
INFO - 2022-04-06 03:36:19 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:19 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:19 --> URI Class Initialized
INFO - 2022-04-06 03:36:19 --> Router Class Initialized
INFO - 2022-04-06 03:36:19 --> Output Class Initialized
INFO - 2022-04-06 03:36:19 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:19 --> Input Class Initialized
INFO - 2022-04-06 03:36:19 --> Language Class Initialized
INFO - 2022-04-06 03:36:19 --> Loader Class Initialized
INFO - 2022-04-06 03:36:19 --> Helper loaded: url_helper
INFO - 2022-04-06 03:36:19 --> Helper loaded: form_helper
INFO - 2022-04-06 03:36:19 --> Helper loaded: common_helper
INFO - 2022-04-06 03:36:19 --> Helper loaded: util_helper
INFO - 2022-04-06 03:36:19 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:36:19 --> Form Validation Class Initialized
INFO - 2022-04-06 03:36:19 --> Controller Class Initialized
INFO - 2022-04-06 03:36:19 --> Model Class Initialized
INFO - 2022-04-06 03:36:19 --> Model Class Initialized
INFO - 2022-04-06 03:36:19 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:36:19 --> Final output sent to browser
DEBUG - 2022-04-06 03:36:19 --> Total execution time: 0.0680
INFO - 2022-04-06 03:36:20 --> Config Class Initialized
INFO - 2022-04-06 03:36:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:20 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:20 --> URI Class Initialized
INFO - 2022-04-06 03:36:20 --> Router Class Initialized
INFO - 2022-04-06 03:36:20 --> Output Class Initialized
INFO - 2022-04-06 03:36:20 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:20 --> Input Class Initialized
INFO - 2022-04-06 03:36:20 --> Language Class Initialized
INFO - 2022-04-06 03:36:20 --> Loader Class Initialized
INFO - 2022-04-06 03:36:20 --> Helper loaded: url_helper
INFO - 2022-04-06 03:36:20 --> Helper loaded: form_helper
INFO - 2022-04-06 03:36:20 --> Helper loaded: common_helper
INFO - 2022-04-06 03:36:20 --> Helper loaded: util_helper
INFO - 2022-04-06 03:36:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:36:20 --> Form Validation Class Initialized
INFO - 2022-04-06 03:36:20 --> Controller Class Initialized
INFO - 2022-04-06 03:36:20 --> Model Class Initialized
INFO - 2022-04-06 03:36:20 --> Model Class Initialized
INFO - 2022-04-06 03:36:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:36:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:36:20 --> Final output sent to browser
DEBUG - 2022-04-06 03:36:20 --> Total execution time: 0.0594
INFO - 2022-04-06 03:36:22 --> Config Class Initialized
INFO - 2022-04-06 03:36:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:22 --> URI Class Initialized
INFO - 2022-04-06 03:36:22 --> Router Class Initialized
INFO - 2022-04-06 03:36:22 --> Output Class Initialized
INFO - 2022-04-06 03:36:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:22 --> Input Class Initialized
INFO - 2022-04-06 03:36:22 --> Language Class Initialized
INFO - 2022-04-06 03:36:22 --> Loader Class Initialized
INFO - 2022-04-06 03:36:22 --> Helper loaded: url_helper
INFO - 2022-04-06 03:36:22 --> Helper loaded: form_helper
INFO - 2022-04-06 03:36:22 --> Helper loaded: common_helper
INFO - 2022-04-06 03:36:22 --> Helper loaded: util_helper
INFO - 2022-04-06 03:36:22 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:36:22 --> Form Validation Class Initialized
INFO - 2022-04-06 03:36:22 --> Controller Class Initialized
INFO - 2022-04-06 03:36:22 --> Model Class Initialized
INFO - 2022-04-06 03:36:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-06 03:36:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-06 03:36:22 --> Final output sent to browser
DEBUG - 2022-04-06 03:36:22 --> Total execution time: 0.1044
INFO - 2022-04-06 03:36:26 --> Config Class Initialized
INFO - 2022-04-06 03:36:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:26 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:26 --> URI Class Initialized
INFO - 2022-04-06 03:36:26 --> Router Class Initialized
INFO - 2022-04-06 03:36:26 --> Output Class Initialized
INFO - 2022-04-06 03:36:26 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:26 --> Input Class Initialized
INFO - 2022-04-06 03:36:26 --> Language Class Initialized
INFO - 2022-04-06 03:36:26 --> Loader Class Initialized
INFO - 2022-04-06 03:36:26 --> Helper loaded: url_helper
INFO - 2022-04-06 03:36:26 --> Helper loaded: form_helper
INFO - 2022-04-06 03:36:26 --> Helper loaded: common_helper
INFO - 2022-04-06 03:36:26 --> Helper loaded: util_helper
INFO - 2022-04-06 03:36:26 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:36:26 --> Form Validation Class Initialized
INFO - 2022-04-06 03:36:26 --> Controller Class Initialized
INFO - 2022-04-06 03:36:26 --> Model Class Initialized
INFO - 2022-04-06 03:36:26 --> Model Class Initialized
INFO - 2022-04-06 03:36:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:36:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:36:26 --> Final output sent to browser
DEBUG - 2022-04-06 03:36:26 --> Total execution time: 0.0708
INFO - 2022-04-06 03:36:34 --> Config Class Initialized
INFO - 2022-04-06 03:36:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:34 --> URI Class Initialized
INFO - 2022-04-06 03:36:34 --> Router Class Initialized
INFO - 2022-04-06 03:36:34 --> Output Class Initialized
INFO - 2022-04-06 03:36:34 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:34 --> Input Class Initialized
INFO - 2022-04-06 03:36:34 --> Language Class Initialized
INFO - 2022-04-06 03:36:34 --> Loader Class Initialized
INFO - 2022-04-06 03:36:34 --> Helper loaded: url_helper
INFO - 2022-04-06 03:36:34 --> Helper loaded: form_helper
INFO - 2022-04-06 03:36:34 --> Helper loaded: common_helper
INFO - 2022-04-06 03:36:34 --> Helper loaded: util_helper
INFO - 2022-04-06 03:36:34 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:36:34 --> Form Validation Class Initialized
INFO - 2022-04-06 03:36:34 --> Controller Class Initialized
INFO - 2022-04-06 03:36:34 --> Model Class Initialized
INFO - 2022-04-06 03:36:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:36:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:36:34 --> Final output sent to browser
DEBUG - 2022-04-06 03:36:34 --> Total execution time: 0.0793
INFO - 2022-04-06 03:36:34 --> Config Class Initialized
INFO - 2022-04-06 03:36:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:34 --> URI Class Initialized
INFO - 2022-04-06 03:36:34 --> Router Class Initialized
INFO - 2022-04-06 03:36:34 --> Output Class Initialized
INFO - 2022-04-06 03:36:34 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:34 --> Input Class Initialized
INFO - 2022-04-06 03:36:34 --> Config Class Initialized
INFO - 2022-04-06 03:36:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:36:34 --> Config Class Initialized
INFO - 2022-04-06 03:36:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:34 --> Config Class Initialized
INFO - 2022-04-06 03:36:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:36:34 --> URI Class Initialized
DEBUG - 2022-04-06 03:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:34 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:36:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:36:34 --> URI Class Initialized
INFO - 2022-04-06 03:36:34 --> URI Class Initialized
INFO - 2022-04-06 03:36:34 --> Language Class Initialized
INFO - 2022-04-06 03:36:34 --> Router Class Initialized
INFO - 2022-04-06 03:36:34 --> Router Class Initialized
ERROR - 2022-04-06 03:36:34 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:36:34 --> Output Class Initialized
INFO - 2022-04-06 03:36:34 --> Router Class Initialized
INFO - 2022-04-06 03:36:34 --> Output Class Initialized
INFO - 2022-04-06 03:36:34 --> Security Class Initialized
INFO - 2022-04-06 03:36:34 --> Output Class Initialized
DEBUG - 2022-04-06 03:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:34 --> Input Class Initialized
INFO - 2022-04-06 03:36:34 --> Security Class Initialized
INFO - 2022-04-06 03:36:34 --> Language Class Initialized
INFO - 2022-04-06 03:36:34 --> Security Class Initialized
DEBUG - 2022-04-06 03:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:34 --> Input Class Initialized
ERROR - 2022-04-06 03:36:34 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:36:34 --> Language Class Initialized
ERROR - 2022-04-06 03:36:34 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:36:34 --> Input Class Initialized
INFO - 2022-04-06 03:36:34 --> Language Class Initialized
ERROR - 2022-04-06 03:36:34 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:39 --> Config Class Initialized
INFO - 2022-04-06 03:40:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:39 --> URI Class Initialized
INFO - 2022-04-06 03:40:39 --> Router Class Initialized
INFO - 2022-04-06 03:40:39 --> Output Class Initialized
INFO - 2022-04-06 03:40:39 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:39 --> Input Class Initialized
INFO - 2022-04-06 03:40:39 --> Language Class Initialized
INFO - 2022-04-06 03:40:39 --> Loader Class Initialized
INFO - 2022-04-06 03:40:39 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:39 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:39 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:39 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:39 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:39 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:39 --> Controller Class Initialized
INFO - 2022-04-06 03:40:39 --> Model Class Initialized
INFO - 2022-04-06 03:40:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:40:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:40:39 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:39 --> Total execution time: 0.4538
INFO - 2022-04-06 03:40:39 --> Config Class Initialized
INFO - 2022-04-06 03:40:39 --> Hooks Class Initialized
INFO - 2022-04-06 03:40:39 --> Config Class Initialized
INFO - 2022-04-06 03:40:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:39 --> URI Class Initialized
DEBUG - 2022-04-06 03:40:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:39 --> Router Class Initialized
INFO - 2022-04-06 03:40:39 --> URI Class Initialized
INFO - 2022-04-06 03:40:39 --> Output Class Initialized
INFO - 2022-04-06 03:40:39 --> Router Class Initialized
INFO - 2022-04-06 03:40:39 --> Security Class Initialized
INFO - 2022-04-06 03:40:39 --> Output Class Initialized
DEBUG - 2022-04-06 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:39 --> Input Class Initialized
INFO - 2022-04-06 03:40:39 --> Language Class Initialized
INFO - 2022-04-06 03:40:39 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:39 --> Input Class Initialized
INFO - 2022-04-06 03:40:39 --> Language Class Initialized
ERROR - 2022-04-06 03:40:39 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:40:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:39 --> Config Class Initialized
INFO - 2022-04-06 03:40:39 --> Config Class Initialized
INFO - 2022-04-06 03:40:39 --> Hooks Class Initialized
INFO - 2022-04-06 03:40:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:40:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:39 --> URI Class Initialized
INFO - 2022-04-06 03:40:39 --> URI Class Initialized
INFO - 2022-04-06 03:40:39 --> Router Class Initialized
INFO - 2022-04-06 03:40:39 --> Router Class Initialized
INFO - 2022-04-06 03:40:39 --> Output Class Initialized
INFO - 2022-04-06 03:40:39 --> Output Class Initialized
INFO - 2022-04-06 03:40:39 --> Security Class Initialized
INFO - 2022-04-06 03:40:39 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:39 --> Input Class Initialized
INFO - 2022-04-06 03:40:39 --> Input Class Initialized
INFO - 2022-04-06 03:40:39 --> Language Class Initialized
INFO - 2022-04-06 03:40:39 --> Language Class Initialized
ERROR - 2022-04-06 03:40:39 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:40:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:43 --> Config Class Initialized
INFO - 2022-04-06 03:40:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:43 --> URI Class Initialized
INFO - 2022-04-06 03:40:43 --> Router Class Initialized
INFO - 2022-04-06 03:40:43 --> Output Class Initialized
INFO - 2022-04-06 03:40:43 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:43 --> Input Class Initialized
INFO - 2022-04-06 03:40:43 --> Language Class Initialized
INFO - 2022-04-06 03:40:43 --> Loader Class Initialized
INFO - 2022-04-06 03:40:43 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:43 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:43 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:43 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:43 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:43 --> Controller Class Initialized
INFO - 2022-04-06 03:40:43 --> Model Class Initialized
INFO - 2022-04-06 03:40:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:40:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:40:43 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:43 --> Total execution time: 0.0656
INFO - 2022-04-06 03:40:43 --> Config Class Initialized
INFO - 2022-04-06 03:40:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:40:43 --> Config Class Initialized
INFO - 2022-04-06 03:40:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:43 --> URI Class Initialized
DEBUG - 2022-04-06 03:40:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:43 --> Router Class Initialized
INFO - 2022-04-06 03:40:43 --> URI Class Initialized
INFO - 2022-04-06 03:40:43 --> Output Class Initialized
INFO - 2022-04-06 03:40:43 --> Router Class Initialized
INFO - 2022-04-06 03:40:43 --> Security Class Initialized
INFO - 2022-04-06 03:40:43 --> Output Class Initialized
DEBUG - 2022-04-06 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:43 --> Security Class Initialized
INFO - 2022-04-06 03:40:43 --> Input Class Initialized
DEBUG - 2022-04-06 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:43 --> Language Class Initialized
INFO - 2022-04-06 03:40:43 --> Input Class Initialized
INFO - 2022-04-06 03:40:43 --> Language Class Initialized
ERROR - 2022-04-06 03:40:43 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:40:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:43 --> Config Class Initialized
INFO - 2022-04-06 03:40:43 --> Config Class Initialized
INFO - 2022-04-06 03:40:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:40:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:40:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:43 --> URI Class Initialized
INFO - 2022-04-06 03:40:43 --> URI Class Initialized
INFO - 2022-04-06 03:40:43 --> Router Class Initialized
INFO - 2022-04-06 03:40:43 --> Router Class Initialized
INFO - 2022-04-06 03:40:43 --> Output Class Initialized
INFO - 2022-04-06 03:40:43 --> Output Class Initialized
INFO - 2022-04-06 03:40:43 --> Security Class Initialized
INFO - 2022-04-06 03:40:43 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:43 --> Input Class Initialized
INFO - 2022-04-06 03:40:43 --> Input Class Initialized
INFO - 2022-04-06 03:40:43 --> Language Class Initialized
INFO - 2022-04-06 03:40:43 --> Language Class Initialized
ERROR - 2022-04-06 03:40:43 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:40:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:45 --> Config Class Initialized
INFO - 2022-04-06 03:40:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:45 --> URI Class Initialized
INFO - 2022-04-06 03:40:45 --> Router Class Initialized
INFO - 2022-04-06 03:40:45 --> Output Class Initialized
INFO - 2022-04-06 03:40:45 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:45 --> Input Class Initialized
INFO - 2022-04-06 03:40:45 --> Language Class Initialized
INFO - 2022-04-06 03:40:45 --> Loader Class Initialized
INFO - 2022-04-06 03:40:45 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:45 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:45 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:45 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:45 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:45 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:45 --> Controller Class Initialized
INFO - 2022-04-06 03:40:45 --> Model Class Initialized
INFO - 2022-04-06 03:40:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:40:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:40:45 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:45 --> Total execution time: 0.0714
INFO - 2022-04-06 03:40:45 --> Config Class Initialized
INFO - 2022-04-06 03:40:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:45 --> URI Class Initialized
INFO - 2022-04-06 03:40:45 --> Router Class Initialized
INFO - 2022-04-06 03:40:45 --> Config Class Initialized
INFO - 2022-04-06 03:40:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:45 --> Config Class Initialized
INFO - 2022-04-06 03:40:45 --> Hooks Class Initialized
INFO - 2022-04-06 03:40:45 --> Config Class Initialized
INFO - 2022-04-06 03:40:45 --> Hooks Class Initialized
INFO - 2022-04-06 03:40:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:45 --> Output Class Initialized
DEBUG - 2022-04-06 03:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:40:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:45 --> URI Class Initialized
INFO - 2022-04-06 03:40:45 --> URI Class Initialized
INFO - 2022-04-06 03:40:45 --> URI Class Initialized
INFO - 2022-04-06 03:40:45 --> Router Class Initialized
INFO - 2022-04-06 03:40:45 --> Router Class Initialized
INFO - 2022-04-06 03:40:45 --> Security Class Initialized
INFO - 2022-04-06 03:40:45 --> Output Class Initialized
INFO - 2022-04-06 03:40:45 --> Output Class Initialized
DEBUG - 2022-04-06 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:45 --> Router Class Initialized
INFO - 2022-04-06 03:40:45 --> Input Class Initialized
INFO - 2022-04-06 03:40:45 --> Language Class Initialized
INFO - 2022-04-06 03:40:45 --> Security Class Initialized
INFO - 2022-04-06 03:40:45 --> Security Class Initialized
INFO - 2022-04-06 03:40:45 --> Output Class Initialized
DEBUG - 2022-04-06 03:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:45 --> Input Class Initialized
ERROR - 2022-04-06 03:40:45 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:45 --> Input Class Initialized
INFO - 2022-04-06 03:40:45 --> Security Class Initialized
INFO - 2022-04-06 03:40:45 --> Language Class Initialized
DEBUG - 2022-04-06 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:45 --> Input Class Initialized
INFO - 2022-04-06 03:40:45 --> Language Class Initialized
ERROR - 2022-04-06 03:40:45 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:45 --> Language Class Initialized
ERROR - 2022-04-06 03:40:45 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:40:45 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:40:48 --> Config Class Initialized
INFO - 2022-04-06 03:40:48 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:48 --> URI Class Initialized
INFO - 2022-04-06 03:40:48 --> Router Class Initialized
INFO - 2022-04-06 03:40:48 --> Output Class Initialized
INFO - 2022-04-06 03:40:48 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:48 --> Input Class Initialized
INFO - 2022-04-06 03:40:48 --> Language Class Initialized
INFO - 2022-04-06 03:40:48 --> Loader Class Initialized
INFO - 2022-04-06 03:40:48 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:48 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:48 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:48 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:48 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:48 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:48 --> Controller Class Initialized
INFO - 2022-04-06 03:40:48 --> Model Class Initialized
INFO - 2022-04-06 03:40:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:40:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:40:48 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:48 --> Total execution time: 0.0706
INFO - 2022-04-06 03:40:48 --> Config Class Initialized
INFO - 2022-04-06 03:40:48 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:48 --> URI Class Initialized
INFO - 2022-04-06 03:40:48 --> Router Class Initialized
INFO - 2022-04-06 03:40:48 --> Output Class Initialized
INFO - 2022-04-06 03:40:48 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:48 --> Input Class Initialized
INFO - 2022-04-06 03:40:48 --> Language Class Initialized
INFO - 2022-04-06 03:40:48 --> Loader Class Initialized
INFO - 2022-04-06 03:40:48 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:48 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:48 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:48 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:48 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:48 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:48 --> Controller Class Initialized
INFO - 2022-04-06 03:40:48 --> Model Class Initialized
INFO - 2022-04-06 03:40:48 --> Model Class Initialized
INFO - 2022-04-06 03:40:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:40:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:40:48 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:48 --> Total execution time: 0.0652
INFO - 2022-04-06 03:40:50 --> Config Class Initialized
INFO - 2022-04-06 03:40:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:50 --> URI Class Initialized
INFO - 2022-04-06 03:40:50 --> Router Class Initialized
INFO - 2022-04-06 03:40:50 --> Output Class Initialized
INFO - 2022-04-06 03:40:50 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:50 --> Input Class Initialized
INFO - 2022-04-06 03:40:50 --> Language Class Initialized
INFO - 2022-04-06 03:40:50 --> Loader Class Initialized
INFO - 2022-04-06 03:40:50 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:50 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:50 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:50 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:50 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:50 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:50 --> Controller Class Initialized
INFO - 2022-04-06 03:40:50 --> Model Class Initialized
INFO - 2022-04-06 03:40:50 --> Model Class Initialized
INFO - 2022-04-06 03:40:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:40:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:40:50 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:50 --> Total execution time: 0.0733
INFO - 2022-04-06 03:40:51 --> Config Class Initialized
INFO - 2022-04-06 03:40:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:51 --> URI Class Initialized
INFO - 2022-04-06 03:40:51 --> Router Class Initialized
INFO - 2022-04-06 03:40:51 --> Output Class Initialized
INFO - 2022-04-06 03:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:52 --> Input Class Initialized
INFO - 2022-04-06 03:40:52 --> Language Class Initialized
INFO - 2022-04-06 03:40:52 --> Loader Class Initialized
INFO - 2022-04-06 03:40:52 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:52 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:52 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:52 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:52 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:52 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:52 --> Controller Class Initialized
INFO - 2022-04-06 03:40:52 --> Model Class Initialized
INFO - 2022-04-06 03:40:52 --> Model Class Initialized
INFO - 2022-04-06 03:40:52 --> Config Class Initialized
INFO - 2022-04-06 03:40:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:40:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:40:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:40:52 --> URI Class Initialized
INFO - 2022-04-06 03:40:52 --> Router Class Initialized
INFO - 2022-04-06 03:40:52 --> Output Class Initialized
INFO - 2022-04-06 03:40:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:40:52 --> Input Class Initialized
INFO - 2022-04-06 03:40:52 --> Language Class Initialized
INFO - 2022-04-06 03:40:52 --> Loader Class Initialized
INFO - 2022-04-06 03:40:52 --> Helper loaded: url_helper
INFO - 2022-04-06 03:40:52 --> Helper loaded: form_helper
INFO - 2022-04-06 03:40:52 --> Helper loaded: common_helper
INFO - 2022-04-06 03:40:52 --> Helper loaded: util_helper
INFO - 2022-04-06 03:40:52 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:40:52 --> Form Validation Class Initialized
INFO - 2022-04-06 03:40:52 --> Controller Class Initialized
INFO - 2022-04-06 03:40:52 --> Model Class Initialized
INFO - 2022-04-06 03:40:52 --> Model Class Initialized
INFO - 2022-04-06 03:40:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:40:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:40:52 --> Final output sent to browser
DEBUG - 2022-04-06 03:40:52 --> Total execution time: 0.0813
INFO - 2022-04-06 03:41:18 --> Config Class Initialized
INFO - 2022-04-06 03:41:18 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:18 --> URI Class Initialized
DEBUG - 2022-04-06 03:41:18 --> No URI present. Default controller set.
INFO - 2022-04-06 03:41:18 --> Router Class Initialized
INFO - 2022-04-06 03:41:18 --> Output Class Initialized
INFO - 2022-04-06 03:41:18 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:18 --> Input Class Initialized
INFO - 2022-04-06 03:41:18 --> Language Class Initialized
INFO - 2022-04-06 03:41:18 --> Loader Class Initialized
INFO - 2022-04-06 03:41:18 --> Helper loaded: url_helper
INFO - 2022-04-06 03:41:18 --> Helper loaded: form_helper
INFO - 2022-04-06 03:41:18 --> Helper loaded: common_helper
INFO - 2022-04-06 03:41:18 --> Helper loaded: util_helper
INFO - 2022-04-06 03:41:18 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:41:18 --> Form Validation Class Initialized
INFO - 2022-04-06 03:41:18 --> Controller Class Initialized
INFO - 2022-04-06 03:41:18 --> Model Class Initialized
INFO - 2022-04-06 03:41:18 --> Model Class Initialized
INFO - 2022-04-06 03:41:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:41:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:41:18 --> Final output sent to browser
DEBUG - 2022-04-06 03:41:18 --> Total execution time: 0.0832
INFO - 2022-04-06 03:41:19 --> Config Class Initialized
INFO - 2022-04-06 03:41:19 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:19 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:19 --> URI Class Initialized
INFO - 2022-04-06 03:41:19 --> Router Class Initialized
INFO - 2022-04-06 03:41:19 --> Output Class Initialized
INFO - 2022-04-06 03:41:19 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:19 --> Input Class Initialized
INFO - 2022-04-06 03:41:19 --> Language Class Initialized
ERROR - 2022-04-06 03:41:19 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
DEBUG - 2022-04-06 03:41:22 --> No URI present. Default controller set.
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
INFO - 2022-04-06 03:41:22 --> Loader Class Initialized
INFO - 2022-04-06 03:41:22 --> Helper loaded: url_helper
INFO - 2022-04-06 03:41:22 --> Helper loaded: form_helper
INFO - 2022-04-06 03:41:22 --> Helper loaded: common_helper
INFO - 2022-04-06 03:41:22 --> Helper loaded: util_helper
INFO - 2022-04-06 03:41:22 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:41:22 --> Form Validation Class Initialized
INFO - 2022-04-06 03:41:22 --> Controller Class Initialized
INFO - 2022-04-06 03:41:22 --> Model Class Initialized
INFO - 2022-04-06 03:41:22 --> Model Class Initialized
INFO - 2022-04-06 03:41:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:41:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:41:22 --> Final output sent to browser
DEBUG - 2022-04-06 03:41:22 --> Total execution time: 0.0653
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
INFO - 2022-04-06 03:41:22 --> Config Class Initialized
INFO - 2022-04-06 03:41:22 --> Hooks Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:41:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:22 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:22 --> URI Class Initialized
INFO - 2022-04-06 03:41:22 --> Router Class Initialized
INFO - 2022-04-06 03:41:22 --> Output Class Initialized
INFO - 2022-04-06 03:41:22 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:22 --> Input Class Initialized
INFO - 2022-04-06 03:41:22 --> Language Class Initialized
ERROR - 2022-04-06 03:41:22 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:41:28 --> Config Class Initialized
INFO - 2022-04-06 03:41:28 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:28 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:28 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:28 --> URI Class Initialized
INFO - 2022-04-06 03:41:28 --> Router Class Initialized
INFO - 2022-04-06 03:41:28 --> Output Class Initialized
INFO - 2022-04-06 03:41:28 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:28 --> Input Class Initialized
INFO - 2022-04-06 03:41:28 --> Language Class Initialized
ERROR - 2022-04-06 03:41:28 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
INFO - 2022-04-06 03:41:43 --> Loader Class Initialized
INFO - 2022-04-06 03:41:43 --> Helper loaded: url_helper
INFO - 2022-04-06 03:41:43 --> Helper loaded: form_helper
INFO - 2022-04-06 03:41:43 --> Helper loaded: common_helper
INFO - 2022-04-06 03:41:43 --> Helper loaded: util_helper
INFO - 2022-04-06 03:41:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:41:43 --> Form Validation Class Initialized
INFO - 2022-04-06 03:41:43 --> Controller Class Initialized
INFO - 2022-04-06 03:41:43 --> Model Class Initialized
INFO - 2022-04-06 03:41:43 --> Model Class Initialized
INFO - 2022-04-06 03:41:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:41:43 --> Final output sent to browser
DEBUG - 2022-04-06 03:41:43 --> Total execution time: 0.0582
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
INFO - 2022-04-06 03:41:43 --> Config Class Initialized
INFO - 2022-04-06 03:41:43 --> Hooks Class Initialized
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
DEBUG - 2022-04-06 03:41:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
INFO - 2022-04-06 03:41:43 --> Utf8 Class Initialized
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> URI Class Initialized
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:41:43 --> Router Class Initialized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
INFO - 2022-04-06 03:41:43 --> Output Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
INFO - 2022-04-06 03:41:43 --> Security Class Initialized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
INFO - 2022-04-06 03:41:43 --> Input Class Initialized
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
INFO - 2022-04-06 03:41:43 --> Language Class Initialized
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:41:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:09 --> Config Class Initialized
INFO - 2022-04-06 03:42:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:09 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:09 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:09 --> No URI present. Default controller set.
INFO - 2022-04-06 03:42:09 --> Router Class Initialized
INFO - 2022-04-06 03:42:09 --> Output Class Initialized
INFO - 2022-04-06 03:42:09 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:09 --> Input Class Initialized
INFO - 2022-04-06 03:42:09 --> Language Class Initialized
INFO - 2022-04-06 03:42:09 --> Loader Class Initialized
INFO - 2022-04-06 03:42:09 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:09 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:09 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:09 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:09 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:09 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:09 --> Controller Class Initialized
INFO - 2022-04-06 03:42:09 --> Model Class Initialized
INFO - 2022-04-06 03:42:09 --> Model Class Initialized
INFO - 2022-04-06 03:42:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:42:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:42:09 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:09 --> Total execution time: 0.0780
INFO - 2022-04-06 03:42:09 --> Config Class Initialized
INFO - 2022-04-06 03:42:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:09 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:09 --> URI Class Initialized
INFO - 2022-04-06 03:42:09 --> Config Class Initialized
INFO - 2022-04-06 03:42:09 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:09 --> Router Class Initialized
INFO - 2022-04-06 03:42:09 --> Output Class Initialized
INFO - 2022-04-06 03:42:09 --> Config Class Initialized
INFO - 2022-04-06 03:42:09 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:09 --> Config Class Initialized
INFO - 2022-04-06 03:42:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:09 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:09 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:09 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:09 --> Router Class Initialized
INFO - 2022-04-06 03:42:09 --> URI Class Initialized
INFO - 2022-04-06 03:42:09 --> Output Class Initialized
INFO - 2022-04-06 03:42:09 --> Router Class Initialized
INFO - 2022-04-06 03:42:09 --> Security Class Initialized
INFO - 2022-04-06 03:42:09 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:09 --> Output Class Initialized
INFO - 2022-04-06 03:42:09 --> Input Class Initialized
INFO - 2022-04-06 03:42:09 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:09 --> Security Class Initialized
INFO - 2022-04-06 03:42:09 --> Input Class Initialized
INFO - 2022-04-06 03:42:09 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:09 --> Input Class Initialized
INFO - 2022-04-06 03:42:09 --> Language Class Initialized
ERROR - 2022-04-06 03:42:09 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:09 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:42:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:09 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:42:09 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:09 --> URI Class Initialized
INFO - 2022-04-06 03:42:09 --> Router Class Initialized
INFO - 2022-04-06 03:42:09 --> Output Class Initialized
INFO - 2022-04-06 03:42:09 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:09 --> Input Class Initialized
INFO - 2022-04-06 03:42:09 --> Language Class Initialized
ERROR - 2022-04-06 03:42:09 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:13 --> No URI present. Default controller set.
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
INFO - 2022-04-06 03:42:13 --> Loader Class Initialized
INFO - 2022-04-06 03:42:13 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:13 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:13 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:13 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:13 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:13 --> Controller Class Initialized
INFO - 2022-04-06 03:42:13 --> Model Class Initialized
INFO - 2022-04-06 03:42:13 --> Model Class Initialized
INFO - 2022-04-06 03:42:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:42:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:42:13 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:13 --> Total execution time: 0.0589
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
INFO - 2022-04-06 03:42:13 --> Config Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> URI Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:13 --> Router Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Output Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
INFO - 2022-04-06 03:42:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
DEBUG - 2022-04-06 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
INFO - 2022-04-06 03:42:13 --> Input Class Initialized
INFO - 2022-04-06 03:42:13 --> Language Class Initialized
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:42:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
INFO - 2022-04-06 03:42:17 --> Loader Class Initialized
INFO - 2022-04-06 03:42:17 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:17 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:17 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:17 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:17 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:17 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:17 --> Controller Class Initialized
INFO - 2022-04-06 03:42:17 --> Model Class Initialized
INFO - 2022-04-06 03:42:17 --> Model Class Initialized
INFO - 2022-04-06 03:42:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:42:17 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:17 --> Total execution time: 0.0566
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:17 --> Config Class Initialized
INFO - 2022-04-06 03:42:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:17 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:17 --> URI Class Initialized
INFO - 2022-04-06 03:42:17 --> Router Class Initialized
INFO - 2022-04-06 03:42:17 --> Output Class Initialized
INFO - 2022-04-06 03:42:17 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:17 --> Input Class Initialized
INFO - 2022-04-06 03:42:17 --> Language Class Initialized
ERROR - 2022-04-06 03:42:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
INFO - 2022-04-06 03:42:44 --> Loader Class Initialized
INFO - 2022-04-06 03:42:44 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:44 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:44 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:44 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:44 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:44 --> Controller Class Initialized
INFO - 2022-04-06 03:42:44 --> Model Class Initialized
INFO - 2022-04-06 03:42:44 --> Model Class Initialized
INFO - 2022-04-06 03:42:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:42:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:42:44 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:44 --> Total execution time: 0.2094
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:44 --> Config Class Initialized
INFO - 2022-04-06 03:42:44 --> Hooks Class Initialized
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:44 --> URI Class Initialized
INFO - 2022-04-06 03:42:44 --> Router Class Initialized
INFO - 2022-04-06 03:42:44 --> Output Class Initialized
INFO - 2022-04-06 03:42:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:44 --> Input Class Initialized
INFO - 2022-04-06 03:42:44 --> Language Class Initialized
ERROR - 2022-04-06 03:42:44 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:51 --> Config Class Initialized
INFO - 2022-04-06 03:42:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:51 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:51 --> URI Class Initialized
INFO - 2022-04-06 03:42:51 --> Router Class Initialized
INFO - 2022-04-06 03:42:51 --> Output Class Initialized
INFO - 2022-04-06 03:42:51 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:51 --> Input Class Initialized
INFO - 2022-04-06 03:42:51 --> Language Class Initialized
INFO - 2022-04-06 03:42:51 --> Loader Class Initialized
INFO - 2022-04-06 03:42:51 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:51 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:51 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:51 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:51 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:51 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:51 --> Controller Class Initialized
INFO - 2022-04-06 03:42:51 --> Model Class Initialized
INFO - 2022-04-06 03:42:51 --> Model Class Initialized
INFO - 2022-04-06 03:42:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:42:51 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:51 --> Total execution time: 0.0837
INFO - 2022-04-06 03:42:52 --> Config Class Initialized
INFO - 2022-04-06 03:42:52 --> Config Class Initialized
INFO - 2022-04-06 03:42:52 --> Config Class Initialized
INFO - 2022-04-06 03:42:52 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:52 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:52 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:52 --> Config Class Initialized
INFO - 2022-04-06 03:42:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:52 --> URI Class Initialized
INFO - 2022-04-06 03:42:52 --> URI Class Initialized
INFO - 2022-04-06 03:42:52 --> URI Class Initialized
INFO - 2022-04-06 03:42:52 --> URI Class Initialized
INFO - 2022-04-06 03:42:52 --> Router Class Initialized
INFO - 2022-04-06 03:42:52 --> Router Class Initialized
INFO - 2022-04-06 03:42:52 --> Router Class Initialized
INFO - 2022-04-06 03:42:52 --> Router Class Initialized
INFO - 2022-04-06 03:42:52 --> Output Class Initialized
INFO - 2022-04-06 03:42:52 --> Output Class Initialized
INFO - 2022-04-06 03:42:52 --> Output Class Initialized
INFO - 2022-04-06 03:42:52 --> Security Class Initialized
INFO - 2022-04-06 03:42:52 --> Output Class Initialized
INFO - 2022-04-06 03:42:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:52 --> Security Class Initialized
INFO - 2022-04-06 03:42:52 --> Security Class Initialized
INFO - 2022-04-06 03:42:52 --> Input Class Initialized
DEBUG - 2022-04-06 03:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:52 --> Input Class Initialized
INFO - 2022-04-06 03:42:52 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:52 --> Language Class Initialized
INFO - 2022-04-06 03:42:52 --> Input Class Initialized
INFO - 2022-04-06 03:42:52 --> Language Class Initialized
ERROR - 2022-04-06 03:42:52 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:52 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:52 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:52 --> Input Class Initialized
INFO - 2022-04-06 03:42:52 --> Language Class Initialized
ERROR - 2022-04-06 03:42:52 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:53 --> Config Class Initialized
INFO - 2022-04-06 03:42:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:53 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:53 --> No URI present. Default controller set.
INFO - 2022-04-06 03:42:53 --> Router Class Initialized
INFO - 2022-04-06 03:42:53 --> Output Class Initialized
INFO - 2022-04-06 03:42:53 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:53 --> Input Class Initialized
INFO - 2022-04-06 03:42:53 --> Language Class Initialized
INFO - 2022-04-06 03:42:53 --> Loader Class Initialized
INFO - 2022-04-06 03:42:53 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:53 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:53 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:53 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:53 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:53 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:53 --> Controller Class Initialized
INFO - 2022-04-06 03:42:53 --> Model Class Initialized
INFO - 2022-04-06 03:42:53 --> Model Class Initialized
INFO - 2022-04-06 03:42:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:42:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:42:53 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:53 --> Total execution time: 0.1011
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
INFO - 2022-04-06 03:42:58 --> Loader Class Initialized
INFO - 2022-04-06 03:42:58 --> Helper loaded: url_helper
INFO - 2022-04-06 03:42:58 --> Helper loaded: form_helper
INFO - 2022-04-06 03:42:58 --> Helper loaded: common_helper
INFO - 2022-04-06 03:42:58 --> Helper loaded: util_helper
INFO - 2022-04-06 03:42:58 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:42:58 --> Form Validation Class Initialized
INFO - 2022-04-06 03:42:58 --> Controller Class Initialized
INFO - 2022-04-06 03:42:58 --> Model Class Initialized
INFO - 2022-04-06 03:42:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:42:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:42:58 --> Final output sent to browser
DEBUG - 2022-04-06 03:42:58 --> Total execution time: 0.0725
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Config Class Initialized
INFO - 2022-04-06 03:42:58 --> Hooks Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
DEBUG - 2022-04-06 03:42:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:42:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:42:58 --> URI Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:42:58 --> Router Class Initialized
INFO - 2022-04-06 03:42:58 --> Output Class Initialized
INFO - 2022-04-06 03:42:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:42:58 --> Input Class Initialized
INFO - 2022-04-06 03:42:58 --> Language Class Initialized
ERROR - 2022-04-06 03:42:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
INFO - 2022-04-06 03:43:00 --> Loader Class Initialized
INFO - 2022-04-06 03:43:00 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:00 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:00 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:00 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:00 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:00 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:00 --> Controller Class Initialized
INFO - 2022-04-06 03:43:00 --> Model Class Initialized
INFO - 2022-04-06 03:43:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:43:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:43:00 --> Final output sent to browser
DEBUG - 2022-04-06 03:43:00 --> Total execution time: 0.0669
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Config Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
DEBUG - 2022-04-06 03:43:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> URI Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
INFO - 2022-04-06 03:43:00 --> Router Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> Output Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
INFO - 2022-04-06 03:43:00 --> Security Class Initialized
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
DEBUG - 2022-04-06 03:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:00 --> Input Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:43:00 --> Language Class Initialized
ERROR - 2022-04-06 03:43:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:43:26 --> Config Class Initialized
INFO - 2022-04-06 03:43:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:26 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:26 --> URI Class Initialized
INFO - 2022-04-06 03:43:26 --> Router Class Initialized
INFO - 2022-04-06 03:43:26 --> Output Class Initialized
INFO - 2022-04-06 03:43:26 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:26 --> Input Class Initialized
INFO - 2022-04-06 03:43:26 --> Language Class Initialized
INFO - 2022-04-06 03:43:26 --> Loader Class Initialized
INFO - 2022-04-06 03:43:26 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:26 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:26 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:26 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:26 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:26 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:26 --> Controller Class Initialized
INFO - 2022-04-06 03:43:26 --> Model Class Initialized
INFO - 2022-04-06 03:43:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:43:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:43:26 --> Final output sent to browser
DEBUG - 2022-04-06 03:43:26 --> Total execution time: 0.0629
INFO - 2022-04-06 03:43:28 --> Config Class Initialized
INFO - 2022-04-06 03:43:28 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:28 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:28 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:28 --> URI Class Initialized
INFO - 2022-04-06 03:43:28 --> Router Class Initialized
INFO - 2022-04-06 03:43:28 --> Output Class Initialized
INFO - 2022-04-06 03:43:28 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:28 --> Input Class Initialized
INFO - 2022-04-06 03:43:28 --> Language Class Initialized
INFO - 2022-04-06 03:43:28 --> Loader Class Initialized
INFO - 2022-04-06 03:43:28 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:28 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:28 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:28 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:28 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:28 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:28 --> Controller Class Initialized
INFO - 2022-04-06 03:43:28 --> Model Class Initialized
INFO - 2022-04-06 03:43:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:43:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:43:28 --> Final output sent to browser
DEBUG - 2022-04-06 03:43:28 --> Total execution time: 0.0722
INFO - 2022-04-06 03:43:36 --> Config Class Initialized
INFO - 2022-04-06 03:43:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:36 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:36 --> URI Class Initialized
INFO - 2022-04-06 03:43:36 --> Router Class Initialized
INFO - 2022-04-06 03:43:36 --> Output Class Initialized
INFO - 2022-04-06 03:43:36 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:36 --> Input Class Initialized
INFO - 2022-04-06 03:43:36 --> Language Class Initialized
INFO - 2022-04-06 03:43:36 --> Loader Class Initialized
INFO - 2022-04-06 03:43:36 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:36 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:36 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:36 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:36 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:36 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:36 --> Controller Class Initialized
INFO - 2022-04-06 03:43:36 --> Model Class Initialized
INFO - 2022-04-06 03:43:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:43:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:43:36 --> Final output sent to browser
DEBUG - 2022-04-06 03:43:36 --> Total execution time: 0.0605
INFO - 2022-04-06 03:43:40 --> Config Class Initialized
INFO - 2022-04-06 03:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:40 --> URI Class Initialized
INFO - 2022-04-06 03:43:40 --> Router Class Initialized
INFO - 2022-04-06 03:43:40 --> Output Class Initialized
INFO - 2022-04-06 03:43:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:40 --> Input Class Initialized
INFO - 2022-04-06 03:43:40 --> Language Class Initialized
INFO - 2022-04-06 03:43:40 --> Loader Class Initialized
INFO - 2022-04-06 03:43:40 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:40 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:40 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:40 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:40 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:40 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:40 --> Controller Class Initialized
INFO - 2022-04-06 03:43:40 --> Model Class Initialized
INFO - 2022-04-06 03:43:40 --> Model Class Initialized
INFO - 2022-04-06 03:43:40 --> Config Class Initialized
INFO - 2022-04-06 03:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:40 --> URI Class Initialized
INFO - 2022-04-06 03:43:40 --> Router Class Initialized
INFO - 2022-04-06 03:43:40 --> Output Class Initialized
INFO - 2022-04-06 03:43:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:40 --> Input Class Initialized
INFO - 2022-04-06 03:43:40 --> Language Class Initialized
INFO - 2022-04-06 03:43:40 --> Loader Class Initialized
INFO - 2022-04-06 03:43:40 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:40 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:40 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:40 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:40 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:40 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:40 --> Controller Class Initialized
INFO - 2022-04-06 03:43:40 --> Model Class Initialized
INFO - 2022-04-06 03:43:41 --> Model Class Initialized
INFO - 2022-04-06 03:43:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:43:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:43:41 --> Final output sent to browser
DEBUG - 2022-04-06 03:43:41 --> Total execution time: 0.0665
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Config Class Initialized
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:41 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
DEBUG - 2022-04-06 03:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
INFO - 2022-04-06 03:43:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
INFO - 2022-04-06 03:43:41 --> URI Class Initialized
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
INFO - 2022-04-06 03:43:41 --> Router Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:43:41 --> Output Class Initialized
INFO - 2022-04-06 03:43:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:41 --> Input Class Initialized
INFO - 2022-04-06 03:43:41 --> Language Class Initialized
ERROR - 2022-04-06 03:43:41 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
INFO - 2022-04-06 03:43:46 --> Loader Class Initialized
INFO - 2022-04-06 03:43:46 --> Helper loaded: url_helper
INFO - 2022-04-06 03:43:46 --> Helper loaded: form_helper
INFO - 2022-04-06 03:43:46 --> Helper loaded: common_helper
INFO - 2022-04-06 03:43:46 --> Helper loaded: util_helper
INFO - 2022-04-06 03:43:46 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:43:46 --> Form Validation Class Initialized
INFO - 2022-04-06 03:43:46 --> Controller Class Initialized
INFO - 2022-04-06 03:43:46 --> Model Class Initialized
INFO - 2022-04-06 03:43:46 --> Model Class Initialized
INFO - 2022-04-06 03:43:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:43:46 --> Final output sent to browser
DEBUG - 2022-04-06 03:43:46 --> Total execution time: 0.0640
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> Config Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
INFO - 2022-04-06 03:43:46 --> URI Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:43:46 --> Router Class Initialized
INFO - 2022-04-06 03:43:46 --> Output Class Initialized
INFO - 2022-04-06 03:43:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:43:46 --> Input Class Initialized
INFO - 2022-04-06 03:43:46 --> Language Class Initialized
ERROR - 2022-04-06 03:43:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
INFO - 2022-04-06 03:44:10 --> Loader Class Initialized
INFO - 2022-04-06 03:44:10 --> Helper loaded: url_helper
INFO - 2022-04-06 03:44:10 --> Helper loaded: form_helper
INFO - 2022-04-06 03:44:10 --> Helper loaded: common_helper
INFO - 2022-04-06 03:44:10 --> Helper loaded: util_helper
INFO - 2022-04-06 03:44:10 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:44:10 --> Form Validation Class Initialized
INFO - 2022-04-06 03:44:10 --> Controller Class Initialized
INFO - 2022-04-06 03:44:10 --> Model Class Initialized
INFO - 2022-04-06 03:44:10 --> Model Class Initialized
INFO - 2022-04-06 03:44:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:44:10 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:44:10 --> Final output sent to browser
DEBUG - 2022-04-06 03:44:10 --> Total execution time: 0.1465
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Config Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> URI Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
INFO - 2022-04-06 03:44:10 --> Router Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Security Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:10 --> Input Class Initialized
INFO - 2022-04-06 03:44:10 --> Language Class Initialized
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:44:10 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:13 --> Config Class Initialized
INFO - 2022-04-06 03:44:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:13 --> URI Class Initialized
INFO - 2022-04-06 03:44:13 --> Router Class Initialized
INFO - 2022-04-06 03:44:13 --> Output Class Initialized
INFO - 2022-04-06 03:44:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:13 --> Input Class Initialized
INFO - 2022-04-06 03:44:13 --> Language Class Initialized
INFO - 2022-04-06 03:44:13 --> Loader Class Initialized
INFO - 2022-04-06 03:44:13 --> Helper loaded: url_helper
INFO - 2022-04-06 03:44:13 --> Helper loaded: form_helper
INFO - 2022-04-06 03:44:13 --> Helper loaded: common_helper
INFO - 2022-04-06 03:44:13 --> Helper loaded: util_helper
INFO - 2022-04-06 03:44:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:44:13 --> Form Validation Class Initialized
INFO - 2022-04-06 03:44:13 --> Controller Class Initialized
INFO - 2022-04-06 03:44:13 --> Model Class Initialized
INFO - 2022-04-06 03:44:13 --> Model Class Initialized
INFO - 2022-04-06 03:44:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:44:13 --> Final output sent to browser
DEBUG - 2022-04-06 03:44:13 --> Total execution time: 0.0930
INFO - 2022-04-06 03:44:13 --> Config Class Initialized
INFO - 2022-04-06 03:44:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:13 --> Config Class Initialized
INFO - 2022-04-06 03:44:13 --> Config Class Initialized
INFO - 2022-04-06 03:44:13 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:13 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:13 --> Router Class Initialized
INFO - 2022-04-06 03:44:13 --> URI Class Initialized
INFO - 2022-04-06 03:44:13 --> Output Class Initialized
INFO - 2022-04-06 03:44:13 --> Router Class Initialized
DEBUG - 2022-04-06 03:44:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:13 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:13 --> Security Class Initialized
INFO - 2022-04-06 03:44:13 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:13 --> URI Class Initialized
INFO - 2022-04-06 03:44:13 --> Input Class Initialized
INFO - 2022-04-06 03:44:13 --> Language Class Initialized
INFO - 2022-04-06 03:44:13 --> Router Class Initialized
ERROR - 2022-04-06 03:44:13 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:13 --> Output Class Initialized
INFO - 2022-04-06 03:44:13 --> Security Class Initialized
INFO - 2022-04-06 03:44:13 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:13 --> Input Class Initialized
INFO - 2022-04-06 03:44:13 --> Input Class Initialized
INFO - 2022-04-06 03:44:13 --> Language Class Initialized
INFO - 2022-04-06 03:44:13 --> Language Class Initialized
ERROR - 2022-04-06 03:44:13 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:44:13 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
INFO - 2022-04-06 03:44:25 --> Loader Class Initialized
INFO - 2022-04-06 03:44:25 --> Helper loaded: url_helper
INFO - 2022-04-06 03:44:25 --> Helper loaded: form_helper
INFO - 2022-04-06 03:44:25 --> Helper loaded: common_helper
INFO - 2022-04-06 03:44:25 --> Helper loaded: util_helper
INFO - 2022-04-06 03:44:25 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:44:25 --> Form Validation Class Initialized
INFO - 2022-04-06 03:44:25 --> Controller Class Initialized
INFO - 2022-04-06 03:44:25 --> Model Class Initialized
INFO - 2022-04-06 03:44:25 --> Model Class Initialized
INFO - 2022-04-06 03:44:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:44:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:44:25 --> Final output sent to browser
DEBUG - 2022-04-06 03:44:25 --> Total execution time: 0.1424
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:25 --> Config Class Initialized
INFO - 2022-04-06 03:44:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:25 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:25 --> URI Class Initialized
INFO - 2022-04-06 03:44:25 --> Router Class Initialized
INFO - 2022-04-06 03:44:25 --> Output Class Initialized
INFO - 2022-04-06 03:44:25 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:25 --> Input Class Initialized
INFO - 2022-04-06 03:44:25 --> Language Class Initialized
ERROR - 2022-04-06 03:44:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:27 --> Config Class Initialized
INFO - 2022-04-06 03:44:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:27 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:27 --> URI Class Initialized
INFO - 2022-04-06 03:44:27 --> Router Class Initialized
INFO - 2022-04-06 03:44:27 --> Output Class Initialized
INFO - 2022-04-06 03:44:27 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:27 --> Input Class Initialized
INFO - 2022-04-06 03:44:27 --> Language Class Initialized
INFO - 2022-04-06 03:44:27 --> Loader Class Initialized
INFO - 2022-04-06 03:44:27 --> Helper loaded: url_helper
INFO - 2022-04-06 03:44:27 --> Helper loaded: form_helper
INFO - 2022-04-06 03:44:27 --> Helper loaded: common_helper
INFO - 2022-04-06 03:44:27 --> Helper loaded: util_helper
INFO - 2022-04-06 03:44:27 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:44:27 --> Form Validation Class Initialized
INFO - 2022-04-06 03:44:27 --> Controller Class Initialized
INFO - 2022-04-06 03:44:27 --> Model Class Initialized
INFO - 2022-04-06 03:44:27 --> Model Class Initialized
INFO - 2022-04-06 03:44:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:44:27 --> Final output sent to browser
DEBUG - 2022-04-06 03:44:27 --> Total execution time: 0.0752
INFO - 2022-04-06 03:44:27 --> Config Class Initialized
INFO - 2022-04-06 03:44:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:27 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:27 --> URI Class Initialized
INFO - 2022-04-06 03:44:27 --> Router Class Initialized
INFO - 2022-04-06 03:44:27 --> Output Class Initialized
INFO - 2022-04-06 03:44:27 --> Config Class Initialized
INFO - 2022-04-06 03:44:27 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:27 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:27 --> Input Class Initialized
INFO - 2022-04-06 03:44:27 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:27 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:27 --> URI Class Initialized
ERROR - 2022-04-06 03:44:27 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:27 --> Router Class Initialized
INFO - 2022-04-06 03:44:27 --> Output Class Initialized
INFO - 2022-04-06 03:44:27 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:27 --> Input Class Initialized
INFO - 2022-04-06 03:44:27 --> Language Class Initialized
ERROR - 2022-04-06 03:44:27 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> Loader Class Initialized
INFO - 2022-04-06 03:44:37 --> Helper loaded: url_helper
INFO - 2022-04-06 03:44:37 --> Helper loaded: form_helper
INFO - 2022-04-06 03:44:37 --> Helper loaded: common_helper
INFO - 2022-04-06 03:44:37 --> Helper loaded: util_helper
INFO - 2022-04-06 03:44:37 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:44:37 --> Form Validation Class Initialized
INFO - 2022-04-06 03:44:37 --> Controller Class Initialized
INFO - 2022-04-06 03:44:37 --> Model Class Initialized
INFO - 2022-04-06 03:44:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:44:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:44:37 --> Final output sent to browser
DEBUG - 2022-04-06 03:44:37 --> Total execution time: 0.0606
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
INFO - 2022-04-06 03:44:37 --> Config Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> URI Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> Router Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
INFO - 2022-04-06 03:44:37 --> Output Class Initialized
INFO - 2022-04-06 03:44:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:37 --> Input Class Initialized
INFO - 2022-04-06 03:44:37 --> Language Class Initialized
ERROR - 2022-04-06 03:44:37 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Loader Class Initialized
INFO - 2022-04-06 03:44:40 --> Helper loaded: url_helper
INFO - 2022-04-06 03:44:40 --> Helper loaded: form_helper
INFO - 2022-04-06 03:44:40 --> Helper loaded: common_helper
INFO - 2022-04-06 03:44:40 --> Helper loaded: util_helper
INFO - 2022-04-06 03:44:40 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:44:40 --> Form Validation Class Initialized
INFO - 2022-04-06 03:44:40 --> Controller Class Initialized
INFO - 2022-04-06 03:44:40 --> Model Class Initialized
INFO - 2022-04-06 03:44:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:44:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:44:40 --> Final output sent to browser
DEBUG - 2022-04-06 03:44:40 --> Total execution time: 0.0572
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Config Class Initialized
INFO - 2022-04-06 03:44:40 --> Hooks Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:44:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:44:40 --> URI Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
INFO - 2022-04-06 03:44:40 --> Router Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
INFO - 2022-04-06 03:44:40 --> Output Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
INFO - 2022-04-06 03:44:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:44:40 --> Input Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:44:40 --> Language Class Initialized
ERROR - 2022-04-06 03:44:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
INFO - 2022-04-06 03:46:52 --> Loader Class Initialized
INFO - 2022-04-06 03:46:52 --> Helper loaded: url_helper
INFO - 2022-04-06 03:46:52 --> Helper loaded: form_helper
INFO - 2022-04-06 03:46:52 --> Helper loaded: common_helper
INFO - 2022-04-06 03:46:52 --> Helper loaded: util_helper
INFO - 2022-04-06 03:46:52 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:46:52 --> Form Validation Class Initialized
INFO - 2022-04-06 03:46:52 --> Controller Class Initialized
INFO - 2022-04-06 03:46:52 --> Model Class Initialized
INFO - 2022-04-06 03:46:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:46:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:46:52 --> Final output sent to browser
DEBUG - 2022-04-06 03:46:52 --> Total execution time: 0.3591
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:46:52 --> Config Class Initialized
INFO - 2022-04-06 03:46:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:46:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:46:52 --> Utf8 Class Initialized
INFO - 2022-04-06 03:46:52 --> URI Class Initialized
INFO - 2022-04-06 03:46:52 --> Router Class Initialized
INFO - 2022-04-06 03:46:52 --> Output Class Initialized
INFO - 2022-04-06 03:46:52 --> Security Class Initialized
DEBUG - 2022-04-06 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:46:52 --> Input Class Initialized
INFO - 2022-04-06 03:46:52 --> Language Class Initialized
ERROR - 2022-04-06 03:46:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:11 --> Config Class Initialized
INFO - 2022-04-06 03:48:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:11 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:11 --> URI Class Initialized
INFO - 2022-04-06 03:48:11 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Loader Class Initialized
INFO - 2022-04-06 03:48:12 --> Helper loaded: url_helper
INFO - 2022-04-06 03:48:12 --> Helper loaded: form_helper
INFO - 2022-04-06 03:48:12 --> Helper loaded: common_helper
INFO - 2022-04-06 03:48:12 --> Helper loaded: util_helper
INFO - 2022-04-06 03:48:12 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:48:12 --> Form Validation Class Initialized
INFO - 2022-04-06 03:48:12 --> Controller Class Initialized
INFO - 2022-04-06 03:48:12 --> Model Class Initialized
INFO - 2022-04-06 03:48:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:48:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:48:12 --> Final output sent to browser
DEBUG - 2022-04-06 03:48:12 --> Total execution time: 0.3280
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
INFO - 2022-04-06 03:48:12 --> Config Class Initialized
INFO - 2022-04-06 03:48:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
DEBUG - 2022-04-06 03:48:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:12 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:12 --> URI Class Initialized
INFO - 2022-04-06 03:48:12 --> Router Class Initialized
INFO - 2022-04-06 03:48:12 --> Output Class Initialized
INFO - 2022-04-06 03:48:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:12 --> Input Class Initialized
INFO - 2022-04-06 03:48:12 --> Language Class Initialized
ERROR - 2022-04-06 03:48:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:38 --> Config Class Initialized
INFO - 2022-04-06 03:48:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:38 --> URI Class Initialized
INFO - 2022-04-06 03:48:38 --> Router Class Initialized
INFO - 2022-04-06 03:48:38 --> Output Class Initialized
INFO - 2022-04-06 03:48:38 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:38 --> Input Class Initialized
INFO - 2022-04-06 03:48:38 --> Language Class Initialized
INFO - 2022-04-06 03:48:38 --> Loader Class Initialized
INFO - 2022-04-06 03:48:38 --> Helper loaded: url_helper
INFO - 2022-04-06 03:48:38 --> Helper loaded: form_helper
INFO - 2022-04-06 03:48:38 --> Helper loaded: common_helper
INFO - 2022-04-06 03:48:38 --> Helper loaded: util_helper
INFO - 2022-04-06 03:48:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:48:38 --> Form Validation Class Initialized
INFO - 2022-04-06 03:48:38 --> Controller Class Initialized
INFO - 2022-04-06 03:48:38 --> Model Class Initialized
INFO - 2022-04-06 03:48:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:48:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:48:38 --> Final output sent to browser
DEBUG - 2022-04-06 03:48:38 --> Total execution time: 0.0587
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
INFO - 2022-04-06 03:48:45 --> Loader Class Initialized
INFO - 2022-04-06 03:48:45 --> Helper loaded: url_helper
INFO - 2022-04-06 03:48:45 --> Helper loaded: form_helper
INFO - 2022-04-06 03:48:45 --> Helper loaded: common_helper
INFO - 2022-04-06 03:48:45 --> Helper loaded: util_helper
INFO - 2022-04-06 03:48:45 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:48:45 --> Form Validation Class Initialized
INFO - 2022-04-06 03:48:45 --> Controller Class Initialized
INFO - 2022-04-06 03:48:45 --> Model Class Initialized
INFO - 2022-04-06 03:48:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:48:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:48:45 --> Final output sent to browser
DEBUG - 2022-04-06 03:48:45 --> Total execution time: 0.0591
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
INFO - 2022-04-06 03:48:45 --> Router Class Initialized
INFO - 2022-04-06 03:48:45 --> Output Class Initialized
INFO - 2022-04-06 03:48:45 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:45 --> Input Class Initialized
INFO - 2022-04-06 03:48:45 --> Language Class Initialized
ERROR - 2022-04-06 03:48:45 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:48:45 --> Config Class Initialized
INFO - 2022-04-06 03:48:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:45 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:45 --> URI Class Initialized
INFO - 2022-04-06 03:48:46 --> Router Class Initialized
INFO - 2022-04-06 03:48:46 --> Output Class Initialized
INFO - 2022-04-06 03:48:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:46 --> Input Class Initialized
INFO - 2022-04-06 03:48:46 --> Language Class Initialized
ERROR - 2022-04-06 03:48:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:46 --> Config Class Initialized
INFO - 2022-04-06 03:48:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:46 --> URI Class Initialized
INFO - 2022-04-06 03:48:46 --> Router Class Initialized
INFO - 2022-04-06 03:48:46 --> Output Class Initialized
INFO - 2022-04-06 03:48:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:46 --> Input Class Initialized
INFO - 2022-04-06 03:48:46 --> Language Class Initialized
ERROR - 2022-04-06 03:48:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:46 --> Config Class Initialized
INFO - 2022-04-06 03:48:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:46 --> URI Class Initialized
INFO - 2022-04-06 03:48:46 --> Router Class Initialized
INFO - 2022-04-06 03:48:46 --> Output Class Initialized
INFO - 2022-04-06 03:48:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:46 --> Input Class Initialized
INFO - 2022-04-06 03:48:46 --> Language Class Initialized
ERROR - 2022-04-06 03:48:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:46 --> Config Class Initialized
INFO - 2022-04-06 03:48:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:46 --> URI Class Initialized
INFO - 2022-04-06 03:48:46 --> Router Class Initialized
INFO - 2022-04-06 03:48:46 --> Output Class Initialized
INFO - 2022-04-06 03:48:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:46 --> Input Class Initialized
INFO - 2022-04-06 03:48:46 --> Language Class Initialized
ERROR - 2022-04-06 03:48:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:48:56 --> Config Class Initialized
INFO - 2022-04-06 03:48:56 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:56 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:56 --> URI Class Initialized
INFO - 2022-04-06 03:48:56 --> Router Class Initialized
INFO - 2022-04-06 03:48:56 --> Output Class Initialized
INFO - 2022-04-06 03:48:56 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:56 --> Input Class Initialized
INFO - 2022-04-06 03:48:56 --> Language Class Initialized
INFO - 2022-04-06 03:48:56 --> Loader Class Initialized
INFO - 2022-04-06 03:48:56 --> Helper loaded: url_helper
INFO - 2022-04-06 03:48:56 --> Helper loaded: form_helper
INFO - 2022-04-06 03:48:56 --> Helper loaded: common_helper
INFO - 2022-04-06 03:48:56 --> Helper loaded: util_helper
INFO - 2022-04-06 03:48:56 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:48:56 --> Form Validation Class Initialized
INFO - 2022-04-06 03:48:56 --> Controller Class Initialized
INFO - 2022-04-06 03:48:56 --> Model Class Initialized
INFO - 2022-04-06 03:48:56 --> Model Class Initialized
INFO - 2022-04-06 03:48:56 --> Config Class Initialized
INFO - 2022-04-06 03:48:56 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:56 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:56 --> URI Class Initialized
INFO - 2022-04-06 03:48:56 --> Router Class Initialized
INFO - 2022-04-06 03:48:56 --> Output Class Initialized
INFO - 2022-04-06 03:48:56 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:56 --> Input Class Initialized
INFO - 2022-04-06 03:48:56 --> Language Class Initialized
INFO - 2022-04-06 03:48:56 --> Loader Class Initialized
INFO - 2022-04-06 03:48:56 --> Helper loaded: url_helper
INFO - 2022-04-06 03:48:56 --> Helper loaded: form_helper
INFO - 2022-04-06 03:48:56 --> Helper loaded: common_helper
INFO - 2022-04-06 03:48:56 --> Helper loaded: util_helper
INFO - 2022-04-06 03:48:56 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:48:56 --> Form Validation Class Initialized
INFO - 2022-04-06 03:48:56 --> Controller Class Initialized
INFO - 2022-04-06 03:48:56 --> Model Class Initialized
INFO - 2022-04-06 03:48:56 --> Model Class Initialized
INFO - 2022-04-06 03:48:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:48:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:48:56 --> Final output sent to browser
DEBUG - 2022-04-06 03:48:56 --> Total execution time: 0.0711
INFO - 2022-04-06 03:48:56 --> Config Class Initialized
INFO - 2022-04-06 03:48:56 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:56 --> Config Class Initialized
INFO - 2022-04-06 03:48:56 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:56 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:56 --> URI Class Initialized
DEBUG - 2022-04-06 03:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:56 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:56 --> Router Class Initialized
INFO - 2022-04-06 03:48:56 --> URI Class Initialized
INFO - 2022-04-06 03:48:56 --> Config Class Initialized
INFO - 2022-04-06 03:48:56 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:56 --> Output Class Initialized
INFO - 2022-04-06 03:48:56 --> Router Class Initialized
INFO - 2022-04-06 03:48:56 --> Security Class Initialized
DEBUG - 2022-04-06 03:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:56 --> Output Class Initialized
INFO - 2022-04-06 03:48:56 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:56 --> Input Class Initialized
INFO - 2022-04-06 03:48:56 --> Config Class Initialized
INFO - 2022-04-06 03:48:56 --> Security Class Initialized
INFO - 2022-04-06 03:48:56 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:56 --> URI Class Initialized
INFO - 2022-04-06 03:48:56 --> Language Class Initialized
DEBUG - 2022-04-06 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Router Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
DEBUG - 2022-04-06 03:48:57 --> UTF-8 Support Enabled
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:57 --> Output Class Initialized
INFO - 2022-04-06 03:48:57 --> URI Class Initialized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:57 --> Security Class Initialized
INFO - 2022-04-06 03:48:57 --> Router Class Initialized
DEBUG - 2022-04-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Output Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
INFO - 2022-04-06 03:48:57 --> Security Class Initialized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:48:57 --> Config Class Initialized
INFO - 2022-04-06 03:48:57 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:57 --> Config Class Initialized
INFO - 2022-04-06 03:48:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:57 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:48:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:57 --> URI Class Initialized
INFO - 2022-04-06 03:48:57 --> URI Class Initialized
INFO - 2022-04-06 03:48:57 --> Router Class Initialized
INFO - 2022-04-06 03:48:57 --> Router Class Initialized
INFO - 2022-04-06 03:48:57 --> Config Class Initialized
INFO - 2022-04-06 03:48:57 --> Hooks Class Initialized
INFO - 2022-04-06 03:48:57 --> Output Class Initialized
INFO - 2022-04-06 03:48:57 --> Output Class Initialized
INFO - 2022-04-06 03:48:57 --> Security Class Initialized
INFO - 2022-04-06 03:48:57 --> Config Class Initialized
INFO - 2022-04-06 03:48:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:48:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
DEBUG - 2022-04-06 03:48:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:48:57 --> URI Class Initialized
INFO - 2022-04-06 03:48:57 --> Security Class Initialized
INFO - 2022-04-06 03:48:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:48:57 --> URI Class Initialized
DEBUG - 2022-04-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:57 --> Router Class Initialized
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
INFO - 2022-04-06 03:48:57 --> Router Class Initialized
INFO - 2022-04-06 03:48:57 --> Output Class Initialized
INFO - 2022-04-06 03:48:57 --> Output Class Initialized
INFO - 2022-04-06 03:48:57 --> Security Class Initialized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:48:57 --> Security Class Initialized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
DEBUG - 2022-04-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:48:57 --> Input Class Initialized
INFO - 2022-04-06 03:48:57 --> Language Class Initialized
ERROR - 2022-04-06 03:48:57 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
INFO - 2022-04-06 03:49:10 --> Loader Class Initialized
INFO - 2022-04-06 03:49:10 --> Helper loaded: url_helper
INFO - 2022-04-06 03:49:10 --> Helper loaded: form_helper
INFO - 2022-04-06 03:49:10 --> Helper loaded: common_helper
INFO - 2022-04-06 03:49:10 --> Helper loaded: util_helper
INFO - 2022-04-06 03:49:10 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:49:10 --> Form Validation Class Initialized
INFO - 2022-04-06 03:49:10 --> Controller Class Initialized
INFO - 2022-04-06 03:49:10 --> Model Class Initialized
INFO - 2022-04-06 03:49:10 --> Model Class Initialized
INFO - 2022-04-06 03:49:10 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:49:10 --> Final output sent to browser
DEBUG - 2022-04-06 03:49:10 --> Total execution time: 0.0578
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> Config Class Initialized
INFO - 2022-04-06 03:49:10 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:49:10 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:10 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
INFO - 2022-04-06 03:49:10 --> URI Class Initialized
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
INFO - 2022-04-06 03:49:10 --> Router Class Initialized
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:49:10 --> Output Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> Security Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
DEBUG - 2022-04-06 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:10 --> Input Class Initialized
INFO - 2022-04-06 03:49:10 --> Language Class Initialized
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:49:10 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
INFO - 2022-04-06 03:49:34 --> Loader Class Initialized
INFO - 2022-04-06 03:49:34 --> Helper loaded: url_helper
INFO - 2022-04-06 03:49:34 --> Helper loaded: form_helper
INFO - 2022-04-06 03:49:34 --> Helper loaded: common_helper
INFO - 2022-04-06 03:49:34 --> Helper loaded: util_helper
INFO - 2022-04-06 03:49:34 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:49:34 --> Form Validation Class Initialized
INFO - 2022-04-06 03:49:34 --> Controller Class Initialized
INFO - 2022-04-06 03:49:34 --> Model Class Initialized
INFO - 2022-04-06 03:49:34 --> Model Class Initialized
INFO - 2022-04-06 03:49:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:49:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:49:34 --> Final output sent to browser
DEBUG - 2022-04-06 03:49:34 --> Total execution time: 0.1588
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:34 --> Config Class Initialized
INFO - 2022-04-06 03:49:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> URI Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
INFO - 2022-04-06 03:49:34 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Output Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
INFO - 2022-04-06 03:49:34 --> Security Class Initialized
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:34 --> Input Class Initialized
INFO - 2022-04-06 03:49:34 --> Language Class Initialized
ERROR - 2022-04-06 03:49:34 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:49:37 --> Config Class Initialized
INFO - 2022-04-06 03:49:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:37 --> URI Class Initialized
INFO - 2022-04-06 03:49:37 --> Router Class Initialized
INFO - 2022-04-06 03:49:37 --> Output Class Initialized
INFO - 2022-04-06 03:49:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:37 --> Input Class Initialized
INFO - 2022-04-06 03:49:37 --> Language Class Initialized
INFO - 2022-04-06 03:49:37 --> Loader Class Initialized
INFO - 2022-04-06 03:49:37 --> Helper loaded: url_helper
INFO - 2022-04-06 03:49:37 --> Helper loaded: form_helper
INFO - 2022-04-06 03:49:37 --> Helper loaded: common_helper
INFO - 2022-04-06 03:49:37 --> Helper loaded: util_helper
INFO - 2022-04-06 03:49:37 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:49:37 --> Form Validation Class Initialized
INFO - 2022-04-06 03:49:37 --> Controller Class Initialized
INFO - 2022-04-06 03:49:37 --> Model Class Initialized
INFO - 2022-04-06 03:49:37 --> Model Class Initialized
INFO - 2022-04-06 03:49:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:49:37 --> Final output sent to browser
DEBUG - 2022-04-06 03:49:37 --> Total execution time: 0.0668
INFO - 2022-04-06 03:49:37 --> Config Class Initialized
INFO - 2022-04-06 03:49:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:37 --> Config Class Initialized
INFO - 2022-04-06 03:49:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:37 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:49:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:37 --> URI Class Initialized
INFO - 2022-04-06 03:49:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:37 --> Config Class Initialized
INFO - 2022-04-06 03:49:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:37 --> Router Class Initialized
INFO - 2022-04-06 03:49:37 --> URI Class Initialized
DEBUG - 2022-04-06 03:49:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:37 --> Config Class Initialized
INFO - 2022-04-06 03:49:37 --> Hooks Class Initialized
INFO - 2022-04-06 03:49:37 --> Router Class Initialized
INFO - 2022-04-06 03:49:37 --> URI Class Initialized
INFO - 2022-04-06 03:49:37 --> Output Class Initialized
INFO - 2022-04-06 03:49:37 --> Router Class Initialized
DEBUG - 2022-04-06 03:49:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:37 --> Output Class Initialized
INFO - 2022-04-06 03:49:37 --> URI Class Initialized
INFO - 2022-04-06 03:49:37 --> Security Class Initialized
INFO - 2022-04-06 03:49:37 --> Output Class Initialized
INFO - 2022-04-06 03:49:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:37 --> Input Class Initialized
INFO - 2022-04-06 03:49:37 --> Router Class Initialized
INFO - 2022-04-06 03:49:37 --> Security Class Initialized
INFO - 2022-04-06 03:49:37 --> Language Class Initialized
INFO - 2022-04-06 03:49:37 --> Output Class Initialized
ERROR - 2022-04-06 03:49:37 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:37 --> Security Class Initialized
INFO - 2022-04-06 03:49:37 --> Input Class Initialized
INFO - 2022-04-06 03:49:37 --> Language Class Initialized
DEBUG - 2022-04-06 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:37 --> Input Class Initialized
INFO - 2022-04-06 03:49:37 --> Language Class Initialized
ERROR - 2022-04-06 03:49:37 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:37 --> Input Class Initialized
ERROR - 2022-04-06 03:49:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:49:37 --> Language Class Initialized
ERROR - 2022-04-06 03:49:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:49:37 --> Config Class Initialized
INFO - 2022-04-06 03:49:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:49:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:49:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:49:37 --> URI Class Initialized
INFO - 2022-04-06 03:49:37 --> Router Class Initialized
INFO - 2022-04-06 03:49:37 --> Output Class Initialized
INFO - 2022-04-06 03:49:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:49:37 --> Input Class Initialized
INFO - 2022-04-06 03:49:37 --> Language Class Initialized
ERROR - 2022-04-06 03:49:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
INFO - 2022-04-06 03:50:04 --> Loader Class Initialized
INFO - 2022-04-06 03:50:04 --> Helper loaded: url_helper
INFO - 2022-04-06 03:50:04 --> Helper loaded: form_helper
INFO - 2022-04-06 03:50:04 --> Helper loaded: common_helper
INFO - 2022-04-06 03:50:04 --> Helper loaded: util_helper
INFO - 2022-04-06 03:50:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:50:04 --> Form Validation Class Initialized
INFO - 2022-04-06 03:50:04 --> Controller Class Initialized
INFO - 2022-04-06 03:50:04 --> Model Class Initialized
INFO - 2022-04-06 03:50:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:50:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:50:04 --> Final output sent to browser
DEBUG - 2022-04-06 03:50:04 --> Total execution time: 0.0586
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:50:04 --> Config Class Initialized
INFO - 2022-04-06 03:50:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:50:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:50:04 --> Utf8 Class Initialized
INFO - 2022-04-06 03:50:04 --> URI Class Initialized
INFO - 2022-04-06 03:50:04 --> Router Class Initialized
INFO - 2022-04-06 03:50:04 --> Output Class Initialized
INFO - 2022-04-06 03:50:04 --> Security Class Initialized
DEBUG - 2022-04-06 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:50:04 --> Input Class Initialized
INFO - 2022-04-06 03:50:04 --> Language Class Initialized
ERROR - 2022-04-06 03:50:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:51:38 --> Config Class Initialized
INFO - 2022-04-06 03:51:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:38 --> URI Class Initialized
INFO - 2022-04-06 03:51:38 --> Router Class Initialized
INFO - 2022-04-06 03:51:38 --> Output Class Initialized
INFO - 2022-04-06 03:51:38 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:38 --> Input Class Initialized
INFO - 2022-04-06 03:51:38 --> Language Class Initialized
INFO - 2022-04-06 03:51:38 --> Loader Class Initialized
INFO - 2022-04-06 03:51:38 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:38 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:38 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:38 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:38 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:38 --> Controller Class Initialized
INFO - 2022-04-06 03:51:38 --> Model Class Initialized
INFO - 2022-04-06 03:51:38 --> Model Class Initialized
INFO - 2022-04-06 03:51:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:51:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:51:38 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:38 --> Total execution time: 0.0614
INFO - 2022-04-06 03:51:38 --> Config Class Initialized
INFO - 2022-04-06 03:51:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:38 --> URI Class Initialized
INFO - 2022-04-06 03:51:38 --> Config Class Initialized
INFO - 2022-04-06 03:51:38 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:38 --> Router Class Initialized
DEBUG - 2022-04-06 03:51:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:38 --> Output Class Initialized
INFO - 2022-04-06 03:51:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:38 --> Security Class Initialized
INFO - 2022-04-06 03:51:38 --> URI Class Initialized
DEBUG - 2022-04-06 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:38 --> Input Class Initialized
INFO - 2022-04-06 03:51:38 --> Language Class Initialized
INFO - 2022-04-06 03:51:38 --> Router Class Initialized
ERROR - 2022-04-06 03:51:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:51:38 --> Output Class Initialized
INFO - 2022-04-06 03:51:38 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:38 --> Input Class Initialized
INFO - 2022-04-06 03:51:38 --> Language Class Initialized
ERROR - 2022-04-06 03:51:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:51:38 --> Config Class Initialized
INFO - 2022-04-06 03:51:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:38 --> URI Class Initialized
INFO - 2022-04-06 03:51:38 --> Router Class Initialized
INFO - 2022-04-06 03:51:38 --> Output Class Initialized
INFO - 2022-04-06 03:51:38 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:38 --> Input Class Initialized
INFO - 2022-04-06 03:51:38 --> Language Class Initialized
INFO - 2022-04-06 03:51:38 --> Loader Class Initialized
INFO - 2022-04-06 03:51:38 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:38 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:38 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:38 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:38 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:38 --> Controller Class Initialized
INFO - 2022-04-06 03:51:38 --> Model Class Initialized
INFO - 2022-04-06 03:51:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:51:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:51:38 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:38 --> Total execution time: 0.0907
INFO - 2022-04-06 03:51:39 --> Config Class Initialized
INFO - 2022-04-06 03:51:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:39 --> URI Class Initialized
INFO - 2022-04-06 03:51:39 --> Router Class Initialized
INFO - 2022-04-06 03:51:39 --> Output Class Initialized
INFO - 2022-04-06 03:51:39 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:39 --> Input Class Initialized
INFO - 2022-04-06 03:51:39 --> Language Class Initialized
ERROR - 2022-04-06 03:51:39 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:51:39 --> Config Class Initialized
INFO - 2022-04-06 03:51:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:39 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:39 --> URI Class Initialized
INFO - 2022-04-06 03:51:39 --> Router Class Initialized
INFO - 2022-04-06 03:51:39 --> Output Class Initialized
INFO - 2022-04-06 03:51:39 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:39 --> Input Class Initialized
INFO - 2022-04-06 03:51:39 --> Language Class Initialized
INFO - 2022-04-06 03:51:39 --> Loader Class Initialized
INFO - 2022-04-06 03:51:39 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:39 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:39 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:39 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:39 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:39 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:39 --> Controller Class Initialized
INFO - 2022-04-06 03:51:39 --> Model Class Initialized
INFO - 2022-04-06 03:51:39 --> Model Class Initialized
INFO - 2022-04-06 03:51:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:51:39 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:39 --> Total execution time: 0.0554
INFO - 2022-04-06 03:51:40 --> Config Class Initialized
INFO - 2022-04-06 03:51:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:40 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:40 --> URI Class Initialized
INFO - 2022-04-06 03:51:40 --> Router Class Initialized
INFO - 2022-04-06 03:51:40 --> Output Class Initialized
INFO - 2022-04-06 03:51:40 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:40 --> Input Class Initialized
INFO - 2022-04-06 03:51:40 --> Language Class Initialized
INFO - 2022-04-06 03:51:40 --> Loader Class Initialized
INFO - 2022-04-06 03:51:40 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:40 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:40 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:40 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:40 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:40 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:40 --> Controller Class Initialized
INFO - 2022-04-06 03:51:40 --> Model Class Initialized
INFO - 2022-04-06 03:51:40 --> Model Class Initialized
INFO - 2022-04-06 03:51:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:51:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:51:40 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:40 --> Total execution time: 0.0590
INFO - 2022-04-06 03:51:41 --> Config Class Initialized
INFO - 2022-04-06 03:51:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:41 --> URI Class Initialized
INFO - 2022-04-06 03:51:41 --> Router Class Initialized
INFO - 2022-04-06 03:51:41 --> Output Class Initialized
INFO - 2022-04-06 03:51:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:41 --> Input Class Initialized
INFO - 2022-04-06 03:51:41 --> Language Class Initialized
INFO - 2022-04-06 03:51:41 --> Loader Class Initialized
INFO - 2022-04-06 03:51:41 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:41 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:41 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:41 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:41 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:41 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:41 --> Controller Class Initialized
INFO - 2022-04-06 03:51:41 --> Model Class Initialized
INFO - 2022-04-06 03:51:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:51:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:51:41 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:41 --> Total execution time: 0.0607
INFO - 2022-04-06 03:51:42 --> Config Class Initialized
INFO - 2022-04-06 03:51:42 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:42 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:42 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:42 --> URI Class Initialized
DEBUG - 2022-04-06 03:51:42 --> No URI present. Default controller set.
INFO - 2022-04-06 03:51:42 --> Router Class Initialized
INFO - 2022-04-06 03:51:42 --> Output Class Initialized
INFO - 2022-04-06 03:51:42 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:42 --> Input Class Initialized
INFO - 2022-04-06 03:51:42 --> Language Class Initialized
INFO - 2022-04-06 03:51:42 --> Loader Class Initialized
INFO - 2022-04-06 03:51:42 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:42 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:42 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:42 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:42 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:42 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:42 --> Controller Class Initialized
INFO - 2022-04-06 03:51:42 --> Model Class Initialized
INFO - 2022-04-06 03:51:42 --> Model Class Initialized
INFO - 2022-04-06 03:51:42 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:51:42 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:51:42 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:42 --> Total execution time: 0.0631
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
DEBUG - 2022-04-06 03:51:46 --> No URI present. Default controller set.
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
INFO - 2022-04-06 03:51:46 --> Loader Class Initialized
INFO - 2022-04-06 03:51:46 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:46 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:46 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:46 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:46 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:46 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:46 --> Controller Class Initialized
INFO - 2022-04-06 03:51:46 --> Model Class Initialized
INFO - 2022-04-06 03:51:46 --> Model Class Initialized
INFO - 2022-04-06 03:51:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:51:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:51:46 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:46 --> Total execution time: 0.0581
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
INFO - 2022-04-06 03:51:46 --> Config Class Initialized
INFO - 2022-04-06 03:51:46 --> Hooks Class Initialized
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:46 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:46 --> URI Class Initialized
INFO - 2022-04-06 03:51:46 --> Router Class Initialized
INFO - 2022-04-06 03:51:46 --> Output Class Initialized
INFO - 2022-04-06 03:51:46 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:46 --> Input Class Initialized
INFO - 2022-04-06 03:51:46 --> Language Class Initialized
ERROR - 2022-04-06 03:51:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
DEBUG - 2022-04-06 03:51:48 --> No URI present. Default controller set.
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
INFO - 2022-04-06 03:51:48 --> Loader Class Initialized
INFO - 2022-04-06 03:51:48 --> Helper loaded: url_helper
INFO - 2022-04-06 03:51:48 --> Helper loaded: form_helper
INFO - 2022-04-06 03:51:48 --> Helper loaded: common_helper
INFO - 2022-04-06 03:51:48 --> Helper loaded: util_helper
INFO - 2022-04-06 03:51:48 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:51:48 --> Form Validation Class Initialized
INFO - 2022-04-06 03:51:48 --> Controller Class Initialized
INFO - 2022-04-06 03:51:48 --> Model Class Initialized
INFO - 2022-04-06 03:51:48 --> Model Class Initialized
INFO - 2022-04-06 03:51:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:51:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:51:48 --> Final output sent to browser
DEBUG - 2022-04-06 03:51:48 --> Total execution time: 0.0681
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:51:48 --> Config Class Initialized
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> Hooks Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Utf8 Class Initialized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
INFO - 2022-04-06 03:51:48 --> URI Class Initialized
INFO - 2022-04-06 03:51:48 --> Router Class Initialized
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:51:48 --> Output Class Initialized
INFO - 2022-04-06 03:51:48 --> Security Class Initialized
DEBUG - 2022-04-06 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:51:48 --> Input Class Initialized
INFO - 2022-04-06 03:51:48 --> Language Class Initialized
ERROR - 2022-04-06 03:51:48 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:47 --> No URI present. Default controller set.
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
INFO - 2022-04-06 03:52:47 --> Loader Class Initialized
INFO - 2022-04-06 03:52:47 --> Helper loaded: url_helper
INFO - 2022-04-06 03:52:47 --> Helper loaded: form_helper
INFO - 2022-04-06 03:52:47 --> Helper loaded: common_helper
INFO - 2022-04-06 03:52:47 --> Helper loaded: util_helper
INFO - 2022-04-06 03:52:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:52:47 --> Form Validation Class Initialized
INFO - 2022-04-06 03:52:47 --> Controller Class Initialized
INFO - 2022-04-06 03:52:47 --> Model Class Initialized
INFO - 2022-04-06 03:52:47 --> Model Class Initialized
INFO - 2022-04-06 03:52:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:52:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:52:47 --> Final output sent to browser
DEBUG - 2022-04-06 03:52:47 --> Total execution time: 0.0854
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Config Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:47 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:52:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> URI Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
INFO - 2022-04-06 03:52:47 --> Router Class Initialized
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:47 --> Output Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
INFO - 2022-04-06 03:52:47 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
DEBUG - 2022-04-06 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
INFO - 2022-04-06 03:52:47 --> Input Class Initialized
INFO - 2022-04-06 03:52:47 --> Language Class Initialized
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:52:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:50 --> No URI present. Default controller set.
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Loader Class Initialized
INFO - 2022-04-06 03:52:50 --> Helper loaded: url_helper
INFO - 2022-04-06 03:52:50 --> Helper loaded: form_helper
INFO - 2022-04-06 03:52:50 --> Helper loaded: common_helper
INFO - 2022-04-06 03:52:50 --> Helper loaded: util_helper
INFO - 2022-04-06 03:52:50 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:52:50 --> Form Validation Class Initialized
INFO - 2022-04-06 03:52:50 --> Controller Class Initialized
INFO - 2022-04-06 03:52:50 --> Model Class Initialized
INFO - 2022-04-06 03:52:50 --> Model Class Initialized
INFO - 2022-04-06 03:52:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:52:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:52:50 --> Final output sent to browser
DEBUG - 2022-04-06 03:52:50 --> Total execution time: 0.0759
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:50 --> Config Class Initialized
INFO - 2022-04-06 03:52:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:52:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:50 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> URI Class Initialized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Router Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
INFO - 2022-04-06 03:52:50 --> Output Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
INFO - 2022-04-06 03:52:50 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Input Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
INFO - 2022-04-06 03:52:50 --> Language Class Initialized
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:52:50 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:53 --> No URI present. Default controller set.
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
INFO - 2022-04-06 03:52:53 --> Loader Class Initialized
INFO - 2022-04-06 03:52:53 --> Helper loaded: url_helper
INFO - 2022-04-06 03:52:53 --> Helper loaded: form_helper
INFO - 2022-04-06 03:52:53 --> Helper loaded: common_helper
INFO - 2022-04-06 03:52:53 --> Helper loaded: util_helper
INFO - 2022-04-06 03:52:53 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:52:53 --> Form Validation Class Initialized
INFO - 2022-04-06 03:52:53 --> Controller Class Initialized
INFO - 2022-04-06 03:52:53 --> Model Class Initialized
INFO - 2022-04-06 03:52:53 --> Model Class Initialized
INFO - 2022-04-06 03:52:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:52:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:52:53 --> Final output sent to browser
DEBUG - 2022-04-06 03:52:53 --> Total execution time: 0.0684
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
INFO - 2022-04-06 03:52:53 --> Config Class Initialized
INFO - 2022-04-06 03:52:53 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:52:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
INFO - 2022-04-06 03:52:53 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
INFO - 2022-04-06 03:52:53 --> Router Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
INFO - 2022-04-06 03:52:53 --> Output Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:53 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:53 --> Input Class Initialized
INFO - 2022-04-06 03:52:53 --> Language Class Initialized
ERROR - 2022-04-06 03:52:53 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
DEBUG - 2022-04-06 03:52:57 --> No URI present. Default controller set.
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
INFO - 2022-04-06 03:52:57 --> Loader Class Initialized
INFO - 2022-04-06 03:52:57 --> Helper loaded: url_helper
INFO - 2022-04-06 03:52:57 --> Helper loaded: form_helper
INFO - 2022-04-06 03:52:57 --> Helper loaded: common_helper
INFO - 2022-04-06 03:52:57 --> Helper loaded: util_helper
INFO - 2022-04-06 03:52:57 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:52:57 --> Form Validation Class Initialized
INFO - 2022-04-06 03:52:57 --> Controller Class Initialized
INFO - 2022-04-06 03:52:57 --> Model Class Initialized
INFO - 2022-04-06 03:52:57 --> Model Class Initialized
INFO - 2022-04-06 03:52:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:52:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:52:57 --> Final output sent to browser
DEBUG - 2022-04-06 03:52:57 --> Total execution time: 0.0725
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Config Class Initialized
INFO - 2022-04-06 03:52:57 --> Hooks Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
INFO - 2022-04-06 03:52:57 --> URI Class Initialized
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:52:57 --> Router Class Initialized
INFO - 2022-04-06 03:52:57 --> Output Class Initialized
INFO - 2022-04-06 03:52:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:57 --> Input Class Initialized
INFO - 2022-04-06 03:52:57 --> Language Class Initialized
ERROR - 2022-04-06 03:52:57 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 03:52:58 --> Config Class Initialized
INFO - 2022-04-06 03:52:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:52:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:52:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:52:58 --> URI Class Initialized
INFO - 2022-04-06 03:52:58 --> Router Class Initialized
INFO - 2022-04-06 03:52:58 --> Output Class Initialized
INFO - 2022-04-06 03:52:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:52:58 --> Input Class Initialized
INFO - 2022-04-06 03:52:58 --> Language Class Initialized
ERROR - 2022-04-06 03:52:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:53:55 --> Config Class Initialized
INFO - 2022-04-06 03:53:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:53:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:53:55 --> Utf8 Class Initialized
INFO - 2022-04-06 03:53:55 --> URI Class Initialized
DEBUG - 2022-04-06 03:53:55 --> No URI present. Default controller set.
INFO - 2022-04-06 03:53:55 --> Router Class Initialized
INFO - 2022-04-06 03:53:55 --> Output Class Initialized
INFO - 2022-04-06 03:53:55 --> Security Class Initialized
DEBUG - 2022-04-06 03:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:53:55 --> Input Class Initialized
INFO - 2022-04-06 03:53:55 --> Language Class Initialized
INFO - 2022-04-06 03:53:55 --> Loader Class Initialized
INFO - 2022-04-06 03:53:55 --> Helper loaded: url_helper
INFO - 2022-04-06 03:53:55 --> Helper loaded: form_helper
INFO - 2022-04-06 03:53:55 --> Helper loaded: common_helper
INFO - 2022-04-06 03:53:55 --> Helper loaded: util_helper
INFO - 2022-04-06 03:53:55 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:53:55 --> Form Validation Class Initialized
INFO - 2022-04-06 03:53:55 --> Controller Class Initialized
INFO - 2022-04-06 03:53:55 --> Model Class Initialized
INFO - 2022-04-06 03:53:55 --> Model Class Initialized
INFO - 2022-04-06 03:53:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:53:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:53:55 --> Final output sent to browser
DEBUG - 2022-04-06 03:53:55 --> Total execution time: 0.3560
INFO - 2022-04-06 03:53:57 --> Config Class Initialized
INFO - 2022-04-06 03:53:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:53:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:53:57 --> Utf8 Class Initialized
INFO - 2022-04-06 03:53:57 --> URI Class Initialized
INFO - 2022-04-06 03:53:57 --> Router Class Initialized
INFO - 2022-04-06 03:53:57 --> Output Class Initialized
INFO - 2022-04-06 03:53:57 --> Security Class Initialized
DEBUG - 2022-04-06 03:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:53:57 --> Input Class Initialized
INFO - 2022-04-06 03:53:57 --> Language Class Initialized
INFO - 2022-04-06 03:53:57 --> Loader Class Initialized
INFO - 2022-04-06 03:53:57 --> Helper loaded: url_helper
INFO - 2022-04-06 03:53:57 --> Helper loaded: form_helper
INFO - 2022-04-06 03:53:57 --> Helper loaded: common_helper
INFO - 2022-04-06 03:53:57 --> Helper loaded: util_helper
INFO - 2022-04-06 03:53:57 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:53:57 --> Form Validation Class Initialized
INFO - 2022-04-06 03:53:57 --> Controller Class Initialized
INFO - 2022-04-06 03:53:57 --> Model Class Initialized
INFO - 2022-04-06 03:53:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:53:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:53:57 --> Final output sent to browser
DEBUG - 2022-04-06 03:53:57 --> Total execution time: 0.0741
INFO - 2022-04-06 03:53:58 --> Config Class Initialized
INFO - 2022-04-06 03:53:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:53:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:53:58 --> Utf8 Class Initialized
INFO - 2022-04-06 03:53:58 --> URI Class Initialized
INFO - 2022-04-06 03:53:58 --> Router Class Initialized
INFO - 2022-04-06 03:53:58 --> Output Class Initialized
INFO - 2022-04-06 03:53:58 --> Security Class Initialized
DEBUG - 2022-04-06 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:53:58 --> Input Class Initialized
INFO - 2022-04-06 03:53:58 --> Language Class Initialized
INFO - 2022-04-06 03:53:58 --> Loader Class Initialized
INFO - 2022-04-06 03:53:58 --> Helper loaded: url_helper
INFO - 2022-04-06 03:53:58 --> Helper loaded: form_helper
INFO - 2022-04-06 03:53:58 --> Helper loaded: common_helper
INFO - 2022-04-06 03:53:58 --> Helper loaded: util_helper
INFO - 2022-04-06 03:53:58 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:53:58 --> Form Validation Class Initialized
INFO - 2022-04-06 03:53:58 --> Controller Class Initialized
INFO - 2022-04-06 03:53:58 --> Model Class Initialized
INFO - 2022-04-06 03:53:58 --> Model Class Initialized
INFO - 2022-04-06 03:53:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:53:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:53:58 --> Final output sent to browser
DEBUG - 2022-04-06 03:53:58 --> Total execution time: 0.0739
INFO - 2022-04-06 03:54:00 --> Config Class Initialized
INFO - 2022-04-06 03:54:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:00 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:00 --> URI Class Initialized
INFO - 2022-04-06 03:54:00 --> Router Class Initialized
INFO - 2022-04-06 03:54:00 --> Output Class Initialized
INFO - 2022-04-06 03:54:00 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:00 --> Input Class Initialized
INFO - 2022-04-06 03:54:00 --> Language Class Initialized
INFO - 2022-04-06 03:54:00 --> Loader Class Initialized
INFO - 2022-04-06 03:54:00 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:00 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:00 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:00 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:00 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:00 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:00 --> Controller Class Initialized
INFO - 2022-04-06 03:54:00 --> Model Class Initialized
INFO - 2022-04-06 03:54:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:54:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:54:00 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:00 --> Total execution time: 0.0717
INFO - 2022-04-06 03:54:02 --> Config Class Initialized
INFO - 2022-04-06 03:54:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:02 --> URI Class Initialized
INFO - 2022-04-06 03:54:02 --> Router Class Initialized
INFO - 2022-04-06 03:54:02 --> Output Class Initialized
INFO - 2022-04-06 03:54:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:02 --> Input Class Initialized
INFO - 2022-04-06 03:54:02 --> Language Class Initialized
INFO - 2022-04-06 03:54:02 --> Loader Class Initialized
INFO - 2022-04-06 03:54:02 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:02 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:02 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:02 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:02 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:02 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:02 --> Controller Class Initialized
INFO - 2022-04-06 03:54:02 --> Model Class Initialized
INFO - 2022-04-06 03:54:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:54:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:54:02 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:02 --> Total execution time: 0.0795
INFO - 2022-04-06 03:54:02 --> Config Class Initialized
INFO - 2022-04-06 03:54:02 --> Hooks Class Initialized
INFO - 2022-04-06 03:54:02 --> Config Class Initialized
INFO - 2022-04-06 03:54:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:02 --> URI Class Initialized
DEBUG - 2022-04-06 03:54:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:02 --> URI Class Initialized
INFO - 2022-04-06 03:54:02 --> Router Class Initialized
INFO - 2022-04-06 03:54:02 --> Router Class Initialized
INFO - 2022-04-06 03:54:02 --> Output Class Initialized
INFO - 2022-04-06 03:54:02 --> Output Class Initialized
INFO - 2022-04-06 03:54:02 --> Security Class Initialized
INFO - 2022-04-06 03:54:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:02 --> Input Class Initialized
INFO - 2022-04-06 03:54:02 --> Input Class Initialized
INFO - 2022-04-06 03:54:02 --> Language Class Initialized
INFO - 2022-04-06 03:54:02 --> Language Class Initialized
ERROR - 2022-04-06 03:54:02 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:54:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:54:02 --> Config Class Initialized
INFO - 2022-04-06 03:54:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:02 --> Config Class Initialized
INFO - 2022-04-06 03:54:02 --> Hooks Class Initialized
INFO - 2022-04-06 03:54:02 --> URI Class Initialized
INFO - 2022-04-06 03:54:02 --> Router Class Initialized
DEBUG - 2022-04-06 03:54:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:02 --> Output Class Initialized
INFO - 2022-04-06 03:54:02 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:02 --> URI Class Initialized
INFO - 2022-04-06 03:54:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:02 --> Router Class Initialized
INFO - 2022-04-06 03:54:02 --> Input Class Initialized
INFO - 2022-04-06 03:54:02 --> Language Class Initialized
INFO - 2022-04-06 03:54:02 --> Output Class Initialized
ERROR - 2022-04-06 03:54:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:54:02 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:02 --> Input Class Initialized
INFO - 2022-04-06 03:54:02 --> Language Class Initialized
ERROR - 2022-04-06 03:54:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:54:20 --> Config Class Initialized
INFO - 2022-04-06 03:54:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:20 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:20 --> URI Class Initialized
INFO - 2022-04-06 03:54:20 --> Router Class Initialized
INFO - 2022-04-06 03:54:20 --> Output Class Initialized
INFO - 2022-04-06 03:54:20 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:20 --> Input Class Initialized
INFO - 2022-04-06 03:54:20 --> Language Class Initialized
INFO - 2022-04-06 03:54:20 --> Loader Class Initialized
INFO - 2022-04-06 03:54:20 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:20 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:20 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:20 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:20 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:20 --> Controller Class Initialized
INFO - 2022-04-06 03:54:20 --> Model Class Initialized
INFO - 2022-04-06 03:54:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:54:21 --> Config Class Initialized
INFO - 2022-04-06 03:54:21 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:21 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:21 --> URI Class Initialized
INFO - 2022-04-06 03:54:21 --> Router Class Initialized
INFO - 2022-04-06 03:54:21 --> Output Class Initialized
INFO - 2022-04-06 03:54:21 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:21 --> Input Class Initialized
INFO - 2022-04-06 03:54:21 --> Language Class Initialized
INFO - 2022-04-06 03:54:21 --> Loader Class Initialized
INFO - 2022-04-06 03:54:21 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:21 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:21 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:21 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:21 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:21 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:21 --> Controller Class Initialized
INFO - 2022-04-06 03:54:21 --> Model Class Initialized
INFO - 2022-04-06 03:54:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:54:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:54:21 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:21 --> Total execution time: 0.0696
INFO - 2022-04-06 03:54:21 --> Config Class Initialized
INFO - 2022-04-06 03:54:21 --> Hooks Class Initialized
INFO - 2022-04-06 03:54:21 --> Config Class Initialized
INFO - 2022-04-06 03:54:21 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:21 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:54:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:21 --> URI Class Initialized
INFO - 2022-04-06 03:54:21 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:21 --> URI Class Initialized
INFO - 2022-04-06 03:54:21 --> Router Class Initialized
INFO - 2022-04-06 03:54:21 --> Router Class Initialized
INFO - 2022-04-06 03:54:21 --> Output Class Initialized
INFO - 2022-04-06 03:54:21 --> Output Class Initialized
INFO - 2022-04-06 03:54:21 --> Security Class Initialized
INFO - 2022-04-06 03:54:21 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:21 --> Input Class Initialized
INFO - 2022-04-06 03:54:21 --> Input Class Initialized
INFO - 2022-04-06 03:54:21 --> Language Class Initialized
INFO - 2022-04-06 03:54:21 --> Language Class Initialized
ERROR - 2022-04-06 03:54:21 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:54:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:54:21 --> Config Class Initialized
INFO - 2022-04-06 03:54:21 --> Hooks Class Initialized
INFO - 2022-04-06 03:54:21 --> Config Class Initialized
INFO - 2022-04-06 03:54:21 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:21 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:21 --> URI Class Initialized
DEBUG - 2022-04-06 03:54:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:21 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:21 --> Router Class Initialized
INFO - 2022-04-06 03:54:21 --> URI Class Initialized
INFO - 2022-04-06 03:54:21 --> Output Class Initialized
INFO - 2022-04-06 03:54:21 --> Router Class Initialized
INFO - 2022-04-06 03:54:21 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:21 --> Output Class Initialized
INFO - 2022-04-06 03:54:21 --> Input Class Initialized
INFO - 2022-04-06 03:54:21 --> Language Class Initialized
INFO - 2022-04-06 03:54:21 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:21 --> Input Class Initialized
ERROR - 2022-04-06 03:54:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:54:21 --> Language Class Initialized
ERROR - 2022-04-06 03:54:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:54:33 --> Config Class Initialized
INFO - 2022-04-06 03:54:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:33 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:33 --> URI Class Initialized
INFO - 2022-04-06 03:54:33 --> Router Class Initialized
INFO - 2022-04-06 03:54:33 --> Output Class Initialized
INFO - 2022-04-06 03:54:33 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:33 --> Input Class Initialized
INFO - 2022-04-06 03:54:33 --> Language Class Initialized
INFO - 2022-04-06 03:54:33 --> Loader Class Initialized
INFO - 2022-04-06 03:54:33 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:33 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:33 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:33 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:33 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:33 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:33 --> Controller Class Initialized
INFO - 2022-04-06 03:54:33 --> Model Class Initialized
INFO - 2022-04-06 03:54:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:54:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:54:33 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:33 --> Total execution time: 0.0673
INFO - 2022-04-06 03:54:34 --> Config Class Initialized
INFO - 2022-04-06 03:54:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:34 --> URI Class Initialized
INFO - 2022-04-06 03:54:34 --> Router Class Initialized
INFO - 2022-04-06 03:54:34 --> Output Class Initialized
INFO - 2022-04-06 03:54:34 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:34 --> Input Class Initialized
INFO - 2022-04-06 03:54:34 --> Language Class Initialized
INFO - 2022-04-06 03:54:34 --> Loader Class Initialized
INFO - 2022-04-06 03:54:34 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:34 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:34 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:34 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:34 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:34 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:34 --> Controller Class Initialized
INFO - 2022-04-06 03:54:34 --> Model Class Initialized
INFO - 2022-04-06 03:54:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:54:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:54:34 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:34 --> Total execution time: 0.0620
INFO - 2022-04-06 03:54:35 --> Config Class Initialized
INFO - 2022-04-06 03:54:35 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:35 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:35 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:35 --> URI Class Initialized
DEBUG - 2022-04-06 03:54:35 --> No URI present. Default controller set.
INFO - 2022-04-06 03:54:35 --> Router Class Initialized
INFO - 2022-04-06 03:54:35 --> Output Class Initialized
INFO - 2022-04-06 03:54:35 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:35 --> Input Class Initialized
INFO - 2022-04-06 03:54:35 --> Language Class Initialized
INFO - 2022-04-06 03:54:35 --> Loader Class Initialized
INFO - 2022-04-06 03:54:35 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:35 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:35 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:35 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:35 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:35 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:35 --> Controller Class Initialized
INFO - 2022-04-06 03:54:35 --> Model Class Initialized
INFO - 2022-04-06 03:54:35 --> Model Class Initialized
INFO - 2022-04-06 03:54:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:54:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:54:35 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:35 --> Total execution time: 0.0644
INFO - 2022-04-06 03:54:37 --> Config Class Initialized
INFO - 2022-04-06 03:54:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:37 --> URI Class Initialized
INFO - 2022-04-06 03:54:37 --> Router Class Initialized
INFO - 2022-04-06 03:54:37 --> Output Class Initialized
INFO - 2022-04-06 03:54:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:37 --> Input Class Initialized
INFO - 2022-04-06 03:54:37 --> Language Class Initialized
INFO - 2022-04-06 03:54:37 --> Loader Class Initialized
INFO - 2022-04-06 03:54:37 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:37 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:37 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:37 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:37 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:37 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:37 --> Controller Class Initialized
INFO - 2022-04-06 03:54:37 --> Model Class Initialized
INFO - 2022-04-06 03:54:37 --> Model Class Initialized
INFO - 2022-04-06 03:54:37 --> Config Class Initialized
INFO - 2022-04-06 03:54:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:37 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:37 --> URI Class Initialized
INFO - 2022-04-06 03:54:37 --> Router Class Initialized
INFO - 2022-04-06 03:54:37 --> Output Class Initialized
INFO - 2022-04-06 03:54:37 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:37 --> Input Class Initialized
INFO - 2022-04-06 03:54:37 --> Language Class Initialized
INFO - 2022-04-06 03:54:37 --> Loader Class Initialized
INFO - 2022-04-06 03:54:37 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:37 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:37 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:37 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:37 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:37 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:37 --> Controller Class Initialized
INFO - 2022-04-06 03:54:37 --> Model Class Initialized
INFO - 2022-04-06 03:54:37 --> Model Class Initialized
INFO - 2022-04-06 03:54:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 03:54:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 03:54:37 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:37 --> Total execution time: 0.0733
INFO - 2022-04-06 03:54:38 --> Config Class Initialized
INFO - 2022-04-06 03:54:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:38 --> URI Class Initialized
INFO - 2022-04-06 03:54:38 --> Router Class Initialized
INFO - 2022-04-06 03:54:38 --> Output Class Initialized
INFO - 2022-04-06 03:54:38 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:38 --> Input Class Initialized
INFO - 2022-04-06 03:54:38 --> Language Class Initialized
INFO - 2022-04-06 03:54:38 --> Loader Class Initialized
INFO - 2022-04-06 03:54:38 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:38 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:38 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:38 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:38 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:38 --> Controller Class Initialized
INFO - 2022-04-06 03:54:38 --> Model Class Initialized
INFO - 2022-04-06 03:54:38 --> Model Class Initialized
INFO - 2022-04-06 03:54:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:54:38 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:38 --> Total execution time: 0.0578
INFO - 2022-04-06 03:54:38 --> Config Class Initialized
INFO - 2022-04-06 03:54:38 --> Hooks Class Initialized
INFO - 2022-04-06 03:54:38 --> Config Class Initialized
INFO - 2022-04-06 03:54:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:38 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:54:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:38 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:38 --> URI Class Initialized
INFO - 2022-04-06 03:54:38 --> URI Class Initialized
INFO - 2022-04-06 03:54:38 --> Router Class Initialized
INFO - 2022-04-06 03:54:38 --> Output Class Initialized
INFO - 2022-04-06 03:54:38 --> Router Class Initialized
INFO - 2022-04-06 03:54:38 --> Security Class Initialized
INFO - 2022-04-06 03:54:38 --> Output Class Initialized
DEBUG - 2022-04-06 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:38 --> Input Class Initialized
INFO - 2022-04-06 03:54:38 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:38 --> Input Class Initialized
INFO - 2022-04-06 03:54:38 --> Language Class Initialized
INFO - 2022-04-06 03:54:38 --> Language Class Initialized
ERROR - 2022-04-06 03:54:38 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-06 03:54:38 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-06 03:54:59 --> Config Class Initialized
INFO - 2022-04-06 03:54:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:54:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:54:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:54:59 --> URI Class Initialized
INFO - 2022-04-06 03:54:59 --> Router Class Initialized
INFO - 2022-04-06 03:54:59 --> Output Class Initialized
INFO - 2022-04-06 03:54:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:54:59 --> Input Class Initialized
INFO - 2022-04-06 03:54:59 --> Language Class Initialized
INFO - 2022-04-06 03:54:59 --> Loader Class Initialized
INFO - 2022-04-06 03:54:59 --> Helper loaded: url_helper
INFO - 2022-04-06 03:54:59 --> Helper loaded: form_helper
INFO - 2022-04-06 03:54:59 --> Helper loaded: common_helper
INFO - 2022-04-06 03:54:59 --> Helper loaded: util_helper
INFO - 2022-04-06 03:54:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:54:59 --> Form Validation Class Initialized
INFO - 2022-04-06 03:54:59 --> Controller Class Initialized
INFO - 2022-04-06 03:54:59 --> Model Class Initialized
INFO - 2022-04-06 03:54:59 --> Model Class Initialized
INFO - 2022-04-06 03:54:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:54:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:54:59 --> Final output sent to browser
DEBUG - 2022-04-06 03:54:59 --> Total execution time: 0.1587
INFO - 2022-04-06 03:55:05 --> Config Class Initialized
INFO - 2022-04-06 03:55:05 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:55:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:55:05 --> Utf8 Class Initialized
INFO - 2022-04-06 03:55:05 --> URI Class Initialized
INFO - 2022-04-06 03:55:05 --> Router Class Initialized
INFO - 2022-04-06 03:55:05 --> Output Class Initialized
INFO - 2022-04-06 03:55:05 --> Security Class Initialized
DEBUG - 2022-04-06 03:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:55:05 --> Input Class Initialized
INFO - 2022-04-06 03:55:05 --> Language Class Initialized
INFO - 2022-04-06 03:55:05 --> Loader Class Initialized
INFO - 2022-04-06 03:55:05 --> Helper loaded: url_helper
INFO - 2022-04-06 03:55:05 --> Helper loaded: form_helper
INFO - 2022-04-06 03:55:05 --> Helper loaded: common_helper
INFO - 2022-04-06 03:55:05 --> Helper loaded: util_helper
INFO - 2022-04-06 03:55:05 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:55:05 --> Form Validation Class Initialized
INFO - 2022-04-06 03:55:05 --> Controller Class Initialized
INFO - 2022-04-06 03:55:05 --> Model Class Initialized
INFO - 2022-04-06 03:55:05 --> Model Class Initialized
INFO - 2022-04-06 03:55:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 03:55:05 --> Final output sent to browser
DEBUG - 2022-04-06 03:55:05 --> Total execution time: 0.0655
INFO - 2022-04-06 03:55:12 --> Config Class Initialized
INFO - 2022-04-06 03:55:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:55:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:55:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:55:12 --> URI Class Initialized
INFO - 2022-04-06 03:55:12 --> Router Class Initialized
INFO - 2022-04-06 03:55:12 --> Output Class Initialized
INFO - 2022-04-06 03:55:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:55:12 --> Input Class Initialized
INFO - 2022-04-06 03:55:12 --> Language Class Initialized
INFO - 2022-04-06 03:55:12 --> Loader Class Initialized
INFO - 2022-04-06 03:55:12 --> Helper loaded: url_helper
INFO - 2022-04-06 03:55:12 --> Helper loaded: form_helper
INFO - 2022-04-06 03:55:12 --> Helper loaded: common_helper
INFO - 2022-04-06 03:55:12 --> Helper loaded: util_helper
INFO - 2022-04-06 03:55:12 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:55:12 --> Form Validation Class Initialized
INFO - 2022-04-06 03:55:12 --> Controller Class Initialized
INFO - 2022-04-06 03:55:12 --> Model Class Initialized
INFO - 2022-04-06 03:55:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:55:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:55:12 --> Final output sent to browser
DEBUG - 2022-04-06 03:55:12 --> Total execution time: 0.0731
INFO - 2022-04-06 03:55:12 --> Config Class Initialized
INFO - 2022-04-06 03:55:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:55:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:55:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:55:12 --> URI Class Initialized
INFO - 2022-04-06 03:55:12 --> Router Class Initialized
INFO - 2022-04-06 03:55:12 --> Output Class Initialized
INFO - 2022-04-06 03:55:12 --> Config Class Initialized
INFO - 2022-04-06 03:55:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:55:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:55:12 --> Input Class Initialized
INFO - 2022-04-06 03:55:12 --> Language Class Initialized
DEBUG - 2022-04-06 03:55:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:55:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:55:12 --> URI Class Initialized
ERROR - 2022-04-06 03:55:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:55:12 --> Router Class Initialized
INFO - 2022-04-06 03:55:12 --> Output Class Initialized
INFO - 2022-04-06 03:55:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:55:12 --> Input Class Initialized
INFO - 2022-04-06 03:55:12 --> Language Class Initialized
INFO - 2022-04-06 03:55:12 --> Config Class Initialized
INFO - 2022-04-06 03:55:12 --> Hooks Class Initialized
INFO - 2022-04-06 03:55:12 --> Config Class Initialized
INFO - 2022-04-06 03:55:12 --> Hooks Class Initialized
ERROR - 2022-04-06 03:55:12 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:55:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:55:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:55:12 --> URI Class Initialized
INFO - 2022-04-06 03:55:12 --> Utf8 Class Initialized
INFO - 2022-04-06 03:55:12 --> Router Class Initialized
INFO - 2022-04-06 03:55:12 --> URI Class Initialized
INFO - 2022-04-06 03:55:12 --> Output Class Initialized
INFO - 2022-04-06 03:55:12 --> Router Class Initialized
INFO - 2022-04-06 03:55:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:55:12 --> Input Class Initialized
INFO - 2022-04-06 03:55:12 --> Output Class Initialized
INFO - 2022-04-06 03:55:12 --> Language Class Initialized
INFO - 2022-04-06 03:55:12 --> Security Class Initialized
DEBUG - 2022-04-06 03:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 03:55:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:55:12 --> Input Class Initialized
INFO - 2022-04-06 03:55:12 --> Language Class Initialized
ERROR - 2022-04-06 03:55:12 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:56:59 --> Config Class Initialized
INFO - 2022-04-06 03:56:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:56:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:56:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:56:59 --> URI Class Initialized
INFO - 2022-04-06 03:56:59 --> Router Class Initialized
INFO - 2022-04-06 03:56:59 --> Output Class Initialized
INFO - 2022-04-06 03:56:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:56:59 --> Input Class Initialized
INFO - 2022-04-06 03:56:59 --> Language Class Initialized
INFO - 2022-04-06 03:56:59 --> Loader Class Initialized
INFO - 2022-04-06 03:56:59 --> Helper loaded: url_helper
INFO - 2022-04-06 03:56:59 --> Helper loaded: form_helper
INFO - 2022-04-06 03:56:59 --> Helper loaded: common_helper
INFO - 2022-04-06 03:56:59 --> Helper loaded: util_helper
INFO - 2022-04-06 03:56:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:56:59 --> Form Validation Class Initialized
INFO - 2022-04-06 03:56:59 --> Controller Class Initialized
INFO - 2022-04-06 03:56:59 --> Model Class Initialized
INFO - 2022-04-06 03:56:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 03:56:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:56:59 --> Final output sent to browser
DEBUG - 2022-04-06 03:56:59 --> Total execution time: 0.0726
INFO - 2022-04-06 03:56:59 --> Config Class Initialized
INFO - 2022-04-06 03:56:59 --> Hooks Class Initialized
INFO - 2022-04-06 03:56:59 --> Config Class Initialized
INFO - 2022-04-06 03:56:59 --> Config Class Initialized
INFO - 2022-04-06 03:56:59 --> Hooks Class Initialized
INFO - 2022-04-06 03:56:59 --> Hooks Class Initialized
INFO - 2022-04-06 03:56:59 --> Config Class Initialized
INFO - 2022-04-06 03:56:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:56:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:56:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:56:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:56:59 --> URI Class Initialized
INFO - 2022-04-06 03:56:59 --> URI Class Initialized
DEBUG - 2022-04-06 03:56:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:56:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:56:59 --> Router Class Initialized
INFO - 2022-04-06 03:56:59 --> Router Class Initialized
INFO - 2022-04-06 03:56:59 --> URI Class Initialized
INFO - 2022-04-06 03:56:59 --> Output Class Initialized
INFO - 2022-04-06 03:56:59 --> Output Class Initialized
INFO - 2022-04-06 03:56:59 --> Security Class Initialized
INFO - 2022-04-06 03:56:59 --> Security Class Initialized
INFO - 2022-04-06 03:56:59 --> Router Class Initialized
DEBUG - 2022-04-06 03:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:56:59 --> Input Class Initialized
INFO - 2022-04-06 03:56:59 --> Input Class Initialized
DEBUG - 2022-04-06 03:56:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:56:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:56:59 --> Language Class Initialized
INFO - 2022-04-06 03:56:59 --> Language Class Initialized
INFO - 2022-04-06 03:56:59 --> URI Class Initialized
ERROR - 2022-04-06 03:56:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:56:59 --> Router Class Initialized
ERROR - 2022-04-06 03:56:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:56:59 --> Output Class Initialized
INFO - 2022-04-06 03:56:59 --> Output Class Initialized
INFO - 2022-04-06 03:56:59 --> Security Class Initialized
INFO - 2022-04-06 03:56:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:56:59 --> Input Class Initialized
INFO - 2022-04-06 03:56:59 --> Input Class Initialized
INFO - 2022-04-06 03:56:59 --> Language Class Initialized
INFO - 2022-04-06 03:56:59 --> Language Class Initialized
ERROR - 2022-04-06 03:56:59 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:56:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:05 --> Config Class Initialized
INFO - 2022-04-06 03:57:05 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:05 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:05 --> URI Class Initialized
INFO - 2022-04-06 03:57:05 --> Router Class Initialized
INFO - 2022-04-06 03:57:05 --> Output Class Initialized
INFO - 2022-04-06 03:57:05 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:05 --> Input Class Initialized
INFO - 2022-04-06 03:57:05 --> Language Class Initialized
INFO - 2022-04-06 03:57:05 --> Loader Class Initialized
INFO - 2022-04-06 03:57:05 --> Helper loaded: url_helper
INFO - 2022-04-06 03:57:05 --> Helper loaded: form_helper
INFO - 2022-04-06 03:57:05 --> Helper loaded: common_helper
INFO - 2022-04-06 03:57:05 --> Helper loaded: util_helper
INFO - 2022-04-06 03:57:05 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:57:05 --> Form Validation Class Initialized
INFO - 2022-04-06 03:57:05 --> Controller Class Initialized
INFO - 2022-04-06 03:57:05 --> Model Class Initialized
INFO - 2022-04-06 03:57:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:57:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:57:05 --> Final output sent to browser
DEBUG - 2022-04-06 03:57:05 --> Total execution time: 0.0615
INFO - 2022-04-06 03:57:05 --> Config Class Initialized
INFO - 2022-04-06 03:57:05 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:05 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:05 --> Config Class Initialized
INFO - 2022-04-06 03:57:05 --> Hooks Class Initialized
INFO - 2022-04-06 03:57:05 --> URI Class Initialized
INFO - 2022-04-06 03:57:05 --> Router Class Initialized
DEBUG - 2022-04-06 03:57:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:05 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:05 --> Output Class Initialized
INFO - 2022-04-06 03:57:05 --> URI Class Initialized
INFO - 2022-04-06 03:57:05 --> Security Class Initialized
INFO - 2022-04-06 03:57:05 --> Router Class Initialized
DEBUG - 2022-04-06 03:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:05 --> Input Class Initialized
INFO - 2022-04-06 03:57:05 --> Config Class Initialized
INFO - 2022-04-06 03:57:05 --> Hooks Class Initialized
INFO - 2022-04-06 03:57:05 --> Language Class Initialized
ERROR - 2022-04-06 03:57:05 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:57:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:05 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:05 --> Output Class Initialized
INFO - 2022-04-06 03:57:05 --> Security Class Initialized
INFO - 2022-04-06 03:57:05 --> URI Class Initialized
DEBUG - 2022-04-06 03:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:05 --> Input Class Initialized
INFO - 2022-04-06 03:57:05 --> Router Class Initialized
INFO - 2022-04-06 03:57:05 --> Language Class Initialized
INFO - 2022-04-06 03:57:05 --> Output Class Initialized
ERROR - 2022-04-06 03:57:05 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:05 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:05 --> Config Class Initialized
INFO - 2022-04-06 03:57:05 --> Input Class Initialized
INFO - 2022-04-06 03:57:05 --> Hooks Class Initialized
INFO - 2022-04-06 03:57:05 --> Language Class Initialized
DEBUG - 2022-04-06 03:57:05 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:05 --> Utf8 Class Initialized
ERROR - 2022-04-06 03:57:05 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:05 --> URI Class Initialized
INFO - 2022-04-06 03:57:05 --> Router Class Initialized
INFO - 2022-04-06 03:57:05 --> Output Class Initialized
INFO - 2022-04-06 03:57:05 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:05 --> Input Class Initialized
INFO - 2022-04-06 03:57:05 --> Language Class Initialized
ERROR - 2022-04-06 03:57:05 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:27 --> Config Class Initialized
INFO - 2022-04-06 03:57:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:27 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:27 --> URI Class Initialized
INFO - 2022-04-06 03:57:27 --> Router Class Initialized
INFO - 2022-04-06 03:57:27 --> Output Class Initialized
INFO - 2022-04-06 03:57:27 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:28 --> Input Class Initialized
INFO - 2022-04-06 03:57:28 --> Language Class Initialized
INFO - 2022-04-06 03:57:28 --> Loader Class Initialized
INFO - 2022-04-06 03:57:28 --> Helper loaded: url_helper
INFO - 2022-04-06 03:57:28 --> Helper loaded: form_helper
INFO - 2022-04-06 03:57:28 --> Helper loaded: common_helper
INFO - 2022-04-06 03:57:28 --> Helper loaded: util_helper
INFO - 2022-04-06 03:57:28 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:57:28 --> Form Validation Class Initialized
INFO - 2022-04-06 03:57:28 --> Controller Class Initialized
INFO - 2022-04-06 03:57:28 --> Model Class Initialized
INFO - 2022-04-06 03:57:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:57:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:57:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:57:28 --> Final output sent to browser
DEBUG - 2022-04-06 03:57:28 --> Total execution time: 0.1672
INFO - 2022-04-06 03:57:28 --> Config Class Initialized
INFO - 2022-04-06 03:57:28 --> Hooks Class Initialized
INFO - 2022-04-06 03:57:28 --> Config Class Initialized
INFO - 2022-04-06 03:57:28 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:28 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:28 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:57:28 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:28 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:28 --> URI Class Initialized
INFO - 2022-04-06 03:57:28 --> URI Class Initialized
INFO - 2022-04-06 03:57:28 --> Router Class Initialized
INFO - 2022-04-06 03:57:28 --> Router Class Initialized
INFO - 2022-04-06 03:57:28 --> Output Class Initialized
INFO - 2022-04-06 03:57:28 --> Output Class Initialized
INFO - 2022-04-06 03:57:28 --> Security Class Initialized
INFO - 2022-04-06 03:57:28 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:28 --> Input Class Initialized
DEBUG - 2022-04-06 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:28 --> Input Class Initialized
INFO - 2022-04-06 03:57:28 --> Language Class Initialized
INFO - 2022-04-06 03:57:28 --> Language Class Initialized
ERROR - 2022-04-06 03:57:28 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:57:28 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:28 --> Config Class Initialized
INFO - 2022-04-06 03:57:28 --> Config Class Initialized
INFO - 2022-04-06 03:57:28 --> Hooks Class Initialized
INFO - 2022-04-06 03:57:28 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:57:28 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:28 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:28 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:28 --> URI Class Initialized
INFO - 2022-04-06 03:57:28 --> URI Class Initialized
INFO - 2022-04-06 03:57:28 --> Router Class Initialized
INFO - 2022-04-06 03:57:28 --> Router Class Initialized
INFO - 2022-04-06 03:57:28 --> Output Class Initialized
INFO - 2022-04-06 03:57:28 --> Output Class Initialized
INFO - 2022-04-06 03:57:28 --> Security Class Initialized
INFO - 2022-04-06 03:57:28 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:28 --> Input Class Initialized
INFO - 2022-04-06 03:57:28 --> Input Class Initialized
INFO - 2022-04-06 03:57:28 --> Language Class Initialized
INFO - 2022-04-06 03:57:28 --> Language Class Initialized
ERROR - 2022-04-06 03:57:28 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:57:28 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:36 --> Config Class Initialized
INFO - 2022-04-06 03:57:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:36 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:36 --> URI Class Initialized
INFO - 2022-04-06 03:57:36 --> Router Class Initialized
INFO - 2022-04-06 03:57:36 --> Output Class Initialized
INFO - 2022-04-06 03:57:36 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:36 --> Input Class Initialized
INFO - 2022-04-06 03:57:36 --> Language Class Initialized
INFO - 2022-04-06 03:57:36 --> Loader Class Initialized
INFO - 2022-04-06 03:57:36 --> Helper loaded: url_helper
INFO - 2022-04-06 03:57:36 --> Helper loaded: form_helper
INFO - 2022-04-06 03:57:36 --> Helper loaded: common_helper
INFO - 2022-04-06 03:57:36 --> Helper loaded: util_helper
INFO - 2022-04-06 03:57:36 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:57:36 --> Form Validation Class Initialized
INFO - 2022-04-06 03:57:36 --> Controller Class Initialized
INFO - 2022-04-06 03:57:36 --> Model Class Initialized
INFO - 2022-04-06 03:57:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:57:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:57:36 --> Final output sent to browser
DEBUG - 2022-04-06 03:57:36 --> Total execution time: 0.0709
INFO - 2022-04-06 03:57:49 --> Config Class Initialized
INFO - 2022-04-06 03:57:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:49 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:49 --> URI Class Initialized
INFO - 2022-04-06 03:57:49 --> Router Class Initialized
INFO - 2022-04-06 03:57:49 --> Output Class Initialized
INFO - 2022-04-06 03:57:49 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:49 --> Input Class Initialized
INFO - 2022-04-06 03:57:49 --> Language Class Initialized
INFO - 2022-04-06 03:57:49 --> Loader Class Initialized
INFO - 2022-04-06 03:57:49 --> Helper loaded: url_helper
INFO - 2022-04-06 03:57:49 --> Helper loaded: form_helper
INFO - 2022-04-06 03:57:49 --> Helper loaded: common_helper
INFO - 2022-04-06 03:57:49 --> Helper loaded: util_helper
INFO - 2022-04-06 03:57:49 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:57:49 --> Form Validation Class Initialized
INFO - 2022-04-06 03:57:49 --> Controller Class Initialized
INFO - 2022-04-06 03:57:49 --> Model Class Initialized
INFO - 2022-04-06 03:57:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:57:49 --> Config Class Initialized
INFO - 2022-04-06 03:57:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:49 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:49 --> URI Class Initialized
INFO - 2022-04-06 03:57:49 --> Router Class Initialized
INFO - 2022-04-06 03:57:49 --> Output Class Initialized
INFO - 2022-04-06 03:57:49 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:49 --> Input Class Initialized
INFO - 2022-04-06 03:57:49 --> Language Class Initialized
INFO - 2022-04-06 03:57:49 --> Loader Class Initialized
INFO - 2022-04-06 03:57:49 --> Helper loaded: url_helper
INFO - 2022-04-06 03:57:49 --> Helper loaded: form_helper
INFO - 2022-04-06 03:57:49 --> Helper loaded: common_helper
INFO - 2022-04-06 03:57:49 --> Helper loaded: util_helper
INFO - 2022-04-06 03:57:49 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:57:49 --> Form Validation Class Initialized
INFO - 2022-04-06 03:57:49 --> Controller Class Initialized
INFO - 2022-04-06 03:57:49 --> Model Class Initialized
INFO - 2022-04-06 03:57:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:57:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:57:49 --> Final output sent to browser
DEBUG - 2022-04-06 03:57:49 --> Total execution time: 0.0582
INFO - 2022-04-06 03:57:49 --> Config Class Initialized
INFO - 2022-04-06 03:57:49 --> Hooks Class Initialized
INFO - 2022-04-06 03:57:49 --> Config Class Initialized
INFO - 2022-04-06 03:57:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:49 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:49 --> URI Class Initialized
DEBUG - 2022-04-06 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:49 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:49 --> Router Class Initialized
INFO - 2022-04-06 03:57:49 --> URI Class Initialized
INFO - 2022-04-06 03:57:49 --> Output Class Initialized
INFO - 2022-04-06 03:57:49 --> Router Class Initialized
INFO - 2022-04-06 03:57:49 --> Security Class Initialized
INFO - 2022-04-06 03:57:49 --> Output Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:49 --> Input Class Initialized
INFO - 2022-04-06 03:57:49 --> Security Class Initialized
INFO - 2022-04-06 03:57:49 --> Language Class Initialized
INFO - 2022-04-06 03:57:49 --> Config Class Initialized
INFO - 2022-04-06 03:57:49 --> Hooks Class Initialized
ERROR - 2022-04-06 03:57:49 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:49 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:49 --> URI Class Initialized
INFO - 2022-04-06 03:57:49 --> Input Class Initialized
INFO - 2022-04-06 03:57:49 --> Language Class Initialized
INFO - 2022-04-06 03:57:49 --> Router Class Initialized
INFO - 2022-04-06 03:57:49 --> Output Class Initialized
INFO - 2022-04-06 03:57:49 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:49 --> Input Class Initialized
INFO - 2022-04-06 03:57:49 --> Language Class Initialized
ERROR - 2022-04-06 03:57:49 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:57:49 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:49 --> Config Class Initialized
INFO - 2022-04-06 03:57:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:49 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:49 --> URI Class Initialized
INFO - 2022-04-06 03:57:49 --> Router Class Initialized
INFO - 2022-04-06 03:57:49 --> Output Class Initialized
INFO - 2022-04-06 03:57:49 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:49 --> Input Class Initialized
INFO - 2022-04-06 03:57:49 --> Language Class Initialized
ERROR - 2022-04-06 03:57:49 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:57:53 --> Config Class Initialized
INFO - 2022-04-06 03:57:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:57:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:57:53 --> Utf8 Class Initialized
INFO - 2022-04-06 03:57:53 --> URI Class Initialized
INFO - 2022-04-06 03:57:53 --> Router Class Initialized
INFO - 2022-04-06 03:57:53 --> Output Class Initialized
INFO - 2022-04-06 03:57:53 --> Security Class Initialized
DEBUG - 2022-04-06 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:57:53 --> Input Class Initialized
INFO - 2022-04-06 03:57:53 --> Language Class Initialized
INFO - 2022-04-06 03:57:53 --> Loader Class Initialized
INFO - 2022-04-06 03:57:53 --> Helper loaded: url_helper
INFO - 2022-04-06 03:57:53 --> Helper loaded: form_helper
INFO - 2022-04-06 03:57:53 --> Helper loaded: common_helper
INFO - 2022-04-06 03:57:53 --> Helper loaded: util_helper
INFO - 2022-04-06 03:57:54 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:57:54 --> Form Validation Class Initialized
INFO - 2022-04-06 03:57:54 --> Controller Class Initialized
INFO - 2022-04-06 03:57:54 --> Model Class Initialized
INFO - 2022-04-06 03:57:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:57:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:57:54 --> Final output sent to browser
DEBUG - 2022-04-06 03:57:54 --> Total execution time: 0.0707
INFO - 2022-04-06 03:58:16 --> Config Class Initialized
INFO - 2022-04-06 03:58:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:16 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:16 --> URI Class Initialized
INFO - 2022-04-06 03:58:16 --> Router Class Initialized
INFO - 2022-04-06 03:58:16 --> Output Class Initialized
INFO - 2022-04-06 03:58:16 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:16 --> Input Class Initialized
INFO - 2022-04-06 03:58:16 --> Language Class Initialized
INFO - 2022-04-06 03:58:16 --> Loader Class Initialized
INFO - 2022-04-06 03:58:16 --> Helper loaded: url_helper
INFO - 2022-04-06 03:58:16 --> Helper loaded: form_helper
INFO - 2022-04-06 03:58:16 --> Helper loaded: common_helper
INFO - 2022-04-06 03:58:16 --> Helper loaded: util_helper
INFO - 2022-04-06 03:58:16 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:58:16 --> Form Validation Class Initialized
INFO - 2022-04-06 03:58:16 --> Controller Class Initialized
INFO - 2022-04-06 03:58:16 --> Model Class Initialized
INFO - 2022-04-06 03:58:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:58:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:58:16 --> Final output sent to browser
DEBUG - 2022-04-06 03:58:16 --> Total execution time: 0.0592
INFO - 2022-04-06 03:58:16 --> Config Class Initialized
INFO - 2022-04-06 03:58:16 --> Hooks Class Initialized
INFO - 2022-04-06 03:58:16 --> Config Class Initialized
INFO - 2022-04-06 03:58:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:16 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:16 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:16 --> URI Class Initialized
INFO - 2022-04-06 03:58:16 --> URI Class Initialized
INFO - 2022-04-06 03:58:16 --> Router Class Initialized
INFO - 2022-04-06 03:58:16 --> Router Class Initialized
INFO - 2022-04-06 03:58:16 --> Output Class Initialized
INFO - 2022-04-06 03:58:16 --> Security Class Initialized
INFO - 2022-04-06 03:58:16 --> Output Class Initialized
DEBUG - 2022-04-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:16 --> Config Class Initialized
INFO - 2022-04-06 03:58:16 --> Input Class Initialized
INFO - 2022-04-06 03:58:16 --> Hooks Class Initialized
INFO - 2022-04-06 03:58:16 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:16 --> Input Class Initialized
DEBUG - 2022-04-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:16 --> Language Class Initialized
INFO - 2022-04-06 03:58:16 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:16 --> Language Class Initialized
INFO - 2022-04-06 03:58:16 --> URI Class Initialized
ERROR - 2022-04-06 03:58:16 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:58:16 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:58:16 --> Router Class Initialized
INFO - 2022-04-06 03:58:16 --> Output Class Initialized
INFO - 2022-04-06 03:58:16 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:16 --> Input Class Initialized
INFO - 2022-04-06 03:58:16 --> Language Class Initialized
INFO - 2022-04-06 03:58:16 --> Config Class Initialized
INFO - 2022-04-06 03:58:16 --> Hooks Class Initialized
ERROR - 2022-04-06 03:58:16 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:16 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:16 --> URI Class Initialized
INFO - 2022-04-06 03:58:16 --> Router Class Initialized
INFO - 2022-04-06 03:58:16 --> Output Class Initialized
INFO - 2022-04-06 03:58:16 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:16 --> Input Class Initialized
INFO - 2022-04-06 03:58:16 --> Language Class Initialized
ERROR - 2022-04-06 03:58:16 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:58:30 --> Config Class Initialized
INFO - 2022-04-06 03:58:30 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:58:30 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:30 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:30 --> URI Class Initialized
INFO - 2022-04-06 03:58:30 --> Router Class Initialized
INFO - 2022-04-06 03:58:30 --> Output Class Initialized
INFO - 2022-04-06 03:58:30 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:30 --> Input Class Initialized
INFO - 2022-04-06 03:58:30 --> Language Class Initialized
INFO - 2022-04-06 03:58:30 --> Loader Class Initialized
INFO - 2022-04-06 03:58:30 --> Helper loaded: url_helper
INFO - 2022-04-06 03:58:30 --> Helper loaded: form_helper
INFO - 2022-04-06 03:58:30 --> Helper loaded: common_helper
INFO - 2022-04-06 03:58:30 --> Helper loaded: util_helper
INFO - 2022-04-06 03:58:31 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:58:31 --> Form Validation Class Initialized
INFO - 2022-04-06 03:58:31 --> Controller Class Initialized
INFO - 2022-04-06 03:58:31 --> Model Class Initialized
INFO - 2022-04-06 03:58:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:58:31 --> Config Class Initialized
INFO - 2022-04-06 03:58:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:58:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:31 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:31 --> URI Class Initialized
INFO - 2022-04-06 03:58:31 --> Router Class Initialized
INFO - 2022-04-06 03:58:31 --> Output Class Initialized
INFO - 2022-04-06 03:58:31 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:31 --> Input Class Initialized
INFO - 2022-04-06 03:58:31 --> Language Class Initialized
INFO - 2022-04-06 03:58:31 --> Loader Class Initialized
INFO - 2022-04-06 03:58:31 --> Helper loaded: url_helper
INFO - 2022-04-06 03:58:31 --> Helper loaded: form_helper
INFO - 2022-04-06 03:58:31 --> Helper loaded: common_helper
INFO - 2022-04-06 03:58:31 --> Helper loaded: util_helper
INFO - 2022-04-06 03:58:31 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:58:31 --> Form Validation Class Initialized
INFO - 2022-04-06 03:58:31 --> Controller Class Initialized
INFO - 2022-04-06 03:58:31 --> Model Class Initialized
INFO - 2022-04-06 03:58:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:58:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:58:31 --> Final output sent to browser
DEBUG - 2022-04-06 03:58:31 --> Total execution time: 0.0524
INFO - 2022-04-06 03:58:31 --> Config Class Initialized
INFO - 2022-04-06 03:58:31 --> Hooks Class Initialized
INFO - 2022-04-06 03:58:31 --> Config Class Initialized
INFO - 2022-04-06 03:58:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:58:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:31 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:31 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:31 --> URI Class Initialized
INFO - 2022-04-06 03:58:31 --> URI Class Initialized
INFO - 2022-04-06 03:58:31 --> Router Class Initialized
INFO - 2022-04-06 03:58:31 --> Router Class Initialized
INFO - 2022-04-06 03:58:31 --> Config Class Initialized
INFO - 2022-04-06 03:58:31 --> Output Class Initialized
INFO - 2022-04-06 03:58:31 --> Output Class Initialized
INFO - 2022-04-06 03:58:31 --> Config Class Initialized
INFO - 2022-04-06 03:58:31 --> Hooks Class Initialized
INFO - 2022-04-06 03:58:31 --> Hooks Class Initialized
INFO - 2022-04-06 03:58:31 --> Security Class Initialized
INFO - 2022-04-06 03:58:31 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:31 --> Input Class Initialized
DEBUG - 2022-04-06 03:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 03:58:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:31 --> Input Class Initialized
INFO - 2022-04-06 03:58:31 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:31 --> Language Class Initialized
INFO - 2022-04-06 03:58:31 --> URI Class Initialized
ERROR - 2022-04-06 03:58:31 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:58:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:58:31 --> Router Class Initialized
INFO - 2022-04-06 03:58:31 --> Language Class Initialized
INFO - 2022-04-06 03:58:31 --> Utf8 Class Initialized
INFO - 2022-04-06 03:58:31 --> URI Class Initialized
INFO - 2022-04-06 03:58:31 --> Output Class Initialized
ERROR - 2022-04-06 03:58:31 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:58:31 --> Router Class Initialized
INFO - 2022-04-06 03:58:31 --> Security Class Initialized
DEBUG - 2022-04-06 03:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:31 --> Output Class Initialized
INFO - 2022-04-06 03:58:31 --> Input Class Initialized
INFO - 2022-04-06 03:58:31 --> Language Class Initialized
INFO - 2022-04-06 03:58:31 --> Security Class Initialized
ERROR - 2022-04-06 03:58:31 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:58:31 --> Input Class Initialized
INFO - 2022-04-06 03:58:31 --> Language Class Initialized
ERROR - 2022-04-06 03:58:31 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:20 --> Config Class Initialized
INFO - 2022-04-06 03:59:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:20 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:20 --> URI Class Initialized
INFO - 2022-04-06 03:59:20 --> Router Class Initialized
INFO - 2022-04-06 03:59:20 --> Output Class Initialized
INFO - 2022-04-06 03:59:20 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:20 --> Input Class Initialized
INFO - 2022-04-06 03:59:20 --> Language Class Initialized
INFO - 2022-04-06 03:59:20 --> Loader Class Initialized
INFO - 2022-04-06 03:59:20 --> Helper loaded: url_helper
INFO - 2022-04-06 03:59:20 --> Helper loaded: form_helper
INFO - 2022-04-06 03:59:20 --> Helper loaded: common_helper
INFO - 2022-04-06 03:59:20 --> Helper loaded: util_helper
INFO - 2022-04-06 03:59:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:59:20 --> Form Validation Class Initialized
INFO - 2022-04-06 03:59:20 --> Controller Class Initialized
INFO - 2022-04-06 03:59:20 --> Model Class Initialized
INFO - 2022-04-06 03:59:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:59:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:59:20 --> Final output sent to browser
DEBUG - 2022-04-06 03:59:20 --> Total execution time: 0.0577
INFO - 2022-04-06 03:59:20 --> Config Class Initialized
INFO - 2022-04-06 03:59:20 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:20 --> Config Class Initialized
INFO - 2022-04-06 03:59:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:59:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:20 --> URI Class Initialized
INFO - 2022-04-06 03:59:20 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:20 --> URI Class Initialized
INFO - 2022-04-06 03:59:20 --> Router Class Initialized
INFO - 2022-04-06 03:59:20 --> Router Class Initialized
INFO - 2022-04-06 03:59:20 --> Output Class Initialized
INFO - 2022-04-06 03:59:20 --> Security Class Initialized
INFO - 2022-04-06 03:59:20 --> Output Class Initialized
DEBUG - 2022-04-06 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:20 --> Security Class Initialized
INFO - 2022-04-06 03:59:20 --> Input Class Initialized
DEBUG - 2022-04-06 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:20 --> Input Class Initialized
INFO - 2022-04-06 03:59:20 --> Language Class Initialized
INFO - 2022-04-06 03:59:20 --> Language Class Initialized
ERROR - 2022-04-06 03:59:20 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:59:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:20 --> Config Class Initialized
INFO - 2022-04-06 03:59:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:20 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:20 --> Config Class Initialized
INFO - 2022-04-06 03:59:20 --> URI Class Initialized
INFO - 2022-04-06 03:59:20 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:20 --> Router Class Initialized
DEBUG - 2022-04-06 03:59:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:20 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:20 --> Output Class Initialized
INFO - 2022-04-06 03:59:20 --> URI Class Initialized
INFO - 2022-04-06 03:59:20 --> Security Class Initialized
INFO - 2022-04-06 03:59:20 --> Router Class Initialized
DEBUG - 2022-04-06 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:20 --> Input Class Initialized
INFO - 2022-04-06 03:59:20 --> Output Class Initialized
INFO - 2022-04-06 03:59:20 --> Language Class Initialized
INFO - 2022-04-06 03:59:20 --> Security Class Initialized
ERROR - 2022-04-06 03:59:20 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:20 --> Input Class Initialized
INFO - 2022-04-06 03:59:20 --> Language Class Initialized
ERROR - 2022-04-06 03:59:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:33 --> Config Class Initialized
INFO - 2022-04-06 03:59:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:33 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:33 --> URI Class Initialized
INFO - 2022-04-06 03:59:33 --> Router Class Initialized
INFO - 2022-04-06 03:59:33 --> Output Class Initialized
INFO - 2022-04-06 03:59:33 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:33 --> Input Class Initialized
INFO - 2022-04-06 03:59:33 --> Language Class Initialized
INFO - 2022-04-06 03:59:33 --> Loader Class Initialized
INFO - 2022-04-06 03:59:33 --> Helper loaded: url_helper
INFO - 2022-04-06 03:59:33 --> Helper loaded: form_helper
INFO - 2022-04-06 03:59:33 --> Helper loaded: common_helper
INFO - 2022-04-06 03:59:33 --> Helper loaded: util_helper
INFO - 2022-04-06 03:59:33 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:59:33 --> Form Validation Class Initialized
INFO - 2022-04-06 03:59:33 --> Controller Class Initialized
INFO - 2022-04-06 03:59:33 --> Model Class Initialized
INFO - 2022-04-06 03:59:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:59:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:59:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:59:33 --> Final output sent to browser
DEBUG - 2022-04-06 03:59:33 --> Total execution time: 0.1511
INFO - 2022-04-06 03:59:34 --> Config Class Initialized
INFO - 2022-04-06 03:59:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:34 --> Config Class Initialized
INFO - 2022-04-06 03:59:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:34 --> URI Class Initialized
DEBUG - 2022-04-06 03:59:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:34 --> Router Class Initialized
INFO - 2022-04-06 03:59:34 --> URI Class Initialized
INFO - 2022-04-06 03:59:34 --> Output Class Initialized
INFO - 2022-04-06 03:59:34 --> Router Class Initialized
INFO - 2022-04-06 03:59:34 --> Security Class Initialized
INFO - 2022-04-06 03:59:34 --> Output Class Initialized
INFO - 2022-04-06 03:59:34 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:34 --> Input Class Initialized
INFO - 2022-04-06 03:59:34 --> Language Class Initialized
DEBUG - 2022-04-06 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:34 --> Input Class Initialized
INFO - 2022-04-06 03:59:34 --> Language Class Initialized
ERROR - 2022-04-06 03:59:34 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:59:34 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:34 --> Config Class Initialized
INFO - 2022-04-06 03:59:34 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:34 --> Config Class Initialized
INFO - 2022-04-06 03:59:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:34 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:59:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:34 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:34 --> URI Class Initialized
INFO - 2022-04-06 03:59:34 --> URI Class Initialized
INFO - 2022-04-06 03:59:34 --> Router Class Initialized
INFO - 2022-04-06 03:59:34 --> Output Class Initialized
INFO - 2022-04-06 03:59:34 --> Router Class Initialized
INFO - 2022-04-06 03:59:34 --> Security Class Initialized
INFO - 2022-04-06 03:59:34 --> Output Class Initialized
DEBUG - 2022-04-06 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:34 --> Input Class Initialized
INFO - 2022-04-06 03:59:34 --> Security Class Initialized
INFO - 2022-04-06 03:59:34 --> Language Class Initialized
DEBUG - 2022-04-06 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:34 --> Input Class Initialized
INFO - 2022-04-06 03:59:34 --> Language Class Initialized
ERROR - 2022-04-06 03:59:34 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:59:34 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:41 --> Config Class Initialized
INFO - 2022-04-06 03:59:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:41 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:41 --> URI Class Initialized
INFO - 2022-04-06 03:59:41 --> Router Class Initialized
INFO - 2022-04-06 03:59:41 --> Output Class Initialized
INFO - 2022-04-06 03:59:41 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:41 --> Input Class Initialized
INFO - 2022-04-06 03:59:41 --> Language Class Initialized
INFO - 2022-04-06 03:59:41 --> Loader Class Initialized
INFO - 2022-04-06 03:59:41 --> Helper loaded: url_helper
INFO - 2022-04-06 03:59:41 --> Helper loaded: form_helper
INFO - 2022-04-06 03:59:41 --> Helper loaded: common_helper
INFO - 2022-04-06 03:59:41 --> Helper loaded: util_helper
INFO - 2022-04-06 03:59:41 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:59:41 --> Form Validation Class Initialized
INFO - 2022-04-06 03:59:41 --> Controller Class Initialized
INFO - 2022-04-06 03:59:41 --> Model Class Initialized
INFO - 2022-04-06 03:59:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:59:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:59:41 --> Final output sent to browser
DEBUG - 2022-04-06 03:59:41 --> Total execution time: 0.0624
INFO - 2022-04-06 03:59:44 --> Config Class Initialized
INFO - 2022-04-06 03:59:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:44 --> URI Class Initialized
INFO - 2022-04-06 03:59:44 --> Router Class Initialized
INFO - 2022-04-06 03:59:44 --> Output Class Initialized
INFO - 2022-04-06 03:59:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:44 --> Input Class Initialized
INFO - 2022-04-06 03:59:44 --> Language Class Initialized
INFO - 2022-04-06 03:59:44 --> Loader Class Initialized
INFO - 2022-04-06 03:59:44 --> Helper loaded: url_helper
INFO - 2022-04-06 03:59:44 --> Helper loaded: form_helper
INFO - 2022-04-06 03:59:44 --> Helper loaded: common_helper
INFO - 2022-04-06 03:59:44 --> Helper loaded: util_helper
INFO - 2022-04-06 03:59:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:59:44 --> Form Validation Class Initialized
INFO - 2022-04-06 03:59:44 --> Controller Class Initialized
INFO - 2022-04-06 03:59:44 --> Model Class Initialized
INFO - 2022-04-06 03:59:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:59:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:59:44 --> Final output sent to browser
DEBUG - 2022-04-06 03:59:44 --> Total execution time: 0.0673
INFO - 2022-04-06 03:59:44 --> Config Class Initialized
INFO - 2022-04-06 03:59:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:44 --> Config Class Initialized
INFO - 2022-04-06 03:59:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:44 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:59:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:44 --> URI Class Initialized
INFO - 2022-04-06 03:59:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:44 --> URI Class Initialized
INFO - 2022-04-06 03:59:44 --> Router Class Initialized
INFO - 2022-04-06 03:59:44 --> Router Class Initialized
INFO - 2022-04-06 03:59:44 --> Output Class Initialized
INFO - 2022-04-06 03:59:44 --> Output Class Initialized
INFO - 2022-04-06 03:59:44 --> Security Class Initialized
INFO - 2022-04-06 03:59:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:44 --> Input Class Initialized
DEBUG - 2022-04-06 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:44 --> Input Class Initialized
INFO - 2022-04-06 03:59:44 --> Config Class Initialized
INFO - 2022-04-06 03:59:44 --> Language Class Initialized
INFO - 2022-04-06 03:59:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:44 --> Language Class Initialized
ERROR - 2022-04-06 03:59:44 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:59:44 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:59:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:44 --> URI Class Initialized
INFO - 2022-04-06 03:59:44 --> Router Class Initialized
INFO - 2022-04-06 03:59:44 --> Output Class Initialized
INFO - 2022-04-06 03:59:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:44 --> Input Class Initialized
INFO - 2022-04-06 03:59:44 --> Config Class Initialized
INFO - 2022-04-06 03:59:44 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:44 --> Language Class Initialized
ERROR - 2022-04-06 03:59:44 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:59:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:44 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:44 --> URI Class Initialized
INFO - 2022-04-06 03:59:44 --> Router Class Initialized
INFO - 2022-04-06 03:59:44 --> Output Class Initialized
INFO - 2022-04-06 03:59:44 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:44 --> Input Class Initialized
INFO - 2022-04-06 03:59:44 --> Language Class Initialized
ERROR - 2022-04-06 03:59:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:59 --> Config Class Initialized
INFO - 2022-04-06 03:59:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:59 --> URI Class Initialized
INFO - 2022-04-06 03:59:59 --> Router Class Initialized
INFO - 2022-04-06 03:59:59 --> Output Class Initialized
INFO - 2022-04-06 03:59:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:59 --> Input Class Initialized
INFO - 2022-04-06 03:59:59 --> Language Class Initialized
INFO - 2022-04-06 03:59:59 --> Loader Class Initialized
INFO - 2022-04-06 03:59:59 --> Helper loaded: url_helper
INFO - 2022-04-06 03:59:59 --> Helper loaded: form_helper
INFO - 2022-04-06 03:59:59 --> Helper loaded: common_helper
INFO - 2022-04-06 03:59:59 --> Helper loaded: util_helper
INFO - 2022-04-06 03:59:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:59:59 --> Form Validation Class Initialized
INFO - 2022-04-06 03:59:59 --> Controller Class Initialized
INFO - 2022-04-06 03:59:59 --> Model Class Initialized
INFO - 2022-04-06 03:59:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 03:59:59 --> Config Class Initialized
INFO - 2022-04-06 03:59:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:59 --> URI Class Initialized
INFO - 2022-04-06 03:59:59 --> Router Class Initialized
INFO - 2022-04-06 03:59:59 --> Output Class Initialized
INFO - 2022-04-06 03:59:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:59 --> Input Class Initialized
INFO - 2022-04-06 03:59:59 --> Language Class Initialized
INFO - 2022-04-06 03:59:59 --> Loader Class Initialized
INFO - 2022-04-06 03:59:59 --> Helper loaded: url_helper
INFO - 2022-04-06 03:59:59 --> Helper loaded: form_helper
INFO - 2022-04-06 03:59:59 --> Helper loaded: common_helper
INFO - 2022-04-06 03:59:59 --> Helper loaded: util_helper
INFO - 2022-04-06 03:59:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 03:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 03:59:59 --> Form Validation Class Initialized
INFO - 2022-04-06 03:59:59 --> Controller Class Initialized
INFO - 2022-04-06 03:59:59 --> Model Class Initialized
INFO - 2022-04-06 03:59:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 03:59:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 03:59:59 --> Final output sent to browser
DEBUG - 2022-04-06 03:59:59 --> Total execution time: 0.0569
INFO - 2022-04-06 03:59:59 --> Config Class Initialized
INFO - 2022-04-06 03:59:59 --> Config Class Initialized
INFO - 2022-04-06 03:59:59 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 03:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 03:59:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:59 --> URI Class Initialized
INFO - 2022-04-06 03:59:59 --> URI Class Initialized
INFO - 2022-04-06 03:59:59 --> Router Class Initialized
INFO - 2022-04-06 03:59:59 --> Router Class Initialized
INFO - 2022-04-06 03:59:59 --> Config Class Initialized
INFO - 2022-04-06 03:59:59 --> Hooks Class Initialized
INFO - 2022-04-06 03:59:59 --> Output Class Initialized
INFO - 2022-04-06 03:59:59 --> Output Class Initialized
INFO - 2022-04-06 03:59:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:59 --> Utf8 Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:59 --> Security Class Initialized
INFO - 2022-04-06 03:59:59 --> Input Class Initialized
INFO - 2022-04-06 03:59:59 --> Language Class Initialized
INFO - 2022-04-06 03:59:59 --> URI Class Initialized
INFO - 2022-04-06 03:59:59 --> Router Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 03:59:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 03:59:59 --> Input Class Initialized
INFO - 2022-04-06 03:59:59 --> Output Class Initialized
INFO - 2022-04-06 03:59:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:59 --> Input Class Initialized
INFO - 2022-04-06 03:59:59 --> Language Class Initialized
INFO - 2022-04-06 03:59:59 --> Language Class Initialized
INFO - 2022-04-06 03:59:59 --> Config Class Initialized
INFO - 2022-04-06 03:59:59 --> Hooks Class Initialized
ERROR - 2022-04-06 03:59:59 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 03:59:59 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 03:59:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 03:59:59 --> Utf8 Class Initialized
INFO - 2022-04-06 03:59:59 --> URI Class Initialized
INFO - 2022-04-06 03:59:59 --> Router Class Initialized
INFO - 2022-04-06 03:59:59 --> Output Class Initialized
INFO - 2022-04-06 03:59:59 --> Security Class Initialized
DEBUG - 2022-04-06 03:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 03:59:59 --> Input Class Initialized
INFO - 2022-04-06 03:59:59 --> Language Class Initialized
ERROR - 2022-04-06 03:59:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:00:30 --> Config Class Initialized
INFO - 2022-04-06 04:00:30 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:00:30 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:30 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:30 --> URI Class Initialized
INFO - 2022-04-06 04:00:30 --> Router Class Initialized
INFO - 2022-04-06 04:00:30 --> Output Class Initialized
INFO - 2022-04-06 04:00:30 --> Security Class Initialized
DEBUG - 2022-04-06 04:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:30 --> Input Class Initialized
INFO - 2022-04-06 04:00:30 --> Language Class Initialized
INFO - 2022-04-06 04:00:30 --> Loader Class Initialized
INFO - 2022-04-06 04:00:30 --> Helper loaded: url_helper
INFO - 2022-04-06 04:00:30 --> Helper loaded: form_helper
INFO - 2022-04-06 04:00:30 --> Helper loaded: common_helper
INFO - 2022-04-06 04:00:30 --> Helper loaded: util_helper
INFO - 2022-04-06 04:00:30 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:00:30 --> Form Validation Class Initialized
INFO - 2022-04-06 04:00:30 --> Controller Class Initialized
INFO - 2022-04-06 04:00:30 --> Model Class Initialized
INFO - 2022-04-06 04:00:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:00:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:00:30 --> Final output sent to browser
DEBUG - 2022-04-06 04:00:30 --> Total execution time: 0.0571
INFO - 2022-04-06 04:00:30 --> Config Class Initialized
INFO - 2022-04-06 04:00:30 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:00:30 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:30 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:30 --> URI Class Initialized
INFO - 2022-04-06 04:00:30 --> Router Class Initialized
INFO - 2022-04-06 04:00:30 --> Output Class Initialized
INFO - 2022-04-06 04:00:30 --> Security Class Initialized
DEBUG - 2022-04-06 04:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:30 --> Input Class Initialized
INFO - 2022-04-06 04:00:30 --> Language Class Initialized
INFO - 2022-04-06 04:00:30 --> Loader Class Initialized
INFO - 2022-04-06 04:00:30 --> Helper loaded: url_helper
INFO - 2022-04-06 04:00:30 --> Helper loaded: form_helper
INFO - 2022-04-06 04:00:30 --> Helper loaded: common_helper
INFO - 2022-04-06 04:00:30 --> Helper loaded: util_helper
INFO - 2022-04-06 04:00:30 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:00:31 --> Form Validation Class Initialized
INFO - 2022-04-06 04:00:31 --> Controller Class Initialized
INFO - 2022-04-06 04:00:31 --> Model Class Initialized
INFO - 2022-04-06 04:00:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:00:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:00:31 --> Final output sent to browser
DEBUG - 2022-04-06 04:00:31 --> Total execution time: 0.0579
INFO - 2022-04-06 04:00:31 --> Config Class Initialized
INFO - 2022-04-06 04:00:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:00:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:31 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:31 --> URI Class Initialized
INFO - 2022-04-06 04:00:31 --> Router Class Initialized
INFO - 2022-04-06 04:00:31 --> Output Class Initialized
INFO - 2022-04-06 04:00:31 --> Security Class Initialized
DEBUG - 2022-04-06 04:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:31 --> Input Class Initialized
INFO - 2022-04-06 04:00:31 --> Language Class Initialized
INFO - 2022-04-06 04:00:31 --> Loader Class Initialized
INFO - 2022-04-06 04:00:31 --> Helper loaded: url_helper
INFO - 2022-04-06 04:00:31 --> Helper loaded: form_helper
INFO - 2022-04-06 04:00:31 --> Helper loaded: common_helper
INFO - 2022-04-06 04:00:31 --> Helper loaded: util_helper
INFO - 2022-04-06 04:00:31 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:00:31 --> Form Validation Class Initialized
INFO - 2022-04-06 04:00:31 --> Controller Class Initialized
INFO - 2022-04-06 04:00:31 --> Model Class Initialized
INFO - 2022-04-06 04:00:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:00:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:00:31 --> Final output sent to browser
DEBUG - 2022-04-06 04:00:31 --> Total execution time: 0.0746
INFO - 2022-04-06 04:00:39 --> Config Class Initialized
INFO - 2022-04-06 04:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:39 --> URI Class Initialized
INFO - 2022-04-06 04:00:39 --> Router Class Initialized
INFO - 2022-04-06 04:00:39 --> Output Class Initialized
INFO - 2022-04-06 04:00:39 --> Security Class Initialized
DEBUG - 2022-04-06 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:39 --> Input Class Initialized
INFO - 2022-04-06 04:00:39 --> Language Class Initialized
INFO - 2022-04-06 04:00:39 --> Loader Class Initialized
INFO - 2022-04-06 04:00:39 --> Helper loaded: url_helper
INFO - 2022-04-06 04:00:39 --> Helper loaded: form_helper
INFO - 2022-04-06 04:00:39 --> Helper loaded: common_helper
INFO - 2022-04-06 04:00:39 --> Helper loaded: util_helper
INFO - 2022-04-06 04:00:39 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:00:39 --> Form Validation Class Initialized
INFO - 2022-04-06 04:00:39 --> Controller Class Initialized
INFO - 2022-04-06 04:00:39 --> Model Class Initialized
INFO - 2022-04-06 04:00:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:00:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:00:39 --> Final output sent to browser
DEBUG - 2022-04-06 04:00:39 --> Total execution time: 0.0617
INFO - 2022-04-06 04:00:39 --> Config Class Initialized
INFO - 2022-04-06 04:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:39 --> URI Class Initialized
INFO - 2022-04-06 04:00:39 --> Config Class Initialized
INFO - 2022-04-06 04:00:39 --> Hooks Class Initialized
INFO - 2022-04-06 04:00:39 --> Router Class Initialized
DEBUG - 2022-04-06 04:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:39 --> Output Class Initialized
INFO - 2022-04-06 04:00:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:39 --> URI Class Initialized
INFO - 2022-04-06 04:00:39 --> Security Class Initialized
INFO - 2022-04-06 04:00:39 --> Router Class Initialized
DEBUG - 2022-04-06 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:39 --> Input Class Initialized
INFO - 2022-04-06 04:00:39 --> Output Class Initialized
INFO - 2022-04-06 04:00:39 --> Language Class Initialized
INFO - 2022-04-06 04:00:39 --> Security Class Initialized
ERROR - 2022-04-06 04:00:39 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:39 --> Input Class Initialized
INFO - 2022-04-06 04:00:39 --> Language Class Initialized
ERROR - 2022-04-06 04:00:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:00:39 --> Config Class Initialized
INFO - 2022-04-06 04:00:39 --> Hooks Class Initialized
INFO - 2022-04-06 04:00:39 --> Config Class Initialized
INFO - 2022-04-06 04:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:39 --> URI Class Initialized
DEBUG - 2022-04-06 04:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:00:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:00:39 --> Router Class Initialized
INFO - 2022-04-06 04:00:39 --> URI Class Initialized
INFO - 2022-04-06 04:00:39 --> Output Class Initialized
INFO - 2022-04-06 04:00:39 --> Router Class Initialized
INFO - 2022-04-06 04:00:39 --> Security Class Initialized
INFO - 2022-04-06 04:00:39 --> Output Class Initialized
DEBUG - 2022-04-06 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:39 --> Input Class Initialized
INFO - 2022-04-06 04:00:39 --> Language Class Initialized
INFO - 2022-04-06 04:00:39 --> Security Class Initialized
ERROR - 2022-04-06 04:00:39 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:00:39 --> Input Class Initialized
INFO - 2022-04-06 04:00:39 --> Language Class Initialized
ERROR - 2022-04-06 04:00:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:19 --> Config Class Initialized
INFO - 2022-04-06 04:02:19 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:19 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:19 --> URI Class Initialized
INFO - 2022-04-06 04:02:19 --> Router Class Initialized
INFO - 2022-04-06 04:02:19 --> Output Class Initialized
INFO - 2022-04-06 04:02:19 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:19 --> Input Class Initialized
INFO - 2022-04-06 04:02:19 --> Language Class Initialized
INFO - 2022-04-06 04:02:19 --> Loader Class Initialized
INFO - 2022-04-06 04:02:19 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:19 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:19 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:19 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:19 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:19 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:19 --> Controller Class Initialized
INFO - 2022-04-06 04:02:19 --> Model Class Initialized
INFO - 2022-04-06 04:02:19 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:02:19 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:19 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:19 --> Total execution time: 0.0698
INFO - 2022-04-06 04:02:19 --> Config Class Initialized
INFO - 2022-04-06 04:02:19 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:19 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:19 --> URI Class Initialized
INFO - 2022-04-06 04:02:19 --> Config Class Initialized
INFO - 2022-04-06 04:02:19 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:19 --> Router Class Initialized
DEBUG - 2022-04-06 04:02:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:19 --> Output Class Initialized
INFO - 2022-04-06 04:02:19 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:19 --> URI Class Initialized
INFO - 2022-04-06 04:02:19 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:19 --> Router Class Initialized
INFO - 2022-04-06 04:02:19 --> Input Class Initialized
INFO - 2022-04-06 04:02:19 --> Language Class Initialized
INFO - 2022-04-06 04:02:19 --> Output Class Initialized
ERROR - 2022-04-06 04:02:19 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:19 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:19 --> Input Class Initialized
INFO - 2022-04-06 04:02:19 --> Language Class Initialized
ERROR - 2022-04-06 04:02:19 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:19 --> Config Class Initialized
INFO - 2022-04-06 04:02:19 --> Config Class Initialized
INFO - 2022-04-06 04:02:19 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:19 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:19 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:19 --> URI Class Initialized
INFO - 2022-04-06 04:02:19 --> Router Class Initialized
DEBUG - 2022-04-06 04:02:19 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:19 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:19 --> URI Class Initialized
INFO - 2022-04-06 04:02:19 --> Router Class Initialized
INFO - 2022-04-06 04:02:19 --> Output Class Initialized
INFO - 2022-04-06 04:02:19 --> Security Class Initialized
INFO - 2022-04-06 04:02:19 --> Output Class Initialized
INFO - 2022-04-06 04:02:19 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:19 --> Input Class Initialized
DEBUG - 2022-04-06 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:19 --> Language Class Initialized
INFO - 2022-04-06 04:02:19 --> Input Class Initialized
INFO - 2022-04-06 04:02:19 --> Language Class Initialized
ERROR - 2022-04-06 04:02:19 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:02:19 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:22 --> Config Class Initialized
INFO - 2022-04-06 04:02:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:22 --> URI Class Initialized
INFO - 2022-04-06 04:02:22 --> Router Class Initialized
INFO - 2022-04-06 04:02:22 --> Output Class Initialized
INFO - 2022-04-06 04:02:22 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:22 --> Input Class Initialized
INFO - 2022-04-06 04:02:22 --> Language Class Initialized
INFO - 2022-04-06 04:02:22 --> Loader Class Initialized
INFO - 2022-04-06 04:02:22 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:22 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:22 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:22 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:22 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:22 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:22 --> Controller Class Initialized
INFO - 2022-04-06 04:02:22 --> Model Class Initialized
INFO - 2022-04-06 04:02:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:02:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:22 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:22 --> Total execution time: 0.0808
INFO - 2022-04-06 04:02:25 --> Config Class Initialized
INFO - 2022-04-06 04:02:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:25 --> URI Class Initialized
INFO - 2022-04-06 04:02:25 --> Router Class Initialized
INFO - 2022-04-06 04:02:25 --> Output Class Initialized
INFO - 2022-04-06 04:02:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:25 --> Input Class Initialized
INFO - 2022-04-06 04:02:25 --> Language Class Initialized
INFO - 2022-04-06 04:02:25 --> Loader Class Initialized
INFO - 2022-04-06 04:02:25 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:25 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:25 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:25 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:25 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:25 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:25 --> Controller Class Initialized
INFO - 2022-04-06 04:02:25 --> Model Class Initialized
INFO - 2022-04-06 04:02:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:02:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:25 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:25 --> Total execution time: 0.0679
INFO - 2022-04-06 04:02:25 --> Config Class Initialized
INFO - 2022-04-06 04:02:25 --> Config Class Initialized
INFO - 2022-04-06 04:02:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:25 --> URI Class Initialized
DEBUG - 2022-04-06 04:02:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:25 --> Router Class Initialized
INFO - 2022-04-06 04:02:25 --> URI Class Initialized
INFO - 2022-04-06 04:02:25 --> Output Class Initialized
INFO - 2022-04-06 04:02:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:25 --> Input Class Initialized
INFO - 2022-04-06 04:02:25 --> Language Class Initialized
ERROR - 2022-04-06 04:02:25 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:25 --> Router Class Initialized
INFO - 2022-04-06 04:02:25 --> Output Class Initialized
INFO - 2022-04-06 04:02:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:25 --> Input Class Initialized
INFO - 2022-04-06 04:02:25 --> Language Class Initialized
INFO - 2022-04-06 04:02:25 --> Config Class Initialized
INFO - 2022-04-06 04:02:25 --> Hooks Class Initialized
ERROR - 2022-04-06 04:02:25 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:02:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:25 --> URI Class Initialized
INFO - 2022-04-06 04:02:25 --> Router Class Initialized
INFO - 2022-04-06 04:02:25 --> Output Class Initialized
INFO - 2022-04-06 04:02:25 --> Config Class Initialized
INFO - 2022-04-06 04:02:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:25 --> Input Class Initialized
DEBUG - 2022-04-06 04:02:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:25 --> Language Class Initialized
INFO - 2022-04-06 04:02:25 --> URI Class Initialized
ERROR - 2022-04-06 04:02:25 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:25 --> Router Class Initialized
INFO - 2022-04-06 04:02:25 --> Output Class Initialized
INFO - 2022-04-06 04:02:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:25 --> Input Class Initialized
INFO - 2022-04-06 04:02:25 --> Language Class Initialized
ERROR - 2022-04-06 04:02:25 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:27 --> Config Class Initialized
INFO - 2022-04-06 04:02:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:27 --> URI Class Initialized
INFO - 2022-04-06 04:02:27 --> Router Class Initialized
INFO - 2022-04-06 04:02:27 --> Output Class Initialized
INFO - 2022-04-06 04:02:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:27 --> Input Class Initialized
INFO - 2022-04-06 04:02:27 --> Language Class Initialized
INFO - 2022-04-06 04:02:27 --> Loader Class Initialized
INFO - 2022-04-06 04:02:27 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:27 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:27 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:27 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:27 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:27 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:27 --> Controller Class Initialized
INFO - 2022-04-06 04:02:27 --> Model Class Initialized
INFO - 2022-04-06 04:02:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:02:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:27 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:27 --> Total execution time: 0.0653
INFO - 2022-04-06 04:02:29 --> Config Class Initialized
INFO - 2022-04-06 04:02:29 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:29 --> URI Class Initialized
INFO - 2022-04-06 04:02:29 --> Router Class Initialized
INFO - 2022-04-06 04:02:29 --> Output Class Initialized
INFO - 2022-04-06 04:02:29 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:29 --> Input Class Initialized
INFO - 2022-04-06 04:02:29 --> Language Class Initialized
INFO - 2022-04-06 04:02:29 --> Loader Class Initialized
INFO - 2022-04-06 04:02:29 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:29 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:29 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:29 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:29 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:29 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:29 --> Controller Class Initialized
INFO - 2022-04-06 04:02:29 --> Model Class Initialized
INFO - 2022-04-06 04:02:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:02:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:29 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:29 --> Total execution time: 0.0672
INFO - 2022-04-06 04:02:29 --> Config Class Initialized
INFO - 2022-04-06 04:02:29 --> Config Class Initialized
INFO - 2022-04-06 04:02:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:29 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:02:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:29 --> URI Class Initialized
INFO - 2022-04-06 04:02:29 --> URI Class Initialized
INFO - 2022-04-06 04:02:29 --> Router Class Initialized
INFO - 2022-04-06 04:02:29 --> Router Class Initialized
INFO - 2022-04-06 04:02:29 --> Output Class Initialized
INFO - 2022-04-06 04:02:29 --> Output Class Initialized
INFO - 2022-04-06 04:02:29 --> Security Class Initialized
INFO - 2022-04-06 04:02:29 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:29 --> Input Class Initialized
INFO - 2022-04-06 04:02:29 --> Input Class Initialized
INFO - 2022-04-06 04:02:29 --> Language Class Initialized
INFO - 2022-04-06 04:02:29 --> Language Class Initialized
ERROR - 2022-04-06 04:02:29 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:02:29 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:29 --> Config Class Initialized
INFO - 2022-04-06 04:02:29 --> Config Class Initialized
INFO - 2022-04-06 04:02:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:29 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:02:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:29 --> URI Class Initialized
INFO - 2022-04-06 04:02:29 --> URI Class Initialized
INFO - 2022-04-06 04:02:29 --> Router Class Initialized
INFO - 2022-04-06 04:02:29 --> Router Class Initialized
INFO - 2022-04-06 04:02:29 --> Output Class Initialized
INFO - 2022-04-06 04:02:29 --> Output Class Initialized
INFO - 2022-04-06 04:02:29 --> Security Class Initialized
INFO - 2022-04-06 04:02:29 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:29 --> Input Class Initialized
INFO - 2022-04-06 04:02:29 --> Input Class Initialized
INFO - 2022-04-06 04:02:29 --> Language Class Initialized
INFO - 2022-04-06 04:02:29 --> Language Class Initialized
ERROR - 2022-04-06 04:02:29 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:02:29 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:43 --> Config Class Initialized
INFO - 2022-04-06 04:02:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:43 --> URI Class Initialized
INFO - 2022-04-06 04:02:43 --> Router Class Initialized
INFO - 2022-04-06 04:02:43 --> Output Class Initialized
INFO - 2022-04-06 04:02:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:43 --> Input Class Initialized
INFO - 2022-04-06 04:02:43 --> Language Class Initialized
INFO - 2022-04-06 04:02:43 --> Loader Class Initialized
INFO - 2022-04-06 04:02:43 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:43 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:43 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:43 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:43 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:43 --> Controller Class Initialized
INFO - 2022-04-06 04:02:43 --> Model Class Initialized
INFO - 2022-04-06 04:02:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:02:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:43 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:43 --> Total execution time: 0.0552
INFO - 2022-04-06 04:02:43 --> Config Class Initialized
INFO - 2022-04-06 04:02:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:43 --> Config Class Initialized
DEBUG - 2022-04-06 04:02:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:43 --> URI Class Initialized
DEBUG - 2022-04-06 04:02:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:43 --> URI Class Initialized
INFO - 2022-04-06 04:02:43 --> Router Class Initialized
INFO - 2022-04-06 04:02:43 --> Router Class Initialized
INFO - 2022-04-06 04:02:43 --> Output Class Initialized
INFO - 2022-04-06 04:02:43 --> Output Class Initialized
INFO - 2022-04-06 04:02:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:43 --> Security Class Initialized
INFO - 2022-04-06 04:02:43 --> Input Class Initialized
INFO - 2022-04-06 04:02:43 --> Language Class Initialized
DEBUG - 2022-04-06 04:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:43 --> Input Class Initialized
INFO - 2022-04-06 04:02:43 --> Language Class Initialized
ERROR - 2022-04-06 04:02:43 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:02:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:43 --> Config Class Initialized
INFO - 2022-04-06 04:02:43 --> Config Class Initialized
INFO - 2022-04-06 04:02:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:02:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:43 --> URI Class Initialized
INFO - 2022-04-06 04:02:43 --> URI Class Initialized
INFO - 2022-04-06 04:02:43 --> Router Class Initialized
INFO - 2022-04-06 04:02:43 --> Router Class Initialized
INFO - 2022-04-06 04:02:43 --> Output Class Initialized
INFO - 2022-04-06 04:02:43 --> Output Class Initialized
INFO - 2022-04-06 04:02:43 --> Security Class Initialized
INFO - 2022-04-06 04:02:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:43 --> Input Class Initialized
DEBUG - 2022-04-06 04:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:43 --> Input Class Initialized
INFO - 2022-04-06 04:02:43 --> Language Class Initialized
INFO - 2022-04-06 04:02:43 --> Language Class Initialized
ERROR - 2022-04-06 04:02:43 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:02:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:46 --> Config Class Initialized
INFO - 2022-04-06 04:02:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:46 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:46 --> URI Class Initialized
INFO - 2022-04-06 04:02:46 --> Router Class Initialized
INFO - 2022-04-06 04:02:46 --> Output Class Initialized
INFO - 2022-04-06 04:02:46 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:46 --> Input Class Initialized
INFO - 2022-04-06 04:02:46 --> Language Class Initialized
INFO - 2022-04-06 04:02:46 --> Loader Class Initialized
INFO - 2022-04-06 04:02:46 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:46 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:46 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:46 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:46 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:46 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:46 --> Controller Class Initialized
INFO - 2022-04-06 04:02:46 --> Model Class Initialized
INFO - 2022-04-06 04:02:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:02:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:46 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:46 --> Total execution time: 0.0684
INFO - 2022-04-06 04:02:49 --> Config Class Initialized
INFO - 2022-04-06 04:02:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:49 --> URI Class Initialized
INFO - 2022-04-06 04:02:49 --> Router Class Initialized
INFO - 2022-04-06 04:02:49 --> Output Class Initialized
INFO - 2022-04-06 04:02:49 --> Security Class Initialized
DEBUG - 2022-04-06 04:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:49 --> Input Class Initialized
INFO - 2022-04-06 04:02:49 --> Language Class Initialized
INFO - 2022-04-06 04:02:49 --> Loader Class Initialized
INFO - 2022-04-06 04:02:49 --> Helper loaded: url_helper
INFO - 2022-04-06 04:02:49 --> Helper loaded: form_helper
INFO - 2022-04-06 04:02:49 --> Helper loaded: common_helper
INFO - 2022-04-06 04:02:49 --> Helper loaded: util_helper
INFO - 2022-04-06 04:02:49 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:02:49 --> Form Validation Class Initialized
INFO - 2022-04-06 04:02:49 --> Controller Class Initialized
INFO - 2022-04-06 04:02:49 --> Model Class Initialized
INFO - 2022-04-06 04:02:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:02:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:02:49 --> Final output sent to browser
DEBUG - 2022-04-06 04:02:49 --> Total execution time: 0.0656
INFO - 2022-04-06 04:02:49 --> Config Class Initialized
INFO - 2022-04-06 04:02:49 --> Config Class Initialized
INFO - 2022-04-06 04:02:49 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:02:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:49 --> URI Class Initialized
INFO - 2022-04-06 04:02:49 --> URI Class Initialized
INFO - 2022-04-06 04:02:49 --> Router Class Initialized
INFO - 2022-04-06 04:02:49 --> Output Class Initialized
INFO - 2022-04-06 04:02:49 --> Router Class Initialized
INFO - 2022-04-06 04:02:49 --> Output Class Initialized
INFO - 2022-04-06 04:02:49 --> Security Class Initialized
INFO - 2022-04-06 04:02:49 --> Config Class Initialized
INFO - 2022-04-06 04:02:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:49 --> Input Class Initialized
INFO - 2022-04-06 04:02:49 --> Language Class Initialized
DEBUG - 2022-04-06 04:02:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:49 --> Config Class Initialized
ERROR - 2022-04-06 04:02:49 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:49 --> Hooks Class Initialized
INFO - 2022-04-06 04:02:49 --> URI Class Initialized
INFO - 2022-04-06 04:02:49 --> Security Class Initialized
INFO - 2022-04-06 04:02:49 --> Router Class Initialized
DEBUG - 2022-04-06 04:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:49 --> Input Class Initialized
DEBUG - 2022-04-06 04:02:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:02:49 --> Language Class Initialized
INFO - 2022-04-06 04:02:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:02:49 --> Output Class Initialized
INFO - 2022-04-06 04:02:49 --> URI Class Initialized
ERROR - 2022-04-06 04:02:49 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:02:49 --> Security Class Initialized
INFO - 2022-04-06 04:02:49 --> Router Class Initialized
DEBUG - 2022-04-06 04:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:49 --> Input Class Initialized
INFO - 2022-04-06 04:02:49 --> Output Class Initialized
INFO - 2022-04-06 04:02:49 --> Language Class Initialized
INFO - 2022-04-06 04:02:49 --> Security Class Initialized
ERROR - 2022-04-06 04:02:49 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:02:49 --> Input Class Initialized
INFO - 2022-04-06 04:02:49 --> Language Class Initialized
ERROR - 2022-04-06 04:02:49 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:03:03 --> Config Class Initialized
INFO - 2022-04-06 04:03:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:03:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:03:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:03:03 --> URI Class Initialized
INFO - 2022-04-06 04:03:03 --> Router Class Initialized
INFO - 2022-04-06 04:03:03 --> Output Class Initialized
INFO - 2022-04-06 04:03:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:03:03 --> Input Class Initialized
INFO - 2022-04-06 04:03:03 --> Language Class Initialized
INFO - 2022-04-06 04:03:03 --> Loader Class Initialized
INFO - 2022-04-06 04:03:03 --> Helper loaded: url_helper
INFO - 2022-04-06 04:03:03 --> Helper loaded: form_helper
INFO - 2022-04-06 04:03:03 --> Helper loaded: common_helper
INFO - 2022-04-06 04:03:03 --> Helper loaded: util_helper
INFO - 2022-04-06 04:03:03 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:03:03 --> Form Validation Class Initialized
INFO - 2022-04-06 04:03:03 --> Controller Class Initialized
INFO - 2022-04-06 04:03:03 --> Model Class Initialized
INFO - 2022-04-06 04:03:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:03:03 --> Config Class Initialized
INFO - 2022-04-06 04:03:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:03:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:03:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:03:03 --> URI Class Initialized
INFO - 2022-04-06 04:03:03 --> Router Class Initialized
INFO - 2022-04-06 04:03:03 --> Output Class Initialized
INFO - 2022-04-06 04:03:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:03:03 --> Input Class Initialized
INFO - 2022-04-06 04:03:03 --> Language Class Initialized
INFO - 2022-04-06 04:03:03 --> Loader Class Initialized
INFO - 2022-04-06 04:03:03 --> Helper loaded: url_helper
INFO - 2022-04-06 04:03:03 --> Helper loaded: form_helper
INFO - 2022-04-06 04:03:03 --> Helper loaded: common_helper
INFO - 2022-04-06 04:03:03 --> Helper loaded: util_helper
INFO - 2022-04-06 04:03:03 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:03:03 --> Form Validation Class Initialized
INFO - 2022-04-06 04:03:03 --> Controller Class Initialized
INFO - 2022-04-06 04:03:03 --> Model Class Initialized
INFO - 2022-04-06 04:03:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:03:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:03:03 --> Final output sent to browser
DEBUG - 2022-04-06 04:03:03 --> Total execution time: 0.0556
INFO - 2022-04-06 04:03:03 --> Config Class Initialized
INFO - 2022-04-06 04:03:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:03:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:03:03 --> Config Class Initialized
INFO - 2022-04-06 04:03:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:03:03 --> Hooks Class Initialized
INFO - 2022-04-06 04:03:03 --> URI Class Initialized
INFO - 2022-04-06 04:03:03 --> Router Class Initialized
DEBUG - 2022-04-06 04:03:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:03:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:03:03 --> Output Class Initialized
INFO - 2022-04-06 04:03:03 --> URI Class Initialized
INFO - 2022-04-06 04:03:03 --> Security Class Initialized
INFO - 2022-04-06 04:03:03 --> Router Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:03:03 --> Input Class Initialized
INFO - 2022-04-06 04:03:03 --> Output Class Initialized
INFO - 2022-04-06 04:03:03 --> Language Class Initialized
INFO - 2022-04-06 04:03:03 --> Security Class Initialized
ERROR - 2022-04-06 04:03:03 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:03:03 --> Input Class Initialized
INFO - 2022-04-06 04:03:03 --> Language Class Initialized
ERROR - 2022-04-06 04:03:03 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:03:03 --> Config Class Initialized
INFO - 2022-04-06 04:03:03 --> Hooks Class Initialized
INFO - 2022-04-06 04:03:03 --> Config Class Initialized
DEBUG - 2022-04-06 04:03:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:03:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:03:03 --> URI Class Initialized
INFO - 2022-04-06 04:03:03 --> Hooks Class Initialized
INFO - 2022-04-06 04:03:03 --> Router Class Initialized
INFO - 2022-04-06 04:03:03 --> Output Class Initialized
DEBUG - 2022-04-06 04:03:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:03:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:03:03 --> Security Class Initialized
INFO - 2022-04-06 04:03:03 --> URI Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:03:03 --> Input Class Initialized
INFO - 2022-04-06 04:03:03 --> Router Class Initialized
INFO - 2022-04-06 04:03:03 --> Language Class Initialized
INFO - 2022-04-06 04:03:03 --> Output Class Initialized
ERROR - 2022-04-06 04:03:03 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:03:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:03:03 --> Input Class Initialized
INFO - 2022-04-06 04:03:03 --> Language Class Initialized
ERROR - 2022-04-06 04:03:03 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:15 --> Config Class Initialized
INFO - 2022-04-06 04:04:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:15 --> URI Class Initialized
INFO - 2022-04-06 04:04:15 --> Router Class Initialized
INFO - 2022-04-06 04:04:15 --> Output Class Initialized
INFO - 2022-04-06 04:04:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:15 --> Input Class Initialized
INFO - 2022-04-06 04:04:15 --> Language Class Initialized
INFO - 2022-04-06 04:04:15 --> Loader Class Initialized
INFO - 2022-04-06 04:04:15 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:15 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:15 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:15 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:15 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:15 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:15 --> Controller Class Initialized
INFO - 2022-04-06 04:04:15 --> Model Class Initialized
INFO - 2022-04-06 04:04:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:04:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:04:15 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:15 --> Total execution time: 0.0643
INFO - 2022-04-06 04:04:16 --> Config Class Initialized
INFO - 2022-04-06 04:04:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:16 --> URI Class Initialized
INFO - 2022-04-06 04:04:16 --> Router Class Initialized
INFO - 2022-04-06 04:04:16 --> Output Class Initialized
INFO - 2022-04-06 04:04:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:16 --> Input Class Initialized
INFO - 2022-04-06 04:04:16 --> Language Class Initialized
INFO - 2022-04-06 04:04:16 --> Loader Class Initialized
INFO - 2022-04-06 04:04:16 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:16 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:16 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:16 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:16 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:16 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:16 --> Controller Class Initialized
INFO - 2022-04-06 04:04:16 --> Model Class Initialized
INFO - 2022-04-06 04:04:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:04:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:04:16 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:16 --> Total execution time: 0.0809
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Loader Class Initialized
INFO - 2022-04-06 04:04:20 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:20 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:20 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:20 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:20 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:20 --> Controller Class Initialized
INFO - 2022-04-06 04:04:20 --> Model Class Initialized
INFO - 2022-04-06 04:04:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:04:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:04:20 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:20 --> Total execution time: 0.0581
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Config Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
DEBUG - 2022-04-06 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> URI Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Router Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Output Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
INFO - 2022-04-06 04:04:20 --> Security Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:20 --> Input Class Initialized
INFO - 2022-04-06 04:04:20 --> Language Class Initialized
ERROR - 2022-04-06 04:04:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:21 --> Config Class Initialized
INFO - 2022-04-06 04:04:21 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:21 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:21 --> URI Class Initialized
INFO - 2022-04-06 04:04:21 --> Router Class Initialized
INFO - 2022-04-06 04:04:21 --> Output Class Initialized
INFO - 2022-04-06 04:04:21 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:21 --> Input Class Initialized
INFO - 2022-04-06 04:04:21 --> Language Class Initialized
ERROR - 2022-04-06 04:04:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:34 --> Config Class Initialized
INFO - 2022-04-06 04:04:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:34 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:34 --> URI Class Initialized
INFO - 2022-04-06 04:04:34 --> Router Class Initialized
INFO - 2022-04-06 04:04:34 --> Output Class Initialized
INFO - 2022-04-06 04:04:34 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:34 --> Input Class Initialized
INFO - 2022-04-06 04:04:34 --> Language Class Initialized
INFO - 2022-04-06 04:04:34 --> Loader Class Initialized
INFO - 2022-04-06 04:04:34 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:34 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:34 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:34 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:34 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:34 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:34 --> Controller Class Initialized
INFO - 2022-04-06 04:04:34 --> Model Class Initialized
INFO - 2022-04-06 04:04:34 --> Config Class Initialized
INFO - 2022-04-06 04:04:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:34 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:34 --> URI Class Initialized
INFO - 2022-04-06 04:04:34 --> Router Class Initialized
INFO - 2022-04-06 04:04:34 --> Output Class Initialized
INFO - 2022-04-06 04:04:34 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:34 --> Input Class Initialized
INFO - 2022-04-06 04:04:34 --> Language Class Initialized
INFO - 2022-04-06 04:04:34 --> Loader Class Initialized
INFO - 2022-04-06 04:04:34 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:34 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:34 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:34 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:34 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:34 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:34 --> Controller Class Initialized
INFO - 2022-04-06 04:04:34 --> Model Class Initialized
INFO - 2022-04-06 04:04:34 --> Model Class Initialized
INFO - 2022-04-06 04:04:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:04:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:04:34 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:34 --> Total execution time: 0.0713
INFO - 2022-04-06 04:04:34 --> Config Class Initialized
INFO - 2022-04-06 04:04:34 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:34 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:34 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:34 --> URI Class Initialized
INFO - 2022-04-06 04:04:34 --> Router Class Initialized
INFO - 2022-04-06 04:04:34 --> Output Class Initialized
INFO - 2022-04-06 04:04:34 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:34 --> Input Class Initialized
INFO - 2022-04-06 04:04:34 --> Language Class Initialized
ERROR - 2022-04-06 04:04:34 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:44 --> Config Class Initialized
INFO - 2022-04-06 04:04:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:44 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:44 --> URI Class Initialized
INFO - 2022-04-06 04:04:44 --> Router Class Initialized
INFO - 2022-04-06 04:04:44 --> Output Class Initialized
INFO - 2022-04-06 04:04:44 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:44 --> Input Class Initialized
INFO - 2022-04-06 04:04:44 --> Language Class Initialized
INFO - 2022-04-06 04:04:44 --> Loader Class Initialized
INFO - 2022-04-06 04:04:44 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:44 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:44 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:44 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:44 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:44 --> Controller Class Initialized
INFO - 2022-04-06 04:04:44 --> Model Class Initialized
INFO - 2022-04-06 04:04:44 --> Config Class Initialized
INFO - 2022-04-06 04:04:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:44 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:44 --> URI Class Initialized
INFO - 2022-04-06 04:04:44 --> Router Class Initialized
INFO - 2022-04-06 04:04:44 --> Output Class Initialized
INFO - 2022-04-06 04:04:44 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:44 --> Input Class Initialized
INFO - 2022-04-06 04:04:44 --> Language Class Initialized
INFO - 2022-04-06 04:04:44 --> Loader Class Initialized
INFO - 2022-04-06 04:04:44 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:44 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:44 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:44 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:44 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:44 --> Controller Class Initialized
INFO - 2022-04-06 04:04:44 --> Model Class Initialized
INFO - 2022-04-06 04:04:44 --> Model Class Initialized
INFO - 2022-04-06 04:04:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:04:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:04:44 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:44 --> Total execution time: 0.0541
INFO - 2022-04-06 04:04:44 --> Config Class Initialized
INFO - 2022-04-06 04:04:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:44 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:44 --> URI Class Initialized
INFO - 2022-04-06 04:04:44 --> Router Class Initialized
INFO - 2022-04-06 04:04:44 --> Output Class Initialized
INFO - 2022-04-06 04:04:44 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:44 --> Input Class Initialized
INFO - 2022-04-06 04:04:44 --> Language Class Initialized
ERROR - 2022-04-06 04:04:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:04:51 --> Config Class Initialized
INFO - 2022-04-06 04:04:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:51 --> URI Class Initialized
INFO - 2022-04-06 04:04:51 --> Router Class Initialized
INFO - 2022-04-06 04:04:51 --> Output Class Initialized
INFO - 2022-04-06 04:04:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:51 --> Input Class Initialized
INFO - 2022-04-06 04:04:51 --> Language Class Initialized
INFO - 2022-04-06 04:04:51 --> Loader Class Initialized
INFO - 2022-04-06 04:04:51 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:51 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:51 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:51 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:51 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:51 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:51 --> Controller Class Initialized
INFO - 2022-04-06 04:04:51 --> Model Class Initialized
INFO - 2022-04-06 04:04:51 --> Model Class Initialized
INFO - 2022-04-06 04:04:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:04:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:04:51 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:51 --> Total execution time: 0.0553
INFO - 2022-04-06 04:04:55 --> Config Class Initialized
INFO - 2022-04-06 04:04:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:55 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:55 --> URI Class Initialized
INFO - 2022-04-06 04:04:55 --> Router Class Initialized
INFO - 2022-04-06 04:04:55 --> Output Class Initialized
INFO - 2022-04-06 04:04:55 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:55 --> Input Class Initialized
INFO - 2022-04-06 04:04:55 --> Language Class Initialized
INFO - 2022-04-06 04:04:55 --> Loader Class Initialized
INFO - 2022-04-06 04:04:55 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:55 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:55 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:55 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:55 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:55 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:55 --> Controller Class Initialized
INFO - 2022-04-06 04:04:55 --> Model Class Initialized
INFO - 2022-04-06 04:04:55 --> Config Class Initialized
INFO - 2022-04-06 04:04:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:55 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:55 --> URI Class Initialized
INFO - 2022-04-06 04:04:55 --> Router Class Initialized
INFO - 2022-04-06 04:04:55 --> Output Class Initialized
INFO - 2022-04-06 04:04:55 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:55 --> Input Class Initialized
INFO - 2022-04-06 04:04:55 --> Language Class Initialized
INFO - 2022-04-06 04:04:55 --> Loader Class Initialized
INFO - 2022-04-06 04:04:55 --> Helper loaded: url_helper
INFO - 2022-04-06 04:04:55 --> Helper loaded: form_helper
INFO - 2022-04-06 04:04:55 --> Helper loaded: common_helper
INFO - 2022-04-06 04:04:55 --> Helper loaded: util_helper
INFO - 2022-04-06 04:04:55 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:04:55 --> Form Validation Class Initialized
INFO - 2022-04-06 04:04:55 --> Controller Class Initialized
INFO - 2022-04-06 04:04:55 --> Model Class Initialized
INFO - 2022-04-06 04:04:55 --> Model Class Initialized
INFO - 2022-04-06 04:04:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:04:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:04:55 --> Final output sent to browser
DEBUG - 2022-04-06 04:04:55 --> Total execution time: 0.0524
INFO - 2022-04-06 04:04:55 --> Config Class Initialized
INFO - 2022-04-06 04:04:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:04:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:04:55 --> Utf8 Class Initialized
INFO - 2022-04-06 04:04:55 --> URI Class Initialized
INFO - 2022-04-06 04:04:55 --> Router Class Initialized
INFO - 2022-04-06 04:04:55 --> Output Class Initialized
INFO - 2022-04-06 04:04:55 --> Security Class Initialized
DEBUG - 2022-04-06 04:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:04:55 --> Input Class Initialized
INFO - 2022-04-06 04:04:55 --> Language Class Initialized
ERROR - 2022-04-06 04:04:55 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:26 --> Input Class Initialized
INFO - 2022-04-06 04:05:26 --> Language Class Initialized
INFO - 2022-04-06 04:05:26 --> Loader Class Initialized
INFO - 2022-04-06 04:05:26 --> Helper loaded: url_helper
INFO - 2022-04-06 04:05:26 --> Helper loaded: form_helper
INFO - 2022-04-06 04:05:26 --> Helper loaded: common_helper
INFO - 2022-04-06 04:05:26 --> Helper loaded: util_helper
INFO - 2022-04-06 04:05:26 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:05:26 --> Form Validation Class Initialized
INFO - 2022-04-06 04:05:26 --> Controller Class Initialized
INFO - 2022-04-06 04:05:26 --> Model Class Initialized
INFO - 2022-04-06 04:05:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:05:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:05:26 --> Final output sent to browser
DEBUG - 2022-04-06 04:05:26 --> Total execution time: 0.0780
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
DEBUG - 2022-04-06 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
INFO - 2022-04-06 04:05:26 --> Input Class Initialized
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
INFO - 2022-04-06 04:05:26 --> Language Class Initialized
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:26 --> Input Class Initialized
ERROR - 2022-04-06 04:05:26 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:26 --> Language Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:05:26 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:26 --> Input Class Initialized
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Language Class Initialized
INFO - 2022-04-06 04:05:26 --> Config Class Initialized
INFO - 2022-04-06 04:05:26 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
ERROR - 2022-04-06 04:05:26 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:26 --> Input Class Initialized
DEBUG - 2022-04-06 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:26 --> Language Class Initialized
INFO - 2022-04-06 04:05:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
INFO - 2022-04-06 04:05:26 --> URI Class Initialized
ERROR - 2022-04-06 04:05:26 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
INFO - 2022-04-06 04:05:26 --> Router Class Initialized
INFO - 2022-04-06 04:05:26 --> Output Class Initialized
DEBUG - 2022-04-06 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:26 --> Input Class Initialized
INFO - 2022-04-06 04:05:26 --> Security Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
INFO - 2022-04-06 04:05:27 --> Config Class Initialized
INFO - 2022-04-06 04:05:27 --> Hooks Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:05:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:27 --> URI Class Initialized
INFO - 2022-04-06 04:05:27 --> Router Class Initialized
INFO - 2022-04-06 04:05:27 --> Output Class Initialized
INFO - 2022-04-06 04:05:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:27 --> Input Class Initialized
INFO - 2022-04-06 04:05:27 --> Language Class Initialized
ERROR - 2022-04-06 04:05:27 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:05:32 --> Config Class Initialized
INFO - 2022-04-06 04:05:32 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:32 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:32 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:32 --> URI Class Initialized
INFO - 2022-04-06 04:05:32 --> Router Class Initialized
INFO - 2022-04-06 04:05:32 --> Output Class Initialized
INFO - 2022-04-06 04:05:32 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:32 --> Input Class Initialized
INFO - 2022-04-06 04:05:32 --> Language Class Initialized
INFO - 2022-04-06 04:05:32 --> Loader Class Initialized
INFO - 2022-04-06 04:05:32 --> Helper loaded: url_helper
INFO - 2022-04-06 04:05:32 --> Helper loaded: form_helper
INFO - 2022-04-06 04:05:32 --> Helper loaded: common_helper
INFO - 2022-04-06 04:05:32 --> Helper loaded: util_helper
INFO - 2022-04-06 04:05:32 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:05:33 --> Form Validation Class Initialized
INFO - 2022-04-06 04:05:33 --> Controller Class Initialized
INFO - 2022-04-06 04:05:33 --> Model Class Initialized
INFO - 2022-04-06 04:05:33 --> Model Class Initialized
INFO - 2022-04-06 04:05:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:05:33 --> Final output sent to browser
DEBUG - 2022-04-06 04:05:33 --> Total execution time: 0.0584
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:33 --> Config Class Initialized
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
INFO - 2022-04-06 04:05:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
DEBUG - 2022-04-06 04:05:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
INFO - 2022-04-06 04:05:33 --> URI Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
INFO - 2022-04-06 04:05:33 --> Router Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Output Class Initialized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
INFO - 2022-04-06 04:05:33 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:33 --> Input Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:05:33 --> Language Class Initialized
ERROR - 2022-04-06 04:05:33 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:05:36 --> Config Class Initialized
INFO - 2022-04-06 04:05:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:36 --> URI Class Initialized
DEBUG - 2022-04-06 04:05:36 --> No URI present. Default controller set.
INFO - 2022-04-06 04:05:36 --> Router Class Initialized
INFO - 2022-04-06 04:05:36 --> Output Class Initialized
INFO - 2022-04-06 04:05:36 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:36 --> Input Class Initialized
INFO - 2022-04-06 04:05:36 --> Language Class Initialized
INFO - 2022-04-06 04:05:36 --> Loader Class Initialized
INFO - 2022-04-06 04:05:36 --> Helper loaded: url_helper
INFO - 2022-04-06 04:05:36 --> Helper loaded: form_helper
INFO - 2022-04-06 04:05:36 --> Helper loaded: common_helper
INFO - 2022-04-06 04:05:36 --> Helper loaded: util_helper
INFO - 2022-04-06 04:05:36 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:05:36 --> Form Validation Class Initialized
INFO - 2022-04-06 04:05:36 --> Controller Class Initialized
INFO - 2022-04-06 04:05:36 --> Model Class Initialized
INFO - 2022-04-06 04:05:36 --> Model Class Initialized
INFO - 2022-04-06 04:05:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:05:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:05:36 --> Final output sent to browser
DEBUG - 2022-04-06 04:05:36 --> Total execution time: 0.0620
INFO - 2022-04-06 04:05:38 --> Config Class Initialized
INFO - 2022-04-06 04:05:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:38 --> URI Class Initialized
DEBUG - 2022-04-06 04:05:38 --> No URI present. Default controller set.
INFO - 2022-04-06 04:05:38 --> Router Class Initialized
INFO - 2022-04-06 04:05:38 --> Output Class Initialized
INFO - 2022-04-06 04:05:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:38 --> Input Class Initialized
INFO - 2022-04-06 04:05:38 --> Language Class Initialized
INFO - 2022-04-06 04:05:38 --> Loader Class Initialized
INFO - 2022-04-06 04:05:38 --> Helper loaded: url_helper
INFO - 2022-04-06 04:05:38 --> Helper loaded: form_helper
INFO - 2022-04-06 04:05:38 --> Helper loaded: common_helper
INFO - 2022-04-06 04:05:38 --> Helper loaded: util_helper
INFO - 2022-04-06 04:05:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:05:38 --> Form Validation Class Initialized
INFO - 2022-04-06 04:05:38 --> Controller Class Initialized
INFO - 2022-04-06 04:05:38 --> Model Class Initialized
INFO - 2022-04-06 04:05:38 --> Model Class Initialized
INFO - 2022-04-06 04:05:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:05:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:05:38 --> Final output sent to browser
DEBUG - 2022-04-06 04:05:38 --> Total execution time: 0.0704
INFO - 2022-04-06 04:05:41 --> Config Class Initialized
INFO - 2022-04-06 04:05:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:05:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:05:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:05:41 --> URI Class Initialized
DEBUG - 2022-04-06 04:05:41 --> No URI present. Default controller set.
INFO - 2022-04-06 04:05:41 --> Router Class Initialized
INFO - 2022-04-06 04:05:41 --> Output Class Initialized
INFO - 2022-04-06 04:05:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:05:41 --> Input Class Initialized
INFO - 2022-04-06 04:05:41 --> Language Class Initialized
INFO - 2022-04-06 04:05:41 --> Loader Class Initialized
INFO - 2022-04-06 04:05:41 --> Helper loaded: url_helper
INFO - 2022-04-06 04:05:41 --> Helper loaded: form_helper
INFO - 2022-04-06 04:05:41 --> Helper loaded: common_helper
INFO - 2022-04-06 04:05:41 --> Helper loaded: util_helper
INFO - 2022-04-06 04:05:41 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:05:41 --> Form Validation Class Initialized
INFO - 2022-04-06 04:05:41 --> Controller Class Initialized
INFO - 2022-04-06 04:05:41 --> Model Class Initialized
INFO - 2022-04-06 04:05:41 --> Model Class Initialized
INFO - 2022-04-06 04:05:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:05:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:05:41 --> Final output sent to browser
DEBUG - 2022-04-06 04:05:41 --> Total execution time: 0.0730
INFO - 2022-04-06 04:06:16 --> Config Class Initialized
INFO - 2022-04-06 04:06:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:16 --> URI Class Initialized
INFO - 2022-04-06 04:06:16 --> Router Class Initialized
INFO - 2022-04-06 04:06:16 --> Output Class Initialized
INFO - 2022-04-06 04:06:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:16 --> Input Class Initialized
INFO - 2022-04-06 04:06:16 --> Language Class Initialized
INFO - 2022-04-06 04:06:16 --> Loader Class Initialized
INFO - 2022-04-06 04:06:16 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:16 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:16 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:16 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:16 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:16 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:16 --> Controller Class Initialized
INFO - 2022-04-06 04:06:16 --> Model Class Initialized
INFO - 2022-04-06 04:06:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:06:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:06:16 --> Final output sent to browser
DEBUG - 2022-04-06 04:06:16 --> Total execution time: 0.0574
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:06:17 --> Config Class Initialized
INFO - 2022-04-06 04:06:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:17 --> URI Class Initialized
INFO - 2022-04-06 04:06:17 --> Router Class Initialized
INFO - 2022-04-06 04:06:17 --> Output Class Initialized
INFO - 2022-04-06 04:06:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:17 --> Input Class Initialized
INFO - 2022-04-06 04:06:17 --> Language Class Initialized
ERROR - 2022-04-06 04:06:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:06:26 --> Config Class Initialized
INFO - 2022-04-06 04:06:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:26 --> URI Class Initialized
DEBUG - 2022-04-06 04:06:26 --> No URI present. Default controller set.
INFO - 2022-04-06 04:06:26 --> Router Class Initialized
INFO - 2022-04-06 04:06:26 --> Output Class Initialized
INFO - 2022-04-06 04:06:26 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:26 --> Input Class Initialized
INFO - 2022-04-06 04:06:26 --> Language Class Initialized
INFO - 2022-04-06 04:06:26 --> Loader Class Initialized
INFO - 2022-04-06 04:06:26 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:26 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:26 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:26 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:26 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:26 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:26 --> Controller Class Initialized
INFO - 2022-04-06 04:06:26 --> Model Class Initialized
INFO - 2022-04-06 04:06:26 --> Model Class Initialized
INFO - 2022-04-06 04:06:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:06:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:06:26 --> Final output sent to browser
DEBUG - 2022-04-06 04:06:26 --> Total execution time: 0.0925
INFO - 2022-04-06 04:06:47 --> Config Class Initialized
INFO - 2022-04-06 04:06:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:47 --> URI Class Initialized
INFO - 2022-04-06 04:06:47 --> Router Class Initialized
INFO - 2022-04-06 04:06:47 --> Output Class Initialized
INFO - 2022-04-06 04:06:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:47 --> Input Class Initialized
INFO - 2022-04-06 04:06:47 --> Language Class Initialized
INFO - 2022-04-06 04:06:47 --> Loader Class Initialized
INFO - 2022-04-06 04:06:47 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:47 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:47 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:47 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:47 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:47 --> Controller Class Initialized
INFO - 2022-04-06 04:06:47 --> Model Class Initialized
INFO - 2022-04-06 04:06:47 --> Model Class Initialized
INFO - 2022-04-06 04:06:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:06:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:06:47 --> Final output sent to browser
DEBUG - 2022-04-06 04:06:47 --> Total execution time: 0.0698
INFO - 2022-04-06 04:06:47 --> Config Class Initialized
INFO - 2022-04-06 04:06:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:47 --> URI Class Initialized
INFO - 2022-04-06 04:06:47 --> Router Class Initialized
INFO - 2022-04-06 04:06:47 --> Output Class Initialized
INFO - 2022-04-06 04:06:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:47 --> Input Class Initialized
INFO - 2022-04-06 04:06:47 --> Language Class Initialized
ERROR - 2022-04-06 04:06:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:06:49 --> Config Class Initialized
INFO - 2022-04-06 04:06:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:49 --> URI Class Initialized
INFO - 2022-04-06 04:06:49 --> Router Class Initialized
INFO - 2022-04-06 04:06:49 --> Output Class Initialized
INFO - 2022-04-06 04:06:49 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:49 --> Input Class Initialized
INFO - 2022-04-06 04:06:49 --> Language Class Initialized
INFO - 2022-04-06 04:06:49 --> Loader Class Initialized
INFO - 2022-04-06 04:06:49 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:49 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:49 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:49 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:49 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:49 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:49 --> Controller Class Initialized
INFO - 2022-04-06 04:06:49 --> Model Class Initialized
INFO - 2022-04-06 04:06:49 --> Config Class Initialized
INFO - 2022-04-06 04:06:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:49 --> URI Class Initialized
INFO - 2022-04-06 04:06:49 --> Router Class Initialized
INFO - 2022-04-06 04:06:49 --> Output Class Initialized
INFO - 2022-04-06 04:06:49 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:49 --> Input Class Initialized
INFO - 2022-04-06 04:06:49 --> Language Class Initialized
INFO - 2022-04-06 04:06:49 --> Loader Class Initialized
INFO - 2022-04-06 04:06:49 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:49 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:49 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:49 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:50 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:50 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:50 --> Controller Class Initialized
INFO - 2022-04-06 04:06:50 --> Model Class Initialized
INFO - 2022-04-06 04:06:50 --> Model Class Initialized
INFO - 2022-04-06 04:06:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:06:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:06:50 --> Final output sent to browser
DEBUG - 2022-04-06 04:06:50 --> Total execution time: 0.0671
INFO - 2022-04-06 04:06:50 --> Config Class Initialized
INFO - 2022-04-06 04:06:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:50 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:50 --> URI Class Initialized
INFO - 2022-04-06 04:06:50 --> Router Class Initialized
INFO - 2022-04-06 04:06:50 --> Output Class Initialized
INFO - 2022-04-06 04:06:50 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:50 --> Input Class Initialized
INFO - 2022-04-06 04:06:50 --> Language Class Initialized
ERROR - 2022-04-06 04:06:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:06:52 --> Config Class Initialized
INFO - 2022-04-06 04:06:52 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:52 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:52 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:52 --> URI Class Initialized
INFO - 2022-04-06 04:06:52 --> Router Class Initialized
INFO - 2022-04-06 04:06:52 --> Output Class Initialized
INFO - 2022-04-06 04:06:52 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:52 --> Input Class Initialized
INFO - 2022-04-06 04:06:52 --> Language Class Initialized
INFO - 2022-04-06 04:06:52 --> Loader Class Initialized
INFO - 2022-04-06 04:06:52 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:52 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:52 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:52 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:52 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:52 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:52 --> Controller Class Initialized
INFO - 2022-04-06 04:06:52 --> Model Class Initialized
INFO - 2022-04-06 04:06:52 --> Model Class Initialized
INFO - 2022-04-06 04:06:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:06:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:06:52 --> Final output sent to browser
DEBUG - 2022-04-06 04:06:52 --> Total execution time: 0.0657
INFO - 2022-04-06 04:06:53 --> Config Class Initialized
INFO - 2022-04-06 04:06:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:06:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:06:53 --> Utf8 Class Initialized
INFO - 2022-04-06 04:06:53 --> URI Class Initialized
INFO - 2022-04-06 04:06:53 --> Router Class Initialized
INFO - 2022-04-06 04:06:53 --> Output Class Initialized
INFO - 2022-04-06 04:06:53 --> Security Class Initialized
DEBUG - 2022-04-06 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:06:53 --> Input Class Initialized
INFO - 2022-04-06 04:06:53 --> Language Class Initialized
INFO - 2022-04-06 04:06:53 --> Loader Class Initialized
INFO - 2022-04-06 04:06:53 --> Helper loaded: url_helper
INFO - 2022-04-06 04:06:53 --> Helper loaded: form_helper
INFO - 2022-04-06 04:06:53 --> Helper loaded: common_helper
INFO - 2022-04-06 04:06:53 --> Helper loaded: util_helper
INFO - 2022-04-06 04:06:53 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:06:53 --> Form Validation Class Initialized
INFO - 2022-04-06 04:06:53 --> Controller Class Initialized
INFO - 2022-04-06 04:06:53 --> Model Class Initialized
INFO - 2022-04-06 04:06:53 --> Model Class Initialized
INFO - 2022-04-06 04:06:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:06:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:06:53 --> Final output sent to browser
DEBUG - 2022-04-06 04:06:53 --> Total execution time: 0.0601
INFO - 2022-04-06 04:07:00 --> Config Class Initialized
INFO - 2022-04-06 04:07:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:00 --> URI Class Initialized
DEBUG - 2022-04-06 04:07:00 --> No URI present. Default controller set.
INFO - 2022-04-06 04:07:00 --> Router Class Initialized
INFO - 2022-04-06 04:07:00 --> Output Class Initialized
INFO - 2022-04-06 04:07:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:00 --> Input Class Initialized
INFO - 2022-04-06 04:07:00 --> Language Class Initialized
INFO - 2022-04-06 04:07:00 --> Loader Class Initialized
INFO - 2022-04-06 04:07:00 --> Helper loaded: url_helper
INFO - 2022-04-06 04:07:00 --> Helper loaded: form_helper
INFO - 2022-04-06 04:07:00 --> Helper loaded: common_helper
INFO - 2022-04-06 04:07:00 --> Helper loaded: util_helper
INFO - 2022-04-06 04:07:00 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:07:00 --> Form Validation Class Initialized
INFO - 2022-04-06 04:07:00 --> Controller Class Initialized
INFO - 2022-04-06 04:07:00 --> Model Class Initialized
INFO - 2022-04-06 04:07:00 --> Model Class Initialized
INFO - 2022-04-06 04:07:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:07:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:07:00 --> Final output sent to browser
DEBUG - 2022-04-06 04:07:00 --> Total execution time: 0.0799
INFO - 2022-04-06 04:07:00 --> Config Class Initialized
INFO - 2022-04-06 04:07:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:00 --> URI Class Initialized
INFO - 2022-04-06 04:07:00 --> Router Class Initialized
INFO - 2022-04-06 04:07:00 --> Output Class Initialized
INFO - 2022-04-06 04:07:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:00 --> Input Class Initialized
INFO - 2022-04-06 04:07:00 --> Language Class Initialized
ERROR - 2022-04-06 04:07:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:07:03 --> Config Class Initialized
INFO - 2022-04-06 04:07:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:03 --> URI Class Initialized
INFO - 2022-04-06 04:07:03 --> Router Class Initialized
INFO - 2022-04-06 04:07:03 --> Output Class Initialized
INFO - 2022-04-06 04:07:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:03 --> Input Class Initialized
INFO - 2022-04-06 04:07:03 --> Language Class Initialized
INFO - 2022-04-06 04:07:03 --> Loader Class Initialized
INFO - 2022-04-06 04:07:03 --> Helper loaded: url_helper
INFO - 2022-04-06 04:07:03 --> Helper loaded: form_helper
INFO - 2022-04-06 04:07:03 --> Helper loaded: common_helper
INFO - 2022-04-06 04:07:03 --> Helper loaded: util_helper
INFO - 2022-04-06 04:07:03 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:07:03 --> Form Validation Class Initialized
INFO - 2022-04-06 04:07:03 --> Controller Class Initialized
INFO - 2022-04-06 04:07:03 --> Model Class Initialized
INFO - 2022-04-06 04:07:03 --> Config Class Initialized
INFO - 2022-04-06 04:07:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:03 --> URI Class Initialized
INFO - 2022-04-06 04:07:03 --> Router Class Initialized
INFO - 2022-04-06 04:07:03 --> Output Class Initialized
INFO - 2022-04-06 04:07:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:03 --> Input Class Initialized
INFO - 2022-04-06 04:07:03 --> Language Class Initialized
INFO - 2022-04-06 04:07:03 --> Loader Class Initialized
INFO - 2022-04-06 04:07:03 --> Helper loaded: url_helper
INFO - 2022-04-06 04:07:03 --> Helper loaded: form_helper
INFO - 2022-04-06 04:07:03 --> Helper loaded: common_helper
INFO - 2022-04-06 04:07:03 --> Helper loaded: util_helper
INFO - 2022-04-06 04:07:03 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:07:03 --> Form Validation Class Initialized
INFO - 2022-04-06 04:07:03 --> Controller Class Initialized
INFO - 2022-04-06 04:07:03 --> Model Class Initialized
INFO - 2022-04-06 04:07:03 --> Model Class Initialized
INFO - 2022-04-06 04:07:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:07:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:07:03 --> Final output sent to browser
DEBUG - 2022-04-06 04:07:03 --> Total execution time: 0.0670
INFO - 2022-04-06 04:07:03 --> Config Class Initialized
INFO - 2022-04-06 04:07:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:03 --> URI Class Initialized
INFO - 2022-04-06 04:07:03 --> Router Class Initialized
INFO - 2022-04-06 04:07:03 --> Output Class Initialized
INFO - 2022-04-06 04:07:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:03 --> Input Class Initialized
INFO - 2022-04-06 04:07:03 --> Language Class Initialized
ERROR - 2022-04-06 04:07:03 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:07:27 --> Config Class Initialized
INFO - 2022-04-06 04:07:27 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:27 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:27 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:27 --> URI Class Initialized
DEBUG - 2022-04-06 04:07:27 --> No URI present. Default controller set.
INFO - 2022-04-06 04:07:27 --> Router Class Initialized
INFO - 2022-04-06 04:07:27 --> Output Class Initialized
INFO - 2022-04-06 04:07:27 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:27 --> Input Class Initialized
INFO - 2022-04-06 04:07:27 --> Language Class Initialized
INFO - 2022-04-06 04:07:27 --> Loader Class Initialized
INFO - 2022-04-06 04:07:27 --> Helper loaded: url_helper
INFO - 2022-04-06 04:07:27 --> Helper loaded: form_helper
INFO - 2022-04-06 04:07:27 --> Helper loaded: common_helper
INFO - 2022-04-06 04:07:27 --> Helper loaded: util_helper
INFO - 2022-04-06 04:07:27 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:07:28 --> Form Validation Class Initialized
INFO - 2022-04-06 04:07:28 --> Controller Class Initialized
INFO - 2022-04-06 04:07:28 --> Model Class Initialized
INFO - 2022-04-06 04:07:28 --> Model Class Initialized
INFO - 2022-04-06 04:07:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:07:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:07:28 --> Final output sent to browser
DEBUG - 2022-04-06 04:07:28 --> Total execution time: 0.0784
INFO - 2022-04-06 04:07:30 --> Config Class Initialized
INFO - 2022-04-06 04:07:30 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:30 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:30 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:30 --> URI Class Initialized
DEBUG - 2022-04-06 04:07:30 --> No URI present. Default controller set.
INFO - 2022-04-06 04:07:30 --> Router Class Initialized
INFO - 2022-04-06 04:07:30 --> Output Class Initialized
INFO - 2022-04-06 04:07:30 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:30 --> Input Class Initialized
INFO - 2022-04-06 04:07:30 --> Language Class Initialized
INFO - 2022-04-06 04:07:30 --> Loader Class Initialized
INFO - 2022-04-06 04:07:30 --> Helper loaded: url_helper
INFO - 2022-04-06 04:07:30 --> Helper loaded: form_helper
INFO - 2022-04-06 04:07:30 --> Helper loaded: common_helper
INFO - 2022-04-06 04:07:30 --> Helper loaded: util_helper
INFO - 2022-04-06 04:07:30 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:07:30 --> Form Validation Class Initialized
INFO - 2022-04-06 04:07:31 --> Controller Class Initialized
INFO - 2022-04-06 04:07:31 --> Model Class Initialized
INFO - 2022-04-06 04:07:31 --> Model Class Initialized
INFO - 2022-04-06 04:07:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:07:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:07:31 --> Final output sent to browser
DEBUG - 2022-04-06 04:07:31 --> Total execution time: 0.0752
INFO - 2022-04-06 04:07:31 --> Config Class Initialized
INFO - 2022-04-06 04:07:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:31 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:31 --> URI Class Initialized
INFO - 2022-04-06 04:07:31 --> Router Class Initialized
INFO - 2022-04-06 04:07:31 --> Output Class Initialized
INFO - 2022-04-06 04:07:31 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:31 --> Input Class Initialized
INFO - 2022-04-06 04:07:31 --> Language Class Initialized
ERROR - 2022-04-06 04:07:31 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
INFO - 2022-04-06 04:07:38 --> Loader Class Initialized
INFO - 2022-04-06 04:07:38 --> Helper loaded: url_helper
INFO - 2022-04-06 04:07:38 --> Helper loaded: form_helper
INFO - 2022-04-06 04:07:38 --> Helper loaded: common_helper
INFO - 2022-04-06 04:07:38 --> Helper loaded: util_helper
INFO - 2022-04-06 04:07:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:07:38 --> Form Validation Class Initialized
INFO - 2022-04-06 04:07:38 --> Controller Class Initialized
INFO - 2022-04-06 04:07:38 --> Model Class Initialized
INFO - 2022-04-06 04:07:38 --> Model Class Initialized
INFO - 2022-04-06 04:07:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:07:38 --> Final output sent to browser
DEBUG - 2022-04-06 04:07:38 --> Total execution time: 0.0548
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:38 --> Config Class Initialized
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
DEBUG - 2022-04-06 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:07:38 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:07:38 --> URI Class Initialized
INFO - 2022-04-06 04:07:38 --> Router Class Initialized
INFO - 2022-04-06 04:07:38 --> Output Class Initialized
INFO - 2022-04-06 04:07:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:07:38 --> Input Class Initialized
INFO - 2022-04-06 04:07:38 --> Language Class Initialized
ERROR - 2022-04-06 04:07:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
INFO - 2022-04-06 04:08:02 --> Loader Class Initialized
INFO - 2022-04-06 04:08:02 --> Helper loaded: url_helper
INFO - 2022-04-06 04:08:02 --> Helper loaded: form_helper
INFO - 2022-04-06 04:08:02 --> Helper loaded: common_helper
INFO - 2022-04-06 04:08:02 --> Helper loaded: util_helper
INFO - 2022-04-06 04:08:02 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:08:02 --> Form Validation Class Initialized
INFO - 2022-04-06 04:08:02 --> Controller Class Initialized
INFO - 2022-04-06 04:08:02 --> Model Class Initialized
INFO - 2022-04-06 04:08:02 --> Model Class Initialized
INFO - 2022-04-06 04:08:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:08:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:08:02 --> Final output sent to browser
DEBUG - 2022-04-06 04:08:02 --> Total execution time: 0.1457
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:02 --> Config Class Initialized
INFO - 2022-04-06 04:08:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:02 --> URI Class Initialized
INFO - 2022-04-06 04:08:02 --> Router Class Initialized
INFO - 2022-04-06 04:08:02 --> Output Class Initialized
INFO - 2022-04-06 04:08:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:02 --> Input Class Initialized
INFO - 2022-04-06 04:08:02 --> Language Class Initialized
ERROR - 2022-04-06 04:08:02 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:04 --> Config Class Initialized
INFO - 2022-04-06 04:08:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:04 --> URI Class Initialized
INFO - 2022-04-06 04:08:04 --> Router Class Initialized
INFO - 2022-04-06 04:08:04 --> Output Class Initialized
INFO - 2022-04-06 04:08:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:04 --> Input Class Initialized
INFO - 2022-04-06 04:08:04 --> Language Class Initialized
INFO - 2022-04-06 04:08:04 --> Loader Class Initialized
INFO - 2022-04-06 04:08:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:08:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:08:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:08:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:08:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:08:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:08:04 --> Controller Class Initialized
INFO - 2022-04-06 04:08:04 --> Model Class Initialized
INFO - 2022-04-06 04:08:04 --> Model Class Initialized
INFO - 2022-04-06 04:08:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:08:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:08:04 --> Total execution time: 0.0657
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
INFO - 2022-04-06 04:08:15 --> Loader Class Initialized
INFO - 2022-04-06 04:08:15 --> Helper loaded: url_helper
INFO - 2022-04-06 04:08:15 --> Helper loaded: form_helper
INFO - 2022-04-06 04:08:15 --> Helper loaded: common_helper
INFO - 2022-04-06 04:08:15 --> Helper loaded: util_helper
INFO - 2022-04-06 04:08:15 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:08:15 --> Form Validation Class Initialized
INFO - 2022-04-06 04:08:15 --> Controller Class Initialized
INFO - 2022-04-06 04:08:15 --> Model Class Initialized
INFO - 2022-04-06 04:08:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:08:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:08:15 --> Final output sent to browser
DEBUG - 2022-04-06 04:08:15 --> Total execution time: 0.0649
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:08:15 --> Config Class Initialized
INFO - 2022-04-06 04:08:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:15 --> URI Class Initialized
INFO - 2022-04-06 04:08:15 --> Router Class Initialized
INFO - 2022-04-06 04:08:15 --> Output Class Initialized
INFO - 2022-04-06 04:08:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:15 --> Input Class Initialized
INFO - 2022-04-06 04:08:15 --> Language Class Initialized
ERROR - 2022-04-06 04:08:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:08:24 --> Config Class Initialized
INFO - 2022-04-06 04:08:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:24 --> URI Class Initialized
INFO - 2022-04-06 04:08:24 --> Router Class Initialized
INFO - 2022-04-06 04:08:24 --> Output Class Initialized
INFO - 2022-04-06 04:08:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:24 --> Input Class Initialized
INFO - 2022-04-06 04:08:24 --> Language Class Initialized
INFO - 2022-04-06 04:08:24 --> Loader Class Initialized
INFO - 2022-04-06 04:08:24 --> Helper loaded: url_helper
INFO - 2022-04-06 04:08:24 --> Helper loaded: form_helper
INFO - 2022-04-06 04:08:24 --> Helper loaded: common_helper
INFO - 2022-04-06 04:08:24 --> Helper loaded: util_helper
INFO - 2022-04-06 04:08:24 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:08:24 --> Form Validation Class Initialized
INFO - 2022-04-06 04:08:24 --> Controller Class Initialized
INFO - 2022-04-06 04:08:24 --> Model Class Initialized
INFO - 2022-04-06 04:08:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:08:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:08:24 --> Final output sent to browser
DEBUG - 2022-04-06 04:08:24 --> Total execution time: 0.0740
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> Config Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:08:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
DEBUG - 2022-04-06 04:08:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:08:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
INFO - 2022-04-06 04:08:25 --> URI Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Router Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Output Class Initialized
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:08:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Input Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
INFO - 2022-04-06 04:08:25 --> Language Class Initialized
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:08:25 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> Loader Class Initialized
INFO - 2022-04-06 04:09:16 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:16 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:16 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:16 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:16 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:16 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:16 --> Controller Class Initialized
INFO - 2022-04-06 04:09:16 --> Model Class Initialized
INFO - 2022-04-06 04:09:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:09:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:09:16 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:16 --> Total execution time: 0.0664
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Config Class Initialized
INFO - 2022-04-06 04:09:16 --> Hooks Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:16 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> URI Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
INFO - 2022-04-06 04:09:16 --> Router Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:09:16 --> Output Class Initialized
INFO - 2022-04-06 04:09:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:16 --> Input Class Initialized
INFO - 2022-04-06 04:09:16 --> Language Class Initialized
ERROR - 2022-04-06 04:09:16 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:09:23 --> Config Class Initialized
INFO - 2022-04-06 04:09:23 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:23 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:23 --> URI Class Initialized
DEBUG - 2022-04-06 04:09:23 --> No URI present. Default controller set.
INFO - 2022-04-06 04:09:23 --> Router Class Initialized
INFO - 2022-04-06 04:09:23 --> Output Class Initialized
INFO - 2022-04-06 04:09:23 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:23 --> Input Class Initialized
INFO - 2022-04-06 04:09:23 --> Language Class Initialized
INFO - 2022-04-06 04:09:23 --> Loader Class Initialized
INFO - 2022-04-06 04:09:23 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:23 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:23 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:23 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:23 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:23 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:23 --> Controller Class Initialized
INFO - 2022-04-06 04:09:23 --> Model Class Initialized
INFO - 2022-04-06 04:09:23 --> Model Class Initialized
INFO - 2022-04-06 04:09:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:23 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:23 --> Total execution time: 0.0799
INFO - 2022-04-06 04:09:24 --> Config Class Initialized
INFO - 2022-04-06 04:09:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:24 --> URI Class Initialized
DEBUG - 2022-04-06 04:09:24 --> No URI present. Default controller set.
INFO - 2022-04-06 04:09:24 --> Router Class Initialized
INFO - 2022-04-06 04:09:24 --> Output Class Initialized
INFO - 2022-04-06 04:09:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:24 --> Input Class Initialized
INFO - 2022-04-06 04:09:24 --> Language Class Initialized
INFO - 2022-04-06 04:09:24 --> Loader Class Initialized
INFO - 2022-04-06 04:09:24 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:24 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:24 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:24 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:24 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:24 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:24 --> Controller Class Initialized
INFO - 2022-04-06 04:09:24 --> Model Class Initialized
INFO - 2022-04-06 04:09:24 --> Model Class Initialized
INFO - 2022-04-06 04:09:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:24 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:24 --> Total execution time: 0.0733
INFO - 2022-04-06 04:09:30 --> Config Class Initialized
INFO - 2022-04-06 04:09:30 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:30 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:30 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:30 --> URI Class Initialized
INFO - 2022-04-06 04:09:30 --> Router Class Initialized
INFO - 2022-04-06 04:09:30 --> Output Class Initialized
INFO - 2022-04-06 04:09:30 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:30 --> Input Class Initialized
INFO - 2022-04-06 04:09:30 --> Language Class Initialized
INFO - 2022-04-06 04:09:30 --> Loader Class Initialized
INFO - 2022-04-06 04:09:30 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:30 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:30 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:30 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:30 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:30 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:30 --> Controller Class Initialized
INFO - 2022-04-06 04:09:30 --> Model Class Initialized
INFO - 2022-04-06 04:09:30 --> Model Class Initialized
INFO - 2022-04-06 04:09:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:09:30 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:30 --> Total execution time: 0.0688
INFO - 2022-04-06 04:09:31 --> Config Class Initialized
INFO - 2022-04-06 04:09:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:31 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:31 --> URI Class Initialized
DEBUG - 2022-04-06 04:09:31 --> No URI present. Default controller set.
INFO - 2022-04-06 04:09:31 --> Router Class Initialized
INFO - 2022-04-06 04:09:31 --> Output Class Initialized
INFO - 2022-04-06 04:09:31 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:31 --> Input Class Initialized
INFO - 2022-04-06 04:09:31 --> Language Class Initialized
INFO - 2022-04-06 04:09:31 --> Loader Class Initialized
INFO - 2022-04-06 04:09:31 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:31 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:31 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:31 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:31 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:31 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:31 --> Controller Class Initialized
INFO - 2022-04-06 04:09:31 --> Model Class Initialized
INFO - 2022-04-06 04:09:31 --> Model Class Initialized
INFO - 2022-04-06 04:09:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:31 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:31 --> Total execution time: 0.0711
INFO - 2022-04-06 04:09:33 --> Config Class Initialized
INFO - 2022-04-06 04:09:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:33 --> URI Class Initialized
DEBUG - 2022-04-06 04:09:33 --> No URI present. Default controller set.
INFO - 2022-04-06 04:09:33 --> Router Class Initialized
INFO - 2022-04-06 04:09:33 --> Output Class Initialized
INFO - 2022-04-06 04:09:33 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:33 --> Input Class Initialized
INFO - 2022-04-06 04:09:33 --> Language Class Initialized
INFO - 2022-04-06 04:09:33 --> Loader Class Initialized
INFO - 2022-04-06 04:09:33 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:33 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:33 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:33 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:33 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:33 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:33 --> Controller Class Initialized
INFO - 2022-04-06 04:09:33 --> Model Class Initialized
INFO - 2022-04-06 04:09:33 --> Model Class Initialized
INFO - 2022-04-06 04:09:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:33 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:33 --> Total execution time: 0.0752
INFO - 2022-04-06 04:09:33 --> Config Class Initialized
INFO - 2022-04-06 04:09:33 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:33 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:33 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:33 --> URI Class Initialized
INFO - 2022-04-06 04:09:33 --> Router Class Initialized
INFO - 2022-04-06 04:09:33 --> Output Class Initialized
INFO - 2022-04-06 04:09:33 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:33 --> Input Class Initialized
INFO - 2022-04-06 04:09:33 --> Language Class Initialized
ERROR - 2022-04-06 04:09:33 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:09:35 --> Config Class Initialized
INFO - 2022-04-06 04:09:35 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:35 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:35 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:35 --> URI Class Initialized
INFO - 2022-04-06 04:09:35 --> Router Class Initialized
INFO - 2022-04-06 04:09:35 --> Output Class Initialized
INFO - 2022-04-06 04:09:35 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:35 --> Input Class Initialized
INFO - 2022-04-06 04:09:35 --> Language Class Initialized
INFO - 2022-04-06 04:09:35 --> Loader Class Initialized
INFO - 2022-04-06 04:09:35 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:35 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:35 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:35 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:35 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:35 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:35 --> Controller Class Initialized
INFO - 2022-04-06 04:09:35 --> Model Class Initialized
INFO - 2022-04-06 04:09:35 --> Model Class Initialized
INFO - 2022-04-06 04:09:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:09:35 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:35 --> Total execution time: 0.0707
INFO - 2022-04-06 04:09:37 --> Config Class Initialized
INFO - 2022-04-06 04:09:37 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:37 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:37 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:37 --> URI Class Initialized
DEBUG - 2022-04-06 04:09:37 --> No URI present. Default controller set.
INFO - 2022-04-06 04:09:37 --> Router Class Initialized
INFO - 2022-04-06 04:09:37 --> Output Class Initialized
INFO - 2022-04-06 04:09:37 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:37 --> Input Class Initialized
INFO - 2022-04-06 04:09:37 --> Language Class Initialized
INFO - 2022-04-06 04:09:37 --> Loader Class Initialized
INFO - 2022-04-06 04:09:37 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:37 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:37 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:37 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:37 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:37 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:37 --> Controller Class Initialized
INFO - 2022-04-06 04:09:37 --> Model Class Initialized
INFO - 2022-04-06 04:09:37 --> Model Class Initialized
INFO - 2022-04-06 04:09:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:37 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:37 --> Total execution time: 0.0607
INFO - 2022-04-06 04:09:46 --> Config Class Initialized
INFO - 2022-04-06 04:09:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:46 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:46 --> URI Class Initialized
INFO - 2022-04-06 04:09:46 --> Router Class Initialized
INFO - 2022-04-06 04:09:46 --> Output Class Initialized
INFO - 2022-04-06 04:09:46 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:46 --> Input Class Initialized
INFO - 2022-04-06 04:09:46 --> Language Class Initialized
INFO - 2022-04-06 04:09:46 --> Loader Class Initialized
INFO - 2022-04-06 04:09:46 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:46 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:46 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:46 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:46 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:46 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:46 --> Controller Class Initialized
INFO - 2022-04-06 04:09:46 --> Model Class Initialized
INFO - 2022-04-06 04:09:46 --> Model Class Initialized
INFO - 2022-04-06 04:09:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:46 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:46 --> Total execution time: 0.0615
INFO - 2022-04-06 04:09:47 --> Config Class Initialized
INFO - 2022-04-06 04:09:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:47 --> URI Class Initialized
INFO - 2022-04-06 04:09:47 --> Router Class Initialized
INFO - 2022-04-06 04:09:47 --> Output Class Initialized
INFO - 2022-04-06 04:09:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:47 --> Input Class Initialized
INFO - 2022-04-06 04:09:47 --> Language Class Initialized
INFO - 2022-04-06 04:09:47 --> Loader Class Initialized
INFO - 2022-04-06 04:09:47 --> Helper loaded: url_helper
INFO - 2022-04-06 04:09:47 --> Helper loaded: form_helper
INFO - 2022-04-06 04:09:47 --> Helper loaded: common_helper
INFO - 2022-04-06 04:09:47 --> Helper loaded: util_helper
INFO - 2022-04-06 04:09:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:09:47 --> Form Validation Class Initialized
INFO - 2022-04-06 04:09:47 --> Controller Class Initialized
INFO - 2022-04-06 04:09:47 --> Model Class Initialized
INFO - 2022-04-06 04:09:47 --> Model Class Initialized
INFO - 2022-04-06 04:09:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:09:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:09:47 --> Final output sent to browser
DEBUG - 2022-04-06 04:09:47 --> Total execution time: 0.0778
INFO - 2022-04-06 04:09:47 --> Config Class Initialized
INFO - 2022-04-06 04:09:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:09:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:09:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:09:47 --> URI Class Initialized
INFO - 2022-04-06 04:09:47 --> Router Class Initialized
INFO - 2022-04-06 04:09:47 --> Output Class Initialized
INFO - 2022-04-06 04:09:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:09:47 --> Input Class Initialized
INFO - 2022-04-06 04:09:47 --> Language Class Initialized
ERROR - 2022-04-06 04:09:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:10:46 --> Config Class Initialized
INFO - 2022-04-06 04:10:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:10:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:10:46 --> Utf8 Class Initialized
INFO - 2022-04-06 04:10:46 --> URI Class Initialized
DEBUG - 2022-04-06 04:10:46 --> No URI present. Default controller set.
INFO - 2022-04-06 04:10:46 --> Router Class Initialized
INFO - 2022-04-06 04:10:46 --> Output Class Initialized
INFO - 2022-04-06 04:10:46 --> Security Class Initialized
DEBUG - 2022-04-06 04:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:10:46 --> Input Class Initialized
INFO - 2022-04-06 04:10:46 --> Language Class Initialized
INFO - 2022-04-06 04:10:46 --> Loader Class Initialized
INFO - 2022-04-06 04:10:46 --> Helper loaded: url_helper
INFO - 2022-04-06 04:10:46 --> Helper loaded: form_helper
INFO - 2022-04-06 04:10:46 --> Helper loaded: common_helper
INFO - 2022-04-06 04:10:46 --> Helper loaded: util_helper
INFO - 2022-04-06 04:10:46 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:10:46 --> Form Validation Class Initialized
INFO - 2022-04-06 04:10:46 --> Controller Class Initialized
INFO - 2022-04-06 04:10:46 --> Model Class Initialized
INFO - 2022-04-06 04:10:46 --> Model Class Initialized
INFO - 2022-04-06 04:10:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:10:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:10:46 --> Final output sent to browser
DEBUG - 2022-04-06 04:10:46 --> Total execution time: 0.0878
INFO - 2022-04-06 04:11:04 --> Config Class Initialized
INFO - 2022-04-06 04:11:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:11:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:11:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:11:04 --> URI Class Initialized
DEBUG - 2022-04-06 04:11:04 --> No URI present. Default controller set.
INFO - 2022-04-06 04:11:04 --> Router Class Initialized
INFO - 2022-04-06 04:11:04 --> Output Class Initialized
INFO - 2022-04-06 04:11:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:11:04 --> Input Class Initialized
INFO - 2022-04-06 04:11:04 --> Language Class Initialized
INFO - 2022-04-06 04:11:04 --> Loader Class Initialized
INFO - 2022-04-06 04:11:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:11:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:11:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:11:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:11:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:11:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:11:04 --> Controller Class Initialized
INFO - 2022-04-06 04:11:04 --> Model Class Initialized
INFO - 2022-04-06 04:11:04 --> Model Class Initialized
INFO - 2022-04-06 04:11:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:11:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:11:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:11:04 --> Total execution time: 0.0746
INFO - 2022-04-06 04:11:59 --> Config Class Initialized
INFO - 2022-04-06 04:11:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:11:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:11:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:11:59 --> URI Class Initialized
DEBUG - 2022-04-06 04:11:59 --> No URI present. Default controller set.
INFO - 2022-04-06 04:11:59 --> Router Class Initialized
INFO - 2022-04-06 04:11:59 --> Output Class Initialized
INFO - 2022-04-06 04:11:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:11:59 --> Input Class Initialized
INFO - 2022-04-06 04:11:59 --> Language Class Initialized
INFO - 2022-04-06 04:11:59 --> Loader Class Initialized
INFO - 2022-04-06 04:11:59 --> Helper loaded: url_helper
INFO - 2022-04-06 04:11:59 --> Helper loaded: form_helper
INFO - 2022-04-06 04:11:59 --> Helper loaded: common_helper
INFO - 2022-04-06 04:11:59 --> Helper loaded: util_helper
INFO - 2022-04-06 04:11:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:11:59 --> Form Validation Class Initialized
INFO - 2022-04-06 04:11:59 --> Controller Class Initialized
INFO - 2022-04-06 04:11:59 --> Model Class Initialized
INFO - 2022-04-06 04:11:59 --> Model Class Initialized
INFO - 2022-04-06 04:11:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:11:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:11:59 --> Final output sent to browser
DEBUG - 2022-04-06 04:11:59 --> Total execution time: 0.0794
INFO - 2022-04-06 04:12:09 --> Config Class Initialized
INFO - 2022-04-06 04:12:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:12:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:12:09 --> Utf8 Class Initialized
INFO - 2022-04-06 04:12:09 --> URI Class Initialized
INFO - 2022-04-06 04:12:09 --> Router Class Initialized
INFO - 2022-04-06 04:12:09 --> Output Class Initialized
INFO - 2022-04-06 04:12:09 --> Security Class Initialized
DEBUG - 2022-04-06 04:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:12:09 --> Input Class Initialized
INFO - 2022-04-06 04:12:09 --> Language Class Initialized
INFO - 2022-04-06 04:12:09 --> Loader Class Initialized
INFO - 2022-04-06 04:12:09 --> Helper loaded: url_helper
INFO - 2022-04-06 04:12:09 --> Helper loaded: form_helper
INFO - 2022-04-06 04:12:09 --> Helper loaded: common_helper
INFO - 2022-04-06 04:12:09 --> Helper loaded: util_helper
INFO - 2022-04-06 04:12:09 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:12:09 --> Form Validation Class Initialized
INFO - 2022-04-06 04:12:09 --> Controller Class Initialized
INFO - 2022-04-06 04:12:09 --> Model Class Initialized
INFO - 2022-04-06 04:12:09 --> Model Class Initialized
INFO - 2022-04-06 04:12:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:12:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:12:09 --> Final output sent to browser
DEBUG - 2022-04-06 04:12:09 --> Total execution time: 0.0801
INFO - 2022-04-06 04:12:09 --> Config Class Initialized
INFO - 2022-04-06 04:12:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:12:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:12:09 --> Utf8 Class Initialized
INFO - 2022-04-06 04:12:09 --> URI Class Initialized
INFO - 2022-04-06 04:12:09 --> Router Class Initialized
INFO - 2022-04-06 04:12:09 --> Output Class Initialized
INFO - 2022-04-06 04:12:09 --> Security Class Initialized
DEBUG - 2022-04-06 04:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:12:09 --> Input Class Initialized
INFO - 2022-04-06 04:12:09 --> Language Class Initialized
ERROR - 2022-04-06 04:12:09 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:12:13 --> Config Class Initialized
INFO - 2022-04-06 04:12:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:12:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:12:13 --> Utf8 Class Initialized
INFO - 2022-04-06 04:12:13 --> URI Class Initialized
INFO - 2022-04-06 04:12:13 --> Router Class Initialized
INFO - 2022-04-06 04:12:13 --> Output Class Initialized
INFO - 2022-04-06 04:12:13 --> Security Class Initialized
DEBUG - 2022-04-06 04:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:12:13 --> Input Class Initialized
INFO - 2022-04-06 04:12:13 --> Language Class Initialized
INFO - 2022-04-06 04:12:13 --> Loader Class Initialized
INFO - 2022-04-06 04:12:13 --> Helper loaded: url_helper
INFO - 2022-04-06 04:12:13 --> Helper loaded: form_helper
INFO - 2022-04-06 04:12:13 --> Helper loaded: common_helper
INFO - 2022-04-06 04:12:13 --> Helper loaded: util_helper
INFO - 2022-04-06 04:12:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:12:13 --> Form Validation Class Initialized
INFO - 2022-04-06 04:12:13 --> Controller Class Initialized
INFO - 2022-04-06 04:12:13 --> Model Class Initialized
INFO - 2022-04-06 04:12:13 --> Model Class Initialized
INFO - 2022-04-06 04:12:13 --> Config Class Initialized
INFO - 2022-04-06 04:12:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:12:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:12:13 --> Utf8 Class Initialized
INFO - 2022-04-06 04:12:13 --> URI Class Initialized
INFO - 2022-04-06 04:12:13 --> Router Class Initialized
INFO - 2022-04-06 04:12:13 --> Output Class Initialized
INFO - 2022-04-06 04:12:13 --> Security Class Initialized
DEBUG - 2022-04-06 04:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:12:13 --> Input Class Initialized
INFO - 2022-04-06 04:12:13 --> Language Class Initialized
INFO - 2022-04-06 04:12:13 --> Loader Class Initialized
INFO - 2022-04-06 04:12:13 --> Helper loaded: url_helper
INFO - 2022-04-06 04:12:13 --> Helper loaded: form_helper
INFO - 2022-04-06 04:12:13 --> Helper loaded: common_helper
INFO - 2022-04-06 04:12:13 --> Helper loaded: util_helper
INFO - 2022-04-06 04:12:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:12:13 --> Form Validation Class Initialized
INFO - 2022-04-06 04:12:13 --> Controller Class Initialized
INFO - 2022-04-06 04:12:13 --> Model Class Initialized
INFO - 2022-04-06 04:12:13 --> Model Class Initialized
INFO - 2022-04-06 04:12:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:12:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:12:13 --> Final output sent to browser
DEBUG - 2022-04-06 04:12:13 --> Total execution time: 0.0618
INFO - 2022-04-06 04:12:13 --> Config Class Initialized
INFO - 2022-04-06 04:12:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:12:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:12:13 --> Utf8 Class Initialized
INFO - 2022-04-06 04:12:13 --> URI Class Initialized
INFO - 2022-04-06 04:12:13 --> Router Class Initialized
INFO - 2022-04-06 04:12:13 --> Output Class Initialized
INFO - 2022-04-06 04:12:13 --> Security Class Initialized
DEBUG - 2022-04-06 04:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:12:13 --> Input Class Initialized
INFO - 2022-04-06 04:12:13 --> Language Class Initialized
ERROR - 2022-04-06 04:12:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:13:02 --> Config Class Initialized
INFO - 2022-04-06 04:13:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:13:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:13:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:13:02 --> URI Class Initialized
INFO - 2022-04-06 04:13:02 --> Router Class Initialized
INFO - 2022-04-06 04:13:02 --> Output Class Initialized
INFO - 2022-04-06 04:13:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:13:02 --> Input Class Initialized
INFO - 2022-04-06 04:13:02 --> Language Class Initialized
INFO - 2022-04-06 04:13:02 --> Loader Class Initialized
INFO - 2022-04-06 04:13:02 --> Helper loaded: url_helper
INFO - 2022-04-06 04:13:02 --> Helper loaded: form_helper
INFO - 2022-04-06 04:13:02 --> Helper loaded: common_helper
INFO - 2022-04-06 04:13:02 --> Helper loaded: util_helper
INFO - 2022-04-06 04:13:02 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:13:02 --> Form Validation Class Initialized
INFO - 2022-04-06 04:13:02 --> Controller Class Initialized
INFO - 2022-04-06 04:13:02 --> Model Class Initialized
INFO - 2022-04-06 04:13:02 --> Model Class Initialized
INFO - 2022-04-06 04:13:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:13:02 --> Final output sent to browser
DEBUG - 2022-04-06 04:13:02 --> Total execution time: 0.0749
INFO - 2022-04-06 04:13:07 --> Config Class Initialized
INFO - 2022-04-06 04:13:07 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:13:07 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:13:07 --> Utf8 Class Initialized
INFO - 2022-04-06 04:13:07 --> URI Class Initialized
INFO - 2022-04-06 04:13:07 --> Router Class Initialized
INFO - 2022-04-06 04:13:07 --> Output Class Initialized
INFO - 2022-04-06 04:13:07 --> Security Class Initialized
DEBUG - 2022-04-06 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:13:07 --> Input Class Initialized
INFO - 2022-04-06 04:13:07 --> Language Class Initialized
INFO - 2022-04-06 04:13:07 --> Loader Class Initialized
INFO - 2022-04-06 04:13:07 --> Helper loaded: url_helper
INFO - 2022-04-06 04:13:07 --> Helper loaded: form_helper
INFO - 2022-04-06 04:13:07 --> Helper loaded: common_helper
INFO - 2022-04-06 04:13:07 --> Helper loaded: util_helper
INFO - 2022-04-06 04:13:07 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:13:07 --> Form Validation Class Initialized
INFO - 2022-04-06 04:13:07 --> Controller Class Initialized
INFO - 2022-04-06 04:13:07 --> Model Class Initialized
INFO - 2022-04-06 04:13:07 --> Model Class Initialized
INFO - 2022-04-06 04:13:07 --> Config Class Initialized
INFO - 2022-04-06 04:13:07 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:13:07 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:13:07 --> Utf8 Class Initialized
INFO - 2022-04-06 04:13:07 --> URI Class Initialized
INFO - 2022-04-06 04:13:07 --> Router Class Initialized
INFO - 2022-04-06 04:13:07 --> Output Class Initialized
INFO - 2022-04-06 04:13:07 --> Security Class Initialized
DEBUG - 2022-04-06 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:13:07 --> Input Class Initialized
INFO - 2022-04-06 04:13:07 --> Language Class Initialized
INFO - 2022-04-06 04:13:07 --> Loader Class Initialized
INFO - 2022-04-06 04:13:07 --> Helper loaded: url_helper
INFO - 2022-04-06 04:13:07 --> Helper loaded: form_helper
INFO - 2022-04-06 04:13:07 --> Helper loaded: common_helper
INFO - 2022-04-06 04:13:07 --> Helper loaded: util_helper
INFO - 2022-04-06 04:13:07 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:13:07 --> Form Validation Class Initialized
INFO - 2022-04-06 04:13:07 --> Controller Class Initialized
INFO - 2022-04-06 04:13:07 --> Model Class Initialized
INFO - 2022-04-06 04:13:07 --> Model Class Initialized
INFO - 2022-04-06 04:13:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:13:07 --> Final output sent to browser
DEBUG - 2022-04-06 04:13:07 --> Total execution time: 0.0575
INFO - 2022-04-06 04:14:31 --> Config Class Initialized
INFO - 2022-04-06 04:14:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:14:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:31 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:31 --> URI Class Initialized
INFO - 2022-04-06 04:14:31 --> Router Class Initialized
INFO - 2022-04-06 04:14:31 --> Output Class Initialized
INFO - 2022-04-06 04:14:31 --> Security Class Initialized
DEBUG - 2022-04-06 04:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:31 --> Input Class Initialized
INFO - 2022-04-06 04:14:31 --> Language Class Initialized
INFO - 2022-04-06 04:14:31 --> Loader Class Initialized
INFO - 2022-04-06 04:14:31 --> Helper loaded: url_helper
INFO - 2022-04-06 04:14:31 --> Helper loaded: form_helper
INFO - 2022-04-06 04:14:31 --> Helper loaded: common_helper
INFO - 2022-04-06 04:14:31 --> Helper loaded: util_helper
INFO - 2022-04-06 04:14:31 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:14:31 --> Form Validation Class Initialized
INFO - 2022-04-06 04:14:31 --> Controller Class Initialized
INFO - 2022-04-06 04:14:31 --> Model Class Initialized
INFO - 2022-04-06 04:14:31 --> Model Class Initialized
INFO - 2022-04-06 04:14:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:14:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:14:31 --> Final output sent to browser
DEBUG - 2022-04-06 04:14:31 --> Total execution time: 0.0693
INFO - 2022-04-06 04:14:31 --> Config Class Initialized
INFO - 2022-04-06 04:14:31 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:14:31 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:31 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:31 --> URI Class Initialized
INFO - 2022-04-06 04:14:31 --> Router Class Initialized
INFO - 2022-04-06 04:14:31 --> Output Class Initialized
INFO - 2022-04-06 04:14:31 --> Security Class Initialized
DEBUG - 2022-04-06 04:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:31 --> Input Class Initialized
INFO - 2022-04-06 04:14:31 --> Language Class Initialized
ERROR - 2022-04-06 04:14:31 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
INFO - 2022-04-06 04:14:38 --> Loader Class Initialized
INFO - 2022-04-06 04:14:38 --> Helper loaded: url_helper
INFO - 2022-04-06 04:14:38 --> Helper loaded: form_helper
INFO - 2022-04-06 04:14:38 --> Helper loaded: common_helper
INFO - 2022-04-06 04:14:38 --> Helper loaded: util_helper
INFO - 2022-04-06 04:14:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:14:38 --> Form Validation Class Initialized
INFO - 2022-04-06 04:14:38 --> Controller Class Initialized
INFO - 2022-04-06 04:14:38 --> Model Class Initialized
INFO - 2022-04-06 04:14:38 --> Model Class Initialized
INFO - 2022-04-06 04:14:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:14:38 --> Final output sent to browser
DEBUG - 2022-04-06 04:14:38 --> Total execution time: 0.0558
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
INFO - 2022-04-06 04:14:38 --> Config Class Initialized
INFO - 2022-04-06 04:14:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
DEBUG - 2022-04-06 04:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:14:38 --> URI Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:14:38 --> Router Class Initialized
INFO - 2022-04-06 04:14:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Security Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
DEBUG - 2022-04-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:14:38 --> Input Class Initialized
INFO - 2022-04-06 04:14:38 --> Language Class Initialized
ERROR - 2022-04-06 04:14:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:14:40 --> Config Class Initialized
INFO - 2022-04-06 04:14:40 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:14:40 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:14:40 --> Utf8 Class Initialized
INFO - 2022-04-06 04:14:40 --> URI Class Initialized
INFO - 2022-04-06 04:14:40 --> Router Class Initialized
INFO - 2022-04-06 04:14:40 --> Output Class Initialized
INFO - 2022-04-06 04:14:40 --> Security Class Initialized
DEBUG - 2022-04-06 04:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:14:40 --> Input Class Initialized
INFO - 2022-04-06 04:14:40 --> Language Class Initialized
INFO - 2022-04-06 04:14:40 --> Loader Class Initialized
INFO - 2022-04-06 04:14:40 --> Helper loaded: url_helper
INFO - 2022-04-06 04:14:40 --> Helper loaded: form_helper
INFO - 2022-04-06 04:14:40 --> Helper loaded: common_helper
INFO - 2022-04-06 04:14:40 --> Helper loaded: util_helper
INFO - 2022-04-06 04:14:40 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:14:40 --> Form Validation Class Initialized
INFO - 2022-04-06 04:14:40 --> Controller Class Initialized
INFO - 2022-04-06 04:14:40 --> Model Class Initialized
INFO - 2022-04-06 04:14:40 --> Model Class Initialized
INFO - 2022-04-06 04:14:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:14:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:14:40 --> Final output sent to browser
DEBUG - 2022-04-06 04:14:40 --> Total execution time: 0.0719
INFO - 2022-04-06 04:20:16 --> Config Class Initialized
INFO - 2022-04-06 04:20:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:16 --> URI Class Initialized
INFO - 2022-04-06 04:20:16 --> Router Class Initialized
INFO - 2022-04-06 04:20:16 --> Output Class Initialized
INFO - 2022-04-06 04:20:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:16 --> Input Class Initialized
INFO - 2022-04-06 04:20:16 --> Language Class Initialized
INFO - 2022-04-06 04:20:16 --> Loader Class Initialized
INFO - 2022-04-06 04:20:16 --> Helper loaded: url_helper
INFO - 2022-04-06 04:20:16 --> Helper loaded: form_helper
INFO - 2022-04-06 04:20:16 --> Helper loaded: common_helper
INFO - 2022-04-06 04:20:16 --> Helper loaded: util_helper
INFO - 2022-04-06 04:20:16 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:20:16 --> Form Validation Class Initialized
INFO - 2022-04-06 04:20:16 --> Controller Class Initialized
INFO - 2022-04-06 04:20:16 --> Model Class Initialized
INFO - 2022-04-06 04:20:16 --> Model Class Initialized
INFO - 2022-04-06 04:20:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:20:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:20:16 --> Final output sent to browser
DEBUG - 2022-04-06 04:20:16 --> Total execution time: 0.0558
INFO - 2022-04-06 04:20:16 --> Config Class Initialized
INFO - 2022-04-06 04:20:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:16 --> URI Class Initialized
INFO - 2022-04-06 04:20:16 --> Router Class Initialized
INFO - 2022-04-06 04:20:16 --> Output Class Initialized
INFO - 2022-04-06 04:20:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:16 --> Input Class Initialized
INFO - 2022-04-06 04:20:16 --> Language Class Initialized
ERROR - 2022-04-06 04:20:16 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
INFO - 2022-04-06 04:20:24 --> Loader Class Initialized
INFO - 2022-04-06 04:20:24 --> Helper loaded: url_helper
INFO - 2022-04-06 04:20:24 --> Helper loaded: form_helper
INFO - 2022-04-06 04:20:24 --> Helper loaded: common_helper
INFO - 2022-04-06 04:20:24 --> Helper loaded: util_helper
INFO - 2022-04-06 04:20:24 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:20:24 --> Form Validation Class Initialized
INFO - 2022-04-06 04:20:24 --> Controller Class Initialized
INFO - 2022-04-06 04:20:24 --> Model Class Initialized
INFO - 2022-04-06 04:20:24 --> Model Class Initialized
INFO - 2022-04-06 04:20:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:20:24 --> Final output sent to browser
DEBUG - 2022-04-06 04:20:24 --> Total execution time: 0.0682
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:24 --> Config Class Initialized
INFO - 2022-04-06 04:20:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:24 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> URI Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
INFO - 2022-04-06 04:20:24 --> Router Class Initialized
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:20:24 --> Output Class Initialized
INFO - 2022-04-06 04:20:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:24 --> Input Class Initialized
INFO - 2022-04-06 04:20:24 --> Language Class Initialized
ERROR - 2022-04-06 04:20:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:20:26 --> Config Class Initialized
INFO - 2022-04-06 04:20:26 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:26 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:26 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:26 --> URI Class Initialized
INFO - 2022-04-06 04:20:26 --> Router Class Initialized
INFO - 2022-04-06 04:20:26 --> Output Class Initialized
INFO - 2022-04-06 04:20:26 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:26 --> Input Class Initialized
INFO - 2022-04-06 04:20:26 --> Language Class Initialized
INFO - 2022-04-06 04:20:27 --> Loader Class Initialized
INFO - 2022-04-06 04:20:27 --> Helper loaded: url_helper
INFO - 2022-04-06 04:20:27 --> Helper loaded: form_helper
INFO - 2022-04-06 04:20:27 --> Helper loaded: common_helper
INFO - 2022-04-06 04:20:27 --> Helper loaded: util_helper
INFO - 2022-04-06 04:20:27 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:20:27 --> Form Validation Class Initialized
INFO - 2022-04-06 04:20:27 --> Controller Class Initialized
INFO - 2022-04-06 04:20:27 --> Model Class Initialized
INFO - 2022-04-06 04:20:27 --> Model Class Initialized
INFO - 2022-04-06 04:20:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:20:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:20:27 --> Final output sent to browser
DEBUG - 2022-04-06 04:20:27 --> Total execution time: 0.0988
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
INFO - 2022-04-06 04:20:29 --> Loader Class Initialized
INFO - 2022-04-06 04:20:29 --> Helper loaded: url_helper
INFO - 2022-04-06 04:20:29 --> Helper loaded: form_helper
INFO - 2022-04-06 04:20:29 --> Helper loaded: common_helper
INFO - 2022-04-06 04:20:29 --> Helper loaded: util_helper
INFO - 2022-04-06 04:20:29 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:20:29 --> Form Validation Class Initialized
INFO - 2022-04-06 04:20:29 --> Controller Class Initialized
INFO - 2022-04-06 04:20:29 --> Model Class Initialized
INFO - 2022-04-06 04:20:29 --> Model Class Initialized
INFO - 2022-04-06 04:20:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:20:29 --> Final output sent to browser
DEBUG - 2022-04-06 04:20:29 --> Total execution time: 0.0671
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
INFO - 2022-04-06 04:20:29 --> Config Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
INFO - 2022-04-06 04:20:29 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
DEBUG - 2022-04-06 04:20:29 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:29 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
INFO - 2022-04-06 04:20:29 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Router Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
INFO - 2022-04-06 04:20:29 --> Output Class Initialized
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:29 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:29 --> Input Class Initialized
INFO - 2022-04-06 04:20:29 --> Language Class Initialized
ERROR - 2022-04-06 04:20:29 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
INFO - 2022-04-06 04:20:41 --> Loader Class Initialized
INFO - 2022-04-06 04:20:41 --> Helper loaded: url_helper
INFO - 2022-04-06 04:20:41 --> Helper loaded: form_helper
INFO - 2022-04-06 04:20:41 --> Helper loaded: common_helper
INFO - 2022-04-06 04:20:41 --> Helper loaded: util_helper
INFO - 2022-04-06 04:20:41 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:20:41 --> Form Validation Class Initialized
INFO - 2022-04-06 04:20:41 --> Controller Class Initialized
INFO - 2022-04-06 04:20:41 --> Model Class Initialized
INFO - 2022-04-06 04:20:41 --> Model Class Initialized
INFO - 2022-04-06 04:20:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:20:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:20:41 --> Final output sent to browser
DEBUG - 2022-04-06 04:20:41 --> Total execution time: 0.0548
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Config Class Initialized
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:41 --> URI Class Initialized
INFO - 2022-04-06 04:20:41 --> Router Class Initialized
INFO - 2022-04-06 04:20:41 --> Output Class Initialized
INFO - 2022-04-06 04:20:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:41 --> Input Class Initialized
INFO - 2022-04-06 04:20:41 --> Language Class Initialized
ERROR - 2022-04-06 04:20:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:20:44 --> Config Class Initialized
INFO - 2022-04-06 04:20:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:20:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:20:44 --> Utf8 Class Initialized
INFO - 2022-04-06 04:20:44 --> URI Class Initialized
INFO - 2022-04-06 04:20:44 --> Router Class Initialized
INFO - 2022-04-06 04:20:44 --> Output Class Initialized
INFO - 2022-04-06 04:20:44 --> Security Class Initialized
DEBUG - 2022-04-06 04:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:20:44 --> Input Class Initialized
INFO - 2022-04-06 04:20:44 --> Language Class Initialized
INFO - 2022-04-06 04:20:44 --> Loader Class Initialized
INFO - 2022-04-06 04:20:44 --> Helper loaded: url_helper
INFO - 2022-04-06 04:20:44 --> Helper loaded: form_helper
INFO - 2022-04-06 04:20:44 --> Helper loaded: common_helper
INFO - 2022-04-06 04:20:44 --> Helper loaded: util_helper
INFO - 2022-04-06 04:20:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:20:44 --> Form Validation Class Initialized
INFO - 2022-04-06 04:20:44 --> Controller Class Initialized
INFO - 2022-04-06 04:20:44 --> Model Class Initialized
INFO - 2022-04-06 04:20:44 --> Model Class Initialized
INFO - 2022-04-06 04:20:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:20:44 --> Final output sent to browser
DEBUG - 2022-04-06 04:20:44 --> Total execution time: 0.0855
INFO - 2022-04-06 04:21:01 --> Config Class Initialized
INFO - 2022-04-06 04:21:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:01 --> URI Class Initialized
INFO - 2022-04-06 04:21:01 --> Router Class Initialized
INFO - 2022-04-06 04:21:01 --> Output Class Initialized
INFO - 2022-04-06 04:21:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:01 --> Input Class Initialized
INFO - 2022-04-06 04:21:01 --> Language Class Initialized
INFO - 2022-04-06 04:21:01 --> Loader Class Initialized
INFO - 2022-04-06 04:21:01 --> Helper loaded: url_helper
INFO - 2022-04-06 04:21:01 --> Helper loaded: form_helper
INFO - 2022-04-06 04:21:01 --> Helper loaded: common_helper
INFO - 2022-04-06 04:21:01 --> Helper loaded: util_helper
INFO - 2022-04-06 04:21:01 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:21:01 --> Form Validation Class Initialized
INFO - 2022-04-06 04:21:01 --> Controller Class Initialized
INFO - 2022-04-06 04:21:01 --> Model Class Initialized
INFO - 2022-04-06 04:21:01 --> Model Class Initialized
INFO - 2022-04-06 04:21:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:21:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:21:02 --> Final output sent to browser
DEBUG - 2022-04-06 04:21:02 --> Total execution time: 0.1449
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:21:02 --> Config Class Initialized
INFO - 2022-04-06 04:21:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:02 --> URI Class Initialized
INFO - 2022-04-06 04:21:02 --> Router Class Initialized
INFO - 2022-04-06 04:21:02 --> Output Class Initialized
INFO - 2022-04-06 04:21:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:02 --> Input Class Initialized
INFO - 2022-04-06 04:21:02 --> Language Class Initialized
ERROR - 2022-04-06 04:21:02 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:21:04 --> Config Class Initialized
INFO - 2022-04-06 04:21:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:04 --> URI Class Initialized
INFO - 2022-04-06 04:21:04 --> Router Class Initialized
INFO - 2022-04-06 04:21:04 --> Output Class Initialized
INFO - 2022-04-06 04:21:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:04 --> Input Class Initialized
INFO - 2022-04-06 04:21:04 --> Language Class Initialized
INFO - 2022-04-06 04:21:04 --> Loader Class Initialized
INFO - 2022-04-06 04:21:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:21:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:21:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:21:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:21:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:21:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:21:04 --> Controller Class Initialized
INFO - 2022-04-06 04:21:04 --> Model Class Initialized
INFO - 2022-04-06 04:21:04 --> Model Class Initialized
INFO - 2022-04-06 04:21:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:21:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:21:04 --> Total execution time: 0.0708
INFO - 2022-04-06 04:21:04 --> Config Class Initialized
INFO - 2022-04-06 04:21:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:04 --> URI Class Initialized
INFO - 2022-04-06 04:21:04 --> Router Class Initialized
INFO - 2022-04-06 04:21:04 --> Output Class Initialized
INFO - 2022-04-06 04:21:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:04 --> Input Class Initialized
INFO - 2022-04-06 04:21:04 --> Language Class Initialized
INFO - 2022-04-06 04:21:04 --> Loader Class Initialized
INFO - 2022-04-06 04:21:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:21:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:21:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:21:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:21:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:21:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:21:04 --> Controller Class Initialized
INFO - 2022-04-06 04:21:04 --> Model Class Initialized
INFO - 2022-04-06 04:21:04 --> Model Class Initialized
INFO - 2022-04-06 04:21:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:21:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:21:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:21:04 --> Total execution time: 0.0628
INFO - 2022-04-06 04:21:06 --> Config Class Initialized
INFO - 2022-04-06 04:21:06 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:06 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:06 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:06 --> URI Class Initialized
INFO - 2022-04-06 04:21:06 --> Router Class Initialized
INFO - 2022-04-06 04:21:06 --> Output Class Initialized
INFO - 2022-04-06 04:21:06 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:06 --> Input Class Initialized
INFO - 2022-04-06 04:21:06 --> Language Class Initialized
INFO - 2022-04-06 04:21:06 --> Loader Class Initialized
INFO - 2022-04-06 04:21:06 --> Helper loaded: url_helper
INFO - 2022-04-06 04:21:06 --> Helper loaded: form_helper
INFO - 2022-04-06 04:21:06 --> Helper loaded: common_helper
INFO - 2022-04-06 04:21:06 --> Helper loaded: util_helper
INFO - 2022-04-06 04:21:06 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:21:06 --> Form Validation Class Initialized
INFO - 2022-04-06 04:21:06 --> Controller Class Initialized
INFO - 2022-04-06 04:21:06 --> Model Class Initialized
INFO - 2022-04-06 04:21:06 --> Model Class Initialized
INFO - 2022-04-06 04:21:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:21:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:21:06 --> Final output sent to browser
DEBUG - 2022-04-06 04:21:06 --> Total execution time: 0.0775
INFO - 2022-04-06 04:21:06 --> Config Class Initialized
INFO - 2022-04-06 04:21:06 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:06 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:06 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:06 --> URI Class Initialized
INFO - 2022-04-06 04:21:06 --> Router Class Initialized
INFO - 2022-04-06 04:21:06 --> Output Class Initialized
INFO - 2022-04-06 04:21:06 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:06 --> Input Class Initialized
INFO - 2022-04-06 04:21:06 --> Language Class Initialized
ERROR - 2022-04-06 04:21:06 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:21:58 --> Config Class Initialized
INFO - 2022-04-06 04:21:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:58 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:58 --> URI Class Initialized
INFO - 2022-04-06 04:21:58 --> Router Class Initialized
INFO - 2022-04-06 04:21:58 --> Output Class Initialized
INFO - 2022-04-06 04:21:58 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:58 --> Input Class Initialized
INFO - 2022-04-06 04:21:58 --> Language Class Initialized
INFO - 2022-04-06 04:21:58 --> Loader Class Initialized
INFO - 2022-04-06 04:21:58 --> Helper loaded: url_helper
INFO - 2022-04-06 04:21:58 --> Helper loaded: form_helper
INFO - 2022-04-06 04:21:58 --> Helper loaded: common_helper
INFO - 2022-04-06 04:21:58 --> Helper loaded: util_helper
INFO - 2022-04-06 04:21:58 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:21:58 --> Form Validation Class Initialized
INFO - 2022-04-06 04:21:58 --> Controller Class Initialized
INFO - 2022-04-06 04:21:58 --> Model Class Initialized
INFO - 2022-04-06 04:21:58 --> Model Class Initialized
INFO - 2022-04-06 04:21:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:21:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:21:58 --> Final output sent to browser
DEBUG - 2022-04-06 04:21:58 --> Total execution time: 0.0605
INFO - 2022-04-06 04:21:58 --> Config Class Initialized
INFO - 2022-04-06 04:21:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:21:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:21:58 --> Utf8 Class Initialized
INFO - 2022-04-06 04:21:58 --> URI Class Initialized
INFO - 2022-04-06 04:21:58 --> Router Class Initialized
INFO - 2022-04-06 04:21:58 --> Output Class Initialized
INFO - 2022-04-06 04:21:58 --> Security Class Initialized
DEBUG - 2022-04-06 04:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:21:59 --> Input Class Initialized
INFO - 2022-04-06 04:21:59 --> Language Class Initialized
ERROR - 2022-04-06 04:21:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:22:01 --> Config Class Initialized
INFO - 2022-04-06 04:22:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:01 --> URI Class Initialized
INFO - 2022-04-06 04:22:01 --> Router Class Initialized
INFO - 2022-04-06 04:22:01 --> Output Class Initialized
INFO - 2022-04-06 04:22:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:01 --> Input Class Initialized
INFO - 2022-04-06 04:22:01 --> Language Class Initialized
INFO - 2022-04-06 04:22:01 --> Loader Class Initialized
INFO - 2022-04-06 04:22:01 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:01 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:01 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:01 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:01 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:02 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:02 --> Controller Class Initialized
INFO - 2022-04-06 04:22:02 --> Model Class Initialized
INFO - 2022-04-06 04:22:02 --> Model Class Initialized
INFO - 2022-04-06 04:22:02 --> Config Class Initialized
INFO - 2022-04-06 04:22:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:02 --> URI Class Initialized
INFO - 2022-04-06 04:22:02 --> Router Class Initialized
INFO - 2022-04-06 04:22:02 --> Output Class Initialized
INFO - 2022-04-06 04:22:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:02 --> Input Class Initialized
INFO - 2022-04-06 04:22:02 --> Language Class Initialized
INFO - 2022-04-06 04:22:02 --> Loader Class Initialized
INFO - 2022-04-06 04:22:02 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:02 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:02 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:02 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:02 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:02 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:02 --> Controller Class Initialized
INFO - 2022-04-06 04:22:02 --> Model Class Initialized
INFO - 2022-04-06 04:22:02 --> Model Class Initialized
INFO - 2022-04-06 04:22:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:22:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:22:02 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:02 --> Total execution time: 0.0783
INFO - 2022-04-06 04:22:02 --> Config Class Initialized
INFO - 2022-04-06 04:22:02 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:02 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:02 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:02 --> URI Class Initialized
INFO - 2022-04-06 04:22:02 --> Router Class Initialized
INFO - 2022-04-06 04:22:02 --> Output Class Initialized
INFO - 2022-04-06 04:22:02 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:02 --> Input Class Initialized
INFO - 2022-04-06 04:22:02 --> Language Class Initialized
ERROR - 2022-04-06 04:22:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:22:03 --> Config Class Initialized
INFO - 2022-04-06 04:22:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:03 --> URI Class Initialized
INFO - 2022-04-06 04:22:03 --> Router Class Initialized
INFO - 2022-04-06 04:22:03 --> Output Class Initialized
INFO - 2022-04-06 04:22:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:03 --> Input Class Initialized
INFO - 2022-04-06 04:22:03 --> Language Class Initialized
INFO - 2022-04-06 04:22:03 --> Loader Class Initialized
INFO - 2022-04-06 04:22:03 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:03 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:03 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:03 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:03 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:03 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:03 --> Controller Class Initialized
INFO - 2022-04-06 04:22:03 --> Model Class Initialized
INFO - 2022-04-06 04:22:03 --> Model Class Initialized
INFO - 2022-04-06 04:22:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-06 04:22:03 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:03 --> Total execution time: 0.0777
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Config Class Initialized
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Hooks Class Initialized
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:22:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
INFO - 2022-04-06 04:22:04 --> URI Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
INFO - 2022-04-06 04:22:04 --> Router Class Initialized
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:04 --> Output Class Initialized
INFO - 2022-04-06 04:22:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:04 --> Input Class Initialized
INFO - 2022-04-06 04:22:04 --> Language Class Initialized
ERROR - 2022-04-06 04:22:04 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:08 --> Config Class Initialized
INFO - 2022-04-06 04:22:08 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:08 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:08 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:08 --> URI Class Initialized
INFO - 2022-04-06 04:22:08 --> Router Class Initialized
INFO - 2022-04-06 04:22:08 --> Output Class Initialized
INFO - 2022-04-06 04:22:08 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:08 --> Input Class Initialized
INFO - 2022-04-06 04:22:08 --> Language Class Initialized
INFO - 2022-04-06 04:22:08 --> Loader Class Initialized
INFO - 2022-04-06 04:22:08 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:08 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:08 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:08 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:08 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:08 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:08 --> Controller Class Initialized
INFO - 2022-04-06 04:22:08 --> Model Class Initialized
INFO - 2022-04-06 04:22:08 --> Model Class Initialized
INFO - 2022-04-06 04:22:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:22:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:22:08 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:08 --> Total execution time: 0.0706
INFO - 2022-04-06 04:22:09 --> Config Class Initialized
INFO - 2022-04-06 04:22:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:09 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:09 --> URI Class Initialized
INFO - 2022-04-06 04:22:09 --> Router Class Initialized
INFO - 2022-04-06 04:22:09 --> Output Class Initialized
INFO - 2022-04-06 04:22:09 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:09 --> Input Class Initialized
INFO - 2022-04-06 04:22:09 --> Language Class Initialized
INFO - 2022-04-06 04:22:09 --> Loader Class Initialized
INFO - 2022-04-06 04:22:09 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:09 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:09 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:09 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:09 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:09 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:09 --> Controller Class Initialized
INFO - 2022-04-06 04:22:09 --> Model Class Initialized
INFO - 2022-04-06 04:22:09 --> Model Class Initialized
INFO - 2022-04-06 04:22:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:22:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:22:09 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:09 --> Total execution time: 0.0694
INFO - 2022-04-06 04:22:09 --> Config Class Initialized
INFO - 2022-04-06 04:22:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:09 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:09 --> URI Class Initialized
INFO - 2022-04-06 04:22:09 --> Router Class Initialized
INFO - 2022-04-06 04:22:09 --> Output Class Initialized
INFO - 2022-04-06 04:22:09 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:09 --> Input Class Initialized
INFO - 2022-04-06 04:22:09 --> Language Class Initialized
ERROR - 2022-04-06 04:22:09 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
INFO - 2022-04-06 04:22:11 --> Loader Class Initialized
INFO - 2022-04-06 04:22:11 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:11 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:11 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:11 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:11 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:11 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:11 --> Controller Class Initialized
INFO - 2022-04-06 04:22:11 --> Model Class Initialized
INFO - 2022-04-06 04:22:11 --> Model Class Initialized
INFO - 2022-04-06 04:22:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-06 04:22:11 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:11 --> Total execution time: 0.0617
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:11 --> Config Class Initialized
INFO - 2022-04-06 04:22:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:11 --> URI Class Initialized
INFO - 2022-04-06 04:22:11 --> Router Class Initialized
INFO - 2022-04-06 04:22:11 --> Output Class Initialized
INFO - 2022-04-06 04:22:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:11 --> Input Class Initialized
INFO - 2022-04-06 04:22:11 --> Language Class Initialized
ERROR - 2022-04-06 04:22:11 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:50 --> Config Class Initialized
INFO - 2022-04-06 04:22:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:50 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:50 --> URI Class Initialized
INFO - 2022-04-06 04:22:50 --> Router Class Initialized
INFO - 2022-04-06 04:22:50 --> Output Class Initialized
INFO - 2022-04-06 04:22:50 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:50 --> Input Class Initialized
INFO - 2022-04-06 04:22:50 --> Language Class Initialized
INFO - 2022-04-06 04:22:50 --> Loader Class Initialized
INFO - 2022-04-06 04:22:50 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:50 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:50 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:50 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:50 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:50 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:50 --> Controller Class Initialized
INFO - 2022-04-06 04:22:50 --> Model Class Initialized
INFO - 2022-04-06 04:22:50 --> Model Class Initialized
INFO - 2022-04-06 04:22:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:22:50 --> Config Class Initialized
INFO - 2022-04-06 04:22:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:50 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:50 --> URI Class Initialized
INFO - 2022-04-06 04:22:50 --> Router Class Initialized
INFO - 2022-04-06 04:22:50 --> Output Class Initialized
INFO - 2022-04-06 04:22:50 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:50 --> Input Class Initialized
INFO - 2022-04-06 04:22:50 --> Language Class Initialized
INFO - 2022-04-06 04:22:50 --> Loader Class Initialized
INFO - 2022-04-06 04:22:50 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:50 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:50 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:50 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:50 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:50 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:50 --> Controller Class Initialized
INFO - 2022-04-06 04:22:50 --> Model Class Initialized
INFO - 2022-04-06 04:22:50 --> Model Class Initialized
INFO - 2022-04-06 04:22:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-06 04:22:50 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:50 --> Total execution time: 0.0614
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
INFO - 2022-04-06 04:22:51 --> Config Class Initialized
INFO - 2022-04-06 04:22:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
DEBUG - 2022-04-06 04:22:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
INFO - 2022-04-06 04:22:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
INFO - 2022-04-06 04:22:51 --> URI Class Initialized
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:51 --> Router Class Initialized
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
INFO - 2022-04-06 04:22:51 --> Output Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
INFO - 2022-04-06 04:22:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
DEBUG - 2022-04-06 04:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:51 --> Input Class Initialized
INFO - 2022-04-06 04:22:51 --> Language Class Initialized
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:22:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:53 --> Config Class Initialized
INFO - 2022-04-06 04:22:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:53 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:53 --> URI Class Initialized
INFO - 2022-04-06 04:22:53 --> Router Class Initialized
INFO - 2022-04-06 04:22:53 --> Output Class Initialized
INFO - 2022-04-06 04:22:53 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:53 --> Input Class Initialized
INFO - 2022-04-06 04:22:53 --> Language Class Initialized
INFO - 2022-04-06 04:22:53 --> Loader Class Initialized
INFO - 2022-04-06 04:22:53 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:53 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:53 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:53 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:53 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:53 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:53 --> Controller Class Initialized
INFO - 2022-04-06 04:22:53 --> Model Class Initialized
INFO - 2022-04-06 04:22:53 --> Model Class Initialized
INFO - 2022-04-06 04:22:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-06 04:22:53 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:53 --> Total execution time: 0.0777
INFO - 2022-04-06 04:22:53 --> Config Class Initialized
INFO - 2022-04-06 04:22:53 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:53 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:53 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:53 --> URI Class Initialized
INFO - 2022-04-06 04:22:53 --> Router Class Initialized
INFO - 2022-04-06 04:22:53 --> Output Class Initialized
INFO - 2022-04-06 04:22:53 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:53 --> Input Class Initialized
INFO - 2022-04-06 04:22:53 --> Language Class Initialized
ERROR - 2022-04-06 04:22:53 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:22:54 --> Config Class Initialized
INFO - 2022-04-06 04:22:54 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:54 --> URI Class Initialized
INFO - 2022-04-06 04:22:54 --> Router Class Initialized
INFO - 2022-04-06 04:22:54 --> Output Class Initialized
INFO - 2022-04-06 04:22:54 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:54 --> Input Class Initialized
INFO - 2022-04-06 04:22:54 --> Language Class Initialized
INFO - 2022-04-06 04:22:54 --> Loader Class Initialized
INFO - 2022-04-06 04:22:54 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:54 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:54 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:54 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:54 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:54 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:54 --> Controller Class Initialized
INFO - 2022-04-06 04:22:54 --> Model Class Initialized
INFO - 2022-04-06 04:22:54 --> Model Class Initialized
INFO - 2022-04-06 04:22:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:22:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:22:54 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:54 --> Total execution time: 0.0634
INFO - 2022-04-06 04:22:55 --> Config Class Initialized
INFO - 2022-04-06 04:22:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:55 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:55 --> URI Class Initialized
INFO - 2022-04-06 04:22:55 --> Router Class Initialized
INFO - 2022-04-06 04:22:55 --> Output Class Initialized
INFO - 2022-04-06 04:22:55 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:55 --> Input Class Initialized
INFO - 2022-04-06 04:22:55 --> Language Class Initialized
INFO - 2022-04-06 04:22:55 --> Loader Class Initialized
INFO - 2022-04-06 04:22:55 --> Helper loaded: url_helper
INFO - 2022-04-06 04:22:55 --> Helper loaded: form_helper
INFO - 2022-04-06 04:22:55 --> Helper loaded: common_helper
INFO - 2022-04-06 04:22:55 --> Helper loaded: util_helper
INFO - 2022-04-06 04:22:55 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:22:55 --> Form Validation Class Initialized
INFO - 2022-04-06 04:22:55 --> Controller Class Initialized
INFO - 2022-04-06 04:22:55 --> Model Class Initialized
INFO - 2022-04-06 04:22:55 --> Model Class Initialized
INFO - 2022-04-06 04:22:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:22:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:22:55 --> Final output sent to browser
DEBUG - 2022-04-06 04:22:55 --> Total execution time: 0.0695
INFO - 2022-04-06 04:22:55 --> Config Class Initialized
INFO - 2022-04-06 04:22:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:22:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:22:55 --> Utf8 Class Initialized
INFO - 2022-04-06 04:22:55 --> URI Class Initialized
INFO - 2022-04-06 04:22:55 --> Router Class Initialized
INFO - 2022-04-06 04:22:55 --> Output Class Initialized
INFO - 2022-04-06 04:22:55 --> Security Class Initialized
DEBUG - 2022-04-06 04:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:22:55 --> Input Class Initialized
INFO - 2022-04-06 04:22:55 --> Language Class Initialized
ERROR - 2022-04-06 04:22:55 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:23:39 --> Config Class Initialized
INFO - 2022-04-06 04:23:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:23:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:39 --> URI Class Initialized
INFO - 2022-04-06 04:23:39 --> Router Class Initialized
INFO - 2022-04-06 04:23:39 --> Output Class Initialized
INFO - 2022-04-06 04:23:39 --> Security Class Initialized
DEBUG - 2022-04-06 04:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:39 --> Input Class Initialized
INFO - 2022-04-06 04:23:39 --> Language Class Initialized
INFO - 2022-04-06 04:23:39 --> Loader Class Initialized
INFO - 2022-04-06 04:23:39 --> Helper loaded: url_helper
INFO - 2022-04-06 04:23:39 --> Helper loaded: form_helper
INFO - 2022-04-06 04:23:39 --> Helper loaded: common_helper
INFO - 2022-04-06 04:23:39 --> Helper loaded: util_helper
INFO - 2022-04-06 04:23:39 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:23:39 --> Form Validation Class Initialized
INFO - 2022-04-06 04:23:39 --> Controller Class Initialized
INFO - 2022-04-06 04:23:39 --> Model Class Initialized
INFO - 2022-04-06 04:23:39 --> Model Class Initialized
INFO - 2022-04-06 04:23:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:23:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:23:39 --> Final output sent to browser
DEBUG - 2022-04-06 04:23:39 --> Total execution time: 0.0678
INFO - 2022-04-06 04:23:39 --> Config Class Initialized
INFO - 2022-04-06 04:23:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:23:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:39 --> URI Class Initialized
INFO - 2022-04-06 04:23:39 --> Router Class Initialized
INFO - 2022-04-06 04:23:39 --> Output Class Initialized
INFO - 2022-04-06 04:23:39 --> Security Class Initialized
DEBUG - 2022-04-06 04:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:39 --> Input Class Initialized
INFO - 2022-04-06 04:23:39 --> Language Class Initialized
ERROR - 2022-04-06 04:23:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> Loader Class Initialized
INFO - 2022-04-06 04:23:43 --> Helper loaded: url_helper
INFO - 2022-04-06 04:23:43 --> Helper loaded: form_helper
INFO - 2022-04-06 04:23:43 --> Helper loaded: common_helper
INFO - 2022-04-06 04:23:43 --> Helper loaded: util_helper
INFO - 2022-04-06 04:23:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:23:43 --> Form Validation Class Initialized
INFO - 2022-04-06 04:23:43 --> Controller Class Initialized
INFO - 2022-04-06 04:23:43 --> Model Class Initialized
INFO - 2022-04-06 04:23:43 --> Model Class Initialized
INFO - 2022-04-06 04:23:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:23:43 --> Final output sent to browser
DEBUG - 2022-04-06 04:23:43 --> Total execution time: 0.0622
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> Config Class Initialized
INFO - 2022-04-06 04:23:43 --> Hooks Class Initialized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:23:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:23:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:23:43 --> URI Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
INFO - 2022-04-06 04:23:43 --> Router Class Initialized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:23:43 --> Output Class Initialized
INFO - 2022-04-06 04:23:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:23:43 --> Input Class Initialized
INFO - 2022-04-06 04:23:43 --> Language Class Initialized
ERROR - 2022-04-06 04:23:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
INFO - 2022-04-06 04:24:00 --> Loader Class Initialized
INFO - 2022-04-06 04:24:00 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:00 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:00 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:00 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:00 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:00 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:00 --> Controller Class Initialized
INFO - 2022-04-06 04:24:00 --> Model Class Initialized
INFO - 2022-04-06 04:24:00 --> Model Class Initialized
INFO - 2022-04-06 04:24:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:24:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:24:00 --> Final output sent to browser
DEBUG - 2022-04-06 04:24:00 --> Total execution time: 0.1470
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
INFO - 2022-04-06 04:24:00 --> Config Class Initialized
INFO - 2022-04-06 04:24:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:24:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
INFO - 2022-04-06 04:24:00 --> URI Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
INFO - 2022-04-06 04:24:00 --> Router Class Initialized
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:24:00 --> Output Class Initialized
INFO - 2022-04-06 04:24:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:00 --> Input Class Initialized
INFO - 2022-04-06 04:24:00 --> Language Class Initialized
ERROR - 2022-04-06 04:24:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:24:01 --> Config Class Initialized
INFO - 2022-04-06 04:24:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:01 --> URI Class Initialized
INFO - 2022-04-06 04:24:01 --> Router Class Initialized
INFO - 2022-04-06 04:24:01 --> Output Class Initialized
INFO - 2022-04-06 04:24:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:01 --> Input Class Initialized
INFO - 2022-04-06 04:24:01 --> Language Class Initialized
INFO - 2022-04-06 04:24:01 --> Loader Class Initialized
INFO - 2022-04-06 04:24:01 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:01 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:01 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:01 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:01 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:01 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:01 --> Controller Class Initialized
INFO - 2022-04-06 04:24:01 --> Model Class Initialized
INFO - 2022-04-06 04:24:01 --> Model Class Initialized
INFO - 2022-04-06 04:24:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:24:01 --> Final output sent to browser
DEBUG - 2022-04-06 04:24:01 --> Total execution time: 0.0631
INFO - 2022-04-06 04:24:01 --> Config Class Initialized
INFO - 2022-04-06 04:24:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:24:01 --> Config Class Initialized
INFO - 2022-04-06 04:24:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:24:01 --> Config Class Initialized
INFO - 2022-04-06 04:24:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:01 --> URI Class Initialized
DEBUG - 2022-04-06 04:24:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:01 --> Router Class Initialized
DEBUG - 2022-04-06 04:24:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:01 --> URI Class Initialized
INFO - 2022-04-06 04:24:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:01 --> Output Class Initialized
INFO - 2022-04-06 04:24:01 --> Router Class Initialized
INFO - 2022-04-06 04:24:01 --> URI Class Initialized
INFO - 2022-04-06 04:24:01 --> Security Class Initialized
INFO - 2022-04-06 04:24:01 --> Router Class Initialized
DEBUG - 2022-04-06 04:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:02 --> Input Class Initialized
INFO - 2022-04-06 04:24:02 --> Language Class Initialized
INFO - 2022-04-06 04:24:02 --> Output Class Initialized
INFO - 2022-04-06 04:24:02 --> Output Class Initialized
INFO - 2022-04-06 04:24:02 --> Security Class Initialized
INFO - 2022-04-06 04:24:02 --> Security Class Initialized
ERROR - 2022-04-06 04:24:02 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:02 --> Input Class Initialized
INFO - 2022-04-06 04:24:02 --> Language Class Initialized
DEBUG - 2022-04-06 04:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:02 --> Input Class Initialized
INFO - 2022-04-06 04:24:02 --> Language Class Initialized
ERROR - 2022-04-06 04:24:02 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:24:02 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:24:03 --> Config Class Initialized
INFO - 2022-04-06 04:24:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:03 --> URI Class Initialized
INFO - 2022-04-06 04:24:03 --> Router Class Initialized
INFO - 2022-04-06 04:24:03 --> Output Class Initialized
INFO - 2022-04-06 04:24:03 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:03 --> Input Class Initialized
INFO - 2022-04-06 04:24:03 --> Language Class Initialized
INFO - 2022-04-06 04:24:03 --> Loader Class Initialized
INFO - 2022-04-06 04:24:03 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:03 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:03 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:03 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:03 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:03 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:03 --> Controller Class Initialized
INFO - 2022-04-06 04:24:03 --> Model Class Initialized
INFO - 2022-04-06 04:24:03 --> Model Class Initialized
INFO - 2022-04-06 04:24:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:24:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:24:03 --> Final output sent to browser
DEBUG - 2022-04-06 04:24:03 --> Total execution time: 0.0616
INFO - 2022-04-06 04:24:04 --> Config Class Initialized
INFO - 2022-04-06 04:24:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:04 --> URI Class Initialized
INFO - 2022-04-06 04:24:04 --> Router Class Initialized
INFO - 2022-04-06 04:24:04 --> Output Class Initialized
INFO - 2022-04-06 04:24:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:04 --> Input Class Initialized
INFO - 2022-04-06 04:24:04 --> Language Class Initialized
INFO - 2022-04-06 04:24:04 --> Loader Class Initialized
INFO - 2022-04-06 04:24:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:04 --> Controller Class Initialized
INFO - 2022-04-06 04:24:04 --> Model Class Initialized
INFO - 2022-04-06 04:24:04 --> Model Class Initialized
INFO - 2022-04-06 04:24:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:24:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:24:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:24:04 --> Total execution time: 0.0603
INFO - 2022-04-06 04:24:04 --> Config Class Initialized
INFO - 2022-04-06 04:24:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:04 --> URI Class Initialized
INFO - 2022-04-06 04:24:04 --> Router Class Initialized
INFO - 2022-04-06 04:24:04 --> Output Class Initialized
INFO - 2022-04-06 04:24:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:04 --> Input Class Initialized
INFO - 2022-04-06 04:24:04 --> Language Class Initialized
ERROR - 2022-04-06 04:24:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:24:56 --> Config Class Initialized
INFO - 2022-04-06 04:24:56 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:56 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:56 --> URI Class Initialized
INFO - 2022-04-06 04:24:56 --> Router Class Initialized
INFO - 2022-04-06 04:24:56 --> Output Class Initialized
INFO - 2022-04-06 04:24:56 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:56 --> Input Class Initialized
INFO - 2022-04-06 04:24:56 --> Language Class Initialized
INFO - 2022-04-06 04:24:56 --> Loader Class Initialized
INFO - 2022-04-06 04:24:56 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:56 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:56 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:56 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:56 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:56 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:56 --> Controller Class Initialized
INFO - 2022-04-06 04:24:56 --> Model Class Initialized
INFO - 2022-04-06 04:24:56 --> Model Class Initialized
INFO - 2022-04-06 04:24:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:24:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:24:56 --> Final output sent to browser
DEBUG - 2022-04-06 04:24:56 --> Total execution time: 0.0643
INFO - 2022-04-06 04:24:56 --> Config Class Initialized
INFO - 2022-04-06 04:24:56 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:56 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:56 --> URI Class Initialized
INFO - 2022-04-06 04:24:56 --> Router Class Initialized
INFO - 2022-04-06 04:24:56 --> Output Class Initialized
INFO - 2022-04-06 04:24:56 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:56 --> Input Class Initialized
INFO - 2022-04-06 04:24:56 --> Language Class Initialized
ERROR - 2022-04-06 04:24:56 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:24:59 --> Config Class Initialized
INFO - 2022-04-06 04:24:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:59 --> URI Class Initialized
INFO - 2022-04-06 04:24:59 --> Router Class Initialized
INFO - 2022-04-06 04:24:59 --> Output Class Initialized
INFO - 2022-04-06 04:24:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:59 --> Input Class Initialized
INFO - 2022-04-06 04:24:59 --> Language Class Initialized
INFO - 2022-04-06 04:24:59 --> Loader Class Initialized
INFO - 2022-04-06 04:24:59 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:59 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:59 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:59 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:59 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:59 --> Controller Class Initialized
INFO - 2022-04-06 04:24:59 --> Model Class Initialized
INFO - 2022-04-06 04:24:59 --> Model Class Initialized
INFO - 2022-04-06 04:24:59 --> Config Class Initialized
INFO - 2022-04-06 04:24:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:59 --> URI Class Initialized
INFO - 2022-04-06 04:24:59 --> Router Class Initialized
INFO - 2022-04-06 04:24:59 --> Output Class Initialized
INFO - 2022-04-06 04:24:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:59 --> Input Class Initialized
INFO - 2022-04-06 04:24:59 --> Language Class Initialized
INFO - 2022-04-06 04:24:59 --> Loader Class Initialized
INFO - 2022-04-06 04:24:59 --> Helper loaded: url_helper
INFO - 2022-04-06 04:24:59 --> Helper loaded: form_helper
INFO - 2022-04-06 04:24:59 --> Helper loaded: common_helper
INFO - 2022-04-06 04:24:59 --> Helper loaded: util_helper
INFO - 2022-04-06 04:24:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:24:59 --> Form Validation Class Initialized
INFO - 2022-04-06 04:24:59 --> Controller Class Initialized
INFO - 2022-04-06 04:24:59 --> Model Class Initialized
INFO - 2022-04-06 04:24:59 --> Model Class Initialized
INFO - 2022-04-06 04:24:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:24:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:24:59 --> Final output sent to browser
DEBUG - 2022-04-06 04:24:59 --> Total execution time: 0.0583
INFO - 2022-04-06 04:24:59 --> Config Class Initialized
INFO - 2022-04-06 04:24:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:24:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:24:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:24:59 --> URI Class Initialized
INFO - 2022-04-06 04:24:59 --> Router Class Initialized
INFO - 2022-04-06 04:24:59 --> Output Class Initialized
INFO - 2022-04-06 04:24:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:24:59 --> Input Class Initialized
INFO - 2022-04-06 04:24:59 --> Language Class Initialized
ERROR - 2022-04-06 04:24:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:25:35 --> Config Class Initialized
INFO - 2022-04-06 04:25:35 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:25:35 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:25:35 --> Utf8 Class Initialized
INFO - 2022-04-06 04:25:35 --> URI Class Initialized
INFO - 2022-04-06 04:25:35 --> Router Class Initialized
INFO - 2022-04-06 04:25:35 --> Output Class Initialized
INFO - 2022-04-06 04:25:35 --> Security Class Initialized
DEBUG - 2022-04-06 04:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:25:35 --> Input Class Initialized
INFO - 2022-04-06 04:25:35 --> Language Class Initialized
INFO - 2022-04-06 04:25:35 --> Loader Class Initialized
INFO - 2022-04-06 04:25:35 --> Helper loaded: url_helper
INFO - 2022-04-06 04:25:35 --> Helper loaded: form_helper
INFO - 2022-04-06 04:25:35 --> Helper loaded: common_helper
INFO - 2022-04-06 04:25:35 --> Helper loaded: util_helper
INFO - 2022-04-06 04:25:35 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:25:35 --> Form Validation Class Initialized
INFO - 2022-04-06 04:25:35 --> Controller Class Initialized
INFO - 2022-04-06 04:25:35 --> Model Class Initialized
INFO - 2022-04-06 04:25:35 --> Model Class Initialized
INFO - 2022-04-06 04:25:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:25:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:25:35 --> Final output sent to browser
DEBUG - 2022-04-06 04:25:35 --> Total execution time: 0.0587
INFO - 2022-04-06 04:25:35 --> Config Class Initialized
INFO - 2022-04-06 04:25:35 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:25:35 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:25:35 --> Utf8 Class Initialized
INFO - 2022-04-06 04:25:35 --> URI Class Initialized
INFO - 2022-04-06 04:25:35 --> Router Class Initialized
INFO - 2022-04-06 04:25:35 --> Output Class Initialized
INFO - 2022-04-06 04:25:35 --> Security Class Initialized
DEBUG - 2022-04-06 04:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:25:35 --> Input Class Initialized
INFO - 2022-04-06 04:25:35 --> Language Class Initialized
ERROR - 2022-04-06 04:25:35 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:26:14 --> Config Class Initialized
INFO - 2022-04-06 04:26:14 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:26:14 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:26:14 --> Utf8 Class Initialized
INFO - 2022-04-06 04:26:14 --> URI Class Initialized
INFO - 2022-04-06 04:26:14 --> Router Class Initialized
INFO - 2022-04-06 04:26:14 --> Output Class Initialized
INFO - 2022-04-06 04:26:14 --> Security Class Initialized
DEBUG - 2022-04-06 04:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:26:14 --> Input Class Initialized
INFO - 2022-04-06 04:26:14 --> Language Class Initialized
INFO - 2022-04-06 04:26:14 --> Loader Class Initialized
INFO - 2022-04-06 04:26:14 --> Helper loaded: url_helper
INFO - 2022-04-06 04:26:14 --> Helper loaded: form_helper
INFO - 2022-04-06 04:26:14 --> Helper loaded: common_helper
INFO - 2022-04-06 04:26:14 --> Helper loaded: util_helper
INFO - 2022-04-06 04:26:14 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:26:14 --> Form Validation Class Initialized
INFO - 2022-04-06 04:26:14 --> Controller Class Initialized
INFO - 2022-04-06 04:26:14 --> Model Class Initialized
INFO - 2022-04-06 04:26:14 --> Model Class Initialized
INFO - 2022-04-06 04:26:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:26:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:26:14 --> Final output sent to browser
DEBUG - 2022-04-06 04:26:14 --> Total execution time: 0.0659
INFO - 2022-04-06 04:26:14 --> Config Class Initialized
INFO - 2022-04-06 04:26:14 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:26:14 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:26:14 --> Utf8 Class Initialized
INFO - 2022-04-06 04:26:14 --> URI Class Initialized
INFO - 2022-04-06 04:26:14 --> Router Class Initialized
INFO - 2022-04-06 04:26:14 --> Output Class Initialized
INFO - 2022-04-06 04:26:14 --> Security Class Initialized
DEBUG - 2022-04-06 04:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:26:14 --> Input Class Initialized
INFO - 2022-04-06 04:26:14 --> Language Class Initialized
ERROR - 2022-04-06 04:26:14 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:26:47 --> Config Class Initialized
INFO - 2022-04-06 04:26:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:26:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:26:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:26:47 --> URI Class Initialized
INFO - 2022-04-06 04:26:47 --> Router Class Initialized
INFO - 2022-04-06 04:26:47 --> Output Class Initialized
INFO - 2022-04-06 04:26:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:26:47 --> Input Class Initialized
INFO - 2022-04-06 04:26:47 --> Language Class Initialized
INFO - 2022-04-06 04:26:47 --> Loader Class Initialized
INFO - 2022-04-06 04:26:47 --> Helper loaded: url_helper
INFO - 2022-04-06 04:26:47 --> Helper loaded: form_helper
INFO - 2022-04-06 04:26:47 --> Helper loaded: common_helper
INFO - 2022-04-06 04:26:47 --> Helper loaded: util_helper
INFO - 2022-04-06 04:26:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:26:47 --> Form Validation Class Initialized
INFO - 2022-04-06 04:26:47 --> Controller Class Initialized
INFO - 2022-04-06 04:26:47 --> Model Class Initialized
INFO - 2022-04-06 04:26:47 --> Model Class Initialized
INFO - 2022-04-06 04:26:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:26:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:26:47 --> Final output sent to browser
DEBUG - 2022-04-06 04:26:47 --> Total execution time: 0.0520
INFO - 2022-04-06 04:26:47 --> Config Class Initialized
INFO - 2022-04-06 04:26:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:26:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:26:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:26:47 --> URI Class Initialized
INFO - 2022-04-06 04:26:47 --> Router Class Initialized
INFO - 2022-04-06 04:26:47 --> Output Class Initialized
INFO - 2022-04-06 04:26:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:26:47 --> Input Class Initialized
INFO - 2022-04-06 04:26:47 --> Language Class Initialized
ERROR - 2022-04-06 04:26:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:27:04 --> Config Class Initialized
INFO - 2022-04-06 04:27:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:27:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:27:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:27:04 --> URI Class Initialized
INFO - 2022-04-06 04:27:04 --> Router Class Initialized
INFO - 2022-04-06 04:27:04 --> Output Class Initialized
INFO - 2022-04-06 04:27:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:27:04 --> Input Class Initialized
INFO - 2022-04-06 04:27:04 --> Language Class Initialized
INFO - 2022-04-06 04:27:04 --> Loader Class Initialized
INFO - 2022-04-06 04:27:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:27:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:27:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:27:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:27:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:27:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:27:04 --> Controller Class Initialized
INFO - 2022-04-06 04:27:04 --> Model Class Initialized
INFO - 2022-04-06 04:27:04 --> Model Class Initialized
INFO - 2022-04-06 04:27:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:27:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:27:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:27:04 --> Total execution time: 0.0571
INFO - 2022-04-06 04:27:04 --> Config Class Initialized
INFO - 2022-04-06 04:27:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:27:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:27:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:27:04 --> URI Class Initialized
INFO - 2022-04-06 04:27:04 --> Router Class Initialized
INFO - 2022-04-06 04:27:04 --> Output Class Initialized
INFO - 2022-04-06 04:27:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:27:04 --> Input Class Initialized
INFO - 2022-04-06 04:27:04 --> Language Class Initialized
ERROR - 2022-04-06 04:27:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:30:15 --> Config Class Initialized
INFO - 2022-04-06 04:30:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:15 --> URI Class Initialized
INFO - 2022-04-06 04:30:15 --> Router Class Initialized
INFO - 2022-04-06 04:30:15 --> Output Class Initialized
INFO - 2022-04-06 04:30:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:15 --> Input Class Initialized
INFO - 2022-04-06 04:30:15 --> Language Class Initialized
INFO - 2022-04-06 04:30:15 --> Loader Class Initialized
INFO - 2022-04-06 04:30:15 --> Helper loaded: url_helper
INFO - 2022-04-06 04:30:15 --> Helper loaded: form_helper
INFO - 2022-04-06 04:30:15 --> Helper loaded: common_helper
INFO - 2022-04-06 04:30:15 --> Helper loaded: util_helper
INFO - 2022-04-06 04:30:15 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:30:15 --> Form Validation Class Initialized
INFO - 2022-04-06 04:30:15 --> Controller Class Initialized
INFO - 2022-04-06 04:30:15 --> Model Class Initialized
INFO - 2022-04-06 04:30:15 --> Model Class Initialized
INFO - 2022-04-06 04:30:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:30:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:30:15 --> Final output sent to browser
DEBUG - 2022-04-06 04:30:15 --> Total execution time: 0.0748
INFO - 2022-04-06 04:30:15 --> Config Class Initialized
INFO - 2022-04-06 04:30:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:15 --> URI Class Initialized
INFO - 2022-04-06 04:30:15 --> Router Class Initialized
INFO - 2022-04-06 04:30:15 --> Output Class Initialized
INFO - 2022-04-06 04:30:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:15 --> Input Class Initialized
INFO - 2022-04-06 04:30:15 --> Language Class Initialized
ERROR - 2022-04-06 04:30:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:30:22 --> Config Class Initialized
INFO - 2022-04-06 04:30:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:22 --> URI Class Initialized
INFO - 2022-04-06 04:30:22 --> Router Class Initialized
INFO - 2022-04-06 04:30:22 --> Output Class Initialized
INFO - 2022-04-06 04:30:22 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:22 --> Input Class Initialized
INFO - 2022-04-06 04:30:22 --> Language Class Initialized
INFO - 2022-04-06 04:30:22 --> Loader Class Initialized
INFO - 2022-04-06 04:30:22 --> Helper loaded: url_helper
INFO - 2022-04-06 04:30:22 --> Helper loaded: form_helper
INFO - 2022-04-06 04:30:22 --> Helper loaded: common_helper
INFO - 2022-04-06 04:30:22 --> Helper loaded: util_helper
INFO - 2022-04-06 04:30:22 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:30:23 --> Form Validation Class Initialized
INFO - 2022-04-06 04:30:23 --> Controller Class Initialized
INFO - 2022-04-06 04:30:23 --> Model Class Initialized
INFO - 2022-04-06 04:30:23 --> Model Class Initialized
INFO - 2022-04-06 04:30:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:30:23 --> Final output sent to browser
DEBUG - 2022-04-06 04:30:23 --> Total execution time: 0.0796
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
INFO - 2022-04-06 04:30:23 --> Config Class Initialized
INFO - 2022-04-06 04:30:23 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:23 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
INFO - 2022-04-06 04:30:23 --> URI Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
INFO - 2022-04-06 04:30:23 --> Router Class Initialized
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:30:23 --> Output Class Initialized
INFO - 2022-04-06 04:30:23 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:23 --> Input Class Initialized
INFO - 2022-04-06 04:30:23 --> Language Class Initialized
ERROR - 2022-04-06 04:30:23 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
INFO - 2022-04-06 04:30:43 --> Loader Class Initialized
INFO - 2022-04-06 04:30:43 --> Helper loaded: url_helper
INFO - 2022-04-06 04:30:43 --> Helper loaded: form_helper
INFO - 2022-04-06 04:30:43 --> Helper loaded: common_helper
INFO - 2022-04-06 04:30:43 --> Helper loaded: util_helper
INFO - 2022-04-06 04:30:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:30:43 --> Form Validation Class Initialized
INFO - 2022-04-06 04:30:43 --> Controller Class Initialized
INFO - 2022-04-06 04:30:43 --> Model Class Initialized
INFO - 2022-04-06 04:30:43 --> Model Class Initialized
INFO - 2022-04-06 04:30:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:30:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:30:43 --> Final output sent to browser
DEBUG - 2022-04-06 04:30:43 --> Total execution time: 0.1486
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
INFO - 2022-04-06 04:30:43 --> Config Class Initialized
INFO - 2022-04-06 04:30:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
DEBUG - 2022-04-06 04:30:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> URI Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
INFO - 2022-04-06 04:30:43 --> Router Class Initialized
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Output Class Initialized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
INFO - 2022-04-06 04:30:43 --> Security Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:43 --> Input Class Initialized
INFO - 2022-04-06 04:30:43 --> Language Class Initialized
ERROR - 2022-04-06 04:30:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:30:44 --> Config Class Initialized
INFO - 2022-04-06 04:30:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:44 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:44 --> URI Class Initialized
INFO - 2022-04-06 04:30:44 --> Router Class Initialized
INFO - 2022-04-06 04:30:44 --> Output Class Initialized
INFO - 2022-04-06 04:30:44 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:44 --> Input Class Initialized
INFO - 2022-04-06 04:30:44 --> Language Class Initialized
INFO - 2022-04-06 04:30:44 --> Loader Class Initialized
INFO - 2022-04-06 04:30:44 --> Helper loaded: url_helper
INFO - 2022-04-06 04:30:44 --> Helper loaded: form_helper
INFO - 2022-04-06 04:30:44 --> Helper loaded: common_helper
INFO - 2022-04-06 04:30:44 --> Helper loaded: util_helper
INFO - 2022-04-06 04:30:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:30:44 --> Form Validation Class Initialized
INFO - 2022-04-06 04:30:44 --> Controller Class Initialized
INFO - 2022-04-06 04:30:44 --> Model Class Initialized
INFO - 2022-04-06 04:30:44 --> Model Class Initialized
INFO - 2022-04-06 04:30:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:30:44 --> Final output sent to browser
DEBUG - 2022-04-06 04:30:44 --> Total execution time: 0.0720
INFO - 2022-04-06 04:30:45 --> Config Class Initialized
INFO - 2022-04-06 04:30:45 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:45 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:45 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:45 --> URI Class Initialized
INFO - 2022-04-06 04:30:45 --> Router Class Initialized
INFO - 2022-04-06 04:30:45 --> Output Class Initialized
INFO - 2022-04-06 04:30:45 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:45 --> Input Class Initialized
INFO - 2022-04-06 04:30:45 --> Language Class Initialized
INFO - 2022-04-06 04:30:45 --> Loader Class Initialized
INFO - 2022-04-06 04:30:45 --> Helper loaded: url_helper
INFO - 2022-04-06 04:30:45 --> Helper loaded: form_helper
INFO - 2022-04-06 04:30:45 --> Helper loaded: common_helper
INFO - 2022-04-06 04:30:45 --> Helper loaded: util_helper
INFO - 2022-04-06 04:30:45 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:30:45 --> Form Validation Class Initialized
INFO - 2022-04-06 04:30:45 --> Controller Class Initialized
INFO - 2022-04-06 04:30:45 --> Model Class Initialized
INFO - 2022-04-06 04:30:45 --> Model Class Initialized
INFO - 2022-04-06 04:30:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:30:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:30:45 --> Final output sent to browser
DEBUG - 2022-04-06 04:30:45 --> Total execution time: 0.0595
INFO - 2022-04-06 04:30:47 --> Config Class Initialized
INFO - 2022-04-06 04:30:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:47 --> URI Class Initialized
INFO - 2022-04-06 04:30:47 --> Router Class Initialized
INFO - 2022-04-06 04:30:47 --> Output Class Initialized
INFO - 2022-04-06 04:30:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:47 --> Input Class Initialized
INFO - 2022-04-06 04:30:47 --> Language Class Initialized
INFO - 2022-04-06 04:30:47 --> Loader Class Initialized
INFO - 2022-04-06 04:30:47 --> Helper loaded: url_helper
INFO - 2022-04-06 04:30:47 --> Helper loaded: form_helper
INFO - 2022-04-06 04:30:47 --> Helper loaded: common_helper
INFO - 2022-04-06 04:30:47 --> Helper loaded: util_helper
INFO - 2022-04-06 04:30:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:30:47 --> Form Validation Class Initialized
INFO - 2022-04-06 04:30:47 --> Controller Class Initialized
INFO - 2022-04-06 04:30:47 --> Model Class Initialized
INFO - 2022-04-06 04:30:47 --> Model Class Initialized
INFO - 2022-04-06 04:30:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-06 04:30:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:30:47 --> Final output sent to browser
DEBUG - 2022-04-06 04:30:47 --> Total execution time: 0.0698
INFO - 2022-04-06 04:30:47 --> Config Class Initialized
INFO - 2022-04-06 04:30:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:30:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:30:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:30:47 --> URI Class Initialized
INFO - 2022-04-06 04:30:47 --> Router Class Initialized
INFO - 2022-04-06 04:30:47 --> Output Class Initialized
INFO - 2022-04-06 04:30:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:30:47 --> Input Class Initialized
INFO - 2022-04-06 04:30:47 --> Language Class Initialized
ERROR - 2022-04-06 04:30:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:31:17 --> Config Class Initialized
INFO - 2022-04-06 04:31:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:17 --> URI Class Initialized
INFO - 2022-04-06 04:31:17 --> Router Class Initialized
INFO - 2022-04-06 04:31:17 --> Output Class Initialized
INFO - 2022-04-06 04:31:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:17 --> Input Class Initialized
INFO - 2022-04-06 04:31:17 --> Language Class Initialized
INFO - 2022-04-06 04:31:17 --> Loader Class Initialized
INFO - 2022-04-06 04:31:17 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:17 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:17 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:17 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:17 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:17 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:17 --> Controller Class Initialized
INFO - 2022-04-06 04:31:17 --> Model Class Initialized
INFO - 2022-04-06 04:31:17 --> Model Class Initialized
INFO - 2022-04-06 04:31:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:31:17 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:17 --> Total execution time: 0.0543
INFO - 2022-04-06 04:31:21 --> Config Class Initialized
INFO - 2022-04-06 04:31:21 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:21 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:21 --> URI Class Initialized
INFO - 2022-04-06 04:31:21 --> Router Class Initialized
INFO - 2022-04-06 04:31:21 --> Output Class Initialized
INFO - 2022-04-06 04:31:21 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:21 --> Input Class Initialized
INFO - 2022-04-06 04:31:21 --> Language Class Initialized
INFO - 2022-04-06 04:31:21 --> Loader Class Initialized
INFO - 2022-04-06 04:31:21 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:21 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:21 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:21 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:21 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:21 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:21 --> Controller Class Initialized
INFO - 2022-04-06 04:31:21 --> Model Class Initialized
INFO - 2022-04-06 04:31:21 --> Model Class Initialized
INFO - 2022-04-06 04:31:21 --> Config Class Initialized
INFO - 2022-04-06 04:31:21 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:21 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:21 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:21 --> URI Class Initialized
INFO - 2022-04-06 04:31:21 --> Router Class Initialized
INFO - 2022-04-06 04:31:21 --> Output Class Initialized
INFO - 2022-04-06 04:31:21 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:21 --> Input Class Initialized
INFO - 2022-04-06 04:31:21 --> Language Class Initialized
INFO - 2022-04-06 04:31:21 --> Loader Class Initialized
INFO - 2022-04-06 04:31:21 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:21 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:21 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:21 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:21 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:21 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:21 --> Controller Class Initialized
INFO - 2022-04-06 04:31:21 --> Model Class Initialized
INFO - 2022-04-06 04:31:21 --> Model Class Initialized
INFO - 2022-04-06 04:31:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:31:21 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:21 --> Total execution time: 0.0560
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
INFO - 2022-04-06 04:31:25 --> Loader Class Initialized
INFO - 2022-04-06 04:31:25 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:25 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:25 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:25 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:25 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:25 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:25 --> Controller Class Initialized
INFO - 2022-04-06 04:31:25 --> Model Class Initialized
INFO - 2022-04-06 04:31:25 --> Model Class Initialized
INFO - 2022-04-06 04:31:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:31:25 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:25 --> Total execution time: 0.0558
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
INFO - 2022-04-06 04:31:25 --> Config Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:31:25 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
DEBUG - 2022-04-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:25 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:25 --> URI Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:25 --> Router Class Initialized
INFO - 2022-04-06 04:31:25 --> Output Class Initialized
INFO - 2022-04-06 04:31:25 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:25 --> Input Class Initialized
INFO - 2022-04-06 04:31:25 --> Language Class Initialized
ERROR - 2022-04-06 04:31:25 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
INFO - 2022-04-06 04:31:43 --> Loader Class Initialized
INFO - 2022-04-06 04:31:43 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:43 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:43 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:43 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:43 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:43 --> Controller Class Initialized
INFO - 2022-04-06 04:31:43 --> Model Class Initialized
INFO - 2022-04-06 04:31:43 --> Model Class Initialized
INFO - 2022-04-06 04:31:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:31:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:31:43 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:43 --> Total execution time: 0.1444
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
INFO - 2022-04-06 04:31:43 --> Config Class Initialized
INFO - 2022-04-06 04:31:43 --> Hooks Class Initialized
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
DEBUG - 2022-04-06 04:31:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
INFO - 2022-04-06 04:31:43 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> URI Class Initialized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
INFO - 2022-04-06 04:31:43 --> Router Class Initialized
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:31:43 --> Output Class Initialized
INFO - 2022-04-06 04:31:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:43 --> Input Class Initialized
INFO - 2022-04-06 04:31:43 --> Language Class Initialized
ERROR - 2022-04-06 04:31:43 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:31:47 --> Config Class Initialized
INFO - 2022-04-06 04:31:47 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:47 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:47 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:47 --> URI Class Initialized
INFO - 2022-04-06 04:31:47 --> Router Class Initialized
INFO - 2022-04-06 04:31:47 --> Output Class Initialized
INFO - 2022-04-06 04:31:47 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:47 --> Input Class Initialized
INFO - 2022-04-06 04:31:47 --> Language Class Initialized
INFO - 2022-04-06 04:31:47 --> Loader Class Initialized
INFO - 2022-04-06 04:31:47 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:47 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:47 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:47 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:47 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:47 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:47 --> Controller Class Initialized
INFO - 2022-04-06 04:31:47 --> Model Class Initialized
INFO - 2022-04-06 04:31:47 --> Model Class Initialized
INFO - 2022-04-06 04:31:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:31:47 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:47 --> Total execution time: 0.0655
INFO - 2022-04-06 04:31:48 --> Config Class Initialized
INFO - 2022-04-06 04:31:48 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:48 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:48 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:48 --> URI Class Initialized
INFO - 2022-04-06 04:31:48 --> Router Class Initialized
INFO - 2022-04-06 04:31:48 --> Output Class Initialized
INFO - 2022-04-06 04:31:48 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:48 --> Input Class Initialized
INFO - 2022-04-06 04:31:48 --> Language Class Initialized
INFO - 2022-04-06 04:31:48 --> Loader Class Initialized
INFO - 2022-04-06 04:31:48 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:48 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:48 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:48 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:48 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:48 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:48 --> Controller Class Initialized
INFO - 2022-04-06 04:31:48 --> Model Class Initialized
INFO - 2022-04-06 04:31:48 --> Model Class Initialized
INFO - 2022-04-06 04:31:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:31:48 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:48 --> Total execution time: 0.0838
INFO - 2022-04-06 04:31:49 --> Config Class Initialized
INFO - 2022-04-06 04:31:49 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:49 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:49 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:49 --> URI Class Initialized
INFO - 2022-04-06 04:31:49 --> Router Class Initialized
INFO - 2022-04-06 04:31:49 --> Output Class Initialized
INFO - 2022-04-06 04:31:49 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:49 --> Input Class Initialized
INFO - 2022-04-06 04:31:49 --> Language Class Initialized
INFO - 2022-04-06 04:31:49 --> Loader Class Initialized
INFO - 2022-04-06 04:31:49 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:49 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:49 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:49 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:49 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:49 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:49 --> Controller Class Initialized
INFO - 2022-04-06 04:31:49 --> Model Class Initialized
INFO - 2022-04-06 04:31:49 --> Model Class Initialized
INFO - 2022-04-06 04:31:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:31:49 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:49 --> Total execution time: 0.0632
INFO - 2022-04-06 04:31:50 --> Config Class Initialized
INFO - 2022-04-06 04:31:50 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:31:50 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:31:50 --> Utf8 Class Initialized
INFO - 2022-04-06 04:31:50 --> URI Class Initialized
INFO - 2022-04-06 04:31:50 --> Router Class Initialized
INFO - 2022-04-06 04:31:50 --> Output Class Initialized
INFO - 2022-04-06 04:31:50 --> Security Class Initialized
DEBUG - 2022-04-06 04:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:31:50 --> Input Class Initialized
INFO - 2022-04-06 04:31:50 --> Language Class Initialized
INFO - 2022-04-06 04:31:50 --> Loader Class Initialized
INFO - 2022-04-06 04:31:50 --> Helper loaded: url_helper
INFO - 2022-04-06 04:31:50 --> Helper loaded: form_helper
INFO - 2022-04-06 04:31:50 --> Helper loaded: common_helper
INFO - 2022-04-06 04:31:50 --> Helper loaded: util_helper
INFO - 2022-04-06 04:31:50 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:31:50 --> Form Validation Class Initialized
INFO - 2022-04-06 04:31:50 --> Controller Class Initialized
INFO - 2022-04-06 04:31:50 --> Model Class Initialized
INFO - 2022-04-06 04:31:50 --> Model Class Initialized
INFO - 2022-04-06 04:31:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:31:50 --> Final output sent to browser
DEBUG - 2022-04-06 04:31:50 --> Total execution time: 0.0732
INFO - 2022-04-06 04:32:59 --> Config Class Initialized
INFO - 2022-04-06 04:32:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:32:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:32:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:32:59 --> URI Class Initialized
INFO - 2022-04-06 04:32:59 --> Router Class Initialized
INFO - 2022-04-06 04:32:59 --> Output Class Initialized
INFO - 2022-04-06 04:32:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:32:59 --> Input Class Initialized
INFO - 2022-04-06 04:32:59 --> Language Class Initialized
INFO - 2022-04-06 04:32:59 --> Loader Class Initialized
INFO - 2022-04-06 04:32:59 --> Helper loaded: url_helper
INFO - 2022-04-06 04:32:59 --> Helper loaded: form_helper
INFO - 2022-04-06 04:32:59 --> Helper loaded: common_helper
INFO - 2022-04-06 04:32:59 --> Helper loaded: util_helper
INFO - 2022-04-06 04:32:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:32:59 --> Form Validation Class Initialized
INFO - 2022-04-06 04:32:59 --> Controller Class Initialized
INFO - 2022-04-06 04:32:59 --> Model Class Initialized
INFO - 2022-04-06 04:32:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:32:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:32:59 --> Final output sent to browser
DEBUG - 2022-04-06 04:32:59 --> Total execution time: 0.0681
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Config Class Initialized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:33:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> URI Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Router Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Output Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:33:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:00 --> Input Class Initialized
INFO - 2022-04-06 04:33:00 --> Language Class Initialized
ERROR - 2022-04-06 04:33:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:33:03 --> Config Class Initialized
INFO - 2022-04-06 04:33:03 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:03 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:03 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:03 --> URI Class Initialized
INFO - 2022-04-06 04:33:03 --> Router Class Initialized
INFO - 2022-04-06 04:33:03 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Loader Class Initialized
INFO - 2022-04-06 04:33:04 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:04 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:04 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:04 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:04 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:04 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:04 --> Controller Class Initialized
INFO - 2022-04-06 04:33:04 --> Model Class Initialized
INFO - 2022-04-06 04:33:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:33:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:33:04 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:04 --> Total execution time: 0.0656
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:33:04 --> Config Class Initialized
INFO - 2022-04-06 04:33:04 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:04 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:04 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:04 --> URI Class Initialized
INFO - 2022-04-06 04:33:04 --> Router Class Initialized
INFO - 2022-04-06 04:33:04 --> Output Class Initialized
INFO - 2022-04-06 04:33:04 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:04 --> Input Class Initialized
INFO - 2022-04-06 04:33:04 --> Language Class Initialized
ERROR - 2022-04-06 04:33:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:33:06 --> Config Class Initialized
INFO - 2022-04-06 04:33:06 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:06 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:06 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:06 --> URI Class Initialized
INFO - 2022-04-06 04:33:06 --> Router Class Initialized
INFO - 2022-04-06 04:33:06 --> Output Class Initialized
INFO - 2022-04-06 04:33:06 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:06 --> Input Class Initialized
INFO - 2022-04-06 04:33:06 --> Language Class Initialized
INFO - 2022-04-06 04:33:06 --> Loader Class Initialized
INFO - 2022-04-06 04:33:06 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:06 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:06 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:06 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:06 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:06 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:06 --> Controller Class Initialized
INFO - 2022-04-06 04:33:06 --> Model Class Initialized
INFO - 2022-04-06 04:33:06 --> Model Class Initialized
INFO - 2022-04-06 04:33:06 --> Config Class Initialized
INFO - 2022-04-06 04:33:06 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:06 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:06 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:06 --> URI Class Initialized
INFO - 2022-04-06 04:33:06 --> Router Class Initialized
INFO - 2022-04-06 04:33:06 --> Output Class Initialized
INFO - 2022-04-06 04:33:06 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:06 --> Input Class Initialized
INFO - 2022-04-06 04:33:06 --> Language Class Initialized
INFO - 2022-04-06 04:33:06 --> Loader Class Initialized
INFO - 2022-04-06 04:33:07 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:07 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:07 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:07 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:07 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:07 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:07 --> Controller Class Initialized
INFO - 2022-04-06 04:33:07 --> Model Class Initialized
INFO - 2022-04-06 04:33:07 --> Model Class Initialized
INFO - 2022-04-06 04:33:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:07 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:07 --> Total execution time: 0.0613
INFO - 2022-04-06 04:33:11 --> Config Class Initialized
INFO - 2022-04-06 04:33:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:11 --> URI Class Initialized
INFO - 2022-04-06 04:33:11 --> Router Class Initialized
INFO - 2022-04-06 04:33:11 --> Output Class Initialized
INFO - 2022-04-06 04:33:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:11 --> Input Class Initialized
INFO - 2022-04-06 04:33:11 --> Language Class Initialized
INFO - 2022-04-06 04:33:11 --> Loader Class Initialized
INFO - 2022-04-06 04:33:11 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:11 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:11 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:11 --> Controller Class Initialized
INFO - 2022-04-06 04:33:11 --> Model Class Initialized
INFO - 2022-04-06 04:33:11 --> Config Class Initialized
INFO - 2022-04-06 04:33:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:11 --> URI Class Initialized
INFO - 2022-04-06 04:33:11 --> Router Class Initialized
INFO - 2022-04-06 04:33:11 --> Output Class Initialized
INFO - 2022-04-06 04:33:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:11 --> Input Class Initialized
INFO - 2022-04-06 04:33:11 --> Language Class Initialized
INFO - 2022-04-06 04:33:11 --> Loader Class Initialized
INFO - 2022-04-06 04:33:11 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:11 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:11 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:11 --> Controller Class Initialized
INFO - 2022-04-06 04:33:11 --> Model Class Initialized
INFO - 2022-04-06 04:33:11 --> Model Class Initialized
INFO - 2022-04-06 04:33:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:11 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:11 --> Total execution time: 0.0589
INFO - 2022-04-06 04:33:11 --> Config Class Initialized
INFO - 2022-04-06 04:33:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:11 --> URI Class Initialized
INFO - 2022-04-06 04:33:11 --> Router Class Initialized
INFO - 2022-04-06 04:33:11 --> Output Class Initialized
INFO - 2022-04-06 04:33:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:11 --> Input Class Initialized
INFO - 2022-04-06 04:33:11 --> Language Class Initialized
INFO - 2022-04-06 04:33:11 --> Loader Class Initialized
INFO - 2022-04-06 04:33:11 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:11 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:11 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:11 --> Controller Class Initialized
INFO - 2022-04-06 04:33:11 --> Model Class Initialized
INFO - 2022-04-06 04:33:11 --> Config Class Initialized
INFO - 2022-04-06 04:33:11 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:11 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:11 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:11 --> URI Class Initialized
INFO - 2022-04-06 04:33:11 --> Router Class Initialized
INFO - 2022-04-06 04:33:11 --> Output Class Initialized
INFO - 2022-04-06 04:33:11 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:11 --> Input Class Initialized
INFO - 2022-04-06 04:33:11 --> Language Class Initialized
INFO - 2022-04-06 04:33:11 --> Loader Class Initialized
INFO - 2022-04-06 04:33:11 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:11 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:11 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:11 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:11 --> Controller Class Initialized
INFO - 2022-04-06 04:33:11 --> Model Class Initialized
INFO - 2022-04-06 04:33:11 --> Model Class Initialized
INFO - 2022-04-06 04:33:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:11 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:11 --> Total execution time: 0.0556
INFO - 2022-04-06 04:33:12 --> Config Class Initialized
INFO - 2022-04-06 04:33:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:12 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:12 --> URI Class Initialized
INFO - 2022-04-06 04:33:12 --> Router Class Initialized
INFO - 2022-04-06 04:33:12 --> Output Class Initialized
INFO - 2022-04-06 04:33:12 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:12 --> Input Class Initialized
INFO - 2022-04-06 04:33:12 --> Language Class Initialized
INFO - 2022-04-06 04:33:12 --> Loader Class Initialized
INFO - 2022-04-06 04:33:12 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:12 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:12 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:12 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:12 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:12 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:12 --> Controller Class Initialized
INFO - 2022-04-06 04:33:12 --> Model Class Initialized
INFO - 2022-04-06 04:33:12 --> Model Class Initialized
INFO - 2022-04-06 04:33:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:12 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:12 --> Total execution time: 0.0812
INFO - 2022-04-06 04:33:12 --> Config Class Initialized
INFO - 2022-04-06 04:33:12 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:12 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:12 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:12 --> URI Class Initialized
INFO - 2022-04-06 04:33:12 --> Router Class Initialized
INFO - 2022-04-06 04:33:12 --> Output Class Initialized
INFO - 2022-04-06 04:33:12 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:12 --> Input Class Initialized
INFO - 2022-04-06 04:33:12 --> Language Class Initialized
INFO - 2022-04-06 04:33:12 --> Loader Class Initialized
INFO - 2022-04-06 04:33:12 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:12 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:12 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:12 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:12 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:12 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:12 --> Controller Class Initialized
INFO - 2022-04-06 04:33:12 --> Model Class Initialized
INFO - 2022-04-06 04:33:12 --> Model Class Initialized
INFO - 2022-04-06 04:33:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:12 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:12 --> Total execution time: 0.0716
INFO - 2022-04-06 04:33:13 --> Config Class Initialized
INFO - 2022-04-06 04:33:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:13 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:13 --> URI Class Initialized
INFO - 2022-04-06 04:33:13 --> Router Class Initialized
INFO - 2022-04-06 04:33:13 --> Output Class Initialized
INFO - 2022-04-06 04:33:13 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:13 --> Input Class Initialized
INFO - 2022-04-06 04:33:13 --> Language Class Initialized
INFO - 2022-04-06 04:33:13 --> Loader Class Initialized
INFO - 2022-04-06 04:33:13 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:13 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:13 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:13 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:13 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:13 --> Controller Class Initialized
INFO - 2022-04-06 04:33:13 --> Model Class Initialized
INFO - 2022-04-06 04:33:13 --> Model Class Initialized
INFO - 2022-04-06 04:33:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:13 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:13 --> Total execution time: 0.0644
INFO - 2022-04-06 04:33:13 --> Config Class Initialized
INFO - 2022-04-06 04:33:13 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:13 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:13 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:13 --> URI Class Initialized
INFO - 2022-04-06 04:33:13 --> Router Class Initialized
INFO - 2022-04-06 04:33:13 --> Output Class Initialized
INFO - 2022-04-06 04:33:13 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:13 --> Input Class Initialized
INFO - 2022-04-06 04:33:13 --> Language Class Initialized
INFO - 2022-04-06 04:33:13 --> Loader Class Initialized
INFO - 2022-04-06 04:33:13 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:13 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:13 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:13 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:13 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:13 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:13 --> Controller Class Initialized
INFO - 2022-04-06 04:33:13 --> Model Class Initialized
INFO - 2022-04-06 04:33:13 --> Model Class Initialized
INFO - 2022-04-06 04:33:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:13 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:13 --> Total execution time: 0.0867
INFO - 2022-04-06 04:33:14 --> Config Class Initialized
INFO - 2022-04-06 04:33:14 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:14 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:14 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:14 --> URI Class Initialized
INFO - 2022-04-06 04:33:14 --> Router Class Initialized
INFO - 2022-04-06 04:33:14 --> Output Class Initialized
INFO - 2022-04-06 04:33:14 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:14 --> Input Class Initialized
INFO - 2022-04-06 04:33:14 --> Language Class Initialized
INFO - 2022-04-06 04:33:14 --> Loader Class Initialized
INFO - 2022-04-06 04:33:14 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:14 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:14 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:14 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:14 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:14 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:14 --> Controller Class Initialized
INFO - 2022-04-06 04:33:14 --> Model Class Initialized
INFO - 2022-04-06 04:33:14 --> Model Class Initialized
INFO - 2022-04-06 04:33:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:14 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:14 --> Total execution time: 0.0610
INFO - 2022-04-06 04:33:14 --> Config Class Initialized
INFO - 2022-04-06 04:33:14 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:14 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:14 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:14 --> URI Class Initialized
INFO - 2022-04-06 04:33:14 --> Router Class Initialized
INFO - 2022-04-06 04:33:14 --> Output Class Initialized
INFO - 2022-04-06 04:33:14 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:14 --> Input Class Initialized
INFO - 2022-04-06 04:33:14 --> Language Class Initialized
INFO - 2022-04-06 04:33:14 --> Loader Class Initialized
INFO - 2022-04-06 04:33:14 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:14 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:14 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:14 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:14 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:14 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:14 --> Controller Class Initialized
INFO - 2022-04-06 04:33:14 --> Model Class Initialized
INFO - 2022-04-06 04:33:14 --> Model Class Initialized
INFO - 2022-04-06 04:33:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:14 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:14 --> Total execution time: 0.0607
INFO - 2022-04-06 04:33:16 --> Config Class Initialized
INFO - 2022-04-06 04:33:16 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:16 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:16 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:16 --> URI Class Initialized
INFO - 2022-04-06 04:33:16 --> Router Class Initialized
INFO - 2022-04-06 04:33:16 --> Output Class Initialized
INFO - 2022-04-06 04:33:16 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:16 --> Input Class Initialized
INFO - 2022-04-06 04:33:16 --> Language Class Initialized
INFO - 2022-04-06 04:33:16 --> Loader Class Initialized
INFO - 2022-04-06 04:33:16 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:16 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:16 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:16 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:16 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:16 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:16 --> Controller Class Initialized
INFO - 2022-04-06 04:33:16 --> Model Class Initialized
INFO - 2022-04-06 04:33:16 --> Model Class Initialized
INFO - 2022-04-06 04:33:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:16 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:16 --> Total execution time: 0.0818
INFO - 2022-04-06 04:33:17 --> Config Class Initialized
INFO - 2022-04-06 04:33:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:33:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:33:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:33:17 --> URI Class Initialized
INFO - 2022-04-06 04:33:17 --> Router Class Initialized
INFO - 2022-04-06 04:33:17 --> Output Class Initialized
INFO - 2022-04-06 04:33:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:33:17 --> Input Class Initialized
INFO - 2022-04-06 04:33:17 --> Language Class Initialized
INFO - 2022-04-06 04:33:17 --> Loader Class Initialized
INFO - 2022-04-06 04:33:17 --> Helper loaded: url_helper
INFO - 2022-04-06 04:33:17 --> Helper loaded: form_helper
INFO - 2022-04-06 04:33:17 --> Helper loaded: common_helper
INFO - 2022-04-06 04:33:17 --> Helper loaded: util_helper
INFO - 2022-04-06 04:33:17 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:33:17 --> Form Validation Class Initialized
INFO - 2022-04-06 04:33:17 --> Controller Class Initialized
INFO - 2022-04-06 04:33:17 --> Model Class Initialized
INFO - 2022-04-06 04:33:17 --> Model Class Initialized
INFO - 2022-04-06 04:33:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:33:17 --> Final output sent to browser
DEBUG - 2022-04-06 04:33:17 --> Total execution time: 0.0617
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
INFO - 2022-04-06 04:35:36 --> Loader Class Initialized
INFO - 2022-04-06 04:35:36 --> Helper loaded: url_helper
INFO - 2022-04-06 04:35:36 --> Helper loaded: form_helper
INFO - 2022-04-06 04:35:36 --> Helper loaded: common_helper
INFO - 2022-04-06 04:35:36 --> Helper loaded: util_helper
INFO - 2022-04-06 04:35:36 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:35:36 --> Form Validation Class Initialized
INFO - 2022-04-06 04:35:36 --> Controller Class Initialized
INFO - 2022-04-06 04:35:36 --> Model Class Initialized
INFO - 2022-04-06 04:35:36 --> Model Class Initialized
INFO - 2022-04-06 04:35:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:35:36 --> Final output sent to browser
DEBUG - 2022-04-06 04:35:36 --> Total execution time: 0.0569
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:36 --> Config Class Initialized
INFO - 2022-04-06 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
DEBUG - 2022-04-06 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
INFO - 2022-04-06 04:35:36 --> URI Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Router Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
INFO - 2022-04-06 04:35:36 --> Output Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Security Class Initialized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
DEBUG - 2022-04-06 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:36 --> Input Class Initialized
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:35:36 --> Language Class Initialized
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:35:36 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
INFO - 2022-04-06 04:35:54 --> Loader Class Initialized
INFO - 2022-04-06 04:35:54 --> Helper loaded: url_helper
INFO - 2022-04-06 04:35:54 --> Helper loaded: form_helper
INFO - 2022-04-06 04:35:54 --> Helper loaded: common_helper
INFO - 2022-04-06 04:35:54 --> Helper loaded: util_helper
INFO - 2022-04-06 04:35:54 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:35:54 --> Form Validation Class Initialized
INFO - 2022-04-06 04:35:54 --> Controller Class Initialized
INFO - 2022-04-06 04:35:54 --> Model Class Initialized
INFO - 2022-04-06 04:35:54 --> Model Class Initialized
INFO - 2022-04-06 04:35:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:35:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:35:54 --> Final output sent to browser
DEBUG - 2022-04-06 04:35:54 --> Total execution time: 0.1461
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
INFO - 2022-04-06 04:35:54 --> Config Class Initialized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
INFO - 2022-04-06 04:35:54 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
DEBUG - 2022-04-06 04:35:54 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
INFO - 2022-04-06 04:35:54 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:54 --> URI Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
INFO - 2022-04-06 04:35:54 --> Router Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
INFO - 2022-04-06 04:35:54 --> Output Class Initialized
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:35:54 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:54 --> Input Class Initialized
INFO - 2022-04-06 04:35:54 --> Language Class Initialized
ERROR - 2022-04-06 04:35:54 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:35:56 --> Config Class Initialized
INFO - 2022-04-06 04:35:56 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:56 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:56 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:56 --> URI Class Initialized
INFO - 2022-04-06 04:35:56 --> Router Class Initialized
INFO - 2022-04-06 04:35:56 --> Output Class Initialized
INFO - 2022-04-06 04:35:56 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:56 --> Input Class Initialized
INFO - 2022-04-06 04:35:56 --> Language Class Initialized
INFO - 2022-04-06 04:35:56 --> Loader Class Initialized
INFO - 2022-04-06 04:35:56 --> Helper loaded: url_helper
INFO - 2022-04-06 04:35:56 --> Helper loaded: form_helper
INFO - 2022-04-06 04:35:56 --> Helper loaded: common_helper
INFO - 2022-04-06 04:35:56 --> Helper loaded: util_helper
INFO - 2022-04-06 04:35:56 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:35:56 --> Form Validation Class Initialized
INFO - 2022-04-06 04:35:56 --> Controller Class Initialized
INFO - 2022-04-06 04:35:56 --> Model Class Initialized
INFO - 2022-04-06 04:35:56 --> Model Class Initialized
INFO - 2022-04-06 04:35:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:35:56 --> Final output sent to browser
DEBUG - 2022-04-06 04:35:56 --> Total execution time: 0.0709
INFO - 2022-04-06 04:35:57 --> Config Class Initialized
INFO - 2022-04-06 04:35:57 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:57 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:57 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:57 --> URI Class Initialized
INFO - 2022-04-06 04:35:57 --> Router Class Initialized
INFO - 2022-04-06 04:35:57 --> Output Class Initialized
INFO - 2022-04-06 04:35:57 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:57 --> Input Class Initialized
INFO - 2022-04-06 04:35:57 --> Language Class Initialized
INFO - 2022-04-06 04:35:57 --> Loader Class Initialized
INFO - 2022-04-06 04:35:57 --> Helper loaded: url_helper
INFO - 2022-04-06 04:35:57 --> Helper loaded: form_helper
INFO - 2022-04-06 04:35:57 --> Helper loaded: common_helper
INFO - 2022-04-06 04:35:57 --> Helper loaded: util_helper
INFO - 2022-04-06 04:35:57 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:35:57 --> Form Validation Class Initialized
INFO - 2022-04-06 04:35:57 --> Controller Class Initialized
INFO - 2022-04-06 04:35:57 --> Model Class Initialized
INFO - 2022-04-06 04:35:57 --> Model Class Initialized
INFO - 2022-04-06 04:35:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:35:57 --> Final output sent to browser
DEBUG - 2022-04-06 04:35:57 --> Total execution time: 0.0608
INFO - 2022-04-06 04:35:58 --> Config Class Initialized
INFO - 2022-04-06 04:35:58 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:35:58 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:35:58 --> Utf8 Class Initialized
INFO - 2022-04-06 04:35:58 --> URI Class Initialized
INFO - 2022-04-06 04:35:58 --> Router Class Initialized
INFO - 2022-04-06 04:35:58 --> Output Class Initialized
INFO - 2022-04-06 04:35:58 --> Security Class Initialized
DEBUG - 2022-04-06 04:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:35:58 --> Input Class Initialized
INFO - 2022-04-06 04:35:58 --> Language Class Initialized
INFO - 2022-04-06 04:35:58 --> Loader Class Initialized
INFO - 2022-04-06 04:35:58 --> Helper loaded: url_helper
INFO - 2022-04-06 04:35:58 --> Helper loaded: form_helper
INFO - 2022-04-06 04:35:58 --> Helper loaded: common_helper
INFO - 2022-04-06 04:35:58 --> Helper loaded: util_helper
INFO - 2022-04-06 04:35:58 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:35:58 --> Form Validation Class Initialized
INFO - 2022-04-06 04:35:58 --> Controller Class Initialized
INFO - 2022-04-06 04:35:58 --> Model Class Initialized
INFO - 2022-04-06 04:35:58 --> Model Class Initialized
INFO - 2022-04-06 04:35:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:35:58 --> Final output sent to browser
DEBUG - 2022-04-06 04:35:58 --> Total execution time: 0.0727
INFO - 2022-04-06 04:36:00 --> Config Class Initialized
INFO - 2022-04-06 04:36:00 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:36:00 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:00 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:00 --> URI Class Initialized
INFO - 2022-04-06 04:36:00 --> Router Class Initialized
INFO - 2022-04-06 04:36:00 --> Output Class Initialized
INFO - 2022-04-06 04:36:00 --> Security Class Initialized
DEBUG - 2022-04-06 04:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:00 --> Input Class Initialized
INFO - 2022-04-06 04:36:00 --> Language Class Initialized
INFO - 2022-04-06 04:36:00 --> Loader Class Initialized
INFO - 2022-04-06 04:36:00 --> Helper loaded: url_helper
INFO - 2022-04-06 04:36:00 --> Helper loaded: form_helper
INFO - 2022-04-06 04:36:00 --> Helper loaded: common_helper
INFO - 2022-04-06 04:36:00 --> Helper loaded: util_helper
INFO - 2022-04-06 04:36:00 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:36:00 --> Form Validation Class Initialized
INFO - 2022-04-06 04:36:00 --> Controller Class Initialized
INFO - 2022-04-06 04:36:00 --> Model Class Initialized
INFO - 2022-04-06 04:36:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:36:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:36:00 --> Final output sent to browser
DEBUG - 2022-04-06 04:36:00 --> Total execution time: 0.0727
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:36:01 --> Config Class Initialized
INFO - 2022-04-06 04:36:01 --> Hooks Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:36:01 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:36:01 --> Utf8 Class Initialized
INFO - 2022-04-06 04:36:01 --> URI Class Initialized
INFO - 2022-04-06 04:36:01 --> Router Class Initialized
INFO - 2022-04-06 04:36:01 --> Output Class Initialized
INFO - 2022-04-06 04:36:01 --> Security Class Initialized
DEBUG - 2022-04-06 04:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:36:01 --> Input Class Initialized
INFO - 2022-04-06 04:36:01 --> Language Class Initialized
ERROR - 2022-04-06 04:36:01 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
INFO - 2022-04-06 04:37:59 --> Loader Class Initialized
INFO - 2022-04-06 04:37:59 --> Helper loaded: url_helper
INFO - 2022-04-06 04:37:59 --> Helper loaded: form_helper
INFO - 2022-04-06 04:37:59 --> Helper loaded: common_helper
INFO - 2022-04-06 04:37:59 --> Helper loaded: util_helper
INFO - 2022-04-06 04:37:59 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:37:59 --> Form Validation Class Initialized
INFO - 2022-04-06 04:37:59 --> Controller Class Initialized
INFO - 2022-04-06 04:37:59 --> Model Class Initialized
INFO - 2022-04-06 04:37:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:37:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:37:59 --> Final output sent to browser
DEBUG - 2022-04-06 04:37:59 --> Total execution time: 0.0745
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Config Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
INFO - 2022-04-06 04:37:59 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
DEBUG - 2022-04-06 04:37:59 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:37:59 --> Utf8 Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:37:59 --> URI Class Initialized
INFO - 2022-04-06 04:37:59 --> Router Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:37:59 --> Output Class Initialized
INFO - 2022-04-06 04:37:59 --> Security Class Initialized
DEBUG - 2022-04-06 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:37:59 --> Input Class Initialized
INFO - 2022-04-06 04:37:59 --> Language Class Initialized
ERROR - 2022-04-06 04:37:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:38:08 --> Config Class Initialized
INFO - 2022-04-06 04:38:08 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:08 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:08 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:08 --> URI Class Initialized
INFO - 2022-04-06 04:38:08 --> Router Class Initialized
INFO - 2022-04-06 04:38:08 --> Output Class Initialized
INFO - 2022-04-06 04:38:08 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:08 --> Input Class Initialized
INFO - 2022-04-06 04:38:08 --> Language Class Initialized
INFO - 2022-04-06 04:38:08 --> Loader Class Initialized
INFO - 2022-04-06 04:38:08 --> Helper loaded: url_helper
INFO - 2022-04-06 04:38:08 --> Helper loaded: form_helper
INFO - 2022-04-06 04:38:08 --> Helper loaded: common_helper
INFO - 2022-04-06 04:38:08 --> Helper loaded: util_helper
INFO - 2022-04-06 04:38:08 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:38:08 --> Form Validation Class Initialized
INFO - 2022-04-06 04:38:08 --> Controller Class Initialized
INFO - 2022-04-06 04:38:08 --> Model Class Initialized
INFO - 2022-04-06 04:38:08 --> Model Class Initialized
INFO - 2022-04-06 04:38:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:38:08 --> Final output sent to browser
DEBUG - 2022-04-06 04:38:08 --> Total execution time: 0.0677
INFO - 2022-04-06 04:38:09 --> Config Class Initialized
INFO - 2022-04-06 04:38:09 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:09 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:09 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:09 --> URI Class Initialized
INFO - 2022-04-06 04:38:09 --> Router Class Initialized
INFO - 2022-04-06 04:38:09 --> Output Class Initialized
INFO - 2022-04-06 04:38:09 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:09 --> Input Class Initialized
INFO - 2022-04-06 04:38:09 --> Language Class Initialized
INFO - 2022-04-06 04:38:09 --> Loader Class Initialized
INFO - 2022-04-06 04:38:09 --> Helper loaded: url_helper
INFO - 2022-04-06 04:38:09 --> Helper loaded: form_helper
INFO - 2022-04-06 04:38:09 --> Helper loaded: common_helper
INFO - 2022-04-06 04:38:09 --> Helper loaded: util_helper
INFO - 2022-04-06 04:38:09 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:38:09 --> Form Validation Class Initialized
INFO - 2022-04-06 04:38:09 --> Controller Class Initialized
INFO - 2022-04-06 04:38:09 --> Model Class Initialized
INFO - 2022-04-06 04:38:09 --> Model Class Initialized
INFO - 2022-04-06 04:38:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:38:09 --> Final output sent to browser
DEBUG - 2022-04-06 04:38:09 --> Total execution time: 0.0623
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Loader Class Initialized
INFO - 2022-04-06 04:38:17 --> Helper loaded: url_helper
INFO - 2022-04-06 04:38:17 --> Helper loaded: form_helper
INFO - 2022-04-06 04:38:17 --> Helper loaded: common_helper
INFO - 2022-04-06 04:38:17 --> Helper loaded: util_helper
INFO - 2022-04-06 04:38:17 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:38:17 --> Form Validation Class Initialized
INFO - 2022-04-06 04:38:17 --> Controller Class Initialized
INFO - 2022-04-06 04:38:17 --> Model Class Initialized
INFO - 2022-04-06 04:38:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:38:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:38:17 --> Final output sent to browser
DEBUG - 2022-04-06 04:38:17 --> Total execution time: 0.0871
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: provider/Js/front.js
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:17 --> Config Class Initialized
INFO - 2022-04-06 04:38:17 --> Hooks Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
INFO - 2022-04-06 04:38:17 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> URI Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:38:17 --> Router Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:17 --> Output Class Initialized
INFO - 2022-04-06 04:38:17 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:17 --> Input Class Initialized
INFO - 2022-04-06 04:38:17 --> Language Class Initialized
ERROR - 2022-04-06 04:38:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Loader Class Initialized
INFO - 2022-04-06 04:38:24 --> Helper loaded: url_helper
INFO - 2022-04-06 04:38:24 --> Helper loaded: form_helper
INFO - 2022-04-06 04:38:24 --> Helper loaded: common_helper
INFO - 2022-04-06 04:38:24 --> Helper loaded: util_helper
INFO - 2022-04-06 04:38:24 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:38:24 --> Form Validation Class Initialized
INFO - 2022-04-06 04:38:24 --> Controller Class Initialized
INFO - 2022-04-06 04:38:24 --> Model Class Initialized
INFO - 2022-04-06 04:38:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:38:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:38:24 --> Final output sent to browser
DEBUG - 2022-04-06 04:38:24 --> Total execution time: 0.0764
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:38:24 --> Config Class Initialized
INFO - 2022-04-06 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:38:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> URI Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Router Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
INFO - 2022-04-06 04:38:24 --> Output Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
INFO - 2022-04-06 04:38:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Input Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
INFO - 2022-04-06 04:38:24 --> Language Class Initialized
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:38:24 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Loader Class Initialized
INFO - 2022-04-06 04:39:20 --> Helper loaded: url_helper
INFO - 2022-04-06 04:39:20 --> Helper loaded: form_helper
INFO - 2022-04-06 04:39:20 --> Helper loaded: common_helper
INFO - 2022-04-06 04:39:20 --> Helper loaded: util_helper
INFO - 2022-04-06 04:39:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:39:20 --> Form Validation Class Initialized
INFO - 2022-04-06 04:39:20 --> Controller Class Initialized
INFO - 2022-04-06 04:39:20 --> Model Class Initialized
INFO - 2022-04-06 04:39:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:39:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:39:20 --> Final output sent to browser
DEBUG - 2022-04-06 04:39:20 --> Total execution time: 0.0541
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:39:20 --> Config Class Initialized
INFO - 2022-04-06 04:39:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:39:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:39:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:39:20 --> URI Class Initialized
INFO - 2022-04-06 04:39:20 --> Router Class Initialized
INFO - 2022-04-06 04:39:20 --> Output Class Initialized
INFO - 2022-04-06 04:39:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:39:20 --> Input Class Initialized
INFO - 2022-04-06 04:39:20 --> Language Class Initialized
ERROR - 2022-04-06 04:39:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:40:15 --> Config Class Initialized
INFO - 2022-04-06 04:40:15 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:15 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:15 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:15 --> URI Class Initialized
INFO - 2022-04-06 04:40:15 --> Router Class Initialized
INFO - 2022-04-06 04:40:15 --> Output Class Initialized
INFO - 2022-04-06 04:40:15 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:15 --> Input Class Initialized
INFO - 2022-04-06 04:40:15 --> Language Class Initialized
INFO - 2022-04-06 04:40:15 --> Loader Class Initialized
INFO - 2022-04-06 04:40:15 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:15 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:15 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:15 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:15 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:15 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:15 --> Controller Class Initialized
INFO - 2022-04-06 04:40:15 --> Model Class Initialized
INFO - 2022-04-06 04:40:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/dashboard.php
INFO - 2022-04-06 04:40:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:40:15 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:15 --> Total execution time: 0.0596
INFO - 2022-04-06 04:40:20 --> Config Class Initialized
INFO - 2022-04-06 04:40:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:20 --> URI Class Initialized
INFO - 2022-04-06 04:40:20 --> Router Class Initialized
INFO - 2022-04-06 04:40:20 --> Output Class Initialized
INFO - 2022-04-06 04:40:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:20 --> Input Class Initialized
INFO - 2022-04-06 04:40:20 --> Language Class Initialized
INFO - 2022-04-06 04:40:20 --> Loader Class Initialized
INFO - 2022-04-06 04:40:20 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:20 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:20 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:20 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:20 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:20 --> Controller Class Initialized
INFO - 2022-04-06 04:40:20 --> Model Class Initialized
INFO - 2022-04-06 04:40:20 --> Model Class Initialized
INFO - 2022-04-06 04:40:20 --> Config Class Initialized
INFO - 2022-04-06 04:40:20 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:20 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:20 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:20 --> URI Class Initialized
INFO - 2022-04-06 04:40:20 --> Router Class Initialized
INFO - 2022-04-06 04:40:20 --> Output Class Initialized
INFO - 2022-04-06 04:40:20 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:20 --> Input Class Initialized
INFO - 2022-04-06 04:40:20 --> Language Class Initialized
INFO - 2022-04-06 04:40:20 --> Loader Class Initialized
INFO - 2022-04-06 04:40:20 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:20 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:20 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:20 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:20 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:20 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:20 --> Controller Class Initialized
INFO - 2022-04-06 04:40:20 --> Model Class Initialized
INFO - 2022-04-06 04:40:20 --> Model Class Initialized
INFO - 2022-04-06 04:40:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:40:20 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:20 --> Total execution time: 0.0639
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
INFO - 2022-04-06 04:40:22 --> Loader Class Initialized
INFO - 2022-04-06 04:40:22 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:22 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:22 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:22 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:22 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:22 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:22 --> Controller Class Initialized
INFO - 2022-04-06 04:40:22 --> Model Class Initialized
INFO - 2022-04-06 04:40:22 --> Model Class Initialized
INFO - 2022-04-06 04:40:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:40:22 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:22 --> Total execution time: 0.0646
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
INFO - 2022-04-06 04:40:22 --> Config Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
INFO - 2022-04-06 04:40:22 --> Hooks Class Initialized
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:22 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
INFO - 2022-04-06 04:40:22 --> URI Class Initialized
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:22 --> Router Class Initialized
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:22 --> Output Class Initialized
INFO - 2022-04-06 04:40:22 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:22 --> Input Class Initialized
INFO - 2022-04-06 04:40:22 --> Language Class Initialized
ERROR - 2022-04-06 04:40:22 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
INFO - 2022-04-06 04:40:41 --> Loader Class Initialized
INFO - 2022-04-06 04:40:41 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:41 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:41 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:41 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:41 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:41 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:41 --> Controller Class Initialized
INFO - 2022-04-06 04:40:41 --> Model Class Initialized
INFO - 2022-04-06 04:40:41 --> Model Class Initialized
INFO - 2022-04-06 04:40:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-06 04:40:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:40:41 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:41 --> Total execution time: 0.1417
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:41 --> Config Class Initialized
INFO - 2022-04-06 04:40:41 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:41 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:41 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:41 --> URI Class Initialized
INFO - 2022-04-06 04:40:41 --> Router Class Initialized
INFO - 2022-04-06 04:40:41 --> Output Class Initialized
INFO - 2022-04-06 04:40:41 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:41 --> Input Class Initialized
INFO - 2022-04-06 04:40:41 --> Language Class Initialized
ERROR - 2022-04-06 04:40:41 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:43 --> Config Class Initialized
INFO - 2022-04-06 04:40:43 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:43 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:43 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:43 --> URI Class Initialized
INFO - 2022-04-06 04:40:43 --> Router Class Initialized
INFO - 2022-04-06 04:40:43 --> Output Class Initialized
INFO - 2022-04-06 04:40:43 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:43 --> Input Class Initialized
INFO - 2022-04-06 04:40:43 --> Language Class Initialized
INFO - 2022-04-06 04:40:43 --> Loader Class Initialized
INFO - 2022-04-06 04:40:43 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:43 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:43 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:43 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:43 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:43 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:43 --> Controller Class Initialized
INFO - 2022-04-06 04:40:43 --> Model Class Initialized
INFO - 2022-04-06 04:40:43 --> Model Class Initialized
INFO - 2022-04-06 04:40:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-06 04:40:43 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:43 --> Total execution time: 0.0634
INFO - 2022-04-06 04:40:44 --> Config Class Initialized
INFO - 2022-04-06 04:40:44 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:44 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:44 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:44 --> URI Class Initialized
INFO - 2022-04-06 04:40:44 --> Router Class Initialized
INFO - 2022-04-06 04:40:44 --> Output Class Initialized
INFO - 2022-04-06 04:40:44 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:44 --> Input Class Initialized
INFO - 2022-04-06 04:40:44 --> Language Class Initialized
INFO - 2022-04-06 04:40:44 --> Loader Class Initialized
INFO - 2022-04-06 04:40:44 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:44 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:44 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:44 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:44 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:44 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:44 --> Controller Class Initialized
INFO - 2022-04-06 04:40:44 --> Model Class Initialized
INFO - 2022-04-06 04:40:44 --> Model Class Initialized
INFO - 2022-04-06 04:40:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:40:44 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:44 --> Total execution time: 0.0547
INFO - 2022-04-06 04:40:46 --> Config Class Initialized
INFO - 2022-04-06 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:46 --> URI Class Initialized
INFO - 2022-04-06 04:40:46 --> Router Class Initialized
INFO - 2022-04-06 04:40:46 --> Output Class Initialized
INFO - 2022-04-06 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:46 --> Input Class Initialized
INFO - 2022-04-06 04:40:46 --> Language Class Initialized
INFO - 2022-04-06 04:40:46 --> Loader Class Initialized
INFO - 2022-04-06 04:40:46 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:46 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:46 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:46 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:46 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:46 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:46 --> Controller Class Initialized
INFO - 2022-04-06 04:40:46 --> Model Class Initialized
INFO - 2022-04-06 04:40:46 --> Model Class Initialized
INFO - 2022-04-06 04:40:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:40:46 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:46 --> Total execution time: 0.0623
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> Loader Class Initialized
INFO - 2022-04-06 04:40:51 --> Helper loaded: url_helper
INFO - 2022-04-06 04:40:51 --> Helper loaded: form_helper
INFO - 2022-04-06 04:40:51 --> Helper loaded: common_helper
INFO - 2022-04-06 04:40:51 --> Helper loaded: util_helper
INFO - 2022-04-06 04:40:51 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:40:51 --> Form Validation Class Initialized
INFO - 2022-04-06 04:40:51 --> Controller Class Initialized
INFO - 2022-04-06 04:40:51 --> Model Class Initialized
INFO - 2022-04-06 04:40:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:40:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:40:51 --> Final output sent to browser
DEBUG - 2022-04-06 04:40:51 --> Total execution time: 0.0536
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
INFO - 2022-04-06 04:40:51 --> Config Class Initialized
INFO - 2022-04-06 04:40:51 --> Hooks Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-06 04:40:51 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:40:51 --> Utf8 Class Initialized
INFO - 2022-04-06 04:40:51 --> URI Class Initialized
INFO - 2022-04-06 04:40:51 --> Router Class Initialized
INFO - 2022-04-06 04:40:51 --> Output Class Initialized
INFO - 2022-04-06 04:40:51 --> Security Class Initialized
DEBUG - 2022-04-06 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:40:51 --> Input Class Initialized
INFO - 2022-04-06 04:40:51 --> Language Class Initialized
ERROR - 2022-04-06 04:40:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Loader Class Initialized
INFO - 2022-04-06 04:41:18 --> Helper loaded: url_helper
INFO - 2022-04-06 04:41:18 --> Helper loaded: form_helper
INFO - 2022-04-06 04:41:18 --> Helper loaded: common_helper
INFO - 2022-04-06 04:41:18 --> Helper loaded: util_helper
INFO - 2022-04-06 04:41:18 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:41:18 --> Form Validation Class Initialized
INFO - 2022-04-06 04:41:18 --> Controller Class Initialized
INFO - 2022-04-06 04:41:18 --> Model Class Initialized
INFO - 2022-04-06 04:41:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:41:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:41:18 --> Final output sent to browser
DEBUG - 2022-04-06 04:41:18 --> Total execution time: 0.0549
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Config Class Initialized
INFO - 2022-04-06 04:41:18 --> Hooks Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
DEBUG - 2022-04-06 04:41:18 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:41:18 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> URI Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Router Class Initialized
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:41:18 --> Output Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
INFO - 2022-04-06 04:41:18 --> Security Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
DEBUG - 2022-04-06 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:41:18 --> Input Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
INFO - 2022-04-06 04:41:18 --> Language Class Initialized
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-06 04:41:18 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
INFO - 2022-04-06 04:42:38 --> Loader Class Initialized
INFO - 2022-04-06 04:42:38 --> Helper loaded: url_helper
INFO - 2022-04-06 04:42:38 --> Helper loaded: form_helper
INFO - 2022-04-06 04:42:38 --> Helper loaded: common_helper
INFO - 2022-04-06 04:42:38 --> Helper loaded: util_helper
INFO - 2022-04-06 04:42:38 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:42:38 --> Form Validation Class Initialized
INFO - 2022-04-06 04:42:38 --> Controller Class Initialized
INFO - 2022-04-06 04:42:38 --> Model Class Initialized
INFO - 2022-04-06 04:42:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-06 04:42:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-06 04:42:38 --> Final output sent to browser
DEBUG - 2022-04-06 04:42:38 --> Total execution time: 0.4369
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
ERROR - 2022-04-06 04:42:38 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
ERROR - 2022-04-06 04:42:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
ERROR - 2022-04-06 04:42:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
ERROR - 2022-04-06 04:42:38 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
DEBUG - 2022-04-06 04:42:38 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
INFO - 2022-04-06 04:42:38 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:38 --> URI Class Initialized
ERROR - 2022-04-06 04:42:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:42:38 --> Router Class Initialized
INFO - 2022-04-06 04:42:38 --> Output Class Initialized
INFO - 2022-04-06 04:42:38 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:38 --> Input Class Initialized
INFO - 2022-04-06 04:42:38 --> Language Class Initialized
ERROR - 2022-04-06 04:42:38 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:38 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:38 --> Config Class Initialized
INFO - 2022-04-06 04:42:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:39 --> Config Class Initialized
INFO - 2022-04-06 04:42:39 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
INFO - 2022-04-06 04:42:39 --> Config Class Initialized
INFO - 2022-04-06 04:42:39 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:39 --> Config Class Initialized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:42:39 --> Config Class Initialized
INFO - 2022-04-06 04:42:39 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:39 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:39 --> Config Class Initialized
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
INFO - 2022-04-06 04:42:39 --> Hooks Class Initialized
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
DEBUG - 2022-04-06 04:42:39 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:39 --> Utf8 Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
INFO - 2022-04-06 04:42:39 --> URI Class Initialized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:42:39 --> Router Class Initialized
INFO - 2022-04-06 04:42:39 --> Output Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-06 04:42:39 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:39 --> Input Class Initialized
INFO - 2022-04-06 04:42:39 --> Language Class Initialized
ERROR - 2022-04-06 04:42:39 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-06 04:42:55 --> Config Class Initialized
INFO - 2022-04-06 04:42:55 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:42:55 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:42:55 --> Utf8 Class Initialized
INFO - 2022-04-06 04:42:55 --> URI Class Initialized
INFO - 2022-04-06 04:42:55 --> Router Class Initialized
INFO - 2022-04-06 04:42:55 --> Output Class Initialized
INFO - 2022-04-06 04:42:55 --> Security Class Initialized
DEBUG - 2022-04-06 04:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:42:55 --> Input Class Initialized
INFO - 2022-04-06 04:42:55 --> Language Class Initialized
INFO - 2022-04-06 04:42:55 --> Loader Class Initialized
INFO - 2022-04-06 04:42:55 --> Helper loaded: url_helper
INFO - 2022-04-06 04:42:55 --> Helper loaded: form_helper
INFO - 2022-04-06 04:42:55 --> Helper loaded: common_helper
INFO - 2022-04-06 04:42:55 --> Helper loaded: util_helper
INFO - 2022-04-06 04:42:55 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:42:55 --> Form Validation Class Initialized
INFO - 2022-04-06 04:42:55 --> Controller Class Initialized
INFO - 2022-04-06 04:42:55 --> Model Class Initialized
INFO - 2022-04-06 04:42:55 --> Model Class Initialized
INFO - 2022-04-06 04:42:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:42:55 --> Final output sent to browser
DEBUG - 2022-04-06 04:42:55 --> Total execution time: 0.0605
INFO - 2022-04-06 04:43:24 --> Config Class Initialized
INFO - 2022-04-06 04:43:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:43:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:43:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:43:24 --> URI Class Initialized
INFO - 2022-04-06 04:43:24 --> Router Class Initialized
INFO - 2022-04-06 04:43:24 --> Output Class Initialized
INFO - 2022-04-06 04:43:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:43:24 --> Input Class Initialized
INFO - 2022-04-06 04:43:24 --> Language Class Initialized
INFO - 2022-04-06 04:43:24 --> Loader Class Initialized
INFO - 2022-04-06 04:43:24 --> Helper loaded: url_helper
INFO - 2022-04-06 04:43:24 --> Helper loaded: form_helper
INFO - 2022-04-06 04:43:24 --> Helper loaded: common_helper
INFO - 2022-04-06 04:43:24 --> Helper loaded: util_helper
INFO - 2022-04-06 04:43:24 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:43:24 --> Form Validation Class Initialized
INFO - 2022-04-06 04:43:24 --> Controller Class Initialized
INFO - 2022-04-06 04:43:24 --> Model Class Initialized
INFO - 2022-04-06 04:43:24 --> Model Class Initialized
INFO - 2022-04-06 04:43:24 --> Config Class Initialized
INFO - 2022-04-06 04:43:24 --> Hooks Class Initialized
DEBUG - 2022-04-06 04:43:24 --> UTF-8 Support Enabled
INFO - 2022-04-06 04:43:24 --> Utf8 Class Initialized
INFO - 2022-04-06 04:43:24 --> URI Class Initialized
INFO - 2022-04-06 04:43:24 --> Router Class Initialized
INFO - 2022-04-06 04:43:24 --> Output Class Initialized
INFO - 2022-04-06 04:43:24 --> Security Class Initialized
DEBUG - 2022-04-06 04:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-06 04:43:24 --> Input Class Initialized
INFO - 2022-04-06 04:43:24 --> Language Class Initialized
INFO - 2022-04-06 04:43:24 --> Loader Class Initialized
INFO - 2022-04-06 04:43:24 --> Helper loaded: url_helper
INFO - 2022-04-06 04:43:24 --> Helper loaded: form_helper
INFO - 2022-04-06 04:43:24 --> Helper loaded: common_helper
INFO - 2022-04-06 04:43:24 --> Helper loaded: util_helper
INFO - 2022-04-06 04:43:24 --> Database Driver Class Initialized
DEBUG - 2022-04-06 04:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-06 04:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-06 04:43:24 --> Form Validation Class Initialized
INFO - 2022-04-06 04:43:24 --> Controller Class Initialized
INFO - 2022-04-06 04:43:24 --> Model Class Initialized
INFO - 2022-04-06 04:43:24 --> Model Class Initialized
INFO - 2022-04-06 04:43:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-06 04:43:24 --> Final output sent to browser
DEBUG - 2022-04-06 04:43:24 --> Total execution time: 0.0735
