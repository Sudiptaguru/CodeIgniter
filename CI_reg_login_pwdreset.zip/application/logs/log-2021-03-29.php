<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-29 19:39:45 --> Config Class Initialized
INFO - 2021-03-29 19:39:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:45 --> URI Class Initialized
INFO - 2021-03-29 19:39:45 --> Router Class Initialized
INFO - 2021-03-29 19:39:45 --> Output Class Initialized
INFO - 2021-03-29 19:39:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:45 --> Input Class Initialized
INFO - 2021-03-29 19:39:45 --> Language Class Initialized
INFO - 2021-03-29 19:39:45 --> Loader Class Initialized
INFO - 2021-03-29 19:39:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:39:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:39:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:39:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:39:45 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:39:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:39:45 --> Controller Class Initialized
INFO - 2021-03-29 19:39:45 --> Model Class Initialized
INFO - 2021-03-29 19:39:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-29 19:39:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:39:45 --> Total execution time: 0.7334
INFO - 2021-03-29 19:39:49 --> Config Class Initialized
INFO - 2021-03-29 19:39:49 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:49 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:49 --> URI Class Initialized
INFO - 2021-03-29 19:39:49 --> Router Class Initialized
INFO - 2021-03-29 19:39:49 --> Output Class Initialized
INFO - 2021-03-29 19:39:49 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:49 --> Input Class Initialized
INFO - 2021-03-29 19:39:49 --> Language Class Initialized
INFO - 2021-03-29 19:39:49 --> Loader Class Initialized
INFO - 2021-03-29 19:39:49 --> Helper loaded: url_helper
INFO - 2021-03-29 19:39:49 --> Helper loaded: form_helper
INFO - 2021-03-29 19:39:49 --> Helper loaded: common_helper
INFO - 2021-03-29 19:39:49 --> Helper loaded: util_helper
INFO - 2021-03-29 19:39:49 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:39:49 --> Form Validation Class Initialized
INFO - 2021-03-29 19:39:49 --> Controller Class Initialized
INFO - 2021-03-29 19:39:49 --> Model Class Initialized
INFO - 2021-03-29 19:39:49 --> Config Class Initialized
INFO - 2021-03-29 19:39:49 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:49 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:49 --> URI Class Initialized
INFO - 2021-03-29 19:39:49 --> Router Class Initialized
INFO - 2021-03-29 19:39:49 --> Output Class Initialized
INFO - 2021-03-29 19:39:49 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:49 --> Input Class Initialized
INFO - 2021-03-29 19:39:49 --> Language Class Initialized
INFO - 2021-03-29 19:39:49 --> Loader Class Initialized
INFO - 2021-03-29 19:39:49 --> Helper loaded: url_helper
INFO - 2021-03-29 19:39:49 --> Helper loaded: form_helper
INFO - 2021-03-29 19:39:49 --> Helper loaded: common_helper
INFO - 2021-03-29 19:39:49 --> Helper loaded: util_helper
INFO - 2021-03-29 19:39:49 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:39:49 --> Form Validation Class Initialized
INFO - 2021-03-29 19:39:49 --> Controller Class Initialized
INFO - 2021-03-29 19:39:49 --> Model Class Initialized
INFO - 2021-03-29 19:39:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:39:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:39:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-29 19:39:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:39:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:39:49 --> Final output sent to browser
DEBUG - 2021-03-29 19:39:49 --> Total execution time: 0.1461
INFO - 2021-03-29 19:39:50 --> Config Class Initialized
INFO - 2021-03-29 19:39:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:50 --> URI Class Initialized
INFO - 2021-03-29 19:39:50 --> Router Class Initialized
INFO - 2021-03-29 19:39:50 --> Output Class Initialized
INFO - 2021-03-29 19:39:50 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:50 --> Input Class Initialized
INFO - 2021-03-29 19:39:50 --> Language Class Initialized
INFO - 2021-03-29 19:39:50 --> Config Class Initialized
INFO - 2021-03-29 19:39:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:50 --> URI Class Initialized
INFO - 2021-03-29 19:39:50 --> Config Class Initialized
INFO - 2021-03-29 19:39:50 --> Hooks Class Initialized
INFO - 2021-03-29 19:39:50 --> Config Class Initialized
INFO - 2021-03-29 19:39:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:50 --> URI Class Initialized
DEBUG - 2021-03-29 19:39:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:50 --> Router Class Initialized
INFO - 2021-03-29 19:39:50 --> URI Class Initialized
INFO - 2021-03-29 19:39:50 --> Router Class Initialized
INFO - 2021-03-29 19:39:50 --> Output Class Initialized
INFO - 2021-03-29 19:39:50 --> Router Class Initialized
INFO - 2021-03-29 19:39:50 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:50 --> Input Class Initialized
INFO - 2021-03-29 19:39:50 --> Output Class Initialized
INFO - 2021-03-29 19:39:50 --> Output Class Initialized
INFO - 2021-03-29 19:39:50 --> Language Class Initialized
INFO - 2021-03-29 19:39:50 --> Security Class Initialized
INFO - 2021-03-29 19:39:50 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 19:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:50 --> Input Class Initialized
INFO - 2021-03-29 19:39:50 --> Input Class Initialized
INFO - 2021-03-29 19:39:50 --> Language Class Initialized
INFO - 2021-03-29 19:39:50 --> Language Class Initialized
ERROR - 2021-03-29 19:39:50 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-29 19:39:50 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-29 19:39:50 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-29 19:39:50 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-29 19:39:55 --> Config Class Initialized
INFO - 2021-03-29 19:39:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:55 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:55 --> URI Class Initialized
INFO - 2021-03-29 19:39:55 --> Router Class Initialized
INFO - 2021-03-29 19:39:55 --> Output Class Initialized
INFO - 2021-03-29 19:39:55 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:55 --> Input Class Initialized
INFO - 2021-03-29 19:39:55 --> Language Class Initialized
INFO - 2021-03-29 19:39:55 --> Loader Class Initialized
INFO - 2021-03-29 19:39:55 --> Helper loaded: url_helper
INFO - 2021-03-29 19:39:55 --> Helper loaded: form_helper
INFO - 2021-03-29 19:39:55 --> Helper loaded: common_helper
INFO - 2021-03-29 19:39:55 --> Helper loaded: util_helper
INFO - 2021-03-29 19:39:55 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:39:55 --> Form Validation Class Initialized
INFO - 2021-03-29 19:39:55 --> Controller Class Initialized
INFO - 2021-03-29 19:39:55 --> Model Class Initialized
INFO - 2021-03-29 19:39:55 --> Model Class Initialized
INFO - 2021-03-29 19:39:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:39:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:39:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-29 19:39:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:39:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:39:55 --> Final output sent to browser
DEBUG - 2021-03-29 19:39:55 --> Total execution time: 0.1778
INFO - 2021-03-29 19:39:55 --> Config Class Initialized
INFO - 2021-03-29 19:39:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:55 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:55 --> Config Class Initialized
INFO - 2021-03-29 19:39:55 --> Hooks Class Initialized
INFO - 2021-03-29 19:39:55 --> URI Class Initialized
INFO - 2021-03-29 19:39:55 --> Router Class Initialized
INFO - 2021-03-29 19:39:55 --> Output Class Initialized
INFO - 2021-03-29 19:39:55 --> Security Class Initialized
INFO - 2021-03-29 19:39:55 --> Config Class Initialized
INFO - 2021-03-29 19:39:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:55 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:55 --> Input Class Initialized
INFO - 2021-03-29 19:39:55 --> Language Class Initialized
DEBUG - 2021-03-29 19:39:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:55 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:55 --> Utf8 Class Initialized
ERROR - 2021-03-29 19:39:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:39:55 --> URI Class Initialized
INFO - 2021-03-29 19:39:55 --> URI Class Initialized
INFO - 2021-03-29 19:39:55 --> Router Class Initialized
INFO - 2021-03-29 19:39:55 --> Router Class Initialized
INFO - 2021-03-29 19:39:55 --> Output Class Initialized
INFO - 2021-03-29 19:39:55 --> Output Class Initialized
INFO - 2021-03-29 19:39:55 --> Security Class Initialized
INFO - 2021-03-29 19:39:55 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:55 --> Input Class Initialized
DEBUG - 2021-03-29 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:55 --> Input Class Initialized
INFO - 2021-03-29 19:39:55 --> Language Class Initialized
INFO - 2021-03-29 19:39:55 --> Language Class Initialized
ERROR - 2021-03-29 19:39:55 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 19:39:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:39:55 --> Config Class Initialized
INFO - 2021-03-29 19:39:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:39:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:39:55 --> Utf8 Class Initialized
INFO - 2021-03-29 19:39:55 --> URI Class Initialized
INFO - 2021-03-29 19:39:55 --> Router Class Initialized
INFO - 2021-03-29 19:39:55 --> Output Class Initialized
INFO - 2021-03-29 19:39:55 --> Security Class Initialized
DEBUG - 2021-03-29 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:39:55 --> Input Class Initialized
INFO - 2021-03-29 19:39:55 --> Language Class Initialized
ERROR - 2021-03-29 19:39:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:03 --> Config Class Initialized
INFO - 2021-03-29 19:40:03 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:03 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:03 --> URI Class Initialized
INFO - 2021-03-29 19:40:03 --> Router Class Initialized
INFO - 2021-03-29 19:40:03 --> Output Class Initialized
INFO - 2021-03-29 19:40:03 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:03 --> Input Class Initialized
INFO - 2021-03-29 19:40:03 --> Language Class Initialized
INFO - 2021-03-29 19:40:03 --> Loader Class Initialized
INFO - 2021-03-29 19:40:03 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:03 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:03 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:03 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:03 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:03 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:03 --> Controller Class Initialized
INFO - 2021-03-29 19:40:03 --> Model Class Initialized
INFO - 2021-03-29 19:40:03 --> Model Class Initialized
INFO - 2021-03-29 19:40:03 --> Model Class Initialized
INFO - 2021-03-29 19:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-29 19:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:03 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:03 --> Total execution time: 0.1014
INFO - 2021-03-29 19:40:03 --> Config Class Initialized
INFO - 2021-03-29 19:40:03 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:03 --> Config Class Initialized
INFO - 2021-03-29 19:40:03 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:03 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:03 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:03 --> URI Class Initialized
INFO - 2021-03-29 19:40:03 --> URI Class Initialized
INFO - 2021-03-29 19:40:03 --> Router Class Initialized
INFO - 2021-03-29 19:40:03 --> Router Class Initialized
INFO - 2021-03-29 19:40:03 --> Output Class Initialized
INFO - 2021-03-29 19:40:03 --> Security Class Initialized
INFO - 2021-03-29 19:40:03 --> Output Class Initialized
DEBUG - 2021-03-29 19:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:03 --> Input Class Initialized
INFO - 2021-03-29 19:40:03 --> Language Class Initialized
INFO - 2021-03-29 19:40:03 --> Security Class Initialized
ERROR - 2021-03-29 19:40:03 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 19:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:03 --> Input Class Initialized
INFO - 2021-03-29 19:40:03 --> Language Class Initialized
ERROR - 2021-03-29 19:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:03 --> Config Class Initialized
INFO - 2021-03-29 19:40:03 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:03 --> Config Class Initialized
INFO - 2021-03-29 19:40:03 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:03 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:03 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:03 --> URI Class Initialized
INFO - 2021-03-29 19:40:03 --> URI Class Initialized
INFO - 2021-03-29 19:40:03 --> Router Class Initialized
INFO - 2021-03-29 19:40:03 --> Router Class Initialized
INFO - 2021-03-29 19:40:03 --> Output Class Initialized
INFO - 2021-03-29 19:40:03 --> Output Class Initialized
INFO - 2021-03-29 19:40:03 --> Security Class Initialized
INFO - 2021-03-29 19:40:03 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:03 --> Input Class Initialized
DEBUG - 2021-03-29 19:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:03 --> Input Class Initialized
INFO - 2021-03-29 19:40:03 --> Language Class Initialized
INFO - 2021-03-29 19:40:03 --> Language Class Initialized
ERROR - 2021-03-29 19:40:03 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 19:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:11 --> Config Class Initialized
INFO - 2021-03-29 19:40:11 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:11 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:11 --> URI Class Initialized
DEBUG - 2021-03-29 19:40:11 --> No URI present. Default controller set.
INFO - 2021-03-29 19:40:11 --> Router Class Initialized
INFO - 2021-03-29 19:40:11 --> Output Class Initialized
INFO - 2021-03-29 19:40:11 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:11 --> Input Class Initialized
INFO - 2021-03-29 19:40:11 --> Language Class Initialized
INFO - 2021-03-29 19:40:11 --> Loader Class Initialized
INFO - 2021-03-29 19:40:11 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:11 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:11 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:11 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:11 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:11 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:11 --> Controller Class Initialized
INFO - 2021-03-29 19:40:11 --> Model Class Initialized
INFO - 2021-03-29 19:40:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/header.php
INFO - 2021-03-29 19:40:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/login.php
INFO - 2021-03-29 19:40:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/footer.php
INFO - 2021-03-29 19:40:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/index.php
INFO - 2021-03-29 19:40:11 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:11 --> Total execution time: 0.1333
INFO - 2021-03-29 19:40:11 --> Config Class Initialized
INFO - 2021-03-29 19:40:11 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:11 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:11 --> URI Class Initialized
INFO - 2021-03-29 19:40:11 --> Router Class Initialized
INFO - 2021-03-29 19:40:11 --> Output Class Initialized
INFO - 2021-03-29 19:40:11 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:11 --> Input Class Initialized
INFO - 2021-03-29 19:40:11 --> Language Class Initialized
ERROR - 2021-03-29 19:40:11 --> 404 Page Not Found: Assets/js
INFO - 2021-03-29 19:40:11 --> Config Class Initialized
INFO - 2021-03-29 19:40:11 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:11 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:11 --> URI Class Initialized
INFO - 2021-03-29 19:40:11 --> Router Class Initialized
INFO - 2021-03-29 19:40:11 --> Output Class Initialized
INFO - 2021-03-29 19:40:11 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:11 --> Input Class Initialized
INFO - 2021-03-29 19:40:11 --> Language Class Initialized
ERROR - 2021-03-29 19:40:11 --> 404 Page Not Found: Assets/js
INFO - 2021-03-29 19:40:12 --> Config Class Initialized
INFO - 2021-03-29 19:40:12 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:12 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:12 --> URI Class Initialized
DEBUG - 2021-03-29 19:40:12 --> No URI present. Default controller set.
INFO - 2021-03-29 19:40:12 --> Router Class Initialized
INFO - 2021-03-29 19:40:12 --> Output Class Initialized
INFO - 2021-03-29 19:40:12 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:12 --> Input Class Initialized
INFO - 2021-03-29 19:40:12 --> Language Class Initialized
INFO - 2021-03-29 19:40:12 --> Loader Class Initialized
INFO - 2021-03-29 19:40:12 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:12 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:12 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:12 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:12 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:12 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:12 --> Controller Class Initialized
INFO - 2021-03-29 19:40:12 --> Model Class Initialized
INFO - 2021-03-29 19:40:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/header.php
INFO - 2021-03-29 19:40:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/login.php
INFO - 2021-03-29 19:40:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/footer.php
INFO - 2021-03-29 19:40:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/index.php
INFO - 2021-03-29 19:40:12 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:12 --> Total execution time: 0.0477
INFO - 2021-03-29 19:40:15 --> Config Class Initialized
INFO - 2021-03-29 19:40:15 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:15 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:15 --> URI Class Initialized
INFO - 2021-03-29 19:40:15 --> Router Class Initialized
INFO - 2021-03-29 19:40:15 --> Output Class Initialized
INFO - 2021-03-29 19:40:15 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:15 --> Input Class Initialized
INFO - 2021-03-29 19:40:15 --> Language Class Initialized
INFO - 2021-03-29 19:40:15 --> Loader Class Initialized
INFO - 2021-03-29 19:40:15 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:15 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:15 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:15 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:15 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:15 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:15 --> Controller Class Initialized
INFO - 2021-03-29 19:40:15 --> Model Class Initialized
INFO - 2021-03-29 19:40:15 --> Model Class Initialized
INFO - 2021-03-29 19:40:15 --> Model Class Initialized
INFO - 2021-03-29 19:40:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-29 19:40:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:15 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:15 --> Total execution time: 0.0449
INFO - 2021-03-29 19:40:20 --> Config Class Initialized
INFO - 2021-03-29 19:40:20 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:20 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:20 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:20 --> URI Class Initialized
INFO - 2021-03-29 19:40:20 --> Router Class Initialized
INFO - 2021-03-29 19:40:20 --> Output Class Initialized
INFO - 2021-03-29 19:40:20 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:20 --> Input Class Initialized
INFO - 2021-03-29 19:40:20 --> Language Class Initialized
INFO - 2021-03-29 19:40:20 --> Loader Class Initialized
INFO - 2021-03-29 19:40:20 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:20 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:20 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:20 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:20 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:20 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:20 --> Controller Class Initialized
INFO - 2021-03-29 19:40:20 --> Model Class Initialized
INFO - 2021-03-29 19:40:20 --> Model Class Initialized
INFO - 2021-03-29 19:40:20 --> Model Class Initialized
INFO - 2021-03-29 19:40:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-29 19:40:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:20 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:20 --> Total execution time: 0.0442
INFO - 2021-03-29 19:40:21 --> Config Class Initialized
INFO - 2021-03-29 19:40:21 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:21 --> Config Class Initialized
INFO - 2021-03-29 19:40:21 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:21 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:21 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:21 --> URI Class Initialized
DEBUG - 2021-03-29 19:40:21 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:21 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:21 --> Router Class Initialized
INFO - 2021-03-29 19:40:21 --> URI Class Initialized
INFO - 2021-03-29 19:40:21 --> Output Class Initialized
INFO - 2021-03-29 19:40:21 --> Router Class Initialized
INFO - 2021-03-29 19:40:21 --> Security Class Initialized
INFO - 2021-03-29 19:40:21 --> Output Class Initialized
DEBUG - 2021-03-29 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:21 --> Input Class Initialized
INFO - 2021-03-29 19:40:21 --> Security Class Initialized
INFO - 2021-03-29 19:40:21 --> Language Class Initialized
DEBUG - 2021-03-29 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:21 --> Input Class Initialized
ERROR - 2021-03-29 19:40:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:21 --> Language Class Initialized
ERROR - 2021-03-29 19:40:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:21 --> Config Class Initialized
INFO - 2021-03-29 19:40:21 --> Config Class Initialized
INFO - 2021-03-29 19:40:21 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:21 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:21 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 19:40:21 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:21 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:21 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:21 --> URI Class Initialized
INFO - 2021-03-29 19:40:21 --> URI Class Initialized
INFO - 2021-03-29 19:40:21 --> Router Class Initialized
INFO - 2021-03-29 19:40:21 --> Router Class Initialized
INFO - 2021-03-29 19:40:21 --> Output Class Initialized
INFO - 2021-03-29 19:40:21 --> Output Class Initialized
INFO - 2021-03-29 19:40:21 --> Security Class Initialized
INFO - 2021-03-29 19:40:21 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:21 --> Input Class Initialized
INFO - 2021-03-29 19:40:21 --> Input Class Initialized
INFO - 2021-03-29 19:40:21 --> Language Class Initialized
INFO - 2021-03-29 19:40:21 --> Language Class Initialized
ERROR - 2021-03-29 19:40:21 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 19:40:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:28 --> Config Class Initialized
INFO - 2021-03-29 19:40:28 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:28 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:28 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:28 --> URI Class Initialized
INFO - 2021-03-29 19:40:28 --> Router Class Initialized
INFO - 2021-03-29 19:40:28 --> Output Class Initialized
INFO - 2021-03-29 19:40:28 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:28 --> Input Class Initialized
INFO - 2021-03-29 19:40:28 --> Language Class Initialized
INFO - 2021-03-29 19:40:28 --> Loader Class Initialized
INFO - 2021-03-29 19:40:28 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:28 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:28 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:28 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:28 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:28 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:28 --> Controller Class Initialized
INFO - 2021-03-29 19:40:28 --> Model Class Initialized
INFO - 2021-03-29 19:40:28 --> Model Class Initialized
INFO - 2021-03-29 19:40:28 --> Model Class Initialized
INFO - 2021-03-29 19:40:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-29 19:40:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:28 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:28 --> Total execution time: 0.0354
INFO - 2021-03-29 19:40:28 --> Config Class Initialized
INFO - 2021-03-29 19:40:28 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:28 --> Config Class Initialized
INFO - 2021-03-29 19:40:28 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:28 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:28 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:28 --> URI Class Initialized
DEBUG - 2021-03-29 19:40:28 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:28 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:28 --> Router Class Initialized
INFO - 2021-03-29 19:40:28 --> URI Class Initialized
INFO - 2021-03-29 19:40:28 --> Router Class Initialized
INFO - 2021-03-29 19:40:28 --> Output Class Initialized
INFO - 2021-03-29 19:40:28 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:28 --> Input Class Initialized
INFO - 2021-03-29 19:40:28 --> Language Class Initialized
INFO - 2021-03-29 19:40:28 --> Output Class Initialized
ERROR - 2021-03-29 19:40:28 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:28 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:28 --> Input Class Initialized
INFO - 2021-03-29 19:40:28 --> Language Class Initialized
ERROR - 2021-03-29 19:40:28 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:28 --> Config Class Initialized
INFO - 2021-03-29 19:40:28 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:28 --> Config Class Initialized
INFO - 2021-03-29 19:40:28 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:28 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:28 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:28 --> URI Class Initialized
DEBUG - 2021-03-29 19:40:28 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:28 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:28 --> Router Class Initialized
INFO - 2021-03-29 19:40:28 --> URI Class Initialized
INFO - 2021-03-29 19:40:28 --> Router Class Initialized
INFO - 2021-03-29 19:40:28 --> Output Class Initialized
INFO - 2021-03-29 19:40:28 --> Security Class Initialized
INFO - 2021-03-29 19:40:28 --> Output Class Initialized
DEBUG - 2021-03-29 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:28 --> Security Class Initialized
INFO - 2021-03-29 19:40:28 --> Input Class Initialized
INFO - 2021-03-29 19:40:28 --> Language Class Initialized
DEBUG - 2021-03-29 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:28 --> Input Class Initialized
INFO - 2021-03-29 19:40:28 --> Language Class Initialized
ERROR - 2021-03-29 19:40:28 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 19:40:28 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 19:40:31 --> Config Class Initialized
INFO - 2021-03-29 19:40:31 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:31 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:31 --> URI Class Initialized
INFO - 2021-03-29 19:40:31 --> Router Class Initialized
INFO - 2021-03-29 19:40:31 --> Output Class Initialized
INFO - 2021-03-29 19:40:31 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:31 --> Input Class Initialized
INFO - 2021-03-29 19:40:31 --> Language Class Initialized
INFO - 2021-03-29 19:40:31 --> Loader Class Initialized
INFO - 2021-03-29 19:40:31 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:31 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:31 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:31 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:31 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:31 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:31 --> Controller Class Initialized
INFO - 2021-03-29 19:40:31 --> Model Class Initialized
INFO - 2021-03-29 19:40:31 --> Model Class Initialized
INFO - 2021-03-29 19:40:31 --> Model Class Initialized
INFO - 2021-03-29 19:40:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:40:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:31 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:31 --> Total execution time: 0.0987
INFO - 2021-03-29 19:40:31 --> Config Class Initialized
INFO - 2021-03-29 19:40:31 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:31 --> Config Class Initialized
INFO - 2021-03-29 19:40:31 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:31 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:40:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:31 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:31 --> URI Class Initialized
INFO - 2021-03-29 19:40:31 --> URI Class Initialized
INFO - 2021-03-29 19:40:31 --> Router Class Initialized
INFO - 2021-03-29 19:40:31 --> Router Class Initialized
INFO - 2021-03-29 19:40:31 --> Output Class Initialized
INFO - 2021-03-29 19:40:31 --> Output Class Initialized
INFO - 2021-03-29 19:40:31 --> Security Class Initialized
INFO - 2021-03-29 19:40:31 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:31 --> Input Class Initialized
INFO - 2021-03-29 19:40:31 --> Language Class Initialized
DEBUG - 2021-03-29 19:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:32 --> Input Class Initialized
INFO - 2021-03-29 19:40:32 --> Loader Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:32 --> Config Class Initialized
INFO - 2021-03-29 19:40:32 --> Hooks Class Initialized
INFO - 2021-03-29 19:40:32 --> Language Class Initialized
INFO - 2021-03-29 19:40:32 --> Config Class Initialized
INFO - 2021-03-29 19:40:32 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:40:32 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:32 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:32 --> URI Class Initialized
DEBUG - 2021-03-29 19:40:32 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:40:32 --> Loader Class Initialized
INFO - 2021-03-29 19:40:32 --> Utf8 Class Initialized
INFO - 2021-03-29 19:40:32 --> Router Class Initialized
INFO - 2021-03-29 19:40:32 --> Database Driver Class Initialized
INFO - 2021-03-29 19:40:32 --> URI Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:32 --> Output Class Initialized
INFO - 2021-03-29 19:40:32 --> Router Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:32 --> Security Class Initialized
INFO - 2021-03-29 19:40:32 --> Output Class Initialized
DEBUG - 2021-03-29 19:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 19:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:32 --> Input Class Initialized
INFO - 2021-03-29 19:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:32 --> Language Class Initialized
INFO - 2021-03-29 19:40:32 --> Security Class Initialized
DEBUG - 2021-03-29 19:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:40:32 --> Input Class Initialized
INFO - 2021-03-29 19:40:32 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:32 --> Controller Class Initialized
INFO - 2021-03-29 19:40:32 --> Language Class Initialized
INFO - 2021-03-29 19:40:32 --> Loader Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Loader Class Initialized
INFO - 2021-03-29 19:40:32 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: url_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:32 --> Helper loaded: form_helper
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:32 --> Helper loaded: common_helper
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:32 --> Helper loaded: util_helper
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:32 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:32 --> Total execution time: 0.0489
INFO - 2021-03-29 19:40:32 --> Database Driver Class Initialized
INFO - 2021-03-29 19:40:32 --> Database Driver Class Initialized
INFO - 2021-03-29 19:40:32 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 19:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:32 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:32 --> Controller Class Initialized
DEBUG - 2021-03-29 19:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:32 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:32 --> Total execution time: 0.0447
INFO - 2021-03-29 19:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:32 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:32 --> Controller Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:32 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:32 --> Total execution time: 0.0562
INFO - 2021-03-29 19:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:40:32 --> Form Validation Class Initialized
INFO - 2021-03-29 19:40:32 --> Controller Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> Model Class Initialized
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:40:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:40:32 --> Final output sent to browser
DEBUG - 2021-03-29 19:40:32 --> Total execution time: 0.0954
INFO - 2021-03-29 19:50:22 --> Config Class Initialized
INFO - 2021-03-29 19:50:22 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:50:22 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:50:22 --> Utf8 Class Initialized
INFO - 2021-03-29 19:50:22 --> URI Class Initialized
INFO - 2021-03-29 19:50:22 --> Router Class Initialized
INFO - 2021-03-29 19:50:22 --> Output Class Initialized
INFO - 2021-03-29 19:50:22 --> Security Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:50:22 --> Input Class Initialized
INFO - 2021-03-29 19:50:22 --> Language Class Initialized
INFO - 2021-03-29 19:50:22 --> Loader Class Initialized
INFO - 2021-03-29 19:50:22 --> Helper loaded: url_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: form_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: common_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: util_helper
INFO - 2021-03-29 19:50:22 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:50:22 --> Form Validation Class Initialized
INFO - 2021-03-29 19:50:22 --> Controller Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:50:22 --> Final output sent to browser
DEBUG - 2021-03-29 19:50:22 --> Total execution time: 0.0506
INFO - 2021-03-29 19:50:22 --> Config Class Initialized
INFO - 2021-03-29 19:50:22 --> Hooks Class Initialized
INFO - 2021-03-29 19:50:22 --> Config Class Initialized
INFO - 2021-03-29 19:50:22 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:50:22 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 19:50:22 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:50:22 --> Utf8 Class Initialized
INFO - 2021-03-29 19:50:22 --> Utf8 Class Initialized
INFO - 2021-03-29 19:50:22 --> URI Class Initialized
INFO - 2021-03-29 19:50:22 --> URI Class Initialized
INFO - 2021-03-29 19:50:22 --> Router Class Initialized
INFO - 2021-03-29 19:50:22 --> Router Class Initialized
INFO - 2021-03-29 19:50:22 --> Output Class Initialized
INFO - 2021-03-29 19:50:22 --> Output Class Initialized
INFO - 2021-03-29 19:50:22 --> Security Class Initialized
INFO - 2021-03-29 19:50:22 --> Security Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:50:22 --> Input Class Initialized
INFO - 2021-03-29 19:50:22 --> Language Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:50:22 --> Input Class Initialized
INFO - 2021-03-29 19:50:22 --> Loader Class Initialized
INFO - 2021-03-29 19:50:22 --> Language Class Initialized
INFO - 2021-03-29 19:50:22 --> Helper loaded: url_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: form_helper
INFO - 2021-03-29 19:50:22 --> Loader Class Initialized
INFO - 2021-03-29 19:50:22 --> Helper loaded: common_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: util_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: url_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: form_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: common_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: util_helper
INFO - 2021-03-29 19:50:22 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:50:22 --> Database Driver Class Initialized
INFO - 2021-03-29 19:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:50:22 --> Form Validation Class Initialized
INFO - 2021-03-29 19:50:22 --> Controller Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:50:22 --> Final output sent to browser
DEBUG - 2021-03-29 19:50:22 --> Total execution time: 0.0465
INFO - 2021-03-29 19:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:50:22 --> Config Class Initialized
INFO - 2021-03-29 19:50:22 --> Hooks Class Initialized
INFO - 2021-03-29 19:50:22 --> Form Validation Class Initialized
INFO - 2021-03-29 19:50:22 --> Config Class Initialized
INFO - 2021-03-29 19:50:22 --> Hooks Class Initialized
INFO - 2021-03-29 19:50:22 --> Controller Class Initialized
DEBUG - 2021-03-29 19:50:22 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:50:22 --> Utf8 Class Initialized
INFO - 2021-03-29 19:50:22 --> URI Class Initialized
DEBUG - 2021-03-29 19:50:22 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:50:22 --> Utf8 Class Initialized
INFO - 2021-03-29 19:50:22 --> Router Class Initialized
INFO - 2021-03-29 19:50:22 --> URI Class Initialized
INFO - 2021-03-29 19:50:22 --> Output Class Initialized
INFO - 2021-03-29 19:50:22 --> Router Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Security Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Output Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:50:22 --> Input Class Initialized
INFO - 2021-03-29 19:50:22 --> Security Class Initialized
INFO - 2021-03-29 19:50:22 --> Language Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:50:22 --> Input Class Initialized
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:50:22 --> Language Class Initialized
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:50:22 --> Loader Class Initialized
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:50:22 --> Final output sent to browser
INFO - 2021-03-29 19:50:22 --> Helper loaded: url_helper
DEBUG - 2021-03-29 19:50:22 --> Total execution time: 0.0675
INFO - 2021-03-29 19:50:22 --> Loader Class Initialized
INFO - 2021-03-29 19:50:22 --> Helper loaded: form_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: url_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: common_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: form_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: util_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: common_helper
INFO - 2021-03-29 19:50:22 --> Helper loaded: util_helper
INFO - 2021-03-29 19:50:22 --> Database Driver Class Initialized
INFO - 2021-03-29 19:50:22 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:50:22 --> Form Validation Class Initialized
INFO - 2021-03-29 19:50:22 --> Controller Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
DEBUG - 2021-03-29 19:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:50:22 --> Final output sent to browser
DEBUG - 2021-03-29 19:50:22 --> Total execution time: 0.0512
INFO - 2021-03-29 19:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:50:22 --> Form Validation Class Initialized
INFO - 2021-03-29 19:50:22 --> Controller Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> Model Class Initialized
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:50:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:50:22 --> Final output sent to browser
DEBUG - 2021-03-29 19:50:22 --> Total execution time: 0.0614
INFO - 2021-03-29 19:54:26 --> Config Class Initialized
INFO - 2021-03-29 19:54:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:26 --> URI Class Initialized
INFO - 2021-03-29 19:54:26 --> Router Class Initialized
INFO - 2021-03-29 19:54:26 --> Output Class Initialized
INFO - 2021-03-29 19:54:26 --> Security Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:26 --> Input Class Initialized
INFO - 2021-03-29 19:54:26 --> Language Class Initialized
INFO - 2021-03-29 19:54:26 --> Loader Class Initialized
INFO - 2021-03-29 19:54:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:26 --> Controller Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:26 --> Total execution time: 0.0365
INFO - 2021-03-29 19:54:26 --> Config Class Initialized
INFO - 2021-03-29 19:54:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:26 --> Config Class Initialized
INFO - 2021-03-29 19:54:26 --> URI Class Initialized
INFO - 2021-03-29 19:54:26 --> Hooks Class Initialized
INFO - 2021-03-29 19:54:26 --> Router Class Initialized
DEBUG - 2021-03-29 19:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:26 --> Output Class Initialized
INFO - 2021-03-29 19:54:26 --> Security Class Initialized
INFO - 2021-03-29 19:54:26 --> URI Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:26 --> Input Class Initialized
INFO - 2021-03-29 19:54:26 --> Router Class Initialized
INFO - 2021-03-29 19:54:26 --> Language Class Initialized
INFO - 2021-03-29 19:54:26 --> Output Class Initialized
INFO - 2021-03-29 19:54:26 --> Security Class Initialized
INFO - 2021-03-29 19:54:26 --> Loader Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:26 --> Input Class Initialized
INFO - 2021-03-29 19:54:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:26 --> Language Class Initialized
INFO - 2021-03-29 19:54:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:26 --> Loader Class Initialized
INFO - 2021-03-29 19:54:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:26 --> Database Driver Class Initialized
INFO - 2021-03-29 19:54:26 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:26 --> Database Driver Class Initialized
INFO - 2021-03-29 19:54:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:26 --> Controller Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:26 --> Total execution time: 0.0466
INFO - 2021-03-29 19:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:26 --> Controller Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:26 --> Final output sent to browser
INFO - 2021-03-29 19:54:26 --> Config Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Total execution time: 0.0555
INFO - 2021-03-29 19:54:26 --> Hooks Class Initialized
INFO - 2021-03-29 19:54:26 --> Config Class Initialized
INFO - 2021-03-29 19:54:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:26 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:26 --> URI Class Initialized
INFO - 2021-03-29 19:54:26 --> URI Class Initialized
INFO - 2021-03-29 19:54:26 --> Router Class Initialized
INFO - 2021-03-29 19:54:26 --> Router Class Initialized
INFO - 2021-03-29 19:54:26 --> Output Class Initialized
INFO - 2021-03-29 19:54:26 --> Output Class Initialized
INFO - 2021-03-29 19:54:26 --> Security Class Initialized
INFO - 2021-03-29 19:54:26 --> Security Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:26 --> Input Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:26 --> Input Class Initialized
INFO - 2021-03-29 19:54:26 --> Language Class Initialized
INFO - 2021-03-29 19:54:26 --> Language Class Initialized
INFO - 2021-03-29 19:54:26 --> Loader Class Initialized
INFO - 2021-03-29 19:54:26 --> Loader Class Initialized
INFO - 2021-03-29 19:54:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:26 --> Database Driver Class Initialized
INFO - 2021-03-29 19:54:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 19:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:26 --> Controller Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:26 --> Total execution time: 0.0498
INFO - 2021-03-29 19:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:26 --> Controller Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> Model Class Initialized
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:26 --> Total execution time: 0.0616
INFO - 2021-03-29 19:54:40 --> Config Class Initialized
INFO - 2021-03-29 19:54:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:54:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:40 --> URI Class Initialized
INFO - 2021-03-29 19:54:40 --> Router Class Initialized
INFO - 2021-03-29 19:54:40 --> Output Class Initialized
INFO - 2021-03-29 19:54:40 --> Security Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:40 --> Input Class Initialized
INFO - 2021-03-29 19:54:40 --> Language Class Initialized
INFO - 2021-03-29 19:54:40 --> Loader Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:40 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:40 --> Controller Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 19:54:40 --> Config Class Initialized
INFO - 2021-03-29 19:54:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:54:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:40 --> URI Class Initialized
INFO - 2021-03-29 19:54:40 --> Router Class Initialized
INFO - 2021-03-29 19:54:40 --> Output Class Initialized
INFO - 2021-03-29 19:54:40 --> Security Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:40 --> Input Class Initialized
INFO - 2021-03-29 19:54:40 --> Language Class Initialized
INFO - 2021-03-29 19:54:40 --> Loader Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:40 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:40 --> Controller Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:40 --> Total execution time: 0.0509
INFO - 2021-03-29 19:54:40 --> Config Class Initialized
INFO - 2021-03-29 19:54:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:54:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:40 --> URI Class Initialized
INFO - 2021-03-29 19:54:40 --> Config Class Initialized
INFO - 2021-03-29 19:54:40 --> Hooks Class Initialized
INFO - 2021-03-29 19:54:40 --> Router Class Initialized
INFO - 2021-03-29 19:54:40 --> Output Class Initialized
DEBUG - 2021-03-29 19:54:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:40 --> Security Class Initialized
INFO - 2021-03-29 19:54:40 --> URI Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:40 --> Input Class Initialized
INFO - 2021-03-29 19:54:40 --> Router Class Initialized
INFO - 2021-03-29 19:54:40 --> Language Class Initialized
INFO - 2021-03-29 19:54:40 --> Output Class Initialized
INFO - 2021-03-29 19:54:40 --> Loader Class Initialized
INFO - 2021-03-29 19:54:40 --> Security Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: url_helper
DEBUG - 2021-03-29 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:40 --> Input Class Initialized
INFO - 2021-03-29 19:54:40 --> Language Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:40 --> Loader Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:40 --> Database Driver Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:40 --> Controller Class Initialized
INFO - 2021-03-29 19:54:40 --> Database Driver Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:40 --> Total execution time: 0.0461
INFO - 2021-03-29 19:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:40 --> Controller Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:40 --> Config Class Initialized
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:40 --> Hooks Class Initialized
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:40 --> Total execution time: 0.0601
INFO - 2021-03-29 19:54:40 --> Config Class Initialized
DEBUG - 2021-03-29 19:54:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:40 --> Hooks Class Initialized
INFO - 2021-03-29 19:54:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:40 --> URI Class Initialized
DEBUG - 2021-03-29 19:54:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:54:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:54:40 --> URI Class Initialized
INFO - 2021-03-29 19:54:40 --> Router Class Initialized
INFO - 2021-03-29 19:54:40 --> Router Class Initialized
INFO - 2021-03-29 19:54:40 --> Output Class Initialized
INFO - 2021-03-29 19:54:40 --> Output Class Initialized
INFO - 2021-03-29 19:54:40 --> Security Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:40 --> Security Class Initialized
INFO - 2021-03-29 19:54:40 --> Input Class Initialized
INFO - 2021-03-29 19:54:40 --> Language Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:54:40 --> Input Class Initialized
INFO - 2021-03-29 19:54:40 --> Language Class Initialized
INFO - 2021-03-29 19:54:40 --> Loader Class Initialized
INFO - 2021-03-29 19:54:40 --> Loader Class Initialized
INFO - 2021-03-29 19:54:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:54:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:54:40 --> Database Driver Class Initialized
INFO - 2021-03-29 19:54:40 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:54:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:40 --> Controller Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:40 --> Total execution time: 0.0489
INFO - 2021-03-29 19:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:54:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:54:40 --> Controller Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> Model Class Initialized
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:54:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:54:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:54:40 --> Total execution time: 0.0581
INFO - 2021-03-29 19:55:17 --> Config Class Initialized
INFO - 2021-03-29 19:55:17 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:17 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:17 --> URI Class Initialized
INFO - 2021-03-29 19:55:17 --> Router Class Initialized
INFO - 2021-03-29 19:55:17 --> Output Class Initialized
INFO - 2021-03-29 19:55:17 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:17 --> Input Class Initialized
INFO - 2021-03-29 19:55:18 --> Language Class Initialized
INFO - 2021-03-29 19:55:18 --> Loader Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:18 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:18 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:18 --> Controller Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:18 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:18 --> Total execution time: 0.0397
INFO - 2021-03-29 19:55:18 --> Config Class Initialized
INFO - 2021-03-29 19:55:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:18 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:18 --> Config Class Initialized
INFO - 2021-03-29 19:55:18 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:18 --> URI Class Initialized
INFO - 2021-03-29 19:55:18 --> Router Class Initialized
DEBUG - 2021-03-29 19:55:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:18 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:18 --> URI Class Initialized
INFO - 2021-03-29 19:55:18 --> Output Class Initialized
INFO - 2021-03-29 19:55:18 --> Router Class Initialized
INFO - 2021-03-29 19:55:18 --> Security Class Initialized
INFO - 2021-03-29 19:55:18 --> Output Class Initialized
DEBUG - 2021-03-29 19:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:18 --> Input Class Initialized
INFO - 2021-03-29 19:55:18 --> Security Class Initialized
INFO - 2021-03-29 19:55:18 --> Language Class Initialized
DEBUG - 2021-03-29 19:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:18 --> Input Class Initialized
INFO - 2021-03-29 19:55:18 --> Language Class Initialized
INFO - 2021-03-29 19:55:18 --> Loader Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:18 --> Loader Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:18 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:18 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 19:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:18 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:18 --> Controller Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:18 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:18 --> Total execution time: 0.0522
INFO - 2021-03-29 19:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:18 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:18 --> Config Class Initialized
INFO - 2021-03-29 19:55:18 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:18 --> Controller Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
DEBUG - 2021-03-29 19:55:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:18 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> URI Class Initialized
INFO - 2021-03-29 19:55:18 --> Config Class Initialized
INFO - 2021-03-29 19:55:18 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:18 --> Router Class Initialized
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 19:55:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:18 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:18 --> Output Class Initialized
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:18 --> URI Class Initialized
INFO - 2021-03-29 19:55:18 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:18 --> Total execution time: 0.0643
INFO - 2021-03-29 19:55:18 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:18 --> Input Class Initialized
INFO - 2021-03-29 19:55:18 --> Router Class Initialized
INFO - 2021-03-29 19:55:18 --> Language Class Initialized
INFO - 2021-03-29 19:55:18 --> Output Class Initialized
INFO - 2021-03-29 19:55:18 --> Loader Class Initialized
INFO - 2021-03-29 19:55:18 --> Security Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: url_helper
DEBUG - 2021-03-29 19:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:18 --> Input Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:18 --> Language Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:18 --> Loader Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:18 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:18 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:18 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:18 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:18 --> Controller Class Initialized
INFO - 2021-03-29 19:55:18 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
DEBUG - 2021-03-29 19:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:18 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:18 --> Total execution time: 0.0537
INFO - 2021-03-29 19:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:18 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:18 --> Controller Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> Model Class Initialized
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:18 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:18 --> Total execution time: 0.0669
INFO - 2021-03-29 19:55:19 --> Config Class Initialized
INFO - 2021-03-29 19:55:19 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:19 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:19 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:19 --> URI Class Initialized
INFO - 2021-03-29 19:55:19 --> Router Class Initialized
INFO - 2021-03-29 19:55:19 --> Output Class Initialized
INFO - 2021-03-29 19:55:19 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:19 --> Input Class Initialized
INFO - 2021-03-29 19:55:19 --> Language Class Initialized
INFO - 2021-03-29 19:55:19 --> Loader Class Initialized
INFO - 2021-03-29 19:55:19 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:19 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:19 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:19 --> Controller Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:19 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:19 --> Total execution time: 0.0346
INFO - 2021-03-29 19:55:19 --> Config Class Initialized
INFO - 2021-03-29 19:55:19 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:19 --> Config Class Initialized
INFO - 2021-03-29 19:55:19 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:19 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:19 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:19 --> URI Class Initialized
DEBUG - 2021-03-29 19:55:19 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:19 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:19 --> Router Class Initialized
INFO - 2021-03-29 19:55:19 --> URI Class Initialized
INFO - 2021-03-29 19:55:19 --> Output Class Initialized
INFO - 2021-03-29 19:55:19 --> Router Class Initialized
INFO - 2021-03-29 19:55:19 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:19 --> Input Class Initialized
INFO - 2021-03-29 19:55:19 --> Output Class Initialized
INFO - 2021-03-29 19:55:19 --> Language Class Initialized
INFO - 2021-03-29 19:55:19 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:19 --> Loader Class Initialized
INFO - 2021-03-29 19:55:19 --> Input Class Initialized
INFO - 2021-03-29 19:55:19 --> Language Class Initialized
INFO - 2021-03-29 19:55:19 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:19 --> Loader Class Initialized
INFO - 2021-03-29 19:55:19 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:19 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:19 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:19 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:19 --> Controller Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Config Class Initialized
INFO - 2021-03-29 19:55:19 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
DEBUG - 2021-03-29 19:55:19 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:19 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:19 --> URI Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:19 --> Router Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:19 --> Output Class Initialized
INFO - 2021-03-29 19:55:19 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:19 --> Total execution time: 0.0465
INFO - 2021-03-29 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:19 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:19 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:19 --> Input Class Initialized
INFO - 2021-03-29 19:55:19 --> Controller Class Initialized
INFO - 2021-03-29 19:55:19 --> Language Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Config Class Initialized
INFO - 2021-03-29 19:55:19 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:19 --> Loader Class Initialized
INFO - 2021-03-29 19:55:19 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 19:55:19 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:19 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:19 --> URI Class Initialized
INFO - 2021-03-29 19:55:19 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:19 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:19 --> Router Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:19 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:19 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:19 --> Total execution time: 0.0594
INFO - 2021-03-29 19:55:19 --> Output Class Initialized
INFO - 2021-03-29 19:55:19 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:19 --> Input Class Initialized
INFO - 2021-03-29 19:55:19 --> Language Class Initialized
INFO - 2021-03-29 19:55:19 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:19 --> Loader Class Initialized
DEBUG - 2021-03-29 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:19 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:19 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:19 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:19 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:19 --> Controller Class Initialized
INFO - 2021-03-29 19:55:19 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:19 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:19 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:19 --> Total execution time: 0.0475
DEBUG - 2021-03-29 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:19 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:19 --> Controller Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> Model Class Initialized
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:19 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:19 --> Total execution time: 0.0472
INFO - 2021-03-29 19:55:26 --> Config Class Initialized
INFO - 2021-03-29 19:55:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:26 --> URI Class Initialized
INFO - 2021-03-29 19:55:26 --> Router Class Initialized
INFO - 2021-03-29 19:55:26 --> Output Class Initialized
INFO - 2021-03-29 19:55:26 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:26 --> Input Class Initialized
INFO - 2021-03-29 19:55:26 --> Language Class Initialized
INFO - 2021-03-29 19:55:26 --> Loader Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:26 --> Controller Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 19:55:26 --> Config Class Initialized
INFO - 2021-03-29 19:55:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:26 --> URI Class Initialized
INFO - 2021-03-29 19:55:26 --> Router Class Initialized
INFO - 2021-03-29 19:55:26 --> Output Class Initialized
INFO - 2021-03-29 19:55:26 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:26 --> Input Class Initialized
INFO - 2021-03-29 19:55:26 --> Language Class Initialized
INFO - 2021-03-29 19:55:26 --> Loader Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:26 --> Controller Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:26 --> Total execution time: 0.0493
INFO - 2021-03-29 19:55:26 --> Config Class Initialized
INFO - 2021-03-29 19:55:26 --> Config Class Initialized
INFO - 2021-03-29 19:55:26 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 19:55:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:26 --> URI Class Initialized
INFO - 2021-03-29 19:55:26 --> URI Class Initialized
INFO - 2021-03-29 19:55:26 --> Router Class Initialized
INFO - 2021-03-29 19:55:26 --> Router Class Initialized
INFO - 2021-03-29 19:55:26 --> Output Class Initialized
INFO - 2021-03-29 19:55:26 --> Output Class Initialized
INFO - 2021-03-29 19:55:26 --> Security Class Initialized
INFO - 2021-03-29 19:55:26 --> Security Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 19:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:26 --> Input Class Initialized
INFO - 2021-03-29 19:55:26 --> Input Class Initialized
INFO - 2021-03-29 19:55:26 --> Language Class Initialized
INFO - 2021-03-29 19:55:26 --> Language Class Initialized
INFO - 2021-03-29 19:55:26 --> Config Class Initialized
INFO - 2021-03-29 19:55:26 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:26 --> Loader Class Initialized
INFO - 2021-03-29 19:55:26 --> Loader Class Initialized
DEBUG - 2021-03-29 19:55:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:26 --> URI Class Initialized
INFO - 2021-03-29 19:55:26 --> Config Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:26 --> Hooks Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:55:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:55:26 --> Utf8 Class Initialized
INFO - 2021-03-29 19:55:26 --> URI Class Initialized
INFO - 2021-03-29 19:55:26 --> Router Class Initialized
INFO - 2021-03-29 19:55:26 --> Router Class Initialized
INFO - 2021-03-29 19:55:26 --> Output Class Initialized
INFO - 2021-03-29 19:55:26 --> Output Class Initialized
INFO - 2021-03-29 19:55:26 --> Security Class Initialized
INFO - 2021-03-29 19:55:26 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:26 --> Security Class Initialized
INFO - 2021-03-29 19:55:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:26 --> Input Class Initialized
INFO - 2021-03-29 19:55:26 --> Language Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:26 --> Loader Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:55:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:26 --> Controller Class Initialized
INFO - 2021-03-29 19:55:26 --> Input Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:26 --> Language Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:26 --> Loader Class Initialized
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:26 --> Helper loaded: url_helper
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:26 --> Total execution time: 0.0534
INFO - 2021-03-29 19:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:26 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: form_helper
INFO - 2021-03-29 19:55:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:26 --> Controller Class Initialized
INFO - 2021-03-29 19:55:26 --> Helper loaded: common_helper
INFO - 2021-03-29 19:55:26 --> Helper loaded: util_helper
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
DEBUG - 2021-03-29 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:26 --> Database Driver Class Initialized
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:26 --> Total execution time: 0.0665
INFO - 2021-03-29 19:55:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 19:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:55:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:26 --> Controller Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:26 --> Total execution time: 0.0569
INFO - 2021-03-29 19:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:55:26 --> Form Validation Class Initialized
INFO - 2021-03-29 19:55:26 --> Controller Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> Model Class Initialized
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:55:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:55:26 --> Final output sent to browser
DEBUG - 2021-03-29 19:55:26 --> Total execution time: 0.0756
INFO - 2021-03-29 19:56:09 --> Config Class Initialized
INFO - 2021-03-29 19:56:09 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:56:09 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:09 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:09 --> URI Class Initialized
INFO - 2021-03-29 19:56:09 --> Router Class Initialized
INFO - 2021-03-29 19:56:09 --> Output Class Initialized
INFO - 2021-03-29 19:56:09 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:09 --> Input Class Initialized
INFO - 2021-03-29 19:56:09 --> Language Class Initialized
INFO - 2021-03-29 19:56:09 --> Loader Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:09 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:09 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:09 --> Controller Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:09 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:09 --> Total execution time: 0.0363
INFO - 2021-03-29 19:56:09 --> Config Class Initialized
INFO - 2021-03-29 19:56:09 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:56:09 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:09 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:09 --> URI Class Initialized
INFO - 2021-03-29 19:56:09 --> Router Class Initialized
INFO - 2021-03-29 19:56:09 --> Output Class Initialized
INFO - 2021-03-29 19:56:09 --> Config Class Initialized
INFO - 2021-03-29 19:56:09 --> Hooks Class Initialized
INFO - 2021-03-29 19:56:09 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:09 --> Input Class Initialized
INFO - 2021-03-29 19:56:09 --> Language Class Initialized
DEBUG - 2021-03-29 19:56:09 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:09 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:09 --> URI Class Initialized
INFO - 2021-03-29 19:56:09 --> Loader Class Initialized
INFO - 2021-03-29 19:56:09 --> Router Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:09 --> Output Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:09 --> Security Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:09 --> Input Class Initialized
INFO - 2021-03-29 19:56:09 --> Language Class Initialized
INFO - 2021-03-29 19:56:09 --> Loader Class Initialized
INFO - 2021-03-29 19:56:09 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:09 --> Config Class Initialized
DEBUG - 2021-03-29 19:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:09 --> Hooks Class Initialized
INFO - 2021-03-29 19:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:09 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:09 --> Controller Class Initialized
DEBUG - 2021-03-29 19:56:09 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:09 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:09 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> URI Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Router Class Initialized
INFO - 2021-03-29 19:56:09 --> Config Class Initialized
INFO - 2021-03-29 19:56:09 --> Output Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 19:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:09 --> Hooks Class Initialized
INFO - 2021-03-29 19:56:09 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 19:56:09 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:09 --> Input Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:09 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:09 --> Language Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:09 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:09 --> Total execution time: 0.0497
INFO - 2021-03-29 19:56:09 --> URI Class Initialized
INFO - 2021-03-29 19:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:09 --> Router Class Initialized
INFO - 2021-03-29 19:56:09 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:09 --> Controller Class Initialized
INFO - 2021-03-29 19:56:09 --> Loader Class Initialized
INFO - 2021-03-29 19:56:09 --> Output Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:09 --> Security Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:09 --> Input Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:09 --> Language Class Initialized
INFO - 2021-03-29 19:56:09 --> Loader Class Initialized
INFO - 2021-03-29 19:56:09 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:09 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:09 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:09 --> Total execution time: 0.0669
INFO - 2021-03-29 19:56:09 --> Helper loaded: form_helper
DEBUG - 2021-03-29 19:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:09 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:09 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:09 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:09 --> Controller Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-29 19:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:09 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:09 --> Total execution time: 0.0571
INFO - 2021-03-29 19:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:09 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:09 --> Controller Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> Model Class Initialized
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:09 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:09 --> Total execution time: 0.0649
INFO - 2021-03-29 19:56:16 --> Config Class Initialized
INFO - 2021-03-29 19:56:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:16 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:16 --> URI Class Initialized
INFO - 2021-03-29 19:56:16 --> Router Class Initialized
INFO - 2021-03-29 19:56:16 --> Output Class Initialized
INFO - 2021-03-29 19:56:16 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:16 --> Input Class Initialized
INFO - 2021-03-29 19:56:16 --> Language Class Initialized
INFO - 2021-03-29 19:56:16 --> Loader Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:16 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:16 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:16 --> Controller Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 19:56:16 --> Config Class Initialized
INFO - 2021-03-29 19:56:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:16 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:16 --> URI Class Initialized
INFO - 2021-03-29 19:56:16 --> Router Class Initialized
INFO - 2021-03-29 19:56:16 --> Output Class Initialized
INFO - 2021-03-29 19:56:16 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:16 --> Input Class Initialized
INFO - 2021-03-29 19:56:16 --> Language Class Initialized
INFO - 2021-03-29 19:56:16 --> Loader Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:16 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:16 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:16 --> Controller Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:16 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:16 --> Total execution time: 0.0501
INFO - 2021-03-29 19:56:16 --> Config Class Initialized
INFO - 2021-03-29 19:56:16 --> Hooks Class Initialized
INFO - 2021-03-29 19:56:16 --> Config Class Initialized
INFO - 2021-03-29 19:56:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:16 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:16 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:16 --> URI Class Initialized
INFO - 2021-03-29 19:56:16 --> URI Class Initialized
INFO - 2021-03-29 19:56:16 --> Router Class Initialized
INFO - 2021-03-29 19:56:16 --> Router Class Initialized
INFO - 2021-03-29 19:56:16 --> Output Class Initialized
INFO - 2021-03-29 19:56:16 --> Output Class Initialized
INFO - 2021-03-29 19:56:16 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:16 --> Input Class Initialized
INFO - 2021-03-29 19:56:16 --> Security Class Initialized
INFO - 2021-03-29 19:56:16 --> Language Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:16 --> Input Class Initialized
INFO - 2021-03-29 19:56:16 --> Language Class Initialized
INFO - 2021-03-29 19:56:16 --> Loader Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:16 --> Loader Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:16 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:16 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:16 --> Config Class Initialized
INFO - 2021-03-29 19:56:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:16 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:16 --> Controller Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
DEBUG - 2021-03-29 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:16 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> URI Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:16 --> Router Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:16 --> Output Class Initialized
INFO - 2021-03-29 19:56:16 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:16 --> Total execution time: 0.0475
INFO - 2021-03-29 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:16 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:16 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:16 --> Input Class Initialized
INFO - 2021-03-29 19:56:16 --> Controller Class Initialized
INFO - 2021-03-29 19:56:16 --> Config Class Initialized
INFO - 2021-03-29 19:56:16 --> Hooks Class Initialized
INFO - 2021-03-29 19:56:16 --> Language Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
DEBUG - 2021-03-29 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:56:16 --> Utf8 Class Initialized
INFO - 2021-03-29 19:56:16 --> Loader Class Initialized
INFO - 2021-03-29 19:56:16 --> URI Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:16 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:16 --> Router Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:16 --> Output Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:16 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:16 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:16 --> Total execution time: 0.0603
INFO - 2021-03-29 19:56:16 --> Security Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:56:16 --> Input Class Initialized
INFO - 2021-03-29 19:56:16 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:16 --> Language Class Initialized
INFO - 2021-03-29 19:56:16 --> Loader Class Initialized
DEBUG - 2021-03-29 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:16 --> Helper loaded: url_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: form_helper
INFO - 2021-03-29 19:56:16 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:16 --> Controller Class Initialized
INFO - 2021-03-29 19:56:16 --> Helper loaded: common_helper
INFO - 2021-03-29 19:56:16 --> Helper loaded: util_helper
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:16 --> Database Driver Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:16 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:16 --> Total execution time: 0.0519
DEBUG - 2021-03-29 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:56:16 --> Form Validation Class Initialized
INFO - 2021-03-29 19:56:16 --> Controller Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> Model Class Initialized
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:56:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:56:16 --> Final output sent to browser
DEBUG - 2021-03-29 19:56:16 --> Total execution time: 0.0689
INFO - 2021-03-29 19:57:37 --> Config Class Initialized
INFO - 2021-03-29 19:57:37 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:37 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:37 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:37 --> URI Class Initialized
INFO - 2021-03-29 19:57:37 --> Router Class Initialized
INFO - 2021-03-29 19:57:37 --> Output Class Initialized
INFO - 2021-03-29 19:57:37 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:37 --> Input Class Initialized
INFO - 2021-03-29 19:57:37 --> Language Class Initialized
INFO - 2021-03-29 19:57:37 --> Loader Class Initialized
INFO - 2021-03-29 19:57:37 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:37 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:37 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:37 --> Controller Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:37 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:37 --> Total execution time: 0.0396
INFO - 2021-03-29 19:57:37 --> Config Class Initialized
INFO - 2021-03-29 19:57:37 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:37 --> Config Class Initialized
DEBUG - 2021-03-29 19:57:37 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:37 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:37 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:37 --> URI Class Initialized
DEBUG - 2021-03-29 19:57:37 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:37 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:37 --> Router Class Initialized
INFO - 2021-03-29 19:57:37 --> URI Class Initialized
INFO - 2021-03-29 19:57:37 --> Output Class Initialized
INFO - 2021-03-29 19:57:37 --> Security Class Initialized
INFO - 2021-03-29 19:57:37 --> Router Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:37 --> Input Class Initialized
INFO - 2021-03-29 19:57:37 --> Language Class Initialized
INFO - 2021-03-29 19:57:37 --> Output Class Initialized
INFO - 2021-03-29 19:57:37 --> Security Class Initialized
INFO - 2021-03-29 19:57:37 --> Loader Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:37 --> Input Class Initialized
INFO - 2021-03-29 19:57:37 --> Language Class Initialized
INFO - 2021-03-29 19:57:37 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:37 --> Loader Class Initialized
INFO - 2021-03-29 19:57:37 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:37 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:37 --> Config Class Initialized
INFO - 2021-03-29 19:57:37 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:37 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:37 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:37 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:37 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:37 --> Controller Class Initialized
INFO - 2021-03-29 19:57:37 --> URI Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:37 --> Router Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:37 --> Output Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:37 --> Security Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:37 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:37 --> Total execution time: 0.0462
DEBUG - 2021-03-29 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:37 --> Input Class Initialized
INFO - 2021-03-29 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:37 --> Language Class Initialized
INFO - 2021-03-29 19:57:37 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:37 --> Controller Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Loader Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:37 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:37 --> Config Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:37 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:37 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:37 --> Total execution time: 0.0611
INFO - 2021-03-29 19:57:37 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:37 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:37 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:37 --> URI Class Initialized
INFO - 2021-03-29 19:57:37 --> Router Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:37 --> Output Class Initialized
INFO - 2021-03-29 19:57:37 --> Security Class Initialized
INFO - 2021-03-29 19:57:37 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:37 --> Controller Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Input Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Language Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:37 --> Loader Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:37 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:37 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:37 --> Total execution time: 0.0521
INFO - 2021-03-29 19:57:37 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:37 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:37 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:37 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:37 --> Controller Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> Model Class Initialized
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:37 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:37 --> Total execution time: 0.0620
INFO - 2021-03-29 19:57:40 --> Config Class Initialized
INFO - 2021-03-29 19:57:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:40 --> URI Class Initialized
INFO - 2021-03-29 19:57:40 --> Router Class Initialized
INFO - 2021-03-29 19:57:40 --> Output Class Initialized
INFO - 2021-03-29 19:57:40 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:40 --> Input Class Initialized
INFO - 2021-03-29 19:57:40 --> Language Class Initialized
INFO - 2021-03-29 19:57:40 --> Loader Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:40 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:40 --> Controller Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:40 --> Total execution time: 0.0512
INFO - 2021-03-29 19:57:40 --> Config Class Initialized
INFO - 2021-03-29 19:57:40 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:40 --> Config Class Initialized
INFO - 2021-03-29 19:57:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:40 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:57:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:40 --> URI Class Initialized
INFO - 2021-03-29 19:57:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:40 --> URI Class Initialized
INFO - 2021-03-29 19:57:40 --> Router Class Initialized
INFO - 2021-03-29 19:57:40 --> Output Class Initialized
INFO - 2021-03-29 19:57:40 --> Router Class Initialized
INFO - 2021-03-29 19:57:40 --> Security Class Initialized
INFO - 2021-03-29 19:57:40 --> Output Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:40 --> Input Class Initialized
INFO - 2021-03-29 19:57:40 --> Security Class Initialized
INFO - 2021-03-29 19:57:40 --> Language Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:40 --> Input Class Initialized
INFO - 2021-03-29 19:57:40 --> Language Class Initialized
INFO - 2021-03-29 19:57:40 --> Loader Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:40 --> Loader Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:40 --> Config Class Initialized
INFO - 2021-03-29 19:57:40 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:40 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:40 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:40 --> Config Class Initialized
INFO - 2021-03-29 19:57:40 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:40 --> URI Class Initialized
DEBUG - 2021-03-29 19:57:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:40 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:40 --> URI Class Initialized
INFO - 2021-03-29 19:57:40 --> Router Class Initialized
INFO - 2021-03-29 19:57:40 --> Router Class Initialized
INFO - 2021-03-29 19:57:40 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:40 --> Output Class Initialized
INFO - 2021-03-29 19:57:40 --> Output Class Initialized
INFO - 2021-03-29 19:57:40 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 19:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:40 --> Input Class Initialized
INFO - 2021-03-29 19:57:40 --> Language Class Initialized
INFO - 2021-03-29 19:57:40 --> Security Class Initialized
INFO - 2021-03-29 19:57:40 --> Loader Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:40 --> Input Class Initialized
INFO - 2021-03-29 19:57:40 --> Language Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:40 --> Controller Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:40 --> Loader Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:40 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:40 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:40 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:40 --> Total execution time: 0.0638
INFO - 2021-03-29 19:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:40 --> Controller Class Initialized
DEBUG - 2021-03-29 19:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-29 19:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:40 --> Total execution time: 0.0791
INFO - 2021-03-29 19:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:40 --> Controller Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:40 --> Total execution time: 0.0602
INFO - 2021-03-29 19:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:40 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:40 --> Controller Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> Model Class Initialized
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:40 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:40 --> Total execution time: 0.0765
INFO - 2021-03-29 19:57:45 --> Config Class Initialized
INFO - 2021-03-29 19:57:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:45 --> URI Class Initialized
INFO - 2021-03-29 19:57:45 --> Router Class Initialized
INFO - 2021-03-29 19:57:45 --> Output Class Initialized
INFO - 2021-03-29 19:57:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:45 --> Input Class Initialized
INFO - 2021-03-29 19:57:45 --> Language Class Initialized
INFO - 2021-03-29 19:57:45 --> Loader Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:45 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:45 --> Controller Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 19:57:45 --> Config Class Initialized
INFO - 2021-03-29 19:57:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:45 --> URI Class Initialized
INFO - 2021-03-29 19:57:45 --> Router Class Initialized
INFO - 2021-03-29 19:57:45 --> Output Class Initialized
INFO - 2021-03-29 19:57:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:45 --> Input Class Initialized
INFO - 2021-03-29 19:57:45 --> Language Class Initialized
INFO - 2021-03-29 19:57:45 --> Loader Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:45 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:45 --> Controller Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:45 --> Total execution time: 0.0355
INFO - 2021-03-29 19:57:45 --> Config Class Initialized
INFO - 2021-03-29 19:57:45 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:45 --> Config Class Initialized
INFO - 2021-03-29 19:57:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:57:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:45 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:57:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:45 --> URI Class Initialized
INFO - 2021-03-29 19:57:45 --> URI Class Initialized
INFO - 2021-03-29 19:57:45 --> Router Class Initialized
INFO - 2021-03-29 19:57:45 --> Output Class Initialized
INFO - 2021-03-29 19:57:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:45 --> Input Class Initialized
INFO - 2021-03-29 19:57:45 --> Language Class Initialized
INFO - 2021-03-29 19:57:45 --> Config Class Initialized
INFO - 2021-03-29 19:57:45 --> Loader Class Initialized
INFO - 2021-03-29 19:57:45 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:45 --> Config Class Initialized
INFO - 2021-03-29 19:57:45 --> Hooks Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: url_helper
DEBUG - 2021-03-29 19:57:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: form_helper
DEBUG - 2021-03-29 19:57:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:57:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:57:45 --> URI Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:45 --> URI Class Initialized
INFO - 2021-03-29 19:57:45 --> Router Class Initialized
INFO - 2021-03-29 19:57:45 --> Router Class Initialized
INFO - 2021-03-29 19:57:45 --> Router Class Initialized
INFO - 2021-03-29 19:57:45 --> Output Class Initialized
INFO - 2021-03-29 19:57:45 --> Output Class Initialized
INFO - 2021-03-29 19:57:45 --> Security Class Initialized
INFO - 2021-03-29 19:57:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:45 --> Input Class Initialized
INFO - 2021-03-29 19:57:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:45 --> Language Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:45 --> Input Class Initialized
INFO - 2021-03-29 19:57:45 --> Language Class Initialized
INFO - 2021-03-29 19:57:45 --> Loader Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:45 --> Loader Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:45 --> Controller Class Initialized
INFO - 2021-03-29 19:57:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:45 --> Total execution time: 0.0447
INFO - 2021-03-29 19:57:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: common_helper
DEBUG - 2021-03-29 19:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:45 --> Output Class Initialized
INFO - 2021-03-29 19:57:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:45 --> Security Class Initialized
INFO - 2021-03-29 19:57:45 --> Controller Class Initialized
DEBUG - 2021-03-29 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Input Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Language Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:45 --> Loader Class Initialized
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-29 19:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:45 --> Final output sent to browser
INFO - 2021-03-29 19:57:45 --> Helper loaded: form_helper
DEBUG - 2021-03-29 19:57:45 --> Total execution time: 0.0462
INFO - 2021-03-29 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:57:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:57:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:45 --> Controller Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:45 --> Total execution time: 0.0599
DEBUG - 2021-03-29 19:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:57:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:57:45 --> Controller Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> Model Class Initialized
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:57:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:57:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:57:45 --> Total execution time: 0.0877
INFO - 2021-03-29 19:58:44 --> Config Class Initialized
INFO - 2021-03-29 19:58:44 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:44 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:44 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:44 --> URI Class Initialized
INFO - 2021-03-29 19:58:44 --> Router Class Initialized
INFO - 2021-03-29 19:58:44 --> Output Class Initialized
INFO - 2021-03-29 19:58:44 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:44 --> Input Class Initialized
INFO - 2021-03-29 19:58:44 --> Language Class Initialized
INFO - 2021-03-29 19:58:44 --> Loader Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:44 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:44 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:44 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:44 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:44 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:44 --> Controller Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:44 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:44 --> Total execution time: 0.0459
INFO - 2021-03-29 19:58:44 --> Config Class Initialized
INFO - 2021-03-29 19:58:44 --> Config Class Initialized
INFO - 2021-03-29 19:58:44 --> Hooks Class Initialized
INFO - 2021-03-29 19:58:44 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:44 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:44 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:44 --> URI Class Initialized
DEBUG - 2021-03-29 19:58:44 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:44 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:44 --> Router Class Initialized
INFO - 2021-03-29 19:58:44 --> URI Class Initialized
INFO - 2021-03-29 19:58:44 --> Output Class Initialized
INFO - 2021-03-29 19:58:44 --> Security Class Initialized
INFO - 2021-03-29 19:58:44 --> Router Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:44 --> Input Class Initialized
INFO - 2021-03-29 19:58:44 --> Output Class Initialized
INFO - 2021-03-29 19:58:44 --> Language Class Initialized
INFO - 2021-03-29 19:58:44 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:44 --> Loader Class Initialized
INFO - 2021-03-29 19:58:44 --> Input Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:44 --> Language Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:44 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:44 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:44 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:44 --> Config Class Initialized
INFO - 2021-03-29 19:58:44 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 19:58:44 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:44 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:44 --> URI Class Initialized
INFO - 2021-03-29 19:58:44 --> Loader Class Initialized
INFO - 2021-03-29 19:58:44 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:44 --> Controller Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:44 --> Router Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Output Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:44 --> Security Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:44 --> Input Class Initialized
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:44 --> Language Class Initialized
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:44 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:44 --> Total execution time: 0.0474
INFO - 2021-03-29 19:58:44 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:44 --> Loader Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:44 --> Helper loaded: form_helper
DEBUG - 2021-03-29 19:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:44 --> Config Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:44 --> Hooks Class Initialized
INFO - 2021-03-29 19:58:44 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:44 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:44 --> Controller Class Initialized
DEBUG - 2021-03-29 19:58:44 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:44 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> URI Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:44 --> Router Class Initialized
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
DEBUG - 2021-03-29 19:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:44 --> Output Class Initialized
INFO - 2021-03-29 19:58:44 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:44 --> Total execution time: 0.0687
INFO - 2021-03-29 19:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:44 --> Security Class Initialized
INFO - 2021-03-29 19:58:44 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:44 --> Controller Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:44 --> Input Class Initialized
INFO - 2021-03-29 19:58:44 --> Language Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Loader Class Initialized
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:44 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:44 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:44 --> Final output sent to browser
INFO - 2021-03-29 19:58:44 --> Helper loaded: common_helper
DEBUG - 2021-03-29 19:58:44 --> Total execution time: 0.0530
INFO - 2021-03-29 19:58:44 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:44 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:44 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:44 --> Controller Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> Model Class Initialized
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:44 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:44 --> Total execution time: 0.0754
INFO - 2021-03-29 19:58:45 --> Config Class Initialized
INFO - 2021-03-29 19:58:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:45 --> URI Class Initialized
INFO - 2021-03-29 19:58:45 --> Router Class Initialized
INFO - 2021-03-29 19:58:45 --> Output Class Initialized
INFO - 2021-03-29 19:58:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:45 --> Input Class Initialized
INFO - 2021-03-29 19:58:45 --> Language Class Initialized
INFO - 2021-03-29 19:58:45 --> Loader Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:45 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:45 --> Controller Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:45 --> Total execution time: 0.0374
INFO - 2021-03-29 19:58:45 --> Config Class Initialized
INFO - 2021-03-29 19:58:45 --> Hooks Class Initialized
INFO - 2021-03-29 19:58:45 --> Config Class Initialized
INFO - 2021-03-29 19:58:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:45 --> Utf8 Class Initialized
DEBUG - 2021-03-29 19:58:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:45 --> URI Class Initialized
INFO - 2021-03-29 19:58:45 --> URI Class Initialized
INFO - 2021-03-29 19:58:45 --> Router Class Initialized
INFO - 2021-03-29 19:58:45 --> Router Class Initialized
INFO - 2021-03-29 19:58:45 --> Output Class Initialized
INFO - 2021-03-29 19:58:45 --> Output Class Initialized
INFO - 2021-03-29 19:58:45 --> Security Class Initialized
INFO - 2021-03-29 19:58:45 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:45 --> Input Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:45 --> Input Class Initialized
INFO - 2021-03-29 19:58:45 --> Language Class Initialized
INFO - 2021-03-29 19:58:45 --> Language Class Initialized
INFO - 2021-03-29 19:58:45 --> Loader Class Initialized
INFO - 2021-03-29 19:58:45 --> Loader Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:45 --> Config Class Initialized
INFO - 2021-03-29 19:58:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 19:58:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:45 --> Controller Class Initialized
INFO - 2021-03-29 19:58:45 --> URI Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Router Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Output Class Initialized
INFO - 2021-03-29 19:58:45 --> Security Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:45 --> Config Class Initialized
INFO - 2021-03-29 19:58:45 --> Hooks Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-29 19:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:45 --> Input Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:45 --> Language Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:45 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 19:58:45 --> Total execution time: 0.0455
INFO - 2021-03-29 19:58:45 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:45 --> URI Class Initialized
INFO - 2021-03-29 19:58:45 --> Loader Class Initialized
INFO - 2021-03-29 19:58:45 --> Router Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:45 --> Output Class Initialized
INFO - 2021-03-29 19:58:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:45 --> Security Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: util_helper
DEBUG - 2021-03-29 19:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:45 --> Input Class Initialized
INFO - 2021-03-29 19:58:45 --> Language Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:45 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:45 --> Loader Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:45 --> Controller Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:45 --> Final output sent to browser
INFO - 2021-03-29 19:58:45 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Total execution time: 0.0730
INFO - 2021-03-29 19:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:45 --> Controller Class Initialized
DEBUG - 2021-03-29 19:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:45 --> Total execution time: 0.0549
INFO - 2021-03-29 19:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:45 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:45 --> Controller Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> Model Class Initialized
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:45 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:45 --> Total execution time: 0.0581
INFO - 2021-03-29 19:58:50 --> Config Class Initialized
INFO - 2021-03-29 19:58:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:50 --> URI Class Initialized
INFO - 2021-03-29 19:58:50 --> Router Class Initialized
INFO - 2021-03-29 19:58:50 --> Output Class Initialized
INFO - 2021-03-29 19:58:50 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:50 --> Input Class Initialized
INFO - 2021-03-29 19:58:50 --> Language Class Initialized
INFO - 2021-03-29 19:58:50 --> Loader Class Initialized
INFO - 2021-03-29 19:58:50 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:50 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:50 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:50 --> Controller Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 19:58:50 --> Config Class Initialized
INFO - 2021-03-29 19:58:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:50 --> URI Class Initialized
INFO - 2021-03-29 19:58:50 --> Router Class Initialized
INFO - 2021-03-29 19:58:50 --> Output Class Initialized
INFO - 2021-03-29 19:58:50 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:50 --> Input Class Initialized
INFO - 2021-03-29 19:58:50 --> Language Class Initialized
INFO - 2021-03-29 19:58:50 --> Loader Class Initialized
INFO - 2021-03-29 19:58:50 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:50 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:50 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:50 --> Controller Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:50 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:50 --> Total execution time: 0.0356
INFO - 2021-03-29 19:58:50 --> Config Class Initialized
INFO - 2021-03-29 19:58:50 --> Hooks Class Initialized
INFO - 2021-03-29 19:58:50 --> Config Class Initialized
DEBUG - 2021-03-29 19:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:50 --> Hooks Class Initialized
INFO - 2021-03-29 19:58:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:50 --> URI Class Initialized
DEBUG - 2021-03-29 19:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:50 --> Router Class Initialized
INFO - 2021-03-29 19:58:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:50 --> URI Class Initialized
INFO - 2021-03-29 19:58:50 --> Output Class Initialized
INFO - 2021-03-29 19:58:50 --> Router Class Initialized
INFO - 2021-03-29 19:58:50 --> Security Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:50 --> Input Class Initialized
INFO - 2021-03-29 19:58:50 --> Output Class Initialized
INFO - 2021-03-29 19:58:50 --> Language Class Initialized
INFO - 2021-03-29 19:58:50 --> Security Class Initialized
INFO - 2021-03-29 19:58:50 --> Loader Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:50 --> Input Class Initialized
INFO - 2021-03-29 19:58:50 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:50 --> Language Class Initialized
INFO - 2021-03-29 19:58:50 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:50 --> Loader Class Initialized
INFO - 2021-03-29 19:58:50 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:50 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:50 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:50 --> Config Class Initialized
INFO - 2021-03-29 19:58:50 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 19:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:50 --> URI Class Initialized
INFO - 2021-03-29 19:58:50 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:50 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:50 --> Controller Class Initialized
INFO - 2021-03-29 19:58:50 --> Router Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Config Class Initialized
INFO - 2021-03-29 19:58:50 --> Model Class Initialized
INFO - 2021-03-29 19:58:50 --> Hooks Class Initialized
DEBUG - 2021-03-29 19:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:50 --> Output Class Initialized
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 19:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-29 19:58:50 --> Utf8 Class Initialized
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:50 --> Security Class Initialized
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:50 --> URI Class Initialized
INFO - 2021-03-29 19:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:50 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:50 --> Total execution time: 0.0461
DEBUG - 2021-03-29 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:50 --> Input Class Initialized
INFO - 2021-03-29 19:58:50 --> Router Class Initialized
INFO - 2021-03-29 19:58:50 --> Language Class Initialized
INFO - 2021-03-29 19:58:50 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:51 --> Controller Class Initialized
INFO - 2021-03-29 19:58:51 --> Output Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> Security Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> Loader Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
DEBUG - 2021-03-29 19:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 19:58:51 --> Input Class Initialized
INFO - 2021-03-29 19:58:51 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:51 --> Language Class Initialized
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:51 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:51 --> Loader Class Initialized
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:51 --> Helper loaded: url_helper
INFO - 2021-03-29 19:58:51 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:51 --> Total execution time: 0.0600
INFO - 2021-03-29 19:58:51 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:51 --> Helper loaded: form_helper
INFO - 2021-03-29 19:58:51 --> Helper loaded: common_helper
INFO - 2021-03-29 19:58:51 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:51 --> Helper loaded: util_helper
INFO - 2021-03-29 19:58:51 --> Database Driver Class Initialized
INFO - 2021-03-29 19:58:51 --> Database Driver Class Initialized
DEBUG - 2021-03-29 19:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 19:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 19:58:51 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:51 --> Controller Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:51 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:51 --> Total execution time: 0.0576
INFO - 2021-03-29 19:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 19:58:51 --> Form Validation Class Initialized
INFO - 2021-03-29 19:58:51 --> Controller Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> Model Class Initialized
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 19:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 19:58:51 --> Final output sent to browser
DEBUG - 2021-03-29 19:58:51 --> Total execution time: 0.0581
INFO - 2021-03-29 20:00:18 --> Config Class Initialized
INFO - 2021-03-29 20:00:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:18 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:18 --> URI Class Initialized
INFO - 2021-03-29 20:00:18 --> Router Class Initialized
INFO - 2021-03-29 20:00:18 --> Output Class Initialized
INFO - 2021-03-29 20:00:18 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:18 --> Input Class Initialized
INFO - 2021-03-29 20:00:18 --> Language Class Initialized
INFO - 2021-03-29 20:00:18 --> Loader Class Initialized
INFO - 2021-03-29 20:00:18 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:18 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:18 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:18 --> Controller Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:18 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:18 --> Total execution time: 0.0487
INFO - 2021-03-29 20:00:18 --> Config Class Initialized
INFO - 2021-03-29 20:00:18 --> Hooks Class Initialized
INFO - 2021-03-29 20:00:18 --> Config Class Initialized
INFO - 2021-03-29 20:00:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:18 --> Utf8 Class Initialized
DEBUG - 2021-03-29 20:00:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:18 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:18 --> URI Class Initialized
INFO - 2021-03-29 20:00:18 --> URI Class Initialized
INFO - 2021-03-29 20:00:18 --> Router Class Initialized
INFO - 2021-03-29 20:00:18 --> Router Class Initialized
INFO - 2021-03-29 20:00:18 --> Output Class Initialized
INFO - 2021-03-29 20:00:18 --> Output Class Initialized
INFO - 2021-03-29 20:00:18 --> Security Class Initialized
INFO - 2021-03-29 20:00:18 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:18 --> Input Class Initialized
INFO - 2021-03-29 20:00:18 --> Language Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:18 --> Input Class Initialized
INFO - 2021-03-29 20:00:18 --> Language Class Initialized
INFO - 2021-03-29 20:00:18 --> Loader Class Initialized
INFO - 2021-03-29 20:00:18 --> Loader Class Initialized
INFO - 2021-03-29 20:00:18 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:18 --> Database Driver Class Initialized
INFO - 2021-03-29 20:00:18 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:18 --> Config Class Initialized
INFO - 2021-03-29 20:00:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:18 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:18 --> Controller Class Initialized
DEBUG - 2021-03-29 20:00:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:18 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> URI Class Initialized
INFO - 2021-03-29 20:00:18 --> Config Class Initialized
INFO - 2021-03-29 20:00:18 --> Hooks Class Initialized
INFO - 2021-03-29 20:00:18 --> Router Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:18 --> Output Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
DEBUG - 2021-03-29 20:00:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:18 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:18 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:18 --> Total execution time: 0.0459
INFO - 2021-03-29 20:00:18 --> Security Class Initialized
INFO - 2021-03-29 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:18 --> URI Class Initialized
INFO - 2021-03-29 20:00:18 --> Form Validation Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:18 --> Controller Class Initialized
INFO - 2021-03-29 20:00:18 --> Input Class Initialized
INFO - 2021-03-29 20:00:18 --> Router Class Initialized
INFO - 2021-03-29 20:00:18 --> Language Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Output Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Security Class Initialized
INFO - 2021-03-29 20:00:18 --> Loader Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:18 --> Input Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:18 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:18 --> Language Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:18 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:18 --> Total execution time: 0.0588
INFO - 2021-03-29 20:00:18 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:18 --> Loader Class Initialized
INFO - 2021-03-29 20:00:18 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:18 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:18 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:18 --> Database Driver Class Initialized
INFO - 2021-03-29 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:18 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:18 --> Controller Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
DEBUG - 2021-03-29 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:18 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:18 --> Total execution time: 0.0563
INFO - 2021-03-29 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:18 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:18 --> Controller Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> Model Class Initialized
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:18 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:18 --> Total execution time: 0.0635
INFO - 2021-03-29 20:00:26 --> Config Class Initialized
INFO - 2021-03-29 20:00:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:26 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:26 --> URI Class Initialized
INFO - 2021-03-29 20:00:26 --> Router Class Initialized
INFO - 2021-03-29 20:00:26 --> Output Class Initialized
INFO - 2021-03-29 20:00:26 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:26 --> Input Class Initialized
INFO - 2021-03-29 20:00:26 --> Language Class Initialized
INFO - 2021-03-29 20:00:26 --> Loader Class Initialized
INFO - 2021-03-29 20:00:26 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:26 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:26 --> Controller Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 20:00:26 --> Config Class Initialized
INFO - 2021-03-29 20:00:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:26 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:26 --> URI Class Initialized
INFO - 2021-03-29 20:00:26 --> Router Class Initialized
INFO - 2021-03-29 20:00:26 --> Output Class Initialized
INFO - 2021-03-29 20:00:26 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:26 --> Input Class Initialized
INFO - 2021-03-29 20:00:26 --> Language Class Initialized
INFO - 2021-03-29 20:00:26 --> Loader Class Initialized
INFO - 2021-03-29 20:00:26 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:26 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:26 --> Controller Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:26 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:26 --> Total execution time: 0.0331
INFO - 2021-03-29 20:00:26 --> Config Class Initialized
INFO - 2021-03-29 20:00:26 --> Hooks Class Initialized
INFO - 2021-03-29 20:00:26 --> Config Class Initialized
INFO - 2021-03-29 20:00:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:26 --> Utf8 Class Initialized
DEBUG - 2021-03-29 20:00:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:26 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:26 --> URI Class Initialized
INFO - 2021-03-29 20:00:26 --> URI Class Initialized
INFO - 2021-03-29 20:00:26 --> Router Class Initialized
INFO - 2021-03-29 20:00:26 --> Output Class Initialized
INFO - 2021-03-29 20:00:26 --> Router Class Initialized
INFO - 2021-03-29 20:00:26 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:26 --> Output Class Initialized
INFO - 2021-03-29 20:00:26 --> Input Class Initialized
INFO - 2021-03-29 20:00:26 --> Language Class Initialized
INFO - 2021-03-29 20:00:26 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:26 --> Input Class Initialized
INFO - 2021-03-29 20:00:26 --> Language Class Initialized
INFO - 2021-03-29 20:00:26 --> Loader Class Initialized
INFO - 2021-03-29 20:00:26 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:26 --> Loader Class Initialized
INFO - 2021-03-29 20:00:26 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:26 --> Database Driver Class Initialized
INFO - 2021-03-29 20:00:26 --> Config Class Initialized
INFO - 2021-03-29 20:00:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:00:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:26 --> Utf8 Class Initialized
INFO - 2021-03-29 20:00:26 --> URI Class Initialized
INFO - 2021-03-29 20:00:26 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:26 --> Controller Class Initialized
INFO - 2021-03-29 20:00:26 --> Router Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Config Class Initialized
INFO - 2021-03-29 20:00:26 --> Hooks Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Output Class Initialized
INFO - 2021-03-29 20:00:26 --> Security Class Initialized
DEBUG - 2021-03-29 20:00:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:26 --> Utf8 Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:26 --> URI Class Initialized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:26 --> Input Class Initialized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:26 --> Language Class Initialized
INFO - 2021-03-29 20:00:26 --> Database Driver Class Initialized
INFO - 2021-03-29 20:00:26 --> Final output sent to browser
INFO - 2021-03-29 20:00:26 --> Router Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Total execution time: 0.0479
INFO - 2021-03-29 20:00:26 --> Output Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:26 --> Security Class Initialized
INFO - 2021-03-29 20:00:26 --> Loader Class Initialized
INFO - 2021-03-29 20:00:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:00:26 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:26 --> Input Class Initialized
INFO - 2021-03-29 20:00:26 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:26 --> Controller Class Initialized
INFO - 2021-03-29 20:00:26 --> Language Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:26 --> Loader Class Initialized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:26 --> Helper loaded: url_helper
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:26 --> Helper loaded: form_helper
INFO - 2021-03-29 20:00:26 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:26 --> Total execution time: 0.0630
INFO - 2021-03-29 20:00:26 --> Helper loaded: common_helper
INFO - 2021-03-29 20:00:26 --> Helper loaded: util_helper
INFO - 2021-03-29 20:00:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:26 --> Database Driver Class Initialized
INFO - 2021-03-29 20:00:26 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:26 --> Controller Class Initialized
DEBUG - 2021-03-29 20:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:26 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:26 --> Total execution time: 0.0531
INFO - 2021-03-29 20:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:00:26 --> Form Validation Class Initialized
INFO - 2021-03-29 20:00:26 --> Controller Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> Model Class Initialized
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:00:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:00:26 --> Final output sent to browser
DEBUG - 2021-03-29 20:00:26 --> Total execution time: 0.0615
INFO - 2021-03-29 20:01:38 --> Config Class Initialized
INFO - 2021-03-29 20:01:38 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:01:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:38 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:38 --> URI Class Initialized
INFO - 2021-03-29 20:01:38 --> Router Class Initialized
INFO - 2021-03-29 20:01:38 --> Output Class Initialized
INFO - 2021-03-29 20:01:38 --> Security Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:38 --> Input Class Initialized
INFO - 2021-03-29 20:01:38 --> Language Class Initialized
INFO - 2021-03-29 20:01:38 --> Loader Class Initialized
INFO - 2021-03-29 20:01:38 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:38 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:38 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:38 --> Controller Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:38 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:38 --> Total execution time: 0.0491
INFO - 2021-03-29 20:01:38 --> Config Class Initialized
INFO - 2021-03-29 20:01:38 --> Hooks Class Initialized
INFO - 2021-03-29 20:01:38 --> Config Class Initialized
INFO - 2021-03-29 20:01:38 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:01:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:38 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:38 --> URI Class Initialized
DEBUG - 2021-03-29 20:01:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:38 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:38 --> Router Class Initialized
INFO - 2021-03-29 20:01:38 --> Output Class Initialized
INFO - 2021-03-29 20:01:38 --> URI Class Initialized
INFO - 2021-03-29 20:01:38 --> Security Class Initialized
INFO - 2021-03-29 20:01:38 --> Router Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:38 --> Input Class Initialized
INFO - 2021-03-29 20:01:38 --> Language Class Initialized
INFO - 2021-03-29 20:01:38 --> Output Class Initialized
INFO - 2021-03-29 20:01:38 --> Security Class Initialized
INFO - 2021-03-29 20:01:38 --> Loader Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:38 --> Input Class Initialized
INFO - 2021-03-29 20:01:38 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:38 --> Language Class Initialized
INFO - 2021-03-29 20:01:38 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:38 --> Loader Class Initialized
INFO - 2021-03-29 20:01:38 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:38 --> Database Driver Class Initialized
INFO - 2021-03-29 20:01:38 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:38 --> Config Class Initialized
INFO - 2021-03-29 20:01:38 --> Config Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:38 --> Hooks Class Initialized
INFO - 2021-03-29 20:01:38 --> Hooks Class Initialized
INFO - 2021-03-29 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:38 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:38 --> Controller Class Initialized
DEBUG - 2021-03-29 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 20:01:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:38 --> Database Driver Class Initialized
INFO - 2021-03-29 20:01:38 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:38 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> URI Class Initialized
INFO - 2021-03-29 20:01:38 --> URI Class Initialized
INFO - 2021-03-29 20:01:38 --> Router Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:38 --> Router Class Initialized
INFO - 2021-03-29 20:01:38 --> Output Class Initialized
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:38 --> Output Class Initialized
INFO - 2021-03-29 20:01:38 --> Security Class Initialized
INFO - 2021-03-29 20:01:38 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:38 --> Total execution time: 0.0475
INFO - 2021-03-29 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:38 --> Security Class Initialized
INFO - 2021-03-29 20:01:38 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:38 --> Controller Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:38 --> Input Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Input Class Initialized
INFO - 2021-03-29 20:01:38 --> Language Class Initialized
INFO - 2021-03-29 20:01:38 --> Language Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Loader Class Initialized
INFO - 2021-03-29 20:01:38 --> Loader Class Initialized
INFO - 2021-03-29 20:01:38 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:38 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:38 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:38 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:38 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:38 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:38 --> Total execution time: 0.0649
INFO - 2021-03-29 20:01:38 --> Database Driver Class Initialized
INFO - 2021-03-29 20:01:38 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:38 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:38 --> Controller Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:38 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:38 --> Total execution time: 0.0581
INFO - 2021-03-29 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:38 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:38 --> Controller Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> Model Class Initialized
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:38 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:38 --> Total execution time: 0.0703
INFO - 2021-03-29 20:01:39 --> Config Class Initialized
INFO - 2021-03-29 20:01:39 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:01:39 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:39 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:39 --> URI Class Initialized
INFO - 2021-03-29 20:01:39 --> Router Class Initialized
INFO - 2021-03-29 20:01:39 --> Output Class Initialized
INFO - 2021-03-29 20:01:39 --> Security Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:39 --> Input Class Initialized
INFO - 2021-03-29 20:01:39 --> Language Class Initialized
INFO - 2021-03-29 20:01:39 --> Loader Class Initialized
INFO - 2021-03-29 20:01:39 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:39 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:39 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:39 --> Controller Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:39 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:39 --> Total execution time: 0.0331
INFO - 2021-03-29 20:01:39 --> Config Class Initialized
INFO - 2021-03-29 20:01:39 --> Hooks Class Initialized
INFO - 2021-03-29 20:01:39 --> Config Class Initialized
INFO - 2021-03-29 20:01:39 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:01:39 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:39 --> Utf8 Class Initialized
DEBUG - 2021-03-29 20:01:39 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:39 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:39 --> URI Class Initialized
INFO - 2021-03-29 20:01:39 --> URI Class Initialized
INFO - 2021-03-29 20:01:39 --> Router Class Initialized
INFO - 2021-03-29 20:01:39 --> Router Class Initialized
INFO - 2021-03-29 20:01:39 --> Output Class Initialized
INFO - 2021-03-29 20:01:39 --> Output Class Initialized
INFO - 2021-03-29 20:01:39 --> Security Class Initialized
INFO - 2021-03-29 20:01:39 --> Security Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:39 --> Input Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:39 --> Input Class Initialized
INFO - 2021-03-29 20:01:39 --> Language Class Initialized
INFO - 2021-03-29 20:01:39 --> Language Class Initialized
INFO - 2021-03-29 20:01:39 --> Loader Class Initialized
INFO - 2021-03-29 20:01:39 --> Loader Class Initialized
INFO - 2021-03-29 20:01:39 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:39 --> Database Driver Class Initialized
INFO - 2021-03-29 20:01:39 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:39 --> Config Class Initialized
INFO - 2021-03-29 20:01:39 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:01:39 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:39 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:39 --> URI Class Initialized
INFO - 2021-03-29 20:01:39 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:39 --> Controller Class Initialized
INFO - 2021-03-29 20:01:39 --> Database Driver Class Initialized
INFO - 2021-03-29 20:01:39 --> Router Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Output Class Initialized
INFO - 2021-03-29 20:01:39 --> Security Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 20:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 20:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:39 --> Input Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:39 --> Language Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:39 --> Final output sent to browser
INFO - 2021-03-29 20:01:39 --> Loader Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Total execution time: 0.0492
INFO - 2021-03-29 20:01:39 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:39 --> Config Class Initialized
INFO - 2021-03-29 20:01:39 --> Hooks Class Initialized
INFO - 2021-03-29 20:01:39 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:39 --> Helper loaded: util_helper
DEBUG - 2021-03-29 20:01:39 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:39 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:39 --> URI Class Initialized
INFO - 2021-03-29 20:01:39 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:39 --> Controller Class Initialized
INFO - 2021-03-29 20:01:39 --> Router Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Output Class Initialized
INFO - 2021-03-29 20:01:39 --> Database Driver Class Initialized
INFO - 2021-03-29 20:01:39 --> Security Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:39 --> Input Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
DEBUG - 2021-03-29 20:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:39 --> Language Class Initialized
INFO - 2021-03-29 20:01:39 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:39 --> Total execution time: 0.0691
INFO - 2021-03-29 20:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:39 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:39 --> Controller Class Initialized
INFO - 2021-03-29 20:01:39 --> Loader Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:39 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:39 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:39 --> Total execution time: 0.0529
INFO - 2021-03-29 20:01:39 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:39 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:39 --> Controller Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> Model Class Initialized
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:01:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:01:39 --> Final output sent to browser
DEBUG - 2021-03-29 20:01:39 --> Total execution time: 0.0565
INFO - 2021-03-29 20:01:45 --> Config Class Initialized
INFO - 2021-03-29 20:01:45 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:01:45 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:01:45 --> Utf8 Class Initialized
INFO - 2021-03-29 20:01:45 --> URI Class Initialized
INFO - 2021-03-29 20:01:45 --> Router Class Initialized
INFO - 2021-03-29 20:01:45 --> Output Class Initialized
INFO - 2021-03-29 20:01:45 --> Security Class Initialized
DEBUG - 2021-03-29 20:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:01:45 --> Input Class Initialized
INFO - 2021-03-29 20:01:45 --> Language Class Initialized
INFO - 2021-03-29 20:01:45 --> Loader Class Initialized
INFO - 2021-03-29 20:01:45 --> Helper loaded: url_helper
INFO - 2021-03-29 20:01:45 --> Helper loaded: form_helper
INFO - 2021-03-29 20:01:45 --> Helper loaded: common_helper
INFO - 2021-03-29 20:01:45 --> Helper loaded: util_helper
INFO - 2021-03-29 20:01:45 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:01:45 --> Form Validation Class Initialized
INFO - 2021-03-29 20:01:45 --> Controller Class Initialized
INFO - 2021-03-29 20:01:45 --> Model Class Initialized
INFO - 2021-03-29 20:01:45 --> Model Class Initialized
INFO - 2021-03-29 20:01:45 --> Model Class Initialized
INFO - 2021-03-29 20:02:14 --> Config Class Initialized
INFO - 2021-03-29 20:02:14 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:02:14 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:02:14 --> Utf8 Class Initialized
INFO - 2021-03-29 20:02:14 --> URI Class Initialized
INFO - 2021-03-29 20:02:14 --> Router Class Initialized
INFO - 2021-03-29 20:02:14 --> Output Class Initialized
INFO - 2021-03-29 20:02:14 --> Security Class Initialized
DEBUG - 2021-03-29 20:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:02:14 --> Input Class Initialized
INFO - 2021-03-29 20:02:14 --> Language Class Initialized
INFO - 2021-03-29 20:02:14 --> Loader Class Initialized
INFO - 2021-03-29 20:02:14 --> Helper loaded: url_helper
INFO - 2021-03-29 20:02:14 --> Helper loaded: form_helper
INFO - 2021-03-29 20:02:14 --> Helper loaded: common_helper
INFO - 2021-03-29 20:02:14 --> Helper loaded: util_helper
INFO - 2021-03-29 20:02:14 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:02:14 --> Form Validation Class Initialized
INFO - 2021-03-29 20:02:14 --> Controller Class Initialized
INFO - 2021-03-29 20:02:14 --> Model Class Initialized
INFO - 2021-03-29 20:02:14 --> Model Class Initialized
INFO - 2021-03-29 20:02:14 --> Model Class Initialized
INFO - 2021-03-29 20:03:33 --> Config Class Initialized
INFO - 2021-03-29 20:03:33 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:03:33 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:03:33 --> Utf8 Class Initialized
INFO - 2021-03-29 20:03:33 --> URI Class Initialized
INFO - 2021-03-29 20:03:33 --> Router Class Initialized
INFO - 2021-03-29 20:03:33 --> Output Class Initialized
INFO - 2021-03-29 20:03:33 --> Security Class Initialized
DEBUG - 2021-03-29 20:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:03:33 --> Input Class Initialized
INFO - 2021-03-29 20:03:33 --> Language Class Initialized
INFO - 2021-03-29 20:03:33 --> Loader Class Initialized
INFO - 2021-03-29 20:03:33 --> Helper loaded: url_helper
INFO - 2021-03-29 20:03:33 --> Helper loaded: form_helper
INFO - 2021-03-29 20:03:33 --> Helper loaded: common_helper
INFO - 2021-03-29 20:03:33 --> Helper loaded: util_helper
INFO - 2021-03-29 20:03:33 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:03:33 --> Form Validation Class Initialized
INFO - 2021-03-29 20:03:33 --> Controller Class Initialized
INFO - 2021-03-29 20:03:33 --> Model Class Initialized
INFO - 2021-03-29 20:03:33 --> Model Class Initialized
INFO - 2021-03-29 20:03:33 --> Model Class Initialized
INFO - 2021-03-29 20:03:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 20:04:33 --> Config Class Initialized
INFO - 2021-03-29 20:04:33 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:04:33 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:33 --> Utf8 Class Initialized
INFO - 2021-03-29 20:04:33 --> URI Class Initialized
INFO - 2021-03-29 20:04:33 --> Router Class Initialized
INFO - 2021-03-29 20:04:33 --> Output Class Initialized
INFO - 2021-03-29 20:04:33 --> Security Class Initialized
DEBUG - 2021-03-29 20:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:33 --> Input Class Initialized
INFO - 2021-03-29 20:04:33 --> Language Class Initialized
INFO - 2021-03-29 20:04:33 --> Loader Class Initialized
INFO - 2021-03-29 20:04:33 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:33 --> Helper loaded: form_helper
INFO - 2021-03-29 20:04:33 --> Helper loaded: common_helper
INFO - 2021-03-29 20:04:33 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:33 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:04:33 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:33 --> Controller Class Initialized
INFO - 2021-03-29 20:04:33 --> Model Class Initialized
INFO - 2021-03-29 20:04:33 --> Model Class Initialized
INFO - 2021-03-29 20:04:33 --> Model Class Initialized
INFO - 2021-03-29 20:04:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 20:04:57 --> Config Class Initialized
INFO - 2021-03-29 20:04:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:04:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:57 --> Utf8 Class Initialized
INFO - 2021-03-29 20:04:57 --> URI Class Initialized
INFO - 2021-03-29 20:04:57 --> Router Class Initialized
INFO - 2021-03-29 20:04:57 --> Output Class Initialized
INFO - 2021-03-29 20:04:57 --> Security Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:57 --> Input Class Initialized
INFO - 2021-03-29 20:04:57 --> Language Class Initialized
INFO - 2021-03-29 20:04:57 --> Loader Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: form_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: common_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:57 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:04:57 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:57 --> Controller Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 20:04:57 --> Config Class Initialized
INFO - 2021-03-29 20:04:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:04:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:57 --> Utf8 Class Initialized
INFO - 2021-03-29 20:04:57 --> URI Class Initialized
INFO - 2021-03-29 20:04:57 --> Router Class Initialized
INFO - 2021-03-29 20:04:57 --> Output Class Initialized
INFO - 2021-03-29 20:04:57 --> Security Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:57 --> Input Class Initialized
INFO - 2021-03-29 20:04:57 --> Language Class Initialized
INFO - 2021-03-29 20:04:57 --> Loader Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: form_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: common_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:57 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:04:57 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:57 --> Controller Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:04:57 --> Final output sent to browser
DEBUG - 2021-03-29 20:04:57 --> Total execution time: 0.0413
INFO - 2021-03-29 20:04:57 --> Config Class Initialized
INFO - 2021-03-29 20:04:57 --> Hooks Class Initialized
INFO - 2021-03-29 20:04:57 --> Config Class Initialized
INFO - 2021-03-29 20:04:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:04:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:57 --> Utf8 Class Initialized
INFO - 2021-03-29 20:04:57 --> Config Class Initialized
INFO - 2021-03-29 20:04:57 --> Hooks Class Initialized
INFO - 2021-03-29 20:04:57 --> URI Class Initialized
DEBUG - 2021-03-29 20:04:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:57 --> Utf8 Class Initialized
INFO - 2021-03-29 20:04:57 --> URI Class Initialized
INFO - 2021-03-29 20:04:57 --> Router Class Initialized
INFO - 2021-03-29 20:04:57 --> Output Class Initialized
INFO - 2021-03-29 20:04:57 --> Router Class Initialized
INFO - 2021-03-29 20:04:57 --> Security Class Initialized
INFO - 2021-03-29 20:04:57 --> Output Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:57 --> Input Class Initialized
INFO - 2021-03-29 20:04:57 --> Security Class Initialized
INFO - 2021-03-29 20:04:57 --> Language Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:57 --> Input Class Initialized
INFO - 2021-03-29 20:04:57 --> Language Class Initialized
INFO - 2021-03-29 20:04:57 --> Loader Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:57 --> Loader Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: form_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: common_helper
INFO - 2021-03-29 20:04:57 --> Config Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:57 --> Hooks Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: form_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: common_helper
DEBUG - 2021-03-29 20:04:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:57 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:57 --> Utf8 Class Initialized
INFO - 2021-03-29 20:04:57 --> URI Class Initialized
INFO - 2021-03-29 20:04:57 --> Database Driver Class Initialized
INFO - 2021-03-29 20:04:57 --> Router Class Initialized
INFO - 2021-03-29 20:04:57 --> Output Class Initialized
INFO - 2021-03-29 20:04:57 --> Database Driver Class Initialized
INFO - 2021-03-29 20:04:57 --> Security Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:57 --> Input Class Initialized
DEBUG - 2021-03-29 20:04:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:04:57 --> Language Class Initialized
INFO - 2021-03-29 20:04:57 --> Utf8 Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:04:57 --> URI Class Initialized
INFO - 2021-03-29 20:04:57 --> Loader Class Initialized
INFO - 2021-03-29 20:04:57 --> Router Class Initialized
INFO - 2021-03-29 20:04:57 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:57 --> Controller Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:57 --> Output Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Security Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: form_helper
DEBUG - 2021-03-29 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:04:57 --> Input Class Initialized
INFO - 2021-03-29 20:04:57 --> Language Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: common_helper
INFO - 2021-03-29 20:04:57 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:57 --> Loader Class Initialized
INFO - 2021-03-29 20:04:57 --> Helper loaded: url_helper
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:04:57 --> Helper loaded: form_helper
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:04:57 --> Helper loaded: common_helper
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:04:57 --> Helper loaded: util_helper
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:04:57 --> Final output sent to browser
DEBUG - 2021-03-29 20:04:57 --> Total execution time: 0.0537
INFO - 2021-03-29 20:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:04:57 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:57 --> Controller Class Initialized
INFO - 2021-03-29 20:04:57 --> Database Driver Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:04:57 --> Final output sent to browser
DEBUG - 2021-03-29 20:04:57 --> Total execution time: 0.0695
INFO - 2021-03-29 20:04:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:04:57 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:57 --> Controller Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:04:57 --> Final output sent to browser
DEBUG - 2021-03-29 20:04:57 --> Total execution time: 0.0644
INFO - 2021-03-29 20:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:04:57 --> Form Validation Class Initialized
INFO - 2021-03-29 20:04:57 --> Controller Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> Model Class Initialized
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:04:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:04:57 --> Final output sent to browser
DEBUG - 2021-03-29 20:04:57 --> Total execution time: 0.0944
INFO - 2021-03-29 20:07:11 --> Config Class Initialized
INFO - 2021-03-29 20:07:11 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:11 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:11 --> URI Class Initialized
INFO - 2021-03-29 20:07:11 --> Router Class Initialized
INFO - 2021-03-29 20:07:11 --> Output Class Initialized
INFO - 2021-03-29 20:07:11 --> Security Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:11 --> Input Class Initialized
INFO - 2021-03-29 20:07:11 --> Language Class Initialized
INFO - 2021-03-29 20:07:11 --> Loader Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:11 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:11 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:11 --> Controller Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:11 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:11 --> Total execution time: 0.0363
INFO - 2021-03-29 20:07:11 --> Config Class Initialized
INFO - 2021-03-29 20:07:11 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:11 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:11 --> URI Class Initialized
INFO - 2021-03-29 20:07:11 --> Config Class Initialized
INFO - 2021-03-29 20:07:11 --> Router Class Initialized
INFO - 2021-03-29 20:07:11 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:11 --> Output Class Initialized
DEBUG - 2021-03-29 20:07:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:11 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:11 --> Security Class Initialized
INFO - 2021-03-29 20:07:11 --> URI Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:11 --> Input Class Initialized
INFO - 2021-03-29 20:07:11 --> Router Class Initialized
INFO - 2021-03-29 20:07:11 --> Language Class Initialized
INFO - 2021-03-29 20:07:11 --> Output Class Initialized
INFO - 2021-03-29 20:07:11 --> Loader Class Initialized
INFO - 2021-03-29 20:07:11 --> Security Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: url_helper
DEBUG - 2021-03-29 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:11 --> Input Class Initialized
INFO - 2021-03-29 20:07:11 --> Language Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:11 --> Loader Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:11 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: util_helper
DEBUG - 2021-03-29 20:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:11 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:11 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:11 --> Controller Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:11 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:11 --> Total execution time: 0.0453
INFO - 2021-03-29 20:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:11 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:11 --> Controller Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Config Class Initialized
INFO - 2021-03-29 20:07:11 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:11 --> Config Class Initialized
INFO - 2021-03-29 20:07:11 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 20:07:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:11 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:11 --> URI Class Initialized
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-29 20:07:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:11 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:11 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:11 --> Total execution time: 0.0622
INFO - 2021-03-29 20:07:11 --> Router Class Initialized
INFO - 2021-03-29 20:07:11 --> URI Class Initialized
INFO - 2021-03-29 20:07:11 --> Output Class Initialized
INFO - 2021-03-29 20:07:11 --> Router Class Initialized
INFO - 2021-03-29 20:07:11 --> Security Class Initialized
INFO - 2021-03-29 20:07:11 --> Output Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:11 --> Security Class Initialized
INFO - 2021-03-29 20:07:11 --> Input Class Initialized
INFO - 2021-03-29 20:07:11 --> Language Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:11 --> Input Class Initialized
INFO - 2021-03-29 20:07:11 --> Language Class Initialized
INFO - 2021-03-29 20:07:11 --> Loader Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:11 --> Loader Class Initialized
INFO - 2021-03-29 20:07:11 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:11 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:11 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:11 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:11 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:11 --> Controller Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:11 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:11 --> Total execution time: 0.0475
INFO - 2021-03-29 20:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:11 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:11 --> Controller Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> Model Class Initialized
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:11 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:11 --> Total execution time: 0.0615
INFO - 2021-03-29 20:07:15 --> Config Class Initialized
INFO - 2021-03-29 20:07:15 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:15 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:15 --> URI Class Initialized
INFO - 2021-03-29 20:07:15 --> Router Class Initialized
INFO - 2021-03-29 20:07:15 --> Output Class Initialized
INFO - 2021-03-29 20:07:15 --> Security Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:15 --> Input Class Initialized
INFO - 2021-03-29 20:07:15 --> Language Class Initialized
INFO - 2021-03-29 20:07:15 --> Loader Class Initialized
INFO - 2021-03-29 20:07:15 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:15 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:15 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:15 --> Controller Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 20:07:15 --> Config Class Initialized
INFO - 2021-03-29 20:07:15 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:15 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:15 --> URI Class Initialized
INFO - 2021-03-29 20:07:15 --> Router Class Initialized
INFO - 2021-03-29 20:07:15 --> Output Class Initialized
INFO - 2021-03-29 20:07:15 --> Security Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:15 --> Input Class Initialized
INFO - 2021-03-29 20:07:15 --> Language Class Initialized
INFO - 2021-03-29 20:07:15 --> Loader Class Initialized
INFO - 2021-03-29 20:07:15 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:15 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:15 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:15 --> Controller Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:15 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:15 --> Total execution time: 0.0434
INFO - 2021-03-29 20:07:15 --> Config Class Initialized
INFO - 2021-03-29 20:07:15 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:15 --> Config Class Initialized
INFO - 2021-03-29 20:07:15 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:15 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:15 --> URI Class Initialized
DEBUG - 2021-03-29 20:07:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:15 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:15 --> Router Class Initialized
INFO - 2021-03-29 20:07:15 --> URI Class Initialized
INFO - 2021-03-29 20:07:15 --> Output Class Initialized
INFO - 2021-03-29 20:07:15 --> Router Class Initialized
INFO - 2021-03-29 20:07:15 --> Security Class Initialized
INFO - 2021-03-29 20:07:15 --> Output Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:15 --> Input Class Initialized
INFO - 2021-03-29 20:07:15 --> Security Class Initialized
INFO - 2021-03-29 20:07:15 --> Language Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:15 --> Input Class Initialized
INFO - 2021-03-29 20:07:15 --> Language Class Initialized
INFO - 2021-03-29 20:07:15 --> Loader Class Initialized
INFO - 2021-03-29 20:07:15 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:15 --> Loader Class Initialized
INFO - 2021-03-29 20:07:15 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:15 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:15 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:15 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:15 --> Controller Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:15 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:15 --> Total execution time: 0.0461
INFO - 2021-03-29 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:15 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:15 --> Controller Class Initialized
INFO - 2021-03-29 20:07:15 --> Config Class Initialized
INFO - 2021-03-29 20:07:15 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:15 --> Config Class Initialized
INFO - 2021-03-29 20:07:15 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
DEBUG - 2021-03-29 20:07:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:15 --> Utf8 Class Initialized
DEBUG - 2021-03-29 20:07:15 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:15 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:15 --> URI Class Initialized
INFO - 2021-03-29 20:07:15 --> URI Class Initialized
INFO - 2021-03-29 20:07:15 --> Router Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:15 --> Router Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:15 --> Output Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:15 --> Output Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:15 --> Security Class Initialized
INFO - 2021-03-29 20:07:15 --> Final output sent to browser
INFO - 2021-03-29 20:07:15 --> Security Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Total execution time: 0.0579
DEBUG - 2021-03-29 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:15 --> Input Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:15 --> Input Class Initialized
INFO - 2021-03-29 20:07:15 --> Language Class Initialized
INFO - 2021-03-29 20:07:15 --> Language Class Initialized
INFO - 2021-03-29 20:07:15 --> Loader Class Initialized
INFO - 2021-03-29 20:07:15 --> Loader Class Initialized
INFO - 2021-03-29 20:07:15 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:15 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:15 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:15 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:15 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:15 --> Controller Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:15 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:15 --> Total execution time: 0.0451
INFO - 2021-03-29 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:15 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:15 --> Controller Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> Model Class Initialized
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:15 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:15 --> Total execution time: 0.0578
INFO - 2021-03-29 20:07:35 --> Config Class Initialized
INFO - 2021-03-29 20:07:35 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:35 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:35 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:35 --> URI Class Initialized
INFO - 2021-03-29 20:07:35 --> Router Class Initialized
INFO - 2021-03-29 20:07:35 --> Output Class Initialized
INFO - 2021-03-29 20:07:35 --> Security Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:35 --> Input Class Initialized
INFO - 2021-03-29 20:07:35 --> Language Class Initialized
INFO - 2021-03-29 20:07:35 --> Loader Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:35 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:35 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:35 --> Controller Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:35 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:35 --> Total execution time: 0.0362
INFO - 2021-03-29 20:07:35 --> Config Class Initialized
INFO - 2021-03-29 20:07:35 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:35 --> Config Class Initialized
INFO - 2021-03-29 20:07:35 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:35 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:35 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:35 --> URI Class Initialized
DEBUG - 2021-03-29 20:07:35 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:35 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:35 --> Router Class Initialized
INFO - 2021-03-29 20:07:35 --> URI Class Initialized
INFO - 2021-03-29 20:07:35 --> Output Class Initialized
INFO - 2021-03-29 20:07:35 --> Security Class Initialized
INFO - 2021-03-29 20:07:35 --> Router Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:35 --> Input Class Initialized
INFO - 2021-03-29 20:07:35 --> Language Class Initialized
INFO - 2021-03-29 20:07:35 --> Output Class Initialized
INFO - 2021-03-29 20:07:35 --> Security Class Initialized
INFO - 2021-03-29 20:07:35 --> Loader Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:35 --> Input Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:35 --> Language Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:35 --> Loader Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:35 --> Helper loaded: util_helper
INFO - 2021-03-29 20:07:35 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:35 --> Config Class Initialized
INFO - 2021-03-29 20:07:35 --> Hooks Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 20:07:35 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:35 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:35 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:35 --> URI Class Initialized
INFO - 2021-03-29 20:07:35 --> Controller Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Router Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Config Class Initialized
INFO - 2021-03-29 20:07:35 --> Hooks Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Output Class Initialized
INFO - 2021-03-29 20:07:35 --> Security Class Initialized
DEBUG - 2021-03-29 20:07:35 --> UTF-8 Support Enabled
INFO - 2021-03-29 20:07:35 --> Utf8 Class Initialized
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:35 --> Input Class Initialized
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:35 --> Language Class Initialized
INFO - 2021-03-29 20:07:35 --> URI Class Initialized
INFO - 2021-03-29 20:07:35 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:35 --> Total execution time: 0.0501
INFO - 2021-03-29 20:07:35 --> Router Class Initialized
INFO - 2021-03-29 20:07:35 --> Loader Class Initialized
INFO - 2021-03-29 20:07:35 --> Output Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:35 --> Security Class Initialized
INFO - 2021-03-29 20:07:35 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: form_helper
DEBUG - 2021-03-29 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 20:07:35 --> Input Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:35 --> Language Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: util_helper
DEBUG - 2021-03-29 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:35 --> Loader Class Initialized
INFO - 2021-03-29 20:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:35 --> Helper loaded: url_helper
INFO - 2021-03-29 20:07:35 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:35 --> Controller Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: form_helper
INFO - 2021-03-29 20:07:35 --> Database Driver Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: common_helper
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Helper loaded: util_helper
DEBUG - 2021-03-29 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:35 --> Final output sent to browser
INFO - 2021-03-29 20:07:35 --> Database Driver Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Total execution time: 0.0772
INFO - 2021-03-29 20:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:35 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:35 --> Controller Class Initialized
DEBUG - 2021-03-29 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:35 --> Model Class Initialized
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:36 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:36 --> Total execution time: 0.0586
INFO - 2021-03-29 20:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 20:07:36 --> Form Validation Class Initialized
INFO - 2021-03-29 20:07:36 --> Controller Class Initialized
INFO - 2021-03-29 20:07:36 --> Model Class Initialized
INFO - 2021-03-29 20:07:36 --> Model Class Initialized
INFO - 2021-03-29 20:07:36 --> Model Class Initialized
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 20:07:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 20:07:36 --> Final output sent to browser
DEBUG - 2021-03-29 20:07:36 --> Total execution time: 0.0699
INFO - 2021-03-29 21:42:11 --> Config Class Initialized
INFO - 2021-03-29 21:42:11 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:42:11 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:42:11 --> Utf8 Class Initialized
INFO - 2021-03-29 21:42:11 --> URI Class Initialized
INFO - 2021-03-29 21:42:11 --> Router Class Initialized
INFO - 2021-03-29 21:42:11 --> Output Class Initialized
INFO - 2021-03-29 21:42:11 --> Security Class Initialized
DEBUG - 2021-03-29 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:42:11 --> Input Class Initialized
INFO - 2021-03-29 21:42:11 --> Language Class Initialized
INFO - 2021-03-29 21:42:11 --> Loader Class Initialized
INFO - 2021-03-29 21:42:11 --> Helper loaded: url_helper
INFO - 2021-03-29 21:42:11 --> Helper loaded: form_helper
INFO - 2021-03-29 21:42:11 --> Helper loaded: common_helper
INFO - 2021-03-29 21:42:11 --> Helper loaded: util_helper
INFO - 2021-03-29 21:42:11 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:42:11 --> Form Validation Class Initialized
INFO - 2021-03-29 21:42:11 --> Controller Class Initialized
INFO - 2021-03-29 21:42:11 --> Model Class Initialized
INFO - 2021-03-29 21:42:11 --> Model Class Initialized
INFO - 2021-03-29 21:42:11 --> Model Class Initialized
INFO - 2021-03-29 21:42:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:42:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:42:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:42:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:42:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:42:11 --> Final output sent to browser
DEBUG - 2021-03-29 21:42:11 --> Total execution time: 0.0512
INFO - 2021-03-29 21:42:12 --> Config Class Initialized
INFO - 2021-03-29 21:42:12 --> Hooks Class Initialized
INFO - 2021-03-29 21:42:12 --> Config Class Initialized
INFO - 2021-03-29 21:42:12 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:42:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:42:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:42:12 --> URI Class Initialized
DEBUG - 2021-03-29 21:42:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:42:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:42:12 --> URI Class Initialized
INFO - 2021-03-29 21:42:12 --> Router Class Initialized
INFO - 2021-03-29 21:42:12 --> Router Class Initialized
INFO - 2021-03-29 21:42:12 --> Output Class Initialized
INFO - 2021-03-29 21:42:12 --> Output Class Initialized
INFO - 2021-03-29 21:42:12 --> Security Class Initialized
INFO - 2021-03-29 21:42:12 --> Security Class Initialized
DEBUG - 2021-03-29 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:42:12 --> Input Class Initialized
DEBUG - 2021-03-29 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:42:12 --> Input Class Initialized
INFO - 2021-03-29 21:42:12 --> Language Class Initialized
INFO - 2021-03-29 21:42:12 --> Language Class Initialized
INFO - 2021-03-29 21:42:12 --> Loader Class Initialized
INFO - 2021-03-29 21:42:12 --> Loader Class Initialized
INFO - 2021-03-29 21:42:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:42:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:42:12 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:42:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 21:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:42:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:42:12 --> Config Class Initialized
INFO - 2021-03-29 21:42:12 --> Controller Class Initialized
INFO - 2021-03-29 21:42:12 --> Hooks Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
DEBUG - 2021-03-29 21:42:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:42:12 --> URI Class Initialized
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:42:12 --> Router Class Initialized
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:42:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:42:12 --> Total execution time: 0.0507
INFO - 2021-03-29 21:42:12 --> Output Class Initialized
INFO - 2021-03-29 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:42:12 --> Security Class Initialized
INFO - 2021-03-29 21:42:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:42:12 --> Controller Class Initialized
INFO - 2021-03-29 21:42:12 --> Config Class Initialized
INFO - 2021-03-29 21:42:12 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Input Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Language Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
DEBUG - 2021-03-29 21:42:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:42:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:42:12 --> Loader Class Initialized
INFO - 2021-03-29 21:42:12 --> URI Class Initialized
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:42:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:42:12 --> Router Class Initialized
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:42:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:42:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:42:12 --> Total execution time: 0.0661
INFO - 2021-03-29 21:42:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:42:12 --> Output Class Initialized
INFO - 2021-03-29 21:42:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:42:12 --> Security Class Initialized
DEBUG - 2021-03-29 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:42:12 --> Input Class Initialized
INFO - 2021-03-29 21:42:12 --> Language Class Initialized
INFO - 2021-03-29 21:42:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:42:12 --> Loader Class Initialized
INFO - 2021-03-29 21:42:12 --> Helper loaded: url_helper
DEBUG - 2021-03-29 21:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:42:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:42:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:42:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:42:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:42:12 --> Controller Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
DEBUG - 2021-03-29 21:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:42:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:42:12 --> Total execution time: 0.0553
INFO - 2021-03-29 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:42:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:42:12 --> Controller Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> Model Class Initialized
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:42:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:42:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:42:12 --> Total execution time: 0.0596
INFO - 2021-03-29 21:43:12 --> Config Class Initialized
INFO - 2021-03-29 21:43:12 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:12 --> URI Class Initialized
INFO - 2021-03-29 21:43:12 --> Router Class Initialized
INFO - 2021-03-29 21:43:12 --> Output Class Initialized
INFO - 2021-03-29 21:43:12 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:12 --> Input Class Initialized
INFO - 2021-03-29 21:43:12 --> Language Class Initialized
INFO - 2021-03-29 21:43:12 --> Loader Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:12 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:12 --> Controller Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:12 --> Total execution time: 0.0344
INFO - 2021-03-29 21:43:12 --> Config Class Initialized
INFO - 2021-03-29 21:43:12 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:12 --> URI Class Initialized
INFO - 2021-03-29 21:43:12 --> Config Class Initialized
INFO - 2021-03-29 21:43:12 --> Hooks Class Initialized
INFO - 2021-03-29 21:43:12 --> Router Class Initialized
INFO - 2021-03-29 21:43:12 --> Output Class Initialized
INFO - 2021-03-29 21:43:12 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:12 --> Utf8 Class Initialized
DEBUG - 2021-03-29 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:12 --> Input Class Initialized
INFO - 2021-03-29 21:43:12 --> URI Class Initialized
INFO - 2021-03-29 21:43:12 --> Language Class Initialized
INFO - 2021-03-29 21:43:12 --> Router Class Initialized
INFO - 2021-03-29 21:43:12 --> Loader Class Initialized
INFO - 2021-03-29 21:43:12 --> Output Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:12 --> Security Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: form_helper
DEBUG - 2021-03-29 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:12 --> Input Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:12 --> Language Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:12 --> Loader Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: util_helper
DEBUG - 2021-03-29 21:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:12 --> Controller Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Config Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Hooks Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-29 21:43:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:12 --> URI Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:12 --> Total execution time: 0.0477
INFO - 2021-03-29 21:43:12 --> Router Class Initialized
INFO - 2021-03-29 21:43:12 --> Output Class Initialized
INFO - 2021-03-29 21:43:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:12 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 21:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:12 --> Input Class Initialized
INFO - 2021-03-29 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:12 --> Language Class Initialized
INFO - 2021-03-29 21:43:12 --> Config Class Initialized
INFO - 2021-03-29 21:43:12 --> Hooks Class Initialized
INFO - 2021-03-29 21:43:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:12 --> Controller Class Initialized
INFO - 2021-03-29 21:43:12 --> Loader Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
DEBUG - 2021-03-29 21:43:12 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:12 --> URI Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:12 --> Router Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:12 --> Output Class Initialized
INFO - 2021-03-29 21:43:12 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:12 --> Input Class Initialized
INFO - 2021-03-29 21:43:12 --> Language Class Initialized
INFO - 2021-03-29 21:43:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:12 --> Loader Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-29 21:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:12 --> Final output sent to browser
INFO - 2021-03-29 21:43:12 --> Helper loaded: url_helper
DEBUG - 2021-03-29 21:43:12 --> Total execution time: 0.0791
INFO - 2021-03-29 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:12 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:12 --> Controller Class Initialized
INFO - 2021-03-29 21:43:12 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:12 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:12 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:12 --> Total execution time: 0.0562
DEBUG - 2021-03-29 21:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:12 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:12 --> Controller Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> Model Class Initialized
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:12 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:12 --> Total execution time: 0.0578
INFO - 2021-03-29 21:43:16 --> Config Class Initialized
INFO - 2021-03-29 21:43:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:16 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:16 --> URI Class Initialized
INFO - 2021-03-29 21:43:16 --> Router Class Initialized
INFO - 2021-03-29 21:43:16 --> Output Class Initialized
INFO - 2021-03-29 21:43:16 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:16 --> Input Class Initialized
INFO - 2021-03-29 21:43:16 --> Language Class Initialized
INFO - 2021-03-29 21:43:16 --> Loader Class Initialized
INFO - 2021-03-29 21:43:16 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:16 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:16 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:16 --> Controller Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:16 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:16 --> Total execution time: 0.0352
INFO - 2021-03-29 21:43:16 --> Config Class Initialized
INFO - 2021-03-29 21:43:16 --> Config Class Initialized
INFO - 2021-03-29 21:43:16 --> Hooks Class Initialized
INFO - 2021-03-29 21:43:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:16 --> Utf8 Class Initialized
DEBUG - 2021-03-29 21:43:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:16 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:16 --> URI Class Initialized
INFO - 2021-03-29 21:43:16 --> URI Class Initialized
INFO - 2021-03-29 21:43:16 --> Router Class Initialized
INFO - 2021-03-29 21:43:16 --> Router Class Initialized
INFO - 2021-03-29 21:43:16 --> Output Class Initialized
INFO - 2021-03-29 21:43:16 --> Output Class Initialized
INFO - 2021-03-29 21:43:16 --> Security Class Initialized
INFO - 2021-03-29 21:43:16 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:16 --> Input Class Initialized
INFO - 2021-03-29 21:43:16 --> Input Class Initialized
INFO - 2021-03-29 21:43:16 --> Language Class Initialized
INFO - 2021-03-29 21:43:16 --> Language Class Initialized
INFO - 2021-03-29 21:43:16 --> Loader Class Initialized
INFO - 2021-03-29 21:43:16 --> Loader Class Initialized
INFO - 2021-03-29 21:43:16 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:16 --> Config Class Initialized
INFO - 2021-03-29 21:43:16 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:16 --> Hooks Class Initialized
INFO - 2021-03-29 21:43:16 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:16 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:16 --> Config Class Initialized
INFO - 2021-03-29 21:43:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 21:43:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:16 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:16 --> URI Class Initialized
INFO - 2021-03-29 21:43:16 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:16 --> Controller Class Initialized
INFO - 2021-03-29 21:43:16 --> Router Class Initialized
DEBUG - 2021-03-29 21:43:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Output Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> URI Class Initialized
INFO - 2021-03-29 21:43:16 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:16 --> Input Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:16 --> Language Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:16 --> Router Class Initialized
INFO - 2021-03-29 21:43:16 --> Loader Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:16 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:16 --> Final output sent to browser
INFO - 2021-03-29 21:43:16 --> Output Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Total execution time: 0.0536
INFO - 2021-03-29 21:43:16 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:16 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:16 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:16 --> Controller Class Initialized
INFO - 2021-03-29 21:43:16 --> Security Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
DEBUG - 2021-03-29 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Input Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Language Class Initialized
INFO - 2021-03-29 21:43:16 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:16 --> Loader Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:16 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:16 --> Total execution time: 0.0690
DEBUG - 2021-03-29 21:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:16 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:16 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:16 --> Controller Class Initialized
INFO - 2021-03-29 21:43:16 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:16 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:16 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:16 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:16 --> Total execution time: 0.0510
DEBUG - 2021-03-29 21:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:16 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:16 --> Controller Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> Model Class Initialized
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:16 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:16 --> Total execution time: 0.0815
INFO - 2021-03-29 21:43:24 --> Config Class Initialized
INFO - 2021-03-29 21:43:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:24 --> URI Class Initialized
INFO - 2021-03-29 21:43:24 --> Router Class Initialized
INFO - 2021-03-29 21:43:24 --> Output Class Initialized
INFO - 2021-03-29 21:43:24 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:24 --> Input Class Initialized
INFO - 2021-03-29 21:43:24 --> Language Class Initialized
INFO - 2021-03-29 21:43:24 --> Loader Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:24 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:24 --> Controller Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-29 21:43:24 --> Config Class Initialized
INFO - 2021-03-29 21:43:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:24 --> URI Class Initialized
INFO - 2021-03-29 21:43:24 --> Router Class Initialized
INFO - 2021-03-29 21:43:24 --> Output Class Initialized
INFO - 2021-03-29 21:43:24 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:24 --> Input Class Initialized
INFO - 2021-03-29 21:43:24 --> Language Class Initialized
INFO - 2021-03-29 21:43:24 --> Loader Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:24 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:24 --> Controller Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:24 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:24 --> Total execution time: 0.0499
INFO - 2021-03-29 21:43:24 --> Config Class Initialized
INFO - 2021-03-29 21:43:24 --> Config Class Initialized
INFO - 2021-03-29 21:43:24 --> Hooks Class Initialized
INFO - 2021-03-29 21:43:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:24 --> Utf8 Class Initialized
DEBUG - 2021-03-29 21:43:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:24 --> URI Class Initialized
INFO - 2021-03-29 21:43:24 --> URI Class Initialized
INFO - 2021-03-29 21:43:24 --> Router Class Initialized
INFO - 2021-03-29 21:43:24 --> Router Class Initialized
INFO - 2021-03-29 21:43:24 --> Output Class Initialized
INFO - 2021-03-29 21:43:24 --> Output Class Initialized
INFO - 2021-03-29 21:43:24 --> Security Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:24 --> Security Class Initialized
INFO - 2021-03-29 21:43:24 --> Input Class Initialized
INFO - 2021-03-29 21:43:24 --> Language Class Initialized
INFO - 2021-03-29 21:43:24 --> Loader Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:24 --> Input Class Initialized
INFO - 2021-03-29 21:43:24 --> Language Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:24 --> Loader Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:24 --> Config Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:24 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:24 --> Utf8 Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:24 --> URI Class Initialized
INFO - 2021-03-29 21:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:24 --> Router Class Initialized
INFO - 2021-03-29 21:43:24 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:24 --> Controller Class Initialized
INFO - 2021-03-29 21:43:24 --> Output Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Security Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-29 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:24 --> Input Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:24 --> Language Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:24 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:24 --> Total execution time: 0.0455
INFO - 2021-03-29 21:43:24 --> Loader Class Initialized
INFO - 2021-03-29 21:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:24 --> Controller Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:24 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:24 --> Total execution time: 0.0591
INFO - 2021-03-29 21:43:24 --> Database Driver Class Initialized
INFO - 2021-03-29 21:43:24 --> Config Class Initialized
INFO - 2021-03-29 21:43:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-29 21:43:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:43:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:43:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:24 --> Controller Class Initialized
INFO - 2021-03-29 21:43:24 --> URI Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Router Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Output Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:24 --> Security Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-29 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:43:24 --> Input Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:24 --> Language Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:24 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:24 --> Total execution time: 0.0516
INFO - 2021-03-29 21:43:24 --> Loader Class Initialized
INFO - 2021-03-29 21:43:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:43:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:43:24 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:43:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:43:24 --> Controller Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> Model Class Initialized
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:43:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:43:24 --> Final output sent to browser
DEBUG - 2021-03-29 21:43:24 --> Total execution time: 0.0539
INFO - 2021-03-29 21:44:21 --> Config Class Initialized
INFO - 2021-03-29 21:44:21 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:21 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:21 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:21 --> URI Class Initialized
DEBUG - 2021-03-29 21:44:21 --> No URI present. Default controller set.
INFO - 2021-03-29 21:44:21 --> Router Class Initialized
INFO - 2021-03-29 21:44:21 --> Output Class Initialized
INFO - 2021-03-29 21:44:21 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:21 --> Input Class Initialized
INFO - 2021-03-29 21:44:21 --> Language Class Initialized
INFO - 2021-03-29 21:44:21 --> Loader Class Initialized
INFO - 2021-03-29 21:44:21 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:21 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:21 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:21 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:21 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:21 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:21 --> Controller Class Initialized
INFO - 2021-03-29 21:44:21 --> Model Class Initialized
INFO - 2021-03-29 21:44:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/header.php
INFO - 2021-03-29 21:44:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/login.php
INFO - 2021-03-29 21:44:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/footer.php
INFO - 2021-03-29 21:44:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/index.php
INFO - 2021-03-29 21:44:21 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:21 --> Total execution time: 0.0335
INFO - 2021-03-29 21:44:21 --> Config Class Initialized
INFO - 2021-03-29 21:44:21 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:21 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:21 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:21 --> URI Class Initialized
INFO - 2021-03-29 21:44:21 --> Router Class Initialized
INFO - 2021-03-29 21:44:21 --> Output Class Initialized
INFO - 2021-03-29 21:44:21 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:21 --> Input Class Initialized
INFO - 2021-03-29 21:44:21 --> Language Class Initialized
ERROR - 2021-03-29 21:44:21 --> 404 Page Not Found: Assets/js
INFO - 2021-03-29 21:44:22 --> Config Class Initialized
INFO - 2021-03-29 21:44:22 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:22 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:22 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:22 --> URI Class Initialized
INFO - 2021-03-29 21:44:22 --> Router Class Initialized
INFO - 2021-03-29 21:44:22 --> Output Class Initialized
INFO - 2021-03-29 21:44:22 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:22 --> Input Class Initialized
INFO - 2021-03-29 21:44:22 --> Language Class Initialized
ERROR - 2021-03-29 21:44:22 --> 404 Page Not Found: Assets/js
INFO - 2021-03-29 21:44:22 --> Config Class Initialized
INFO - 2021-03-29 21:44:22 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:22 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:22 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:22 --> URI Class Initialized
DEBUG - 2021-03-29 21:44:22 --> No URI present. Default controller set.
INFO - 2021-03-29 21:44:22 --> Router Class Initialized
INFO - 2021-03-29 21:44:22 --> Output Class Initialized
INFO - 2021-03-29 21:44:22 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:22 --> Input Class Initialized
INFO - 2021-03-29 21:44:22 --> Language Class Initialized
INFO - 2021-03-29 21:44:22 --> Loader Class Initialized
INFO - 2021-03-29 21:44:22 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:22 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:22 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:22 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:22 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:22 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:22 --> Controller Class Initialized
INFO - 2021-03-29 21:44:22 --> Model Class Initialized
INFO - 2021-03-29 21:44:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/header.php
INFO - 2021-03-29 21:44:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/login.php
INFO - 2021-03-29 21:44:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/footer.php
INFO - 2021-03-29 21:44:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/index.php
INFO - 2021-03-29 21:44:22 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:22 --> Total execution time: 0.0412
INFO - 2021-03-29 21:44:24 --> Config Class Initialized
INFO - 2021-03-29 21:44:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:24 --> URI Class Initialized
INFO - 2021-03-29 21:44:24 --> Router Class Initialized
INFO - 2021-03-29 21:44:24 --> Output Class Initialized
INFO - 2021-03-29 21:44:24 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:24 --> Input Class Initialized
INFO - 2021-03-29 21:44:24 --> Language Class Initialized
INFO - 2021-03-29 21:44:24 --> Loader Class Initialized
INFO - 2021-03-29 21:44:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:24 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:24 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:24 --> Controller Class Initialized
INFO - 2021-03-29 21:44:24 --> Model Class Initialized
INFO - 2021-03-29 21:44:24 --> Model Class Initialized
INFO - 2021-03-29 21:44:24 --> Model Class Initialized
INFO - 2021-03-29 21:44:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:44:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:44:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:44:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:44:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:44:24 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:24 --> Total execution time: 0.0465
INFO - 2021-03-29 21:44:24 --> Config Class Initialized
INFO - 2021-03-29 21:44:24 --> Hooks Class Initialized
INFO - 2021-03-29 21:44:24 --> Config Class Initialized
INFO - 2021-03-29 21:44:24 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:24 --> URI Class Initialized
DEBUG - 2021-03-29 21:44:24 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:24 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:24 --> Router Class Initialized
INFO - 2021-03-29 21:44:24 --> URI Class Initialized
INFO - 2021-03-29 21:44:24 --> Output Class Initialized
INFO - 2021-03-29 21:44:24 --> Router Class Initialized
INFO - 2021-03-29 21:44:24 --> Security Class Initialized
INFO - 2021-03-29 21:44:24 --> Output Class Initialized
DEBUG - 2021-03-29 21:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:24 --> Input Class Initialized
INFO - 2021-03-29 21:44:24 --> Language Class Initialized
INFO - 2021-03-29 21:44:24 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:24 --> Input Class Initialized
INFO - 2021-03-29 21:44:24 --> Language Class Initialized
INFO - 2021-03-29 21:44:24 --> Loader Class Initialized
INFO - 2021-03-29 21:44:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:24 --> Loader Class Initialized
INFO - 2021-03-29 21:44:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:24 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:24 --> Database Driver Class Initialized
INFO - 2021-03-29 21:44:25 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:25 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:25 --> Controller Class Initialized
DEBUG - 2021-03-29 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:44:25 --> Config Class Initialized
INFO - 2021-03-29 21:44:25 --> Hooks Class Initialized
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-29 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:25 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:25 --> Total execution time: 0.0477
INFO - 2021-03-29 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:25 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:25 --> Controller Class Initialized
INFO - 2021-03-29 21:44:25 --> URI Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Router Class Initialized
INFO - 2021-03-29 21:44:25 --> Config Class Initialized
INFO - 2021-03-29 21:44:25 --> Hooks Class Initialized
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:44:25 --> Output Class Initialized
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
DEBUG - 2021-03-29 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:25 --> Security Class Initialized
INFO - 2021-03-29 21:44:25 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:25 --> Total execution time: 0.0623
INFO - 2021-03-29 21:44:25 --> URI Class Initialized
DEBUG - 2021-03-29 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:25 --> Input Class Initialized
INFO - 2021-03-29 21:44:25 --> Language Class Initialized
INFO - 2021-03-29 21:44:25 --> Router Class Initialized
INFO - 2021-03-29 21:44:25 --> Output Class Initialized
INFO - 2021-03-29 21:44:25 --> Loader Class Initialized
INFO - 2021-03-29 21:44:25 --> Security Class Initialized
INFO - 2021-03-29 21:44:25 --> Helper loaded: url_helper
DEBUG - 2021-03-29 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:25 --> Input Class Initialized
INFO - 2021-03-29 21:44:25 --> Language Class Initialized
INFO - 2021-03-29 21:44:25 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:25 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:25 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:25 --> Loader Class Initialized
INFO - 2021-03-29 21:44:25 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:25 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:25 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:25 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:25 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:25 --> Database Driver Class Initialized
INFO - 2021-03-29 21:44:25 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:25 --> Controller Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
DEBUG - 2021-03-29 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:44:25 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:25 --> Total execution time: 0.0610
INFO - 2021-03-29 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:25 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:25 --> Controller Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> Model Class Initialized
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:44:25 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:25 --> Total execution time: 0.0574
INFO - 2021-03-29 21:44:33 --> Config Class Initialized
INFO - 2021-03-29 21:44:33 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:33 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:33 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:33 --> URI Class Initialized
INFO - 2021-03-29 21:44:33 --> Router Class Initialized
INFO - 2021-03-29 21:44:33 --> Output Class Initialized
INFO - 2021-03-29 21:44:33 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:33 --> Input Class Initialized
INFO - 2021-03-29 21:44:33 --> Language Class Initialized
INFO - 2021-03-29 21:44:33 --> Loader Class Initialized
INFO - 2021-03-29 21:44:33 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:33 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:33 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:33 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:33 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:33 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:33 --> Controller Class Initialized
INFO - 2021-03-29 21:44:33 --> Model Class Initialized
INFO - 2021-03-29 21:44:33 --> Model Class Initialized
INFO - 2021-03-29 21:44:33 --> Model Class Initialized
INFO - 2021-03-29 21:44:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:44:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:44:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 21:44:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:44:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:44:33 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:33 --> Total execution time: 0.0468
INFO - 2021-03-29 21:44:33 --> Config Class Initialized
INFO - 2021-03-29 21:44:33 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:33 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:33 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:33 --> URI Class Initialized
INFO - 2021-03-29 21:44:33 --> Router Class Initialized
INFO - 2021-03-29 21:44:33 --> Config Class Initialized
INFO - 2021-03-29 21:44:33 --> Hooks Class Initialized
INFO - 2021-03-29 21:44:33 --> Output Class Initialized
INFO - 2021-03-29 21:44:33 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:33 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:33 --> Utf8 Class Initialized
DEBUG - 2021-03-29 21:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:33 --> Input Class Initialized
INFO - 2021-03-29 21:44:33 --> Language Class Initialized
INFO - 2021-03-29 21:44:33 --> URI Class Initialized
ERROR - 2021-03-29 21:44:33 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:44:33 --> Router Class Initialized
INFO - 2021-03-29 21:44:33 --> Output Class Initialized
INFO - 2021-03-29 21:44:33 --> Config Class Initialized
INFO - 2021-03-29 21:44:33 --> Hooks Class Initialized
INFO - 2021-03-29 21:44:33 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:33 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 21:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:33 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:33 --> Input Class Initialized
INFO - 2021-03-29 21:44:33 --> Language Class Initialized
INFO - 2021-03-29 21:44:33 --> URI Class Initialized
ERROR - 2021-03-29 21:44:33 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:44:33 --> Config Class Initialized
INFO - 2021-03-29 21:44:33 --> Hooks Class Initialized
INFO - 2021-03-29 21:44:33 --> Router Class Initialized
DEBUG - 2021-03-29 21:44:33 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:33 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:33 --> Output Class Initialized
INFO - 2021-03-29 21:44:33 --> URI Class Initialized
INFO - 2021-03-29 21:44:33 --> Security Class Initialized
INFO - 2021-03-29 21:44:33 --> Router Class Initialized
DEBUG - 2021-03-29 21:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:33 --> Input Class Initialized
INFO - 2021-03-29 21:44:33 --> Language Class Initialized
INFO - 2021-03-29 21:44:33 --> Output Class Initialized
INFO - 2021-03-29 21:44:33 --> Security Class Initialized
ERROR - 2021-03-29 21:44:33 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 21:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:33 --> Input Class Initialized
INFO - 2021-03-29 21:44:33 --> Language Class Initialized
ERROR - 2021-03-29 21:44:33 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:44:37 --> Config Class Initialized
INFO - 2021-03-29 21:44:37 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:44:37 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:44:37 --> Utf8 Class Initialized
INFO - 2021-03-29 21:44:37 --> URI Class Initialized
INFO - 2021-03-29 21:44:37 --> Router Class Initialized
INFO - 2021-03-29 21:44:37 --> Output Class Initialized
INFO - 2021-03-29 21:44:37 --> Security Class Initialized
DEBUG - 2021-03-29 21:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:44:37 --> Input Class Initialized
INFO - 2021-03-29 21:44:37 --> Language Class Initialized
INFO - 2021-03-29 21:44:37 --> Loader Class Initialized
INFO - 2021-03-29 21:44:37 --> Helper loaded: url_helper
INFO - 2021-03-29 21:44:37 --> Helper loaded: form_helper
INFO - 2021-03-29 21:44:37 --> Helper loaded: common_helper
INFO - 2021-03-29 21:44:37 --> Helper loaded: util_helper
INFO - 2021-03-29 21:44:37 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:44:37 --> Form Validation Class Initialized
INFO - 2021-03-29 21:44:37 --> Controller Class Initialized
INFO - 2021-03-29 21:44:37 --> Model Class Initialized
INFO - 2021-03-29 21:44:37 --> Model Class Initialized
INFO - 2021-03-29 21:44:37 --> Model Class Initialized
INFO - 2021-03-29 21:44:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 21:44:37 --> Final output sent to browser
DEBUG - 2021-03-29 21:44:37 --> Total execution time: 0.0487
INFO - 2021-03-29 21:54:57 --> Config Class Initialized
INFO - 2021-03-29 21:54:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:54:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:54:57 --> Utf8 Class Initialized
INFO - 2021-03-29 21:54:57 --> URI Class Initialized
INFO - 2021-03-29 21:54:57 --> Router Class Initialized
INFO - 2021-03-29 21:54:57 --> Output Class Initialized
INFO - 2021-03-29 21:54:57 --> Security Class Initialized
DEBUG - 2021-03-29 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:54:57 --> Input Class Initialized
INFO - 2021-03-29 21:54:57 --> Language Class Initialized
INFO - 2021-03-29 21:54:57 --> Loader Class Initialized
INFO - 2021-03-29 21:54:57 --> Helper loaded: url_helper
INFO - 2021-03-29 21:54:57 --> Helper loaded: form_helper
INFO - 2021-03-29 21:54:57 --> Helper loaded: common_helper
INFO - 2021-03-29 21:54:57 --> Helper loaded: util_helper
INFO - 2021-03-29 21:54:57 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:54:57 --> Form Validation Class Initialized
INFO - 2021-03-29 21:54:57 --> Controller Class Initialized
INFO - 2021-03-29 21:54:57 --> Model Class Initialized
INFO - 2021-03-29 21:54:57 --> Model Class Initialized
INFO - 2021-03-29 21:54:57 --> Model Class Initialized
INFO - 2021-03-29 21:54:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 21:54:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 21:54:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 21:54:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 21:54:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 21:54:57 --> Final output sent to browser
DEBUG - 2021-03-29 21:54:57 --> Total execution time: 0.0379
INFO - 2021-03-29 21:54:57 --> Config Class Initialized
INFO - 2021-03-29 21:54:57 --> Config Class Initialized
INFO - 2021-03-29 21:54:57 --> Hooks Class Initialized
INFO - 2021-03-29 21:54:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 21:54:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:54:57 --> Utf8 Class Initialized
INFO - 2021-03-29 21:54:57 --> Utf8 Class Initialized
INFO - 2021-03-29 21:54:57 --> URI Class Initialized
INFO - 2021-03-29 21:54:57 --> URI Class Initialized
INFO - 2021-03-29 21:54:57 --> Router Class Initialized
INFO - 2021-03-29 21:54:57 --> Router Class Initialized
INFO - 2021-03-29 21:54:57 --> Output Class Initialized
INFO - 2021-03-29 21:54:57 --> Security Class Initialized
INFO - 2021-03-29 21:54:57 --> Output Class Initialized
DEBUG - 2021-03-29 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:54:57 --> Input Class Initialized
INFO - 2021-03-29 21:54:57 --> Language Class Initialized
ERROR - 2021-03-29 21:54:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:54:57 --> Security Class Initialized
DEBUG - 2021-03-29 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:54:57 --> Input Class Initialized
INFO - 2021-03-29 21:54:57 --> Language Class Initialized
ERROR - 2021-03-29 21:54:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:54:57 --> Config Class Initialized
INFO - 2021-03-29 21:54:57 --> Hooks Class Initialized
INFO - 2021-03-29 21:54:57 --> Config Class Initialized
INFO - 2021-03-29 21:54:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:54:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:54:57 --> Utf8 Class Initialized
INFO - 2021-03-29 21:54:57 --> URI Class Initialized
DEBUG - 2021-03-29 21:54:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:54:57 --> Utf8 Class Initialized
INFO - 2021-03-29 21:54:57 --> URI Class Initialized
INFO - 2021-03-29 21:54:57 --> Router Class Initialized
INFO - 2021-03-29 21:54:57 --> Output Class Initialized
INFO - 2021-03-29 21:54:57 --> Router Class Initialized
INFO - 2021-03-29 21:54:57 --> Security Class Initialized
INFO - 2021-03-29 21:54:57 --> Output Class Initialized
DEBUG - 2021-03-29 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:54:57 --> Input Class Initialized
INFO - 2021-03-29 21:54:57 --> Security Class Initialized
INFO - 2021-03-29 21:54:57 --> Language Class Initialized
DEBUG - 2021-03-29 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:54:57 --> Input Class Initialized
ERROR - 2021-03-29 21:54:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:54:57 --> Language Class Initialized
ERROR - 2021-03-29 21:54:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 21:55:04 --> Config Class Initialized
INFO - 2021-03-29 21:55:04 --> Hooks Class Initialized
DEBUG - 2021-03-29 21:55:04 --> UTF-8 Support Enabled
INFO - 2021-03-29 21:55:04 --> Utf8 Class Initialized
INFO - 2021-03-29 21:55:04 --> URI Class Initialized
INFO - 2021-03-29 21:55:04 --> Router Class Initialized
INFO - 2021-03-29 21:55:04 --> Output Class Initialized
INFO - 2021-03-29 21:55:04 --> Security Class Initialized
DEBUG - 2021-03-29 21:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 21:55:04 --> Input Class Initialized
INFO - 2021-03-29 21:55:04 --> Language Class Initialized
INFO - 2021-03-29 21:55:04 --> Loader Class Initialized
INFO - 2021-03-29 21:55:04 --> Helper loaded: url_helper
INFO - 2021-03-29 21:55:04 --> Helper loaded: form_helper
INFO - 2021-03-29 21:55:04 --> Helper loaded: common_helper
INFO - 2021-03-29 21:55:04 --> Helper loaded: util_helper
INFO - 2021-03-29 21:55:04 --> Database Driver Class Initialized
DEBUG - 2021-03-29 21:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 21:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 21:55:04 --> Form Validation Class Initialized
INFO - 2021-03-29 21:55:04 --> Controller Class Initialized
INFO - 2021-03-29 21:55:04 --> Model Class Initialized
INFO - 2021-03-29 21:55:04 --> Model Class Initialized
INFO - 2021-03-29 21:55:04 --> Model Class Initialized
INFO - 2021-03-29 21:55:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 21:55:04 --> Final output sent to browser
DEBUG - 2021-03-29 21:55:04 --> Total execution time: 0.0370
INFO - 2021-03-29 22:11:55 --> Config Class Initialized
INFO - 2021-03-29 22:11:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:11:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:11:55 --> Utf8 Class Initialized
INFO - 2021-03-29 22:11:55 --> URI Class Initialized
INFO - 2021-03-29 22:11:55 --> Router Class Initialized
INFO - 2021-03-29 22:11:55 --> Output Class Initialized
INFO - 2021-03-29 22:11:55 --> Security Class Initialized
DEBUG - 2021-03-29 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:11:55 --> Input Class Initialized
INFO - 2021-03-29 22:11:55 --> Language Class Initialized
INFO - 2021-03-29 22:11:55 --> Loader Class Initialized
INFO - 2021-03-29 22:11:55 --> Helper loaded: url_helper
INFO - 2021-03-29 22:11:55 --> Helper loaded: form_helper
INFO - 2021-03-29 22:11:55 --> Helper loaded: common_helper
INFO - 2021-03-29 22:11:55 --> Helper loaded: util_helper
INFO - 2021-03-29 22:11:55 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:11:55 --> Form Validation Class Initialized
INFO - 2021-03-29 22:11:55 --> Controller Class Initialized
INFO - 2021-03-29 22:11:55 --> Model Class Initialized
INFO - 2021-03-29 22:11:55 --> Model Class Initialized
INFO - 2021-03-29 22:11:55 --> Model Class Initialized
INFO - 2021-03-29 22:11:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 22:11:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 22:11:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 22:11:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 22:11:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 22:11:55 --> Final output sent to browser
DEBUG - 2021-03-29 22:11:55 --> Total execution time: 0.0508
INFO - 2021-03-29 22:11:55 --> Config Class Initialized
INFO - 2021-03-29 22:11:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:11:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:11:55 --> Utf8 Class Initialized
INFO - 2021-03-29 22:11:55 --> URI Class Initialized
INFO - 2021-03-29 22:11:55 --> Config Class Initialized
INFO - 2021-03-29 22:11:55 --> Hooks Class Initialized
INFO - 2021-03-29 22:11:55 --> Router Class Initialized
DEBUG - 2021-03-29 22:11:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:11:55 --> Utf8 Class Initialized
INFO - 2021-03-29 22:11:55 --> URI Class Initialized
INFO - 2021-03-29 22:11:55 --> Router Class Initialized
INFO - 2021-03-29 22:11:55 --> Output Class Initialized
INFO - 2021-03-29 22:11:55 --> Output Class Initialized
INFO - 2021-03-29 22:11:55 --> Security Class Initialized
INFO - 2021-03-29 22:11:55 --> Security Class Initialized
DEBUG - 2021-03-29 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:11:55 --> Input Class Initialized
INFO - 2021-03-29 22:11:55 --> Language Class Initialized
DEBUG - 2021-03-29 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:11:55 --> Input Class Initialized
INFO - 2021-03-29 22:11:55 --> Language Class Initialized
ERROR - 2021-03-29 22:11:55 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 22:11:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:11:55 --> Config Class Initialized
INFO - 2021-03-29 22:11:55 --> Config Class Initialized
INFO - 2021-03-29 22:11:55 --> Hooks Class Initialized
INFO - 2021-03-29 22:11:55 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:11:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:11:55 --> Utf8 Class Initialized
DEBUG - 2021-03-29 22:11:55 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:11:55 --> URI Class Initialized
INFO - 2021-03-29 22:11:55 --> Utf8 Class Initialized
INFO - 2021-03-29 22:11:55 --> URI Class Initialized
INFO - 2021-03-29 22:11:55 --> Router Class Initialized
INFO - 2021-03-29 22:11:55 --> Output Class Initialized
INFO - 2021-03-29 22:11:55 --> Router Class Initialized
INFO - 2021-03-29 22:11:55 --> Security Class Initialized
INFO - 2021-03-29 22:11:55 --> Output Class Initialized
DEBUG - 2021-03-29 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:11:55 --> Input Class Initialized
INFO - 2021-03-29 22:11:55 --> Language Class Initialized
INFO - 2021-03-29 22:11:55 --> Security Class Initialized
ERROR - 2021-03-29 22:11:55 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:11:55 --> Input Class Initialized
INFO - 2021-03-29 22:11:55 --> Language Class Initialized
ERROR - 2021-03-29 22:11:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:11:58 --> Config Class Initialized
INFO - 2021-03-29 22:11:58 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:11:58 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:11:58 --> Utf8 Class Initialized
INFO - 2021-03-29 22:11:58 --> URI Class Initialized
INFO - 2021-03-29 22:11:58 --> Router Class Initialized
INFO - 2021-03-29 22:11:58 --> Output Class Initialized
INFO - 2021-03-29 22:11:58 --> Security Class Initialized
DEBUG - 2021-03-29 22:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:11:58 --> Input Class Initialized
INFO - 2021-03-29 22:11:58 --> Language Class Initialized
INFO - 2021-03-29 22:11:58 --> Loader Class Initialized
INFO - 2021-03-29 22:11:58 --> Helper loaded: url_helper
INFO - 2021-03-29 22:11:58 --> Helper loaded: form_helper
INFO - 2021-03-29 22:11:58 --> Helper loaded: common_helper
INFO - 2021-03-29 22:11:58 --> Helper loaded: util_helper
INFO - 2021-03-29 22:11:58 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:11:58 --> Form Validation Class Initialized
INFO - 2021-03-29 22:11:58 --> Controller Class Initialized
INFO - 2021-03-29 22:11:58 --> Model Class Initialized
INFO - 2021-03-29 22:11:58 --> Model Class Initialized
INFO - 2021-03-29 22:11:58 --> Model Class Initialized
INFO - 2021-03-29 22:11:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 22:11:58 --> Final output sent to browser
DEBUG - 2021-03-29 22:11:58 --> Total execution time: 0.0351
INFO - 2021-03-29 22:12:26 --> Config Class Initialized
INFO - 2021-03-29 22:12:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:12:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:12:26 --> Utf8 Class Initialized
INFO - 2021-03-29 22:12:26 --> URI Class Initialized
INFO - 2021-03-29 22:12:26 --> Router Class Initialized
INFO - 2021-03-29 22:12:26 --> Output Class Initialized
INFO - 2021-03-29 22:12:26 --> Security Class Initialized
DEBUG - 2021-03-29 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:12:26 --> Input Class Initialized
INFO - 2021-03-29 22:12:26 --> Language Class Initialized
INFO - 2021-03-29 22:12:26 --> Loader Class Initialized
INFO - 2021-03-29 22:12:26 --> Helper loaded: url_helper
INFO - 2021-03-29 22:12:26 --> Helper loaded: form_helper
INFO - 2021-03-29 22:12:26 --> Helper loaded: common_helper
INFO - 2021-03-29 22:12:26 --> Helper loaded: util_helper
INFO - 2021-03-29 22:12:26 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:12:26 --> Form Validation Class Initialized
INFO - 2021-03-29 22:12:26 --> Controller Class Initialized
INFO - 2021-03-29 22:12:26 --> Model Class Initialized
INFO - 2021-03-29 22:12:26 --> Model Class Initialized
INFO - 2021-03-29 22:12:26 --> Model Class Initialized
INFO - 2021-03-29 22:12:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 22:12:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 22:12:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 22:12:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 22:12:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 22:12:26 --> Final output sent to browser
DEBUG - 2021-03-29 22:12:26 --> Total execution time: 0.0491
INFO - 2021-03-29 22:12:26 --> Config Class Initialized
INFO - 2021-03-29 22:12:26 --> Hooks Class Initialized
INFO - 2021-03-29 22:12:26 --> Config Class Initialized
INFO - 2021-03-29 22:12:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:12:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:12:26 --> Utf8 Class Initialized
INFO - 2021-03-29 22:12:26 --> URI Class Initialized
INFO - 2021-03-29 22:12:26 --> Router Class Initialized
INFO - 2021-03-29 22:12:26 --> Output Class Initialized
DEBUG - 2021-03-29 22:12:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:12:26 --> Utf8 Class Initialized
INFO - 2021-03-29 22:12:26 --> Security Class Initialized
INFO - 2021-03-29 22:12:26 --> URI Class Initialized
DEBUG - 2021-03-29 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:12:26 --> Input Class Initialized
INFO - 2021-03-29 22:12:26 --> Language Class Initialized
INFO - 2021-03-29 22:12:26 --> Router Class Initialized
ERROR - 2021-03-29 22:12:26 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:12:26 --> Output Class Initialized
INFO - 2021-03-29 22:12:26 --> Security Class Initialized
DEBUG - 2021-03-29 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:12:26 --> Input Class Initialized
INFO - 2021-03-29 22:12:26 --> Language Class Initialized
ERROR - 2021-03-29 22:12:26 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:12:26 --> Config Class Initialized
INFO - 2021-03-29 22:12:26 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:12:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:12:26 --> Utf8 Class Initialized
INFO - 2021-03-29 22:12:26 --> URI Class Initialized
INFO - 2021-03-29 22:12:26 --> Config Class Initialized
INFO - 2021-03-29 22:12:26 --> Hooks Class Initialized
INFO - 2021-03-29 22:12:26 --> Router Class Initialized
DEBUG - 2021-03-29 22:12:26 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:12:26 --> Utf8 Class Initialized
INFO - 2021-03-29 22:12:26 --> URI Class Initialized
INFO - 2021-03-29 22:12:26 --> Output Class Initialized
INFO - 2021-03-29 22:12:26 --> Router Class Initialized
INFO - 2021-03-29 22:12:26 --> Security Class Initialized
DEBUG - 2021-03-29 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:12:26 --> Output Class Initialized
INFO - 2021-03-29 22:12:26 --> Input Class Initialized
INFO - 2021-03-29 22:12:26 --> Language Class Initialized
INFO - 2021-03-29 22:12:26 --> Security Class Initialized
DEBUG - 2021-03-29 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:12:26 --> Input Class Initialized
INFO - 2021-03-29 22:12:26 --> Language Class Initialized
ERROR - 2021-03-29 22:12:26 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 22:12:26 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:12:30 --> Config Class Initialized
INFO - 2021-03-29 22:12:30 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:12:30 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:12:30 --> Utf8 Class Initialized
INFO - 2021-03-29 22:12:30 --> URI Class Initialized
INFO - 2021-03-29 22:12:30 --> Router Class Initialized
INFO - 2021-03-29 22:12:30 --> Output Class Initialized
INFO - 2021-03-29 22:12:30 --> Security Class Initialized
DEBUG - 2021-03-29 22:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:12:30 --> Input Class Initialized
INFO - 2021-03-29 22:12:30 --> Language Class Initialized
INFO - 2021-03-29 22:12:30 --> Loader Class Initialized
INFO - 2021-03-29 22:12:30 --> Helper loaded: url_helper
INFO - 2021-03-29 22:12:30 --> Helper loaded: form_helper
INFO - 2021-03-29 22:12:30 --> Helper loaded: common_helper
INFO - 2021-03-29 22:12:30 --> Helper loaded: util_helper
INFO - 2021-03-29 22:12:30 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:12:30 --> Form Validation Class Initialized
INFO - 2021-03-29 22:12:30 --> Controller Class Initialized
INFO - 2021-03-29 22:12:30 --> Model Class Initialized
INFO - 2021-03-29 22:12:30 --> Model Class Initialized
INFO - 2021-03-29 22:12:30 --> Model Class Initialized
INFO - 2021-03-29 22:12:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 22:12:30 --> Final output sent to browser
DEBUG - 2021-03-29 22:12:30 --> Total execution time: 0.0370
INFO - 2021-03-29 22:14:31 --> Config Class Initialized
INFO - 2021-03-29 22:14:31 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:14:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:14:31 --> Utf8 Class Initialized
INFO - 2021-03-29 22:14:31 --> URI Class Initialized
INFO - 2021-03-29 22:14:31 --> Router Class Initialized
INFO - 2021-03-29 22:14:31 --> Output Class Initialized
INFO - 2021-03-29 22:14:31 --> Security Class Initialized
DEBUG - 2021-03-29 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:14:31 --> Input Class Initialized
INFO - 2021-03-29 22:14:31 --> Language Class Initialized
INFO - 2021-03-29 22:14:31 --> Loader Class Initialized
INFO - 2021-03-29 22:14:31 --> Helper loaded: url_helper
INFO - 2021-03-29 22:14:31 --> Helper loaded: form_helper
INFO - 2021-03-29 22:14:31 --> Helper loaded: common_helper
INFO - 2021-03-29 22:14:31 --> Helper loaded: util_helper
INFO - 2021-03-29 22:14:31 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:14:31 --> Form Validation Class Initialized
INFO - 2021-03-29 22:14:31 --> Controller Class Initialized
INFO - 2021-03-29 22:14:31 --> Model Class Initialized
INFO - 2021-03-29 22:14:31 --> Model Class Initialized
INFO - 2021-03-29 22:14:31 --> Model Class Initialized
INFO - 2021-03-29 22:14:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 22:14:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 22:14:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 22:14:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 22:14:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 22:14:31 --> Final output sent to browser
DEBUG - 2021-03-29 22:14:31 --> Total execution time: 0.0361
INFO - 2021-03-29 22:14:31 --> Config Class Initialized
INFO - 2021-03-29 22:14:31 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:14:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:14:31 --> Utf8 Class Initialized
INFO - 2021-03-29 22:14:31 --> URI Class Initialized
INFO - 2021-03-29 22:14:31 --> Router Class Initialized
INFO - 2021-03-29 22:14:31 --> Output Class Initialized
INFO - 2021-03-29 22:14:31 --> Security Class Initialized
INFO - 2021-03-29 22:14:31 --> Config Class Initialized
INFO - 2021-03-29 22:14:31 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:14:31 --> Input Class Initialized
INFO - 2021-03-29 22:14:31 --> Language Class Initialized
DEBUG - 2021-03-29 22:14:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:14:31 --> Utf8 Class Initialized
ERROR - 2021-03-29 22:14:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:14:31 --> URI Class Initialized
INFO - 2021-03-29 22:14:31 --> Router Class Initialized
INFO - 2021-03-29 22:14:31 --> Output Class Initialized
INFO - 2021-03-29 22:14:31 --> Security Class Initialized
DEBUG - 2021-03-29 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:14:31 --> Input Class Initialized
INFO - 2021-03-29 22:14:31 --> Language Class Initialized
ERROR - 2021-03-29 22:14:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:14:31 --> Config Class Initialized
INFO - 2021-03-29 22:14:31 --> Hooks Class Initialized
INFO - 2021-03-29 22:14:31 --> Config Class Initialized
DEBUG - 2021-03-29 22:14:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:14:31 --> Hooks Class Initialized
INFO - 2021-03-29 22:14:31 --> Utf8 Class Initialized
INFO - 2021-03-29 22:14:31 --> URI Class Initialized
DEBUG - 2021-03-29 22:14:31 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:14:31 --> Utf8 Class Initialized
INFO - 2021-03-29 22:14:31 --> URI Class Initialized
INFO - 2021-03-29 22:14:31 --> Router Class Initialized
INFO - 2021-03-29 22:14:31 --> Router Class Initialized
INFO - 2021-03-29 22:14:31 --> Output Class Initialized
INFO - 2021-03-29 22:14:31 --> Output Class Initialized
INFO - 2021-03-29 22:14:31 --> Security Class Initialized
DEBUG - 2021-03-29 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:14:31 --> Input Class Initialized
INFO - 2021-03-29 22:14:31 --> Language Class Initialized
ERROR - 2021-03-29 22:14:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:14:31 --> Security Class Initialized
DEBUG - 2021-03-29 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:14:31 --> Input Class Initialized
INFO - 2021-03-29 22:14:31 --> Language Class Initialized
ERROR - 2021-03-29 22:14:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:14:34 --> Config Class Initialized
INFO - 2021-03-29 22:14:34 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:14:34 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:14:34 --> Utf8 Class Initialized
INFO - 2021-03-29 22:14:34 --> URI Class Initialized
INFO - 2021-03-29 22:14:34 --> Router Class Initialized
INFO - 2021-03-29 22:14:34 --> Output Class Initialized
INFO - 2021-03-29 22:14:34 --> Security Class Initialized
DEBUG - 2021-03-29 22:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:14:34 --> Input Class Initialized
INFO - 2021-03-29 22:14:34 --> Language Class Initialized
INFO - 2021-03-29 22:14:34 --> Loader Class Initialized
INFO - 2021-03-29 22:14:34 --> Helper loaded: url_helper
INFO - 2021-03-29 22:14:34 --> Helper loaded: form_helper
INFO - 2021-03-29 22:14:34 --> Helper loaded: common_helper
INFO - 2021-03-29 22:14:34 --> Helper loaded: util_helper
INFO - 2021-03-29 22:14:34 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:14:34 --> Form Validation Class Initialized
INFO - 2021-03-29 22:14:34 --> Controller Class Initialized
INFO - 2021-03-29 22:14:34 --> Model Class Initialized
INFO - 2021-03-29 22:14:34 --> Model Class Initialized
INFO - 2021-03-29 22:14:34 --> Model Class Initialized
INFO - 2021-03-29 22:14:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 22:14:34 --> Final output sent to browser
DEBUG - 2021-03-29 22:14:34 --> Total execution time: 0.0451
INFO - 2021-03-29 22:16:49 --> Config Class Initialized
INFO - 2021-03-29 22:16:49 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:16:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:16:49 --> Utf8 Class Initialized
INFO - 2021-03-29 22:16:49 --> URI Class Initialized
INFO - 2021-03-29 22:16:49 --> Router Class Initialized
INFO - 2021-03-29 22:16:49 --> Output Class Initialized
INFO - 2021-03-29 22:16:49 --> Security Class Initialized
DEBUG - 2021-03-29 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:16:49 --> Input Class Initialized
INFO - 2021-03-29 22:16:49 --> Language Class Initialized
INFO - 2021-03-29 22:16:49 --> Loader Class Initialized
INFO - 2021-03-29 22:16:49 --> Helper loaded: url_helper
INFO - 2021-03-29 22:16:49 --> Helper loaded: form_helper
INFO - 2021-03-29 22:16:49 --> Helper loaded: common_helper
INFO - 2021-03-29 22:16:49 --> Helper loaded: util_helper
INFO - 2021-03-29 22:16:49 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:16:49 --> Form Validation Class Initialized
INFO - 2021-03-29 22:16:49 --> Controller Class Initialized
INFO - 2021-03-29 22:16:49 --> Model Class Initialized
INFO - 2021-03-29 22:16:49 --> Model Class Initialized
INFO - 2021-03-29 22:16:49 --> Model Class Initialized
INFO - 2021-03-29 22:16:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 22:16:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 22:16:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 22:16:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 22:16:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 22:16:49 --> Final output sent to browser
DEBUG - 2021-03-29 22:16:49 --> Total execution time: 0.0467
INFO - 2021-03-29 22:16:49 --> Config Class Initialized
INFO - 2021-03-29 22:16:49 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:16:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:16:49 --> Utf8 Class Initialized
INFO - 2021-03-29 22:16:49 --> Config Class Initialized
INFO - 2021-03-29 22:16:49 --> URI Class Initialized
INFO - 2021-03-29 22:16:49 --> Hooks Class Initialized
INFO - 2021-03-29 22:16:49 --> Router Class Initialized
DEBUG - 2021-03-29 22:16:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:16:49 --> Utf8 Class Initialized
INFO - 2021-03-29 22:16:49 --> Output Class Initialized
INFO - 2021-03-29 22:16:49 --> URI Class Initialized
INFO - 2021-03-29 22:16:49 --> Security Class Initialized
INFO - 2021-03-29 22:16:49 --> Router Class Initialized
DEBUG - 2021-03-29 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:16:49 --> Input Class Initialized
INFO - 2021-03-29 22:16:49 --> Language Class Initialized
INFO - 2021-03-29 22:16:49 --> Output Class Initialized
ERROR - 2021-03-29 22:16:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:16:49 --> Security Class Initialized
DEBUG - 2021-03-29 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:16:49 --> Input Class Initialized
INFO - 2021-03-29 22:16:49 --> Language Class Initialized
ERROR - 2021-03-29 22:16:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:16:49 --> Config Class Initialized
INFO - 2021-03-29 22:16:49 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:16:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:16:49 --> Utf8 Class Initialized
INFO - 2021-03-29 22:16:49 --> URI Class Initialized
INFO - 2021-03-29 22:16:49 --> Router Class Initialized
INFO - 2021-03-29 22:16:49 --> Output Class Initialized
INFO - 2021-03-29 22:16:49 --> Security Class Initialized
INFO - 2021-03-29 22:16:49 --> Config Class Initialized
INFO - 2021-03-29 22:16:49 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:16:49 --> Input Class Initialized
INFO - 2021-03-29 22:16:49 --> Language Class Initialized
DEBUG - 2021-03-29 22:16:49 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:16:49 --> Utf8 Class Initialized
INFO - 2021-03-29 22:16:49 --> URI Class Initialized
ERROR - 2021-03-29 22:16:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:16:49 --> Router Class Initialized
INFO - 2021-03-29 22:16:49 --> Output Class Initialized
INFO - 2021-03-29 22:16:49 --> Security Class Initialized
DEBUG - 2021-03-29 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:16:49 --> Input Class Initialized
INFO - 2021-03-29 22:16:49 --> Language Class Initialized
ERROR - 2021-03-29 22:16:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:16:52 --> Config Class Initialized
INFO - 2021-03-29 22:16:52 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:16:52 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:16:52 --> Utf8 Class Initialized
INFO - 2021-03-29 22:16:52 --> URI Class Initialized
INFO - 2021-03-29 22:16:52 --> Router Class Initialized
INFO - 2021-03-29 22:16:52 --> Output Class Initialized
INFO - 2021-03-29 22:16:52 --> Security Class Initialized
DEBUG - 2021-03-29 22:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:16:52 --> Input Class Initialized
INFO - 2021-03-29 22:16:52 --> Language Class Initialized
INFO - 2021-03-29 22:16:52 --> Loader Class Initialized
INFO - 2021-03-29 22:16:52 --> Helper loaded: url_helper
INFO - 2021-03-29 22:16:52 --> Helper loaded: form_helper
INFO - 2021-03-29 22:16:52 --> Helper loaded: common_helper
INFO - 2021-03-29 22:16:52 --> Helper loaded: util_helper
INFO - 2021-03-29 22:16:52 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:16:52 --> Form Validation Class Initialized
INFO - 2021-03-29 22:16:52 --> Controller Class Initialized
INFO - 2021-03-29 22:16:52 --> Model Class Initialized
INFO - 2021-03-29 22:16:52 --> Model Class Initialized
INFO - 2021-03-29 22:16:52 --> Model Class Initialized
INFO - 2021-03-29 22:16:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 22:16:52 --> Final output sent to browser
DEBUG - 2021-03-29 22:16:52 --> Total execution time: 0.0351
INFO - 2021-03-29 22:17:57 --> Config Class Initialized
INFO - 2021-03-29 22:17:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:17:57 --> Utf8 Class Initialized
INFO - 2021-03-29 22:17:57 --> URI Class Initialized
INFO - 2021-03-29 22:17:57 --> Router Class Initialized
INFO - 2021-03-29 22:17:57 --> Output Class Initialized
INFO - 2021-03-29 22:17:57 --> Security Class Initialized
DEBUG - 2021-03-29 22:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:17:57 --> Input Class Initialized
INFO - 2021-03-29 22:17:57 --> Language Class Initialized
INFO - 2021-03-29 22:17:57 --> Loader Class Initialized
INFO - 2021-03-29 22:17:57 --> Helper loaded: url_helper
INFO - 2021-03-29 22:17:57 --> Helper loaded: form_helper
INFO - 2021-03-29 22:17:57 --> Helper loaded: common_helper
INFO - 2021-03-29 22:17:57 --> Helper loaded: util_helper
INFO - 2021-03-29 22:17:57 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:17:57 --> Form Validation Class Initialized
INFO - 2021-03-29 22:17:57 --> Controller Class Initialized
INFO - 2021-03-29 22:17:57 --> Model Class Initialized
INFO - 2021-03-29 22:17:57 --> Model Class Initialized
INFO - 2021-03-29 22:17:57 --> Model Class Initialized
INFO - 2021-03-29 22:17:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 22:17:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 22:17:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 22:17:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 22:17:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 22:17:57 --> Final output sent to browser
DEBUG - 2021-03-29 22:17:57 --> Total execution time: 0.0358
INFO - 2021-03-29 22:17:57 --> Config Class Initialized
INFO - 2021-03-29 22:17:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:17:57 --> Utf8 Class Initialized
INFO - 2021-03-29 22:17:57 --> Config Class Initialized
INFO - 2021-03-29 22:17:57 --> Hooks Class Initialized
INFO - 2021-03-29 22:17:57 --> URI Class Initialized
DEBUG - 2021-03-29 22:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:17:57 --> Router Class Initialized
INFO - 2021-03-29 22:17:57 --> Utf8 Class Initialized
INFO - 2021-03-29 22:17:57 --> URI Class Initialized
INFO - 2021-03-29 22:17:57 --> Output Class Initialized
INFO - 2021-03-29 22:17:57 --> Router Class Initialized
INFO - 2021-03-29 22:17:57 --> Security Class Initialized
DEBUG - 2021-03-29 22:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:17:57 --> Input Class Initialized
INFO - 2021-03-29 22:17:57 --> Output Class Initialized
INFO - 2021-03-29 22:17:57 --> Language Class Initialized
INFO - 2021-03-29 22:17:57 --> Security Class Initialized
ERROR - 2021-03-29 22:17:57 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 22:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:17:57 --> Input Class Initialized
INFO - 2021-03-29 22:17:57 --> Language Class Initialized
ERROR - 2021-03-29 22:17:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:17:57 --> Config Class Initialized
INFO - 2021-03-29 22:17:57 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:17:57 --> Utf8 Class Initialized
INFO - 2021-03-29 22:17:57 --> Config Class Initialized
INFO - 2021-03-29 22:17:57 --> Hooks Class Initialized
INFO - 2021-03-29 22:17:57 --> URI Class Initialized
INFO - 2021-03-29 22:17:57 --> Router Class Initialized
DEBUG - 2021-03-29 22:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:17:57 --> Utf8 Class Initialized
INFO - 2021-03-29 22:17:57 --> Output Class Initialized
INFO - 2021-03-29 22:17:57 --> URI Class Initialized
INFO - 2021-03-29 22:17:57 --> Security Class Initialized
INFO - 2021-03-29 22:17:57 --> Router Class Initialized
DEBUG - 2021-03-29 22:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:17:57 --> Input Class Initialized
INFO - 2021-03-29 22:17:57 --> Language Class Initialized
INFO - 2021-03-29 22:17:57 --> Output Class Initialized
ERROR - 2021-03-29 22:17:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:17:57 --> Security Class Initialized
DEBUG - 2021-03-29 22:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:17:57 --> Input Class Initialized
INFO - 2021-03-29 22:17:57 --> Language Class Initialized
ERROR - 2021-03-29 22:17:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:18:00 --> Config Class Initialized
INFO - 2021-03-29 22:18:00 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:18:00 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:18:00 --> Utf8 Class Initialized
INFO - 2021-03-29 22:18:00 --> URI Class Initialized
INFO - 2021-03-29 22:18:00 --> Router Class Initialized
INFO - 2021-03-29 22:18:00 --> Output Class Initialized
INFO - 2021-03-29 22:18:00 --> Security Class Initialized
DEBUG - 2021-03-29 22:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:18:00 --> Input Class Initialized
INFO - 2021-03-29 22:18:00 --> Language Class Initialized
INFO - 2021-03-29 22:18:00 --> Loader Class Initialized
INFO - 2021-03-29 22:18:00 --> Helper loaded: url_helper
INFO - 2021-03-29 22:18:00 --> Helper loaded: form_helper
INFO - 2021-03-29 22:18:00 --> Helper loaded: common_helper
INFO - 2021-03-29 22:18:00 --> Helper loaded: util_helper
INFO - 2021-03-29 22:18:00 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:18:00 --> Form Validation Class Initialized
INFO - 2021-03-29 22:18:00 --> Controller Class Initialized
INFO - 2021-03-29 22:18:00 --> Model Class Initialized
INFO - 2021-03-29 22:18:00 --> Model Class Initialized
INFO - 2021-03-29 22:18:00 --> Model Class Initialized
INFO - 2021-03-29 22:18:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 22:18:00 --> Final output sent to browser
DEBUG - 2021-03-29 22:18:00 --> Total execution time: 0.0463
INFO - 2021-03-29 22:49:38 --> Config Class Initialized
INFO - 2021-03-29 22:49:38 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:49:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:49:38 --> Utf8 Class Initialized
INFO - 2021-03-29 22:49:38 --> URI Class Initialized
INFO - 2021-03-29 22:49:38 --> Router Class Initialized
INFO - 2021-03-29 22:49:38 --> Output Class Initialized
INFO - 2021-03-29 22:49:38 --> Security Class Initialized
DEBUG - 2021-03-29 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:49:38 --> Input Class Initialized
INFO - 2021-03-29 22:49:38 --> Language Class Initialized
INFO - 2021-03-29 22:49:38 --> Loader Class Initialized
INFO - 2021-03-29 22:49:38 --> Helper loaded: url_helper
INFO - 2021-03-29 22:49:38 --> Helper loaded: form_helper
INFO - 2021-03-29 22:49:38 --> Helper loaded: common_helper
INFO - 2021-03-29 22:49:38 --> Helper loaded: util_helper
INFO - 2021-03-29 22:49:38 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:49:38 --> Form Validation Class Initialized
INFO - 2021-03-29 22:49:38 --> Controller Class Initialized
INFO - 2021-03-29 22:49:38 --> Model Class Initialized
INFO - 2021-03-29 22:49:38 --> Model Class Initialized
INFO - 2021-03-29 22:49:38 --> Model Class Initialized
INFO - 2021-03-29 22:49:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 22:49:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 22:49:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 22:49:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 22:49:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 22:49:38 --> Final output sent to browser
DEBUG - 2021-03-29 22:49:38 --> Total execution time: 0.0358
INFO - 2021-03-29 22:49:38 --> Config Class Initialized
INFO - 2021-03-29 22:49:38 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:49:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:49:38 --> Utf8 Class Initialized
INFO - 2021-03-29 22:49:38 --> URI Class Initialized
INFO - 2021-03-29 22:49:38 --> Router Class Initialized
INFO - 2021-03-29 22:49:38 --> Output Class Initialized
INFO - 2021-03-29 22:49:38 --> Config Class Initialized
INFO - 2021-03-29 22:49:38 --> Hooks Class Initialized
INFO - 2021-03-29 22:49:38 --> Security Class Initialized
DEBUG - 2021-03-29 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:49:38 --> Input Class Initialized
DEBUG - 2021-03-29 22:49:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:49:38 --> Utf8 Class Initialized
INFO - 2021-03-29 22:49:38 --> Language Class Initialized
INFO - 2021-03-29 22:49:38 --> URI Class Initialized
ERROR - 2021-03-29 22:49:38 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:49:38 --> Router Class Initialized
INFO - 2021-03-29 22:49:38 --> Output Class Initialized
INFO - 2021-03-29 22:49:38 --> Security Class Initialized
DEBUG - 2021-03-29 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:49:38 --> Input Class Initialized
INFO - 2021-03-29 22:49:38 --> Language Class Initialized
ERROR - 2021-03-29 22:49:38 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:49:38 --> Config Class Initialized
INFO - 2021-03-29 22:49:38 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:49:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:49:38 --> Utf8 Class Initialized
INFO - 2021-03-29 22:49:38 --> URI Class Initialized
INFO - 2021-03-29 22:49:38 --> Router Class Initialized
INFO - 2021-03-29 22:49:38 --> Output Class Initialized
INFO - 2021-03-29 22:49:38 --> Security Class Initialized
DEBUG - 2021-03-29 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:49:38 --> Input Class Initialized
INFO - 2021-03-29 22:49:38 --> Language Class Initialized
ERROR - 2021-03-29 22:49:38 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:49:38 --> Config Class Initialized
INFO - 2021-03-29 22:49:38 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:49:38 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:49:38 --> Utf8 Class Initialized
INFO - 2021-03-29 22:49:38 --> URI Class Initialized
INFO - 2021-03-29 22:49:38 --> Router Class Initialized
INFO - 2021-03-29 22:49:38 --> Output Class Initialized
INFO - 2021-03-29 22:49:38 --> Security Class Initialized
DEBUG - 2021-03-29 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:49:38 --> Input Class Initialized
INFO - 2021-03-29 22:49:38 --> Language Class Initialized
ERROR - 2021-03-29 22:49:38 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 22:49:41 --> Config Class Initialized
INFO - 2021-03-29 22:49:41 --> Hooks Class Initialized
DEBUG - 2021-03-29 22:49:41 --> UTF-8 Support Enabled
INFO - 2021-03-29 22:49:41 --> Utf8 Class Initialized
INFO - 2021-03-29 22:49:41 --> URI Class Initialized
INFO - 2021-03-29 22:49:41 --> Router Class Initialized
INFO - 2021-03-29 22:49:41 --> Output Class Initialized
INFO - 2021-03-29 22:49:41 --> Security Class Initialized
DEBUG - 2021-03-29 22:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 22:49:41 --> Input Class Initialized
INFO - 2021-03-29 22:49:41 --> Language Class Initialized
INFO - 2021-03-29 22:49:41 --> Loader Class Initialized
INFO - 2021-03-29 22:49:41 --> Helper loaded: url_helper
INFO - 2021-03-29 22:49:41 --> Helper loaded: form_helper
INFO - 2021-03-29 22:49:41 --> Helper loaded: common_helper
INFO - 2021-03-29 22:49:41 --> Helper loaded: util_helper
INFO - 2021-03-29 22:49:41 --> Database Driver Class Initialized
DEBUG - 2021-03-29 22:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 22:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 22:49:41 --> Form Validation Class Initialized
INFO - 2021-03-29 22:49:41 --> Controller Class Initialized
INFO - 2021-03-29 22:49:41 --> Model Class Initialized
INFO - 2021-03-29 22:49:41 --> Model Class Initialized
INFO - 2021-03-29 22:49:41 --> Model Class Initialized
INFO - 2021-03-29 22:49:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 22:49:41 --> Final output sent to browser
DEBUG - 2021-03-29 22:49:41 --> Total execution time: 0.0442
INFO - 2021-03-29 23:22:16 --> Config Class Initialized
INFO - 2021-03-29 23:22:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:22:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:22:16 --> Utf8 Class Initialized
INFO - 2021-03-29 23:22:16 --> URI Class Initialized
INFO - 2021-03-29 23:22:16 --> Router Class Initialized
INFO - 2021-03-29 23:22:16 --> Output Class Initialized
INFO - 2021-03-29 23:22:16 --> Security Class Initialized
DEBUG - 2021-03-29 23:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:22:16 --> Input Class Initialized
INFO - 2021-03-29 23:22:16 --> Language Class Initialized
INFO - 2021-03-29 23:22:16 --> Loader Class Initialized
INFO - 2021-03-29 23:22:16 --> Helper loaded: url_helper
INFO - 2021-03-29 23:22:16 --> Helper loaded: form_helper
INFO - 2021-03-29 23:22:16 --> Helper loaded: common_helper
INFO - 2021-03-29 23:22:16 --> Helper loaded: util_helper
INFO - 2021-03-29 23:22:16 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:22:16 --> Form Validation Class Initialized
INFO - 2021-03-29 23:22:16 --> Controller Class Initialized
INFO - 2021-03-29 23:22:16 --> Model Class Initialized
INFO - 2021-03-29 23:22:16 --> Model Class Initialized
INFO - 2021-03-29 23:22:16 --> Model Class Initialized
INFO - 2021-03-29 23:22:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 23:22:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 23:22:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 23:22:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 23:22:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 23:22:16 --> Final output sent to browser
DEBUG - 2021-03-29 23:22:16 --> Total execution time: 0.0383
INFO - 2021-03-29 23:22:16 --> Config Class Initialized
INFO - 2021-03-29 23:22:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:22:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:22:16 --> Utf8 Class Initialized
INFO - 2021-03-29 23:22:16 --> URI Class Initialized
INFO - 2021-03-29 23:22:16 --> Config Class Initialized
INFO - 2021-03-29 23:22:16 --> Hooks Class Initialized
INFO - 2021-03-29 23:22:16 --> Router Class Initialized
DEBUG - 2021-03-29 23:22:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:22:16 --> Utf8 Class Initialized
INFO - 2021-03-29 23:22:16 --> URI Class Initialized
INFO - 2021-03-29 23:22:16 --> Output Class Initialized
INFO - 2021-03-29 23:22:16 --> Router Class Initialized
INFO - 2021-03-29 23:22:16 --> Security Class Initialized
INFO - 2021-03-29 23:22:16 --> Output Class Initialized
DEBUG - 2021-03-29 23:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:22:16 --> Input Class Initialized
INFO - 2021-03-29 23:22:16 --> Security Class Initialized
INFO - 2021-03-29 23:22:16 --> Language Class Initialized
DEBUG - 2021-03-29 23:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:22:16 --> Input Class Initialized
INFO - 2021-03-29 23:22:16 --> Language Class Initialized
ERROR - 2021-03-29 23:22:16 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 23:22:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:22:16 --> Config Class Initialized
INFO - 2021-03-29 23:22:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:22:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:22:16 --> Utf8 Class Initialized
INFO - 2021-03-29 23:22:16 --> URI Class Initialized
INFO - 2021-03-29 23:22:16 --> Router Class Initialized
INFO - 2021-03-29 23:22:16 --> Output Class Initialized
INFO - 2021-03-29 23:22:16 --> Security Class Initialized
DEBUG - 2021-03-29 23:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:22:16 --> Input Class Initialized
INFO - 2021-03-29 23:22:16 --> Language Class Initialized
ERROR - 2021-03-29 23:22:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:22:16 --> Config Class Initialized
INFO - 2021-03-29 23:22:16 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:22:16 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:22:16 --> Utf8 Class Initialized
INFO - 2021-03-29 23:22:16 --> URI Class Initialized
INFO - 2021-03-29 23:22:16 --> Router Class Initialized
INFO - 2021-03-29 23:22:16 --> Output Class Initialized
INFO - 2021-03-29 23:22:16 --> Security Class Initialized
DEBUG - 2021-03-29 23:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:22:16 --> Input Class Initialized
INFO - 2021-03-29 23:22:16 --> Language Class Initialized
ERROR - 2021-03-29 23:22:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:22:20 --> Config Class Initialized
INFO - 2021-03-29 23:22:20 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:22:20 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:22:20 --> Utf8 Class Initialized
INFO - 2021-03-29 23:22:20 --> URI Class Initialized
INFO - 2021-03-29 23:22:20 --> Router Class Initialized
INFO - 2021-03-29 23:22:20 --> Output Class Initialized
INFO - 2021-03-29 23:22:20 --> Security Class Initialized
DEBUG - 2021-03-29 23:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:22:20 --> Input Class Initialized
INFO - 2021-03-29 23:22:20 --> Language Class Initialized
INFO - 2021-03-29 23:22:20 --> Loader Class Initialized
INFO - 2021-03-29 23:22:20 --> Helper loaded: url_helper
INFO - 2021-03-29 23:22:20 --> Helper loaded: form_helper
INFO - 2021-03-29 23:22:20 --> Helper loaded: common_helper
INFO - 2021-03-29 23:22:20 --> Helper loaded: util_helper
INFO - 2021-03-29 23:22:20 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:22:20 --> Form Validation Class Initialized
INFO - 2021-03-29 23:22:20 --> Controller Class Initialized
INFO - 2021-03-29 23:22:20 --> Model Class Initialized
INFO - 2021-03-29 23:22:20 --> Model Class Initialized
INFO - 2021-03-29 23:22:20 --> Model Class Initialized
INFO - 2021-03-29 23:22:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 23:22:20 --> Final output sent to browser
DEBUG - 2021-03-29 23:22:20 --> Total execution time: 0.0475
INFO - 2021-03-29 23:23:40 --> Config Class Initialized
INFO - 2021-03-29 23:23:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:23:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:23:40 --> Utf8 Class Initialized
INFO - 2021-03-29 23:23:40 --> URI Class Initialized
INFO - 2021-03-29 23:23:40 --> Router Class Initialized
INFO - 2021-03-29 23:23:40 --> Output Class Initialized
INFO - 2021-03-29 23:23:40 --> Security Class Initialized
DEBUG - 2021-03-29 23:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:23:40 --> Input Class Initialized
INFO - 2021-03-29 23:23:40 --> Language Class Initialized
INFO - 2021-03-29 23:23:40 --> Loader Class Initialized
INFO - 2021-03-29 23:23:40 --> Helper loaded: url_helper
INFO - 2021-03-29 23:23:40 --> Helper loaded: form_helper
INFO - 2021-03-29 23:23:40 --> Helper loaded: common_helper
INFO - 2021-03-29 23:23:40 --> Helper loaded: util_helper
INFO - 2021-03-29 23:23:40 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:23:40 --> Form Validation Class Initialized
INFO - 2021-03-29 23:23:40 --> Controller Class Initialized
INFO - 2021-03-29 23:23:40 --> Model Class Initialized
INFO - 2021-03-29 23:23:40 --> Model Class Initialized
INFO - 2021-03-29 23:23:40 --> Model Class Initialized
INFO - 2021-03-29 23:23:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 23:23:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 23:23:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 23:23:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 23:23:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 23:23:40 --> Final output sent to browser
DEBUG - 2021-03-29 23:23:40 --> Total execution time: 0.0343
INFO - 2021-03-29 23:23:40 --> Config Class Initialized
INFO - 2021-03-29 23:23:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:23:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:23:40 --> Utf8 Class Initialized
INFO - 2021-03-29 23:23:40 --> Config Class Initialized
INFO - 2021-03-29 23:23:40 --> Hooks Class Initialized
INFO - 2021-03-29 23:23:40 --> URI Class Initialized
INFO - 2021-03-29 23:23:40 --> Router Class Initialized
DEBUG - 2021-03-29 23:23:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:23:40 --> Utf8 Class Initialized
INFO - 2021-03-29 23:23:40 --> Output Class Initialized
INFO - 2021-03-29 23:23:40 --> URI Class Initialized
INFO - 2021-03-29 23:23:40 --> Security Class Initialized
INFO - 2021-03-29 23:23:40 --> Router Class Initialized
DEBUG - 2021-03-29 23:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:23:40 --> Input Class Initialized
INFO - 2021-03-29 23:23:40 --> Language Class Initialized
INFO - 2021-03-29 23:23:40 --> Output Class Initialized
INFO - 2021-03-29 23:23:40 --> Security Class Initialized
ERROR - 2021-03-29 23:23:40 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 23:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:23:40 --> Input Class Initialized
INFO - 2021-03-29 23:23:40 --> Language Class Initialized
ERROR - 2021-03-29 23:23:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:23:40 --> Config Class Initialized
INFO - 2021-03-29 23:23:40 --> Hooks Class Initialized
INFO - 2021-03-29 23:23:40 --> Config Class Initialized
INFO - 2021-03-29 23:23:40 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:23:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:23:40 --> Utf8 Class Initialized
DEBUG - 2021-03-29 23:23:40 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:23:40 --> Utf8 Class Initialized
INFO - 2021-03-29 23:23:40 --> URI Class Initialized
INFO - 2021-03-29 23:23:40 --> URI Class Initialized
INFO - 2021-03-29 23:23:40 --> Router Class Initialized
INFO - 2021-03-29 23:23:40 --> Router Class Initialized
INFO - 2021-03-29 23:23:40 --> Output Class Initialized
INFO - 2021-03-29 23:23:40 --> Output Class Initialized
INFO - 2021-03-29 23:23:40 --> Security Class Initialized
INFO - 2021-03-29 23:23:40 --> Security Class Initialized
DEBUG - 2021-03-29 23:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-29 23:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:23:40 --> Input Class Initialized
INFO - 2021-03-29 23:23:40 --> Input Class Initialized
INFO - 2021-03-29 23:23:40 --> Language Class Initialized
INFO - 2021-03-29 23:23:40 --> Language Class Initialized
ERROR - 2021-03-29 23:23:40 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 23:23:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:23:43 --> Config Class Initialized
INFO - 2021-03-29 23:23:43 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:23:43 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:23:43 --> Utf8 Class Initialized
INFO - 2021-03-29 23:23:43 --> URI Class Initialized
INFO - 2021-03-29 23:23:43 --> Router Class Initialized
INFO - 2021-03-29 23:23:43 --> Output Class Initialized
INFO - 2021-03-29 23:23:43 --> Security Class Initialized
DEBUG - 2021-03-29 23:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:23:43 --> Input Class Initialized
INFO - 2021-03-29 23:23:43 --> Language Class Initialized
INFO - 2021-03-29 23:23:43 --> Loader Class Initialized
INFO - 2021-03-29 23:23:43 --> Helper loaded: url_helper
INFO - 2021-03-29 23:23:43 --> Helper loaded: form_helper
INFO - 2021-03-29 23:23:43 --> Helper loaded: common_helper
INFO - 2021-03-29 23:23:43 --> Helper loaded: util_helper
INFO - 2021-03-29 23:23:43 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:23:43 --> Form Validation Class Initialized
INFO - 2021-03-29 23:23:43 --> Controller Class Initialized
INFO - 2021-03-29 23:23:43 --> Model Class Initialized
INFO - 2021-03-29 23:23:43 --> Model Class Initialized
INFO - 2021-03-29 23:23:43 --> Model Class Initialized
INFO - 2021-03-29 23:23:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 23:23:43 --> Final output sent to browser
DEBUG - 2021-03-29 23:23:43 --> Total execution time: 0.0459
INFO - 2021-03-29 23:26:58 --> Config Class Initialized
INFO - 2021-03-29 23:26:58 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:26:58 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:26:58 --> Utf8 Class Initialized
INFO - 2021-03-29 23:26:58 --> URI Class Initialized
INFO - 2021-03-29 23:26:58 --> Router Class Initialized
INFO - 2021-03-29 23:26:58 --> Output Class Initialized
INFO - 2021-03-29 23:26:58 --> Security Class Initialized
DEBUG - 2021-03-29 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:26:58 --> Input Class Initialized
INFO - 2021-03-29 23:26:58 --> Language Class Initialized
INFO - 2021-03-29 23:26:58 --> Loader Class Initialized
INFO - 2021-03-29 23:26:58 --> Helper loaded: url_helper
INFO - 2021-03-29 23:26:58 --> Helper loaded: form_helper
INFO - 2021-03-29 23:26:58 --> Helper loaded: common_helper
INFO - 2021-03-29 23:26:58 --> Helper loaded: util_helper
INFO - 2021-03-29 23:26:58 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:26:58 --> Form Validation Class Initialized
INFO - 2021-03-29 23:26:58 --> Controller Class Initialized
INFO - 2021-03-29 23:26:58 --> Model Class Initialized
INFO - 2021-03-29 23:26:58 --> Model Class Initialized
INFO - 2021-03-29 23:26:58 --> Model Class Initialized
INFO - 2021-03-29 23:26:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 23:26:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 23:26:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 23:26:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 23:26:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 23:26:58 --> Final output sent to browser
DEBUG - 2021-03-29 23:26:58 --> Total execution time: 0.0368
INFO - 2021-03-29 23:26:58 --> Config Class Initialized
INFO - 2021-03-29 23:26:58 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:26:58 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:26:58 --> Utf8 Class Initialized
INFO - 2021-03-29 23:26:58 --> URI Class Initialized
INFO - 2021-03-29 23:26:58 --> Router Class Initialized
INFO - 2021-03-29 23:26:58 --> Output Class Initialized
INFO - 2021-03-29 23:26:58 --> Security Class Initialized
DEBUG - 2021-03-29 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:26:58 --> Input Class Initialized
INFO - 2021-03-29 23:26:58 --> Language Class Initialized
ERROR - 2021-03-29 23:26:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:26:58 --> Config Class Initialized
INFO - 2021-03-29 23:26:58 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:26:58 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:26:58 --> Utf8 Class Initialized
INFO - 2021-03-29 23:26:58 --> URI Class Initialized
INFO - 2021-03-29 23:26:58 --> Router Class Initialized
INFO - 2021-03-29 23:26:58 --> Output Class Initialized
INFO - 2021-03-29 23:26:58 --> Security Class Initialized
DEBUG - 2021-03-29 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:26:58 --> Input Class Initialized
INFO - 2021-03-29 23:26:58 --> Language Class Initialized
ERROR - 2021-03-29 23:26:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:26:58 --> Config Class Initialized
INFO - 2021-03-29 23:26:58 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:26:58 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:26:58 --> Utf8 Class Initialized
INFO - 2021-03-29 23:26:58 --> URI Class Initialized
INFO - 2021-03-29 23:26:58 --> Router Class Initialized
INFO - 2021-03-29 23:26:58 --> Output Class Initialized
INFO - 2021-03-29 23:26:58 --> Security Class Initialized
DEBUG - 2021-03-29 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:26:58 --> Input Class Initialized
INFO - 2021-03-29 23:26:58 --> Language Class Initialized
ERROR - 2021-03-29 23:26:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:26:58 --> Config Class Initialized
INFO - 2021-03-29 23:26:58 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:26:58 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:26:58 --> Utf8 Class Initialized
INFO - 2021-03-29 23:26:58 --> URI Class Initialized
INFO - 2021-03-29 23:26:58 --> Router Class Initialized
INFO - 2021-03-29 23:26:58 --> Output Class Initialized
INFO - 2021-03-29 23:26:58 --> Security Class Initialized
DEBUG - 2021-03-29 23:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:26:58 --> Input Class Initialized
INFO - 2021-03-29 23:26:58 --> Language Class Initialized
ERROR - 2021-03-29 23:26:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:27:03 --> Config Class Initialized
INFO - 2021-03-29 23:27:03 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:27:03 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:03 --> Utf8 Class Initialized
INFO - 2021-03-29 23:27:03 --> URI Class Initialized
INFO - 2021-03-29 23:27:03 --> Router Class Initialized
INFO - 2021-03-29 23:27:03 --> Output Class Initialized
INFO - 2021-03-29 23:27:03 --> Security Class Initialized
DEBUG - 2021-03-29 23:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:03 --> Input Class Initialized
INFO - 2021-03-29 23:27:03 --> Language Class Initialized
INFO - 2021-03-29 23:27:03 --> Loader Class Initialized
INFO - 2021-03-29 23:27:03 --> Helper loaded: url_helper
INFO - 2021-03-29 23:27:03 --> Helper loaded: form_helper
INFO - 2021-03-29 23:27:03 --> Helper loaded: common_helper
INFO - 2021-03-29 23:27:03 --> Helper loaded: util_helper
INFO - 2021-03-29 23:27:03 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:27:03 --> Form Validation Class Initialized
INFO - 2021-03-29 23:27:03 --> Controller Class Initialized
INFO - 2021-03-29 23:27:03 --> Model Class Initialized
INFO - 2021-03-29 23:27:03 --> Model Class Initialized
INFO - 2021-03-29 23:27:03 --> Model Class Initialized
INFO - 2021-03-29 23:27:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 23:27:03 --> Final output sent to browser
DEBUG - 2021-03-29 23:27:03 --> Total execution time: 0.0475
INFO - 2021-03-29 23:27:41 --> Config Class Initialized
INFO - 2021-03-29 23:27:41 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:27:41 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:41 --> Utf8 Class Initialized
INFO - 2021-03-29 23:27:41 --> URI Class Initialized
INFO - 2021-03-29 23:27:41 --> Router Class Initialized
INFO - 2021-03-29 23:27:41 --> Output Class Initialized
INFO - 2021-03-29 23:27:41 --> Security Class Initialized
DEBUG - 2021-03-29 23:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:41 --> Input Class Initialized
INFO - 2021-03-29 23:27:41 --> Language Class Initialized
INFO - 2021-03-29 23:27:41 --> Loader Class Initialized
INFO - 2021-03-29 23:27:41 --> Helper loaded: url_helper
INFO - 2021-03-29 23:27:41 --> Helper loaded: form_helper
INFO - 2021-03-29 23:27:41 --> Helper loaded: common_helper
INFO - 2021-03-29 23:27:41 --> Helper loaded: util_helper
INFO - 2021-03-29 23:27:41 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:27:41 --> Form Validation Class Initialized
INFO - 2021-03-29 23:27:41 --> Controller Class Initialized
INFO - 2021-03-29 23:27:41 --> Model Class Initialized
INFO - 2021-03-29 23:27:41 --> Model Class Initialized
INFO - 2021-03-29 23:27:41 --> Model Class Initialized
INFO - 2021-03-29 23:27:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 23:27:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 23:27:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 23:27:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 23:27:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 23:27:41 --> Final output sent to browser
DEBUG - 2021-03-29 23:27:41 --> Total execution time: 0.0470
INFO - 2021-03-29 23:27:41 --> Config Class Initialized
INFO - 2021-03-29 23:27:41 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:27:41 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:41 --> Utf8 Class Initialized
INFO - 2021-03-29 23:27:41 --> Config Class Initialized
INFO - 2021-03-29 23:27:41 --> URI Class Initialized
INFO - 2021-03-29 23:27:41 --> Hooks Class Initialized
INFO - 2021-03-29 23:27:41 --> Router Class Initialized
DEBUG - 2021-03-29 23:27:41 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:41 --> Utf8 Class Initialized
INFO - 2021-03-29 23:27:41 --> Output Class Initialized
INFO - 2021-03-29 23:27:41 --> URI Class Initialized
INFO - 2021-03-29 23:27:41 --> Security Class Initialized
INFO - 2021-03-29 23:27:41 --> Router Class Initialized
DEBUG - 2021-03-29 23:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:41 --> Input Class Initialized
INFO - 2021-03-29 23:27:41 --> Output Class Initialized
INFO - 2021-03-29 23:27:41 --> Language Class Initialized
INFO - 2021-03-29 23:27:41 --> Security Class Initialized
ERROR - 2021-03-29 23:27:41 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 23:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:41 --> Input Class Initialized
INFO - 2021-03-29 23:27:41 --> Language Class Initialized
ERROR - 2021-03-29 23:27:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:27:41 --> Config Class Initialized
INFO - 2021-03-29 23:27:41 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:27:41 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:41 --> Utf8 Class Initialized
INFO - 2021-03-29 23:27:41 --> URI Class Initialized
INFO - 2021-03-29 23:27:41 --> Router Class Initialized
INFO - 2021-03-29 23:27:41 --> Config Class Initialized
INFO - 2021-03-29 23:27:41 --> Hooks Class Initialized
INFO - 2021-03-29 23:27:41 --> Output Class Initialized
INFO - 2021-03-29 23:27:41 --> Security Class Initialized
DEBUG - 2021-03-29 23:27:41 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:41 --> Utf8 Class Initialized
DEBUG - 2021-03-29 23:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:41 --> Input Class Initialized
INFO - 2021-03-29 23:27:41 --> URI Class Initialized
INFO - 2021-03-29 23:27:41 --> Language Class Initialized
ERROR - 2021-03-29 23:27:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:27:41 --> Router Class Initialized
INFO - 2021-03-29 23:27:41 --> Output Class Initialized
INFO - 2021-03-29 23:27:41 --> Security Class Initialized
DEBUG - 2021-03-29 23:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:41 --> Input Class Initialized
INFO - 2021-03-29 23:27:41 --> Language Class Initialized
ERROR - 2021-03-29 23:27:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:27:44 --> Config Class Initialized
INFO - 2021-03-29 23:27:44 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:27:44 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:27:44 --> Utf8 Class Initialized
INFO - 2021-03-29 23:27:44 --> URI Class Initialized
INFO - 2021-03-29 23:27:44 --> Router Class Initialized
INFO - 2021-03-29 23:27:44 --> Output Class Initialized
INFO - 2021-03-29 23:27:44 --> Security Class Initialized
DEBUG - 2021-03-29 23:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:27:44 --> Input Class Initialized
INFO - 2021-03-29 23:27:44 --> Language Class Initialized
INFO - 2021-03-29 23:27:44 --> Loader Class Initialized
INFO - 2021-03-29 23:27:44 --> Helper loaded: url_helper
INFO - 2021-03-29 23:27:44 --> Helper loaded: form_helper
INFO - 2021-03-29 23:27:44 --> Helper loaded: common_helper
INFO - 2021-03-29 23:27:44 --> Helper loaded: util_helper
INFO - 2021-03-29 23:27:44 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:27:44 --> Form Validation Class Initialized
INFO - 2021-03-29 23:27:44 --> Controller Class Initialized
INFO - 2021-03-29 23:27:44 --> Model Class Initialized
INFO - 2021-03-29 23:27:44 --> Model Class Initialized
INFO - 2021-03-29 23:27:44 --> Model Class Initialized
INFO - 2021-03-29 23:27:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 23:27:44 --> Final output sent to browser
DEBUG - 2021-03-29 23:27:44 --> Total execution time: 0.0471
INFO - 2021-03-29 23:29:59 --> Config Class Initialized
INFO - 2021-03-29 23:29:59 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:29:59 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:29:59 --> Utf8 Class Initialized
INFO - 2021-03-29 23:29:59 --> URI Class Initialized
INFO - 2021-03-29 23:29:59 --> Router Class Initialized
INFO - 2021-03-29 23:29:59 --> Output Class Initialized
INFO - 2021-03-29 23:29:59 --> Security Class Initialized
DEBUG - 2021-03-29 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:29:59 --> Input Class Initialized
INFO - 2021-03-29 23:29:59 --> Language Class Initialized
INFO - 2021-03-29 23:29:59 --> Loader Class Initialized
INFO - 2021-03-29 23:29:59 --> Helper loaded: url_helper
INFO - 2021-03-29 23:29:59 --> Helper loaded: form_helper
INFO - 2021-03-29 23:29:59 --> Helper loaded: common_helper
INFO - 2021-03-29 23:29:59 --> Helper loaded: util_helper
INFO - 2021-03-29 23:29:59 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:29:59 --> Form Validation Class Initialized
INFO - 2021-03-29 23:29:59 --> Controller Class Initialized
INFO - 2021-03-29 23:29:59 --> Model Class Initialized
INFO - 2021-03-29 23:29:59 --> Model Class Initialized
INFO - 2021-03-29 23:29:59 --> Model Class Initialized
INFO - 2021-03-29 23:29:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 23:29:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 23:29:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 23:29:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 23:29:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 23:29:59 --> Final output sent to browser
DEBUG - 2021-03-29 23:29:59 --> Total execution time: 0.0353
INFO - 2021-03-29 23:29:59 --> Config Class Initialized
INFO - 2021-03-29 23:29:59 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:29:59 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:29:59 --> Utf8 Class Initialized
INFO - 2021-03-29 23:29:59 --> URI Class Initialized
INFO - 2021-03-29 23:29:59 --> Config Class Initialized
INFO - 2021-03-29 23:29:59 --> Hooks Class Initialized
INFO - 2021-03-29 23:29:59 --> Router Class Initialized
DEBUG - 2021-03-29 23:29:59 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:29:59 --> Utf8 Class Initialized
INFO - 2021-03-29 23:29:59 --> Output Class Initialized
INFO - 2021-03-29 23:29:59 --> URI Class Initialized
INFO - 2021-03-29 23:29:59 --> Security Class Initialized
INFO - 2021-03-29 23:29:59 --> Router Class Initialized
DEBUG - 2021-03-29 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:29:59 --> Input Class Initialized
INFO - 2021-03-29 23:29:59 --> Language Class Initialized
INFO - 2021-03-29 23:29:59 --> Output Class Initialized
INFO - 2021-03-29 23:29:59 --> Security Class Initialized
ERROR - 2021-03-29 23:29:59 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:29:59 --> Input Class Initialized
INFO - 2021-03-29 23:29:59 --> Language Class Initialized
ERROR - 2021-03-29 23:29:59 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:29:59 --> Config Class Initialized
INFO - 2021-03-29 23:29:59 --> Config Class Initialized
INFO - 2021-03-29 23:29:59 --> Hooks Class Initialized
INFO - 2021-03-29 23:29:59 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:29:59 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 23:29:59 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:29:59 --> Utf8 Class Initialized
INFO - 2021-03-29 23:29:59 --> Utf8 Class Initialized
INFO - 2021-03-29 23:29:59 --> URI Class Initialized
INFO - 2021-03-29 23:29:59 --> URI Class Initialized
INFO - 2021-03-29 23:29:59 --> Router Class Initialized
INFO - 2021-03-29 23:29:59 --> Router Class Initialized
INFO - 2021-03-29 23:29:59 --> Output Class Initialized
INFO - 2021-03-29 23:29:59 --> Output Class Initialized
INFO - 2021-03-29 23:29:59 --> Security Class Initialized
INFO - 2021-03-29 23:29:59 --> Security Class Initialized
DEBUG - 2021-03-29 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:29:59 --> Input Class Initialized
DEBUG - 2021-03-29 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:29:59 --> Input Class Initialized
INFO - 2021-03-29 23:29:59 --> Language Class Initialized
INFO - 2021-03-29 23:29:59 --> Language Class Initialized
ERROR - 2021-03-29 23:29:59 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-29 23:29:59 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:30:02 --> Config Class Initialized
INFO - 2021-03-29 23:30:02 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:30:02 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:30:02 --> Utf8 Class Initialized
INFO - 2021-03-29 23:30:02 --> URI Class Initialized
INFO - 2021-03-29 23:30:02 --> Router Class Initialized
INFO - 2021-03-29 23:30:02 --> Output Class Initialized
INFO - 2021-03-29 23:30:02 --> Security Class Initialized
DEBUG - 2021-03-29 23:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:30:02 --> Input Class Initialized
INFO - 2021-03-29 23:30:02 --> Language Class Initialized
INFO - 2021-03-29 23:30:02 --> Loader Class Initialized
INFO - 2021-03-29 23:30:02 --> Helper loaded: url_helper
INFO - 2021-03-29 23:30:02 --> Helper loaded: form_helper
INFO - 2021-03-29 23:30:02 --> Helper loaded: common_helper
INFO - 2021-03-29 23:30:02 --> Helper loaded: util_helper
INFO - 2021-03-29 23:30:02 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:30:02 --> Form Validation Class Initialized
INFO - 2021-03-29 23:30:02 --> Controller Class Initialized
INFO - 2021-03-29 23:30:02 --> Model Class Initialized
INFO - 2021-03-29 23:30:02 --> Model Class Initialized
INFO - 2021-03-29 23:30:02 --> Model Class Initialized
INFO - 2021-03-29 23:30:02 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 23:30:02 --> Final output sent to browser
DEBUG - 2021-03-29 23:30:02 --> Total execution time: 0.0396
INFO - 2021-03-29 23:31:18 --> Config Class Initialized
INFO - 2021-03-29 23:31:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:31:18 --> Utf8 Class Initialized
INFO - 2021-03-29 23:31:18 --> URI Class Initialized
INFO - 2021-03-29 23:31:18 --> Router Class Initialized
INFO - 2021-03-29 23:31:18 --> Output Class Initialized
INFO - 2021-03-29 23:31:18 --> Security Class Initialized
DEBUG - 2021-03-29 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:31:18 --> Input Class Initialized
INFO - 2021-03-29 23:31:18 --> Language Class Initialized
INFO - 2021-03-29 23:31:18 --> Loader Class Initialized
INFO - 2021-03-29 23:31:18 --> Helper loaded: url_helper
INFO - 2021-03-29 23:31:18 --> Helper loaded: form_helper
INFO - 2021-03-29 23:31:18 --> Helper loaded: common_helper
INFO - 2021-03-29 23:31:18 --> Helper loaded: util_helper
INFO - 2021-03-29 23:31:18 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:31:18 --> Form Validation Class Initialized
INFO - 2021-03-29 23:31:18 --> Controller Class Initialized
INFO - 2021-03-29 23:31:18 --> Model Class Initialized
INFO - 2021-03-29 23:31:18 --> Model Class Initialized
INFO - 2021-03-29 23:31:18 --> Model Class Initialized
INFO - 2021-03-29 23:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-29 23:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-29 23:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-29 23:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-29 23:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-29 23:31:18 --> Final output sent to browser
DEBUG - 2021-03-29 23:31:18 --> Total execution time: 0.0353
INFO - 2021-03-29 23:31:18 --> Config Class Initialized
INFO - 2021-03-29 23:31:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:31:18 --> Utf8 Class Initialized
INFO - 2021-03-29 23:31:18 --> URI Class Initialized
INFO - 2021-03-29 23:31:18 --> Config Class Initialized
INFO - 2021-03-29 23:31:18 --> Hooks Class Initialized
INFO - 2021-03-29 23:31:18 --> Router Class Initialized
INFO - 2021-03-29 23:31:18 --> Output Class Initialized
DEBUG - 2021-03-29 23:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:31:18 --> Utf8 Class Initialized
INFO - 2021-03-29 23:31:18 --> URI Class Initialized
INFO - 2021-03-29 23:31:18 --> Security Class Initialized
DEBUG - 2021-03-29 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:31:18 --> Input Class Initialized
INFO - 2021-03-29 23:31:18 --> Router Class Initialized
INFO - 2021-03-29 23:31:18 --> Language Class Initialized
INFO - 2021-03-29 23:31:18 --> Output Class Initialized
ERROR - 2021-03-29 23:31:18 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:31:18 --> Security Class Initialized
DEBUG - 2021-03-29 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:31:18 --> Input Class Initialized
INFO - 2021-03-29 23:31:18 --> Language Class Initialized
ERROR - 2021-03-29 23:31:18 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:31:18 --> Config Class Initialized
INFO - 2021-03-29 23:31:18 --> Hooks Class Initialized
INFO - 2021-03-29 23:31:18 --> Config Class Initialized
INFO - 2021-03-29 23:31:18 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-03-29 23:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:31:18 --> Utf8 Class Initialized
INFO - 2021-03-29 23:31:18 --> Utf8 Class Initialized
INFO - 2021-03-29 23:31:18 --> URI Class Initialized
INFO - 2021-03-29 23:31:18 --> URI Class Initialized
INFO - 2021-03-29 23:31:18 --> Router Class Initialized
INFO - 2021-03-29 23:31:18 --> Router Class Initialized
INFO - 2021-03-29 23:31:18 --> Output Class Initialized
INFO - 2021-03-29 23:31:18 --> Security Class Initialized
INFO - 2021-03-29 23:31:18 --> Output Class Initialized
DEBUG - 2021-03-29 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:31:18 --> Input Class Initialized
INFO - 2021-03-29 23:31:18 --> Language Class Initialized
INFO - 2021-03-29 23:31:18 --> Security Class Initialized
ERROR - 2021-03-29 23:31:18 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-29 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:31:18 --> Input Class Initialized
INFO - 2021-03-29 23:31:18 --> Language Class Initialized
ERROR - 2021-03-29 23:31:18 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-29 23:31:21 --> Config Class Initialized
INFO - 2021-03-29 23:31:21 --> Hooks Class Initialized
DEBUG - 2021-03-29 23:31:21 --> UTF-8 Support Enabled
INFO - 2021-03-29 23:31:21 --> Utf8 Class Initialized
INFO - 2021-03-29 23:31:21 --> URI Class Initialized
INFO - 2021-03-29 23:31:21 --> Router Class Initialized
INFO - 2021-03-29 23:31:21 --> Output Class Initialized
INFO - 2021-03-29 23:31:21 --> Security Class Initialized
DEBUG - 2021-03-29 23:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-29 23:31:21 --> Input Class Initialized
INFO - 2021-03-29 23:31:21 --> Language Class Initialized
INFO - 2021-03-29 23:31:21 --> Loader Class Initialized
INFO - 2021-03-29 23:31:21 --> Helper loaded: url_helper
INFO - 2021-03-29 23:31:21 --> Helper loaded: form_helper
INFO - 2021-03-29 23:31:21 --> Helper loaded: common_helper
INFO - 2021-03-29 23:31:21 --> Helper loaded: util_helper
INFO - 2021-03-29 23:31:21 --> Database Driver Class Initialized
DEBUG - 2021-03-29 23:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-29 23:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-29 23:31:21 --> Form Validation Class Initialized
INFO - 2021-03-29 23:31:21 --> Controller Class Initialized
INFO - 2021-03-29 23:31:21 --> Model Class Initialized
INFO - 2021-03-29 23:31:21 --> Model Class Initialized
INFO - 2021-03-29 23:31:21 --> Model Class Initialized
INFO - 2021-03-29 23:31:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-29 23:31:21 --> Final output sent to browser
DEBUG - 2021-03-29 23:31:21 --> Total execution time: 0.0351
