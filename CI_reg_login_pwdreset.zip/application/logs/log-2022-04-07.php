<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-07 04:21:30 --> Config Class Initialized
INFO - 2022-04-07 04:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:30 --> URI Class Initialized
INFO - 2022-04-07 04:21:30 --> Router Class Initialized
INFO - 2022-04-07 04:21:30 --> Output Class Initialized
INFO - 2022-04-07 04:21:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:30 --> Input Class Initialized
INFO - 2022-04-07 04:21:30 --> Language Class Initialized
INFO - 2022-04-07 04:21:30 --> Loader Class Initialized
INFO - 2022-04-07 04:21:30 --> Helper loaded: url_helper
INFO - 2022-04-07 04:21:30 --> Helper loaded: form_helper
INFO - 2022-04-07 04:21:30 --> Helper loaded: common_helper
INFO - 2022-04-07 04:21:30 --> Helper loaded: util_helper
INFO - 2022-04-07 04:21:30 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:21:30 --> Form Validation Class Initialized
INFO - 2022-04-07 04:21:30 --> Controller Class Initialized
INFO - 2022-04-07 04:21:30 --> Model Class Initialized
INFO - 2022-04-07 04:21:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:21:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:21:30 --> Final output sent to browser
DEBUG - 2022-04-07 04:21:30 --> Total execution time: 0.1969
INFO - 2022-04-07 04:21:30 --> Config Class Initialized
INFO - 2022-04-07 04:21:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:21:30 --> Config Class Initialized
INFO - 2022-04-07 04:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:30 --> URI Class Initialized
INFO - 2022-04-07 04:21:30 --> Config Class Initialized
INFO - 2022-04-07 04:21:30 --> Router Class Initialized
INFO - 2022-04-07 04:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:30 --> Output Class Initialized
INFO - 2022-04-07 04:21:30 --> URI Class Initialized
INFO - 2022-04-07 04:21:30 --> Config Class Initialized
INFO - 2022-04-07 04:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:30 --> Security Class Initialized
INFO - 2022-04-07 04:21:30 --> URI Class Initialized
DEBUG - 2022-04-07 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:30 --> Router Class Initialized
INFO - 2022-04-07 04:21:30 --> Input Class Initialized
INFO - 2022-04-07 04:21:30 --> Language Class Initialized
DEBUG - 2022-04-07 04:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:30 --> Output Class Initialized
INFO - 2022-04-07 04:21:30 --> URI Class Initialized
ERROR - 2022-04-07 04:21:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:21:30 --> Security Class Initialized
INFO - 2022-04-07 04:21:30 --> Router Class Initialized
DEBUG - 2022-04-07 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:30 --> Input Class Initialized
INFO - 2022-04-07 04:21:30 --> Router Class Initialized
INFO - 2022-04-07 04:21:30 --> Output Class Initialized
INFO - 2022-04-07 04:21:30 --> Language Class Initialized
INFO - 2022-04-07 04:21:30 --> Output Class Initialized
INFO - 2022-04-07 04:21:30 --> Security Class Initialized
ERROR - 2022-04-07 04:21:30 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:30 --> Input Class Initialized
INFO - 2022-04-07 04:21:30 --> Language Class Initialized
INFO - 2022-04-07 04:21:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:21:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:21:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:21:30 --> Input Class Initialized
INFO - 2022-04-07 04:21:30 --> Language Class Initialized
ERROR - 2022-04-07 04:21:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:21:43 --> Config Class Initialized
INFO - 2022-04-07 04:21:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:43 --> URI Class Initialized
INFO - 2022-04-07 04:21:43 --> Router Class Initialized
INFO - 2022-04-07 04:21:43 --> Output Class Initialized
INFO - 2022-04-07 04:21:43 --> Security Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:43 --> Input Class Initialized
INFO - 2022-04-07 04:21:43 --> Language Class Initialized
INFO - 2022-04-07 04:21:43 --> Loader Class Initialized
INFO - 2022-04-07 04:21:43 --> Helper loaded: url_helper
INFO - 2022-04-07 04:21:43 --> Helper loaded: form_helper
INFO - 2022-04-07 04:21:43 --> Helper loaded: common_helper
INFO - 2022-04-07 04:21:43 --> Helper loaded: util_helper
INFO - 2022-04-07 04:21:43 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:21:43 --> Form Validation Class Initialized
INFO - 2022-04-07 04:21:43 --> Controller Class Initialized
INFO - 2022-04-07 04:21:43 --> Model Class Initialized
INFO - 2022-04-07 04:21:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:21:43 --> Config Class Initialized
INFO - 2022-04-07 04:21:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:43 --> URI Class Initialized
INFO - 2022-04-07 04:21:43 --> Router Class Initialized
INFO - 2022-04-07 04:21:43 --> Output Class Initialized
INFO - 2022-04-07 04:21:43 --> Security Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:43 --> Input Class Initialized
INFO - 2022-04-07 04:21:43 --> Language Class Initialized
INFO - 2022-04-07 04:21:43 --> Loader Class Initialized
INFO - 2022-04-07 04:21:43 --> Helper loaded: url_helper
INFO - 2022-04-07 04:21:43 --> Helper loaded: form_helper
INFO - 2022-04-07 04:21:43 --> Helper loaded: common_helper
INFO - 2022-04-07 04:21:43 --> Helper loaded: util_helper
INFO - 2022-04-07 04:21:43 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:21:43 --> Form Validation Class Initialized
INFO - 2022-04-07 04:21:43 --> Controller Class Initialized
INFO - 2022-04-07 04:21:43 --> Model Class Initialized
INFO - 2022-04-07 04:21:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:21:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:21:43 --> Final output sent to browser
DEBUG - 2022-04-07 04:21:43 --> Total execution time: 0.0533
INFO - 2022-04-07 04:21:43 --> Config Class Initialized
INFO - 2022-04-07 04:21:43 --> Hooks Class Initialized
INFO - 2022-04-07 04:21:43 --> Config Class Initialized
INFO - 2022-04-07 04:21:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:21:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:43 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:21:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:43 --> URI Class Initialized
INFO - 2022-04-07 04:21:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:43 --> URI Class Initialized
INFO - 2022-04-07 04:21:43 --> Router Class Initialized
INFO - 2022-04-07 04:21:43 --> Router Class Initialized
INFO - 2022-04-07 04:21:43 --> Config Class Initialized
INFO - 2022-04-07 04:21:43 --> Output Class Initialized
INFO - 2022-04-07 04:21:43 --> Hooks Class Initialized
INFO - 2022-04-07 04:21:43 --> Output Class Initialized
INFO - 2022-04-07 04:21:43 --> Security Class Initialized
DEBUG - 2022-04-07 04:21:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:21:43 --> URI Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:43 --> Input Class Initialized
INFO - 2022-04-07 04:21:43 --> Language Class Initialized
ERROR - 2022-04-07 04:21:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:21:43 --> Security Class Initialized
INFO - 2022-04-07 04:21:43 --> Router Class Initialized
INFO - 2022-04-07 04:21:43 --> Config Class Initialized
INFO - 2022-04-07 04:21:43 --> Hooks Class Initialized
INFO - 2022-04-07 04:21:43 --> Output Class Initialized
DEBUG - 2022-04-07 04:21:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:21:43 --> Security Class Initialized
INFO - 2022-04-07 04:21:43 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:43 --> URI Class Initialized
INFO - 2022-04-07 04:21:43 --> Input Class Initialized
INFO - 2022-04-07 04:21:43 --> Language Class Initialized
INFO - 2022-04-07 04:21:43 --> Router Class Initialized
DEBUG - 2022-04-07 04:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:43 --> Input Class Initialized
INFO - 2022-04-07 04:21:43 --> Output Class Initialized
ERROR - 2022-04-07 04:21:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:21:43 --> Language Class Initialized
INFO - 2022-04-07 04:21:43 --> Security Class Initialized
ERROR - 2022-04-07 04:21:43 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:21:43 --> Input Class Initialized
INFO - 2022-04-07 04:21:43 --> Language Class Initialized
ERROR - 2022-04-07 04:21:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:24 --> Config Class Initialized
INFO - 2022-04-07 04:25:24 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:25:24 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:24 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:24 --> URI Class Initialized
DEBUG - 2022-04-07 04:25:24 --> No URI present. Default controller set.
INFO - 2022-04-07 04:25:24 --> Router Class Initialized
INFO - 2022-04-07 04:25:24 --> Output Class Initialized
INFO - 2022-04-07 04:25:24 --> Security Class Initialized
DEBUG - 2022-04-07 04:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:24 --> Input Class Initialized
INFO - 2022-04-07 04:25:24 --> Language Class Initialized
INFO - 2022-04-07 04:25:24 --> Loader Class Initialized
INFO - 2022-04-07 04:25:24 --> Helper loaded: url_helper
INFO - 2022-04-07 04:25:24 --> Helper loaded: form_helper
INFO - 2022-04-07 04:25:24 --> Helper loaded: common_helper
INFO - 2022-04-07 04:25:24 --> Helper loaded: util_helper
INFO - 2022-04-07 04:25:24 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:25:24 --> Form Validation Class Initialized
INFO - 2022-04-07 04:25:24 --> Controller Class Initialized
INFO - 2022-04-07 04:25:24 --> Model Class Initialized
INFO - 2022-04-07 04:25:24 --> Model Class Initialized
INFO - 2022-04-07 04:25:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 04:25:24 --> Final output sent to browser
DEBUG - 2022-04-07 04:25:24 --> Total execution time: 0.1212
INFO - 2022-04-07 04:25:29 --> Config Class Initialized
INFO - 2022-04-07 04:25:29 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:25:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:29 --> URI Class Initialized
INFO - 2022-04-07 04:25:29 --> Router Class Initialized
INFO - 2022-04-07 04:25:29 --> Output Class Initialized
INFO - 2022-04-07 04:25:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:29 --> Input Class Initialized
INFO - 2022-04-07 04:25:29 --> Language Class Initialized
INFO - 2022-04-07 04:25:29 --> Loader Class Initialized
INFO - 2022-04-07 04:25:29 --> Helper loaded: url_helper
INFO - 2022-04-07 04:25:29 --> Helper loaded: form_helper
INFO - 2022-04-07 04:25:29 --> Helper loaded: common_helper
INFO - 2022-04-07 04:25:29 --> Helper loaded: util_helper
INFO - 2022-04-07 04:25:29 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:25:29 --> Form Validation Class Initialized
INFO - 2022-04-07 04:25:29 --> Controller Class Initialized
INFO - 2022-04-07 04:25:29 --> Model Class Initialized
INFO - 2022-04-07 04:25:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:25:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:25:29 --> Final output sent to browser
DEBUG - 2022-04-07 04:25:29 --> Total execution time: 0.0642
INFO - 2022-04-07 04:25:30 --> Config Class Initialized
INFO - 2022-04-07 04:25:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:25:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:30 --> URI Class Initialized
INFO - 2022-04-07 04:25:30 --> Config Class Initialized
INFO - 2022-04-07 04:25:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:25:30 --> Router Class Initialized
INFO - 2022-04-07 04:25:30 --> Output Class Initialized
DEBUG - 2022-04-07 04:25:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:30 --> Config Class Initialized
INFO - 2022-04-07 04:25:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:25:30 --> Security Class Initialized
INFO - 2022-04-07 04:25:30 --> Config Class Initialized
DEBUG - 2022-04-07 04:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:25:30 --> Input Class Initialized
INFO - 2022-04-07 04:25:30 --> Language Class Initialized
DEBUG - 2022-04-07 04:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:25:30 --> UTF-8 Support Enabled
ERROR - 2022-04-07 04:25:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:30 --> URI Class Initialized
INFO - 2022-04-07 04:25:30 --> URI Class Initialized
INFO - 2022-04-07 04:25:30 --> Router Class Initialized
INFO - 2022-04-07 04:25:30 --> Router Class Initialized
INFO - 2022-04-07 04:25:30 --> URI Class Initialized
INFO - 2022-04-07 04:25:30 --> Output Class Initialized
INFO - 2022-04-07 04:25:30 --> Output Class Initialized
INFO - 2022-04-07 04:25:30 --> Router Class Initialized
INFO - 2022-04-07 04:25:30 --> Security Class Initialized
INFO - 2022-04-07 04:25:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:30 --> Input Class Initialized
INFO - 2022-04-07 04:25:30 --> Output Class Initialized
DEBUG - 2022-04-07 04:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:30 --> Input Class Initialized
INFO - 2022-04-07 04:25:30 --> Language Class Initialized
INFO - 2022-04-07 04:25:30 --> Language Class Initialized
INFO - 2022-04-07 04:25:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:25:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:25:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:30 --> Input Class Initialized
INFO - 2022-04-07 04:25:30 --> Language Class Initialized
ERROR - 2022-04-07 04:25:30 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:25:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:43 --> Config Class Initialized
INFO - 2022-04-07 04:25:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:25:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:43 --> URI Class Initialized
INFO - 2022-04-07 04:25:43 --> Router Class Initialized
INFO - 2022-04-07 04:25:43 --> Output Class Initialized
INFO - 2022-04-07 04:25:43 --> Security Class Initialized
DEBUG - 2022-04-07 04:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:43 --> Input Class Initialized
INFO - 2022-04-07 04:25:43 --> Language Class Initialized
INFO - 2022-04-07 04:25:43 --> Loader Class Initialized
INFO - 2022-04-07 04:25:43 --> Helper loaded: url_helper
INFO - 2022-04-07 04:25:43 --> Helper loaded: form_helper
INFO - 2022-04-07 04:25:43 --> Helper loaded: common_helper
INFO - 2022-04-07 04:25:43 --> Helper loaded: util_helper
INFO - 2022-04-07 04:25:43 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:25:43 --> Form Validation Class Initialized
INFO - 2022-04-07 04:25:43 --> Controller Class Initialized
INFO - 2022-04-07 04:25:43 --> Model Class Initialized
INFO - 2022-04-07 04:25:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:25:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:25:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:25:43 --> Final output sent to browser
DEBUG - 2022-04-07 04:25:43 --> Total execution time: 0.1545
INFO - 2022-04-07 04:25:43 --> Config Class Initialized
INFO - 2022-04-07 04:25:43 --> Hooks Class Initialized
INFO - 2022-04-07 04:25:43 --> Config Class Initialized
INFO - 2022-04-07 04:25:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:25:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:43 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:43 --> URI Class Initialized
INFO - 2022-04-07 04:25:43 --> URI Class Initialized
INFO - 2022-04-07 04:25:43 --> Router Class Initialized
INFO - 2022-04-07 04:25:43 --> Router Class Initialized
INFO - 2022-04-07 04:25:43 --> Output Class Initialized
INFO - 2022-04-07 04:25:43 --> Output Class Initialized
INFO - 2022-04-07 04:25:43 --> Security Class Initialized
INFO - 2022-04-07 04:25:43 --> Security Class Initialized
DEBUG - 2022-04-07 04:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:43 --> Input Class Initialized
INFO - 2022-04-07 04:25:43 --> Input Class Initialized
INFO - 2022-04-07 04:25:43 --> Language Class Initialized
ERROR - 2022-04-07 04:25:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:43 --> Language Class Initialized
ERROR - 2022-04-07 04:25:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:43 --> Config Class Initialized
INFO - 2022-04-07 04:25:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:25:44 --> Config Class Initialized
DEBUG - 2022-04-07 04:25:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:25:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:44 --> URI Class Initialized
DEBUG - 2022-04-07 04:25:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:25:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:25:44 --> URI Class Initialized
INFO - 2022-04-07 04:25:44 --> Router Class Initialized
INFO - 2022-04-07 04:25:44 --> Router Class Initialized
INFO - 2022-04-07 04:25:44 --> Output Class Initialized
INFO - 2022-04-07 04:25:44 --> Security Class Initialized
INFO - 2022-04-07 04:25:44 --> Output Class Initialized
DEBUG - 2022-04-07 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:44 --> Security Class Initialized
INFO - 2022-04-07 04:25:44 --> Input Class Initialized
INFO - 2022-04-07 04:25:44 --> Language Class Initialized
DEBUG - 2022-04-07 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:25:44 --> Input Class Initialized
ERROR - 2022-04-07 04:25:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:25:44 --> Language Class Initialized
ERROR - 2022-04-07 04:25:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:26:16 --> Config Class Initialized
INFO - 2022-04-07 04:26:16 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:16 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:16 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:16 --> URI Class Initialized
INFO - 2022-04-07 04:26:17 --> Router Class Initialized
INFO - 2022-04-07 04:26:17 --> Output Class Initialized
INFO - 2022-04-07 04:26:17 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:17 --> Input Class Initialized
INFO - 2022-04-07 04:26:17 --> Language Class Initialized
INFO - 2022-04-07 04:26:17 --> Loader Class Initialized
INFO - 2022-04-07 04:26:17 --> Helper loaded: url_helper
INFO - 2022-04-07 04:26:17 --> Helper loaded: form_helper
INFO - 2022-04-07 04:26:17 --> Helper loaded: common_helper
INFO - 2022-04-07 04:26:17 --> Helper loaded: util_helper
INFO - 2022-04-07 04:26:17 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:26:17 --> Form Validation Class Initialized
INFO - 2022-04-07 04:26:17 --> Controller Class Initialized
INFO - 2022-04-07 04:26:17 --> Model Class Initialized
INFO - 2022-04-07 04:26:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:26:17 --> Config Class Initialized
INFO - 2022-04-07 04:26:17 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:17 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:17 --> URI Class Initialized
INFO - 2022-04-07 04:26:17 --> Router Class Initialized
INFO - 2022-04-07 04:26:17 --> Output Class Initialized
INFO - 2022-04-07 04:26:17 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:17 --> Input Class Initialized
INFO - 2022-04-07 04:26:17 --> Language Class Initialized
INFO - 2022-04-07 04:26:17 --> Loader Class Initialized
INFO - 2022-04-07 04:26:17 --> Helper loaded: url_helper
INFO - 2022-04-07 04:26:17 --> Helper loaded: form_helper
INFO - 2022-04-07 04:26:17 --> Helper loaded: common_helper
INFO - 2022-04-07 04:26:17 --> Helper loaded: util_helper
INFO - 2022-04-07 04:26:17 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:26:17 --> Form Validation Class Initialized
INFO - 2022-04-07 04:26:17 --> Controller Class Initialized
INFO - 2022-04-07 04:26:17 --> Model Class Initialized
INFO - 2022-04-07 04:26:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:26:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:26:17 --> Final output sent to browser
DEBUG - 2022-04-07 04:26:17 --> Total execution time: 0.0515
INFO - 2022-04-07 04:26:17 --> Config Class Initialized
INFO - 2022-04-07 04:26:17 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:17 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:17 --> Config Class Initialized
INFO - 2022-04-07 04:26:17 --> Hooks Class Initialized
INFO - 2022-04-07 04:26:17 --> URI Class Initialized
INFO - 2022-04-07 04:26:17 --> Router Class Initialized
DEBUG - 2022-04-07 04:26:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:17 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:17 --> URI Class Initialized
INFO - 2022-04-07 04:26:17 --> Output Class Initialized
INFO - 2022-04-07 04:26:17 --> Security Class Initialized
INFO - 2022-04-07 04:26:17 --> Router Class Initialized
DEBUG - 2022-04-07 04:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:17 --> Input Class Initialized
INFO - 2022-04-07 04:26:17 --> Output Class Initialized
INFO - 2022-04-07 04:26:17 --> Language Class Initialized
INFO - 2022-04-07 04:26:17 --> Security Class Initialized
ERROR - 2022-04-07 04:26:17 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:17 --> Input Class Initialized
INFO - 2022-04-07 04:26:17 --> Language Class Initialized
ERROR - 2022-04-07 04:26:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:26:17 --> Config Class Initialized
INFO - 2022-04-07 04:26:17 --> Hooks Class Initialized
INFO - 2022-04-07 04:26:17 --> Config Class Initialized
DEBUG - 2022-04-07 04:26:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:17 --> Hooks Class Initialized
INFO - 2022-04-07 04:26:17 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:17 --> URI Class Initialized
DEBUG - 2022-04-07 04:26:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:17 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:17 --> Router Class Initialized
INFO - 2022-04-07 04:26:17 --> URI Class Initialized
INFO - 2022-04-07 04:26:17 --> Output Class Initialized
INFO - 2022-04-07 04:26:17 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:17 --> Input Class Initialized
INFO - 2022-04-07 04:26:17 --> Router Class Initialized
INFO - 2022-04-07 04:26:17 --> Language Class Initialized
INFO - 2022-04-07 04:26:17 --> Output Class Initialized
INFO - 2022-04-07 04:26:17 --> Security Class Initialized
ERROR - 2022-04-07 04:26:17 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:17 --> Input Class Initialized
INFO - 2022-04-07 04:26:17 --> Language Class Initialized
ERROR - 2022-04-07 04:26:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
DEBUG - 2022-04-07 04:26:46 --> No URI present. Default controller set.
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
INFO - 2022-04-07 04:26:46 --> Language Class Initialized
INFO - 2022-04-07 04:26:46 --> Loader Class Initialized
INFO - 2022-04-07 04:26:46 --> Helper loaded: url_helper
INFO - 2022-04-07 04:26:46 --> Helper loaded: form_helper
INFO - 2022-04-07 04:26:46 --> Helper loaded: common_helper
INFO - 2022-04-07 04:26:46 --> Helper loaded: util_helper
INFO - 2022-04-07 04:26:46 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:26:46 --> Form Validation Class Initialized
INFO - 2022-04-07 04:26:46 --> Controller Class Initialized
INFO - 2022-04-07 04:26:46 --> Model Class Initialized
INFO - 2022-04-07 04:26:46 --> Model Class Initialized
INFO - 2022-04-07 04:26:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 04:26:46 --> Final output sent to browser
DEBUG - 2022-04-07 04:26:46 --> Total execution time: 0.0693
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
INFO - 2022-04-07 04:26:46 --> Language Class Initialized
ERROR - 2022-04-07 04:26:46 --> 404 Page Not Found: Css/fontastic.css
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:26:46 --> Language Class Initialized
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
ERROR - 2022-04-07 04:26:46 --> 404 Page Not Found: Css/style.default.css
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Language Class Initialized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
INFO - 2022-04-07 04:26:46 --> Language Class Initialized
ERROR - 2022-04-07 04:26:46 --> 404 Page Not Found: Css/grasp_mobile_progress_circle_1.0.0.min.css
ERROR - 2022-04-07 04:26:46 --> 404 Page Not Found: Css/custom.css
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
INFO - 2022-04-07 04:26:46 --> Language Class Initialized
INFO - 2022-04-07 04:26:46 --> Config Class Initialized
INFO - 2022-04-07 04:26:46 --> Hooks Class Initialized
ERROR - 2022-04-07 04:26:46 --> 404 Page Not Found: Js/charts_home.js
INFO - 2022-04-07 04:26:46 --> Output Class Initialized
DEBUG - 2022-04-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:46 --> URI Class Initialized
INFO - 2022-04-07 04:26:46 --> Security Class Initialized
INFO - 2022-04-07 04:26:46 --> Router Class Initialized
DEBUG - 2022-04-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:46 --> Input Class Initialized
INFO - 2022-04-07 04:26:47 --> Output Class Initialized
INFO - 2022-04-07 04:26:47 --> Language Class Initialized
INFO - 2022-04-07 04:26:47 --> Security Class Initialized
ERROR - 2022-04-07 04:26:47 --> 404 Page Not Found: Js/grasp_mobile_progress_circle_1.0.0.min.js
DEBUG - 2022-04-07 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:47 --> Input Class Initialized
INFO - 2022-04-07 04:26:47 --> Language Class Initialized
ERROR - 2022-04-07 04:26:47 --> 404 Page Not Found: Js/front.js
INFO - 2022-04-07 04:26:47 --> Config Class Initialized
INFO - 2022-04-07 04:26:47 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:47 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:47 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:47 --> URI Class Initialized
INFO - 2022-04-07 04:26:47 --> Router Class Initialized
INFO - 2022-04-07 04:26:47 --> Output Class Initialized
INFO - 2022-04-07 04:26:47 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:47 --> Input Class Initialized
INFO - 2022-04-07 04:26:47 --> Language Class Initialized
ERROR - 2022-04-07 04:26:47 --> 404 Page Not Found: Img/favicon.ico
INFO - 2022-04-07 04:26:50 --> Config Class Initialized
INFO - 2022-04-07 04:26:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:50 --> URI Class Initialized
INFO - 2022-04-07 04:26:50 --> Router Class Initialized
INFO - 2022-04-07 04:26:50 --> Output Class Initialized
INFO - 2022-04-07 04:26:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:50 --> Input Class Initialized
INFO - 2022-04-07 04:26:50 --> Language Class Initialized
INFO - 2022-04-07 04:26:50 --> Loader Class Initialized
INFO - 2022-04-07 04:26:50 --> Helper loaded: url_helper
INFO - 2022-04-07 04:26:50 --> Helper loaded: form_helper
INFO - 2022-04-07 04:26:50 --> Helper loaded: common_helper
INFO - 2022-04-07 04:26:50 --> Helper loaded: util_helper
INFO - 2022-04-07 04:26:50 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:26:50 --> Form Validation Class Initialized
INFO - 2022-04-07 04:26:50 --> Controller Class Initialized
INFO - 2022-04-07 04:26:50 --> Model Class Initialized
INFO - 2022-04-07 04:26:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:26:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:26:50 --> Final output sent to browser
DEBUG - 2022-04-07 04:26:50 --> Total execution time: 0.0563
INFO - 2022-04-07 04:26:51 --> Config Class Initialized
INFO - 2022-04-07 04:26:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:26:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:26:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:26:51 --> URI Class Initialized
DEBUG - 2022-04-07 04:26:51 --> No URI present. Default controller set.
INFO - 2022-04-07 04:26:51 --> Router Class Initialized
INFO - 2022-04-07 04:26:51 --> Output Class Initialized
INFO - 2022-04-07 04:26:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:26:51 --> Input Class Initialized
INFO - 2022-04-07 04:26:51 --> Language Class Initialized
INFO - 2022-04-07 04:26:51 --> Loader Class Initialized
INFO - 2022-04-07 04:26:51 --> Helper loaded: url_helper
INFO - 2022-04-07 04:26:51 --> Helper loaded: form_helper
INFO - 2022-04-07 04:26:51 --> Helper loaded: common_helper
INFO - 2022-04-07 04:26:51 --> Helper loaded: util_helper
INFO - 2022-04-07 04:26:51 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:26:51 --> Form Validation Class Initialized
INFO - 2022-04-07 04:26:51 --> Controller Class Initialized
INFO - 2022-04-07 04:26:51 --> Model Class Initialized
INFO - 2022-04-07 04:26:51 --> Model Class Initialized
INFO - 2022-04-07 04:26:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 04:26:51 --> Final output sent to browser
DEBUG - 2022-04-07 04:26:51 --> Total execution time: 0.0603
INFO - 2022-04-07 04:27:33 --> Config Class Initialized
INFO - 2022-04-07 04:27:33 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:27:33 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:27:33 --> Utf8 Class Initialized
INFO - 2022-04-07 04:27:33 --> URI Class Initialized
DEBUG - 2022-04-07 04:27:33 --> No URI present. Default controller set.
INFO - 2022-04-07 04:27:33 --> Router Class Initialized
INFO - 2022-04-07 04:27:33 --> Output Class Initialized
INFO - 2022-04-07 04:27:33 --> Security Class Initialized
DEBUG - 2022-04-07 04:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:27:33 --> Input Class Initialized
INFO - 2022-04-07 04:27:33 --> Language Class Initialized
INFO - 2022-04-07 04:27:33 --> Loader Class Initialized
INFO - 2022-04-07 04:27:33 --> Helper loaded: url_helper
INFO - 2022-04-07 04:27:33 --> Helper loaded: form_helper
INFO - 2022-04-07 04:27:33 --> Helper loaded: common_helper
INFO - 2022-04-07 04:27:33 --> Helper loaded: util_helper
INFO - 2022-04-07 04:27:33 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:27:33 --> Form Validation Class Initialized
INFO - 2022-04-07 04:27:33 --> Controller Class Initialized
INFO - 2022-04-07 04:27:33 --> Model Class Initialized
INFO - 2022-04-07 04:27:33 --> Model Class Initialized
INFO - 2022-04-07 04:27:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 04:27:33 --> Final output sent to browser
DEBUG - 2022-04-07 04:27:33 --> Total execution time: 0.0588
INFO - 2022-04-07 04:27:42 --> Config Class Initialized
INFO - 2022-04-07 04:27:42 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:27:42 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:27:42 --> Utf8 Class Initialized
INFO - 2022-04-07 04:27:42 --> URI Class Initialized
INFO - 2022-04-07 04:27:42 --> Router Class Initialized
INFO - 2022-04-07 04:27:42 --> Output Class Initialized
INFO - 2022-04-07 04:27:42 --> Security Class Initialized
DEBUG - 2022-04-07 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:27:42 --> Input Class Initialized
INFO - 2022-04-07 04:27:42 --> Language Class Initialized
INFO - 2022-04-07 04:27:42 --> Loader Class Initialized
INFO - 2022-04-07 04:27:42 --> Helper loaded: url_helper
INFO - 2022-04-07 04:27:42 --> Helper loaded: form_helper
INFO - 2022-04-07 04:27:42 --> Helper loaded: common_helper
INFO - 2022-04-07 04:27:42 --> Helper loaded: util_helper
INFO - 2022-04-07 04:27:42 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:27:42 --> Form Validation Class Initialized
INFO - 2022-04-07 04:27:42 --> Controller Class Initialized
INFO - 2022-04-07 04:27:42 --> Model Class Initialized
INFO - 2022-04-07 04:27:42 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:27:42 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:27:42 --> Final output sent to browser
DEBUG - 2022-04-07 04:27:42 --> Total execution time: 0.0563
INFO - 2022-04-07 04:27:42 --> Config Class Initialized
INFO - 2022-04-07 04:27:42 --> Config Class Initialized
INFO - 2022-04-07 04:27:42 --> Hooks Class Initialized
INFO - 2022-04-07 04:27:42 --> Config Class Initialized
INFO - 2022-04-07 04:27:42 --> Hooks Class Initialized
INFO - 2022-04-07 04:27:42 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:27:42 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:27:42 --> Utf8 Class Initialized
INFO - 2022-04-07 04:27:42 --> Utf8 Class Initialized
INFO - 2022-04-07 04:27:42 --> Utf8 Class Initialized
INFO - 2022-04-07 04:27:42 --> Config Class Initialized
INFO - 2022-04-07 04:27:42 --> URI Class Initialized
INFO - 2022-04-07 04:27:42 --> Hooks Class Initialized
INFO - 2022-04-07 04:27:42 --> URI Class Initialized
INFO - 2022-04-07 04:27:42 --> URI Class Initialized
INFO - 2022-04-07 04:27:42 --> Router Class Initialized
INFO - 2022-04-07 04:27:42 --> Router Class Initialized
DEBUG - 2022-04-07 04:27:42 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:27:42 --> Utf8 Class Initialized
INFO - 2022-04-07 04:27:42 --> Router Class Initialized
INFO - 2022-04-07 04:27:42 --> URI Class Initialized
INFO - 2022-04-07 04:27:42 --> Output Class Initialized
INFO - 2022-04-07 04:27:42 --> Output Class Initialized
INFO - 2022-04-07 04:27:42 --> Router Class Initialized
INFO - 2022-04-07 04:27:42 --> Security Class Initialized
INFO - 2022-04-07 04:27:42 --> Output Class Initialized
INFO - 2022-04-07 04:27:42 --> Security Class Initialized
DEBUG - 2022-04-07 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:27:42 --> Security Class Initialized
INFO - 2022-04-07 04:27:42 --> Input Class Initialized
DEBUG - 2022-04-07 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:27:42 --> Language Class Initialized
INFO - 2022-04-07 04:27:42 --> Input Class Initialized
DEBUG - 2022-04-07 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:27:43 --> Input Class Initialized
INFO - 2022-04-07 04:27:43 --> Language Class Initialized
INFO - 2022-04-07 04:27:43 --> Output Class Initialized
INFO - 2022-04-07 04:27:43 --> Language Class Initialized
INFO - 2022-04-07 04:27:43 --> Security Class Initialized
ERROR - 2022-04-07 04:27:43 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:27:43 --> Input Class Initialized
INFO - 2022-04-07 04:27:43 --> Language Class Initialized
ERROR - 2022-04-07 04:27:43 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:27:43 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:27:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:28:00 --> Config Class Initialized
INFO - 2022-04-07 04:28:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:28:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:28:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:28:00 --> URI Class Initialized
INFO - 2022-04-07 04:28:00 --> Router Class Initialized
INFO - 2022-04-07 04:28:00 --> Output Class Initialized
INFO - 2022-04-07 04:28:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:28:00 --> Input Class Initialized
INFO - 2022-04-07 04:28:00 --> Language Class Initialized
INFO - 2022-04-07 04:28:00 --> Loader Class Initialized
INFO - 2022-04-07 04:28:00 --> Helper loaded: url_helper
INFO - 2022-04-07 04:28:00 --> Helper loaded: form_helper
INFO - 2022-04-07 04:28:00 --> Helper loaded: common_helper
INFO - 2022-04-07 04:28:00 --> Helper loaded: util_helper
INFO - 2022-04-07 04:28:00 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:28:00 --> Form Validation Class Initialized
INFO - 2022-04-07 04:28:00 --> Controller Class Initialized
INFO - 2022-04-07 04:28:00 --> Model Class Initialized
INFO - 2022-04-07 04:28:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:28:00 --> Config Class Initialized
INFO - 2022-04-07 04:28:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:28:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:28:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:28:00 --> URI Class Initialized
INFO - 2022-04-07 04:28:00 --> Router Class Initialized
INFO - 2022-04-07 04:28:00 --> Output Class Initialized
INFO - 2022-04-07 04:28:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:28:00 --> Input Class Initialized
INFO - 2022-04-07 04:28:00 --> Language Class Initialized
INFO - 2022-04-07 04:28:00 --> Loader Class Initialized
INFO - 2022-04-07 04:28:00 --> Helper loaded: url_helper
INFO - 2022-04-07 04:28:00 --> Helper loaded: form_helper
INFO - 2022-04-07 04:28:00 --> Helper loaded: common_helper
INFO - 2022-04-07 04:28:00 --> Helper loaded: util_helper
INFO - 2022-04-07 04:28:00 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:28:00 --> Form Validation Class Initialized
INFO - 2022-04-07 04:28:00 --> Controller Class Initialized
INFO - 2022-04-07 04:28:00 --> Model Class Initialized
INFO - 2022-04-07 04:28:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:28:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:28:00 --> Final output sent to browser
DEBUG - 2022-04-07 04:28:00 --> Total execution time: 0.0561
INFO - 2022-04-07 04:28:00 --> Config Class Initialized
INFO - 2022-04-07 04:28:00 --> Config Class Initialized
INFO - 2022-04-07 04:28:00 --> Hooks Class Initialized
INFO - 2022-04-07 04:28:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:28:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:28:00 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:28:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:28:00 --> Config Class Initialized
INFO - 2022-04-07 04:28:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:28:00 --> Config Class Initialized
INFO - 2022-04-07 04:28:00 --> Hooks Class Initialized
INFO - 2022-04-07 04:28:00 --> Hooks Class Initialized
INFO - 2022-04-07 04:28:00 --> URI Class Initialized
INFO - 2022-04-07 04:28:00 --> URI Class Initialized
INFO - 2022-04-07 04:28:00 --> Router Class Initialized
DEBUG - 2022-04-07 04:28:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:28:00 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:28:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:28:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:28:00 --> URI Class Initialized
INFO - 2022-04-07 04:28:00 --> Router Class Initialized
INFO - 2022-04-07 04:28:00 --> URI Class Initialized
INFO - 2022-04-07 04:28:00 --> Output Class Initialized
INFO - 2022-04-07 04:28:00 --> Router Class Initialized
INFO - 2022-04-07 04:28:00 --> Router Class Initialized
INFO - 2022-04-07 04:28:00 --> Security Class Initialized
INFO - 2022-04-07 04:28:00 --> Output Class Initialized
INFO - 2022-04-07 04:28:00 --> Output Class Initialized
INFO - 2022-04-07 04:28:00 --> Output Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:28:00 --> Input Class Initialized
INFO - 2022-04-07 04:28:00 --> Security Class Initialized
INFO - 2022-04-07 04:28:00 --> Security Class Initialized
INFO - 2022-04-07 04:28:00 --> Security Class Initialized
INFO - 2022-04-07 04:28:00 --> Language Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:28:00 --> Input Class Initialized
DEBUG - 2022-04-07 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:28:00 --> Input Class Initialized
INFO - 2022-04-07 04:28:00 --> Input Class Initialized
ERROR - 2022-04-07 04:28:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:28:00 --> Language Class Initialized
INFO - 2022-04-07 04:28:00 --> Language Class Initialized
INFO - 2022-04-07 04:28:00 --> Language Class Initialized
ERROR - 2022-04-07 04:28:00 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:28:00 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:28:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:15 --> Config Class Initialized
INFO - 2022-04-07 04:31:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:15 --> URI Class Initialized
INFO - 2022-04-07 04:31:15 --> Router Class Initialized
INFO - 2022-04-07 04:31:15 --> Output Class Initialized
INFO - 2022-04-07 04:31:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:15 --> Input Class Initialized
INFO - 2022-04-07 04:31:15 --> Language Class Initialized
INFO - 2022-04-07 04:31:15 --> Loader Class Initialized
INFO - 2022-04-07 04:31:15 --> Helper loaded: url_helper
INFO - 2022-04-07 04:31:15 --> Helper loaded: form_helper
INFO - 2022-04-07 04:31:15 --> Helper loaded: common_helper
INFO - 2022-04-07 04:31:15 --> Helper loaded: util_helper
INFO - 2022-04-07 04:31:15 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:31:15 --> Form Validation Class Initialized
INFO - 2022-04-07 04:31:15 --> Controller Class Initialized
INFO - 2022-04-07 04:31:15 --> Model Class Initialized
INFO - 2022-04-07 04:31:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:31:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:31:15 --> Final output sent to browser
DEBUG - 2022-04-07 04:31:15 --> Total execution time: 0.0674
INFO - 2022-04-07 04:31:15 --> Config Class Initialized
INFO - 2022-04-07 04:31:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:15 --> Config Class Initialized
DEBUG - 2022-04-07 04:31:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:15 --> URI Class Initialized
INFO - 2022-04-07 04:31:15 --> Config Class Initialized
INFO - 2022-04-07 04:31:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:15 --> Config Class Initialized
INFO - 2022-04-07 04:31:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:31:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:15 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:31:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:15 --> Output Class Initialized
INFO - 2022-04-07 04:31:15 --> URI Class Initialized
INFO - 2022-04-07 04:31:15 --> URI Class Initialized
DEBUG - 2022-04-07 04:31:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:15 --> Router Class Initialized
INFO - 2022-04-07 04:31:15 --> Router Class Initialized
INFO - 2022-04-07 04:31:15 --> Output Class Initialized
INFO - 2022-04-07 04:31:15 --> Security Class Initialized
INFO - 2022-04-07 04:31:15 --> URI Class Initialized
DEBUG - 2022-04-07 04:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:15 --> Input Class Initialized
INFO - 2022-04-07 04:31:15 --> Router Class Initialized
INFO - 2022-04-07 04:31:15 --> Config Class Initialized
INFO - 2022-04-07 04:31:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:15 --> Security Class Initialized
INFO - 2022-04-07 04:31:15 --> Output Class Initialized
DEBUG - 2022-04-07 04:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:15 --> Output Class Initialized
INFO - 2022-04-07 04:31:15 --> Input Class Initialized
DEBUG - 2022-04-07 04:31:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:15 --> Security Class Initialized
INFO - 2022-04-07 04:31:15 --> Language Class Initialized
INFO - 2022-04-07 04:31:15 --> Security Class Initialized
INFO - 2022-04-07 04:31:15 --> URI Class Initialized
DEBUG - 2022-04-07 04:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:15 --> Input Class Initialized
ERROR - 2022-04-07 04:31:15 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:31:15 --> Input Class Initialized
INFO - 2022-04-07 04:31:15 --> Router Class Initialized
INFO - 2022-04-07 04:31:15 --> Language Class Initialized
INFO - 2022-04-07 04:31:15 --> Language Class Initialized
INFO - 2022-04-07 04:31:15 --> Output Class Initialized
ERROR - 2022-04-07 04:31:15 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:31:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:15 --> Security Class Initialized
INFO - 2022-04-07 04:31:15 --> Language Class Initialized
DEBUG - 2022-04-07 04:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:15 --> Input Class Initialized
ERROR - 2022-04-07 04:31:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:15 --> Language Class Initialized
ERROR - 2022-04-07 04:31:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:30 --> Config Class Initialized
INFO - 2022-04-07 04:31:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:30 --> URI Class Initialized
INFO - 2022-04-07 04:31:30 --> Router Class Initialized
INFO - 2022-04-07 04:31:30 --> Output Class Initialized
INFO - 2022-04-07 04:31:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:30 --> Input Class Initialized
INFO - 2022-04-07 04:31:30 --> Language Class Initialized
INFO - 2022-04-07 04:31:30 --> Loader Class Initialized
INFO - 2022-04-07 04:31:30 --> Helper loaded: url_helper
INFO - 2022-04-07 04:31:30 --> Helper loaded: form_helper
INFO - 2022-04-07 04:31:30 --> Helper loaded: common_helper
INFO - 2022-04-07 04:31:30 --> Helper loaded: util_helper
INFO - 2022-04-07 04:31:30 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:31:30 --> Form Validation Class Initialized
INFO - 2022-04-07 04:31:30 --> Controller Class Initialized
INFO - 2022-04-07 04:31:30 --> Model Class Initialized
INFO - 2022-04-07 04:31:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:31:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:31:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:31:30 --> Final output sent to browser
DEBUG - 2022-04-07 04:31:30 --> Total execution time: 0.1505
INFO - 2022-04-07 04:31:30 --> Config Class Initialized
INFO - 2022-04-07 04:31:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:30 --> Config Class Initialized
DEBUG - 2022-04-07 04:31:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:30 --> URI Class Initialized
INFO - 2022-04-07 04:31:30 --> Config Class Initialized
INFO - 2022-04-07 04:31:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:30 --> Router Class Initialized
DEBUG - 2022-04-07 04:31:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:30 --> Output Class Initialized
INFO - 2022-04-07 04:31:30 --> URI Class Initialized
INFO - 2022-04-07 04:31:30 --> Security Class Initialized
INFO - 2022-04-07 04:31:30 --> Router Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:30 --> Input Class Initialized
DEBUG - 2022-04-07 04:31:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:30 --> Language Class Initialized
INFO - 2022-04-07 04:31:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:30 --> URI Class Initialized
INFO - 2022-04-07 04:31:30 --> Router Class Initialized
INFO - 2022-04-07 04:31:30 --> Output Class Initialized
INFO - 2022-04-07 04:31:30 --> Config Class Initialized
INFO - 2022-04-07 04:31:30 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:30 --> Input Class Initialized
DEBUG - 2022-04-07 04:31:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:30 --> Language Class Initialized
INFO - 2022-04-07 04:31:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:30 --> URI Class Initialized
ERROR - 2022-04-07 04:31:30 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:31:30 --> Output Class Initialized
INFO - 2022-04-07 04:31:30 --> Router Class Initialized
INFO - 2022-04-07 04:31:30 --> Security Class Initialized
INFO - 2022-04-07 04:31:30 --> Output Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:30 --> Security Class Initialized
INFO - 2022-04-07 04:31:30 --> Input Class Initialized
ERROR - 2022-04-07 04:31:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:30 --> Language Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:30 --> Input Class Initialized
ERROR - 2022-04-07 04:31:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:30 --> Language Class Initialized
ERROR - 2022-04-07 04:31:30 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:30 --> Config Class Initialized
INFO - 2022-04-07 04:31:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:30 --> URI Class Initialized
INFO - 2022-04-07 04:31:30 --> Router Class Initialized
INFO - 2022-04-07 04:31:30 --> Output Class Initialized
INFO - 2022-04-07 04:31:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:31 --> Input Class Initialized
INFO - 2022-04-07 04:31:31 --> Language Class Initialized
ERROR - 2022-04-07 04:31:31 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:53 --> Config Class Initialized
INFO - 2022-04-07 04:31:53 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:53 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:53 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:53 --> URI Class Initialized
INFO - 2022-04-07 04:31:53 --> Router Class Initialized
INFO - 2022-04-07 04:31:53 --> Output Class Initialized
INFO - 2022-04-07 04:31:53 --> Security Class Initialized
DEBUG - 2022-04-07 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:53 --> Input Class Initialized
INFO - 2022-04-07 04:31:53 --> Language Class Initialized
INFO - 2022-04-07 04:31:53 --> Loader Class Initialized
INFO - 2022-04-07 04:31:53 --> Helper loaded: url_helper
INFO - 2022-04-07 04:31:53 --> Helper loaded: form_helper
INFO - 2022-04-07 04:31:53 --> Helper loaded: common_helper
INFO - 2022-04-07 04:31:53 --> Helper loaded: util_helper
INFO - 2022-04-07 04:31:53 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:31:53 --> Form Validation Class Initialized
INFO - 2022-04-07 04:31:53 --> Controller Class Initialized
INFO - 2022-04-07 04:31:53 --> Model Class Initialized
INFO - 2022-04-07 04:31:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:31:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:31:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:31:53 --> Final output sent to browser
DEBUG - 2022-04-07 04:31:53 --> Total execution time: 0.1739
INFO - 2022-04-07 04:31:53 --> Config Class Initialized
INFO - 2022-04-07 04:31:53 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:53 --> Config Class Initialized
INFO - 2022-04-07 04:31:53 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:53 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:53 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:53 --> URI Class Initialized
DEBUG - 2022-04-07 04:31:53 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:53 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:53 --> Router Class Initialized
INFO - 2022-04-07 04:31:53 --> URI Class Initialized
INFO - 2022-04-07 04:31:53 --> Output Class Initialized
INFO - 2022-04-07 04:31:53 --> Router Class Initialized
INFO - 2022-04-07 04:31:53 --> Security Class Initialized
INFO - 2022-04-07 04:31:53 --> Output Class Initialized
DEBUG - 2022-04-07 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:53 --> Input Class Initialized
INFO - 2022-04-07 04:31:53 --> Security Class Initialized
INFO - 2022-04-07 04:31:53 --> Config Class Initialized
INFO - 2022-04-07 04:31:53 --> Language Class Initialized
INFO - 2022-04-07 04:31:53 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:53 --> Input Class Initialized
INFO - 2022-04-07 04:31:53 --> Language Class Initialized
ERROR - 2022-04-07 04:31:53 --> 404 Page Not Found: provider/Profile/js
DEBUG - 2022-04-07 04:31:53 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:53 --> Utf8 Class Initialized
ERROR - 2022-04-07 04:31:53 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:53 --> URI Class Initialized
INFO - 2022-04-07 04:31:53 --> Router Class Initialized
INFO - 2022-04-07 04:31:53 --> Config Class Initialized
INFO - 2022-04-07 04:31:53 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:31:53 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:31:53 --> Utf8 Class Initialized
INFO - 2022-04-07 04:31:53 --> URI Class Initialized
INFO - 2022-04-07 04:31:53 --> Router Class Initialized
INFO - 2022-04-07 04:31:53 --> Config Class Initialized
INFO - 2022-04-07 04:31:53 --> Hooks Class Initialized
INFO - 2022-04-07 04:31:53 --> Output Class Initialized
INFO - 2022-04-07 04:31:53 --> Output Class Initialized
INFO - 2022-04-07 04:31:53 --> Security Class Initialized
INFO - 2022-04-07 04:31:53 --> Security Class Initialized
DEBUG - 2022-04-07 04:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:53 --> Input Class Initialized
INFO - 2022-04-07 04:31:53 --> Language Class Initialized
INFO - 2022-04-07 04:31:53 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:31:53 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:31:53 --> URI Class Initialized
INFO - 2022-04-07 04:31:53 --> Router Class Initialized
INFO - 2022-04-07 04:31:53 --> Output Class Initialized
INFO - 2022-04-07 04:31:53 --> Input Class Initialized
INFO - 2022-04-07 04:31:53 --> Security Class Initialized
INFO - 2022-04-07 04:31:53 --> Language Class Initialized
DEBUG - 2022-04-07 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:31:53 --> Input Class Initialized
INFO - 2022-04-07 04:31:53 --> Language Class Initialized
ERROR - 2022-04-07 04:31:53 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:31:53 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
INFO - 2022-04-07 04:32:11 --> Loader Class Initialized
INFO - 2022-04-07 04:32:11 --> Helper loaded: url_helper
INFO - 2022-04-07 04:32:11 --> Helper loaded: form_helper
INFO - 2022-04-07 04:32:11 --> Helper loaded: common_helper
INFO - 2022-04-07 04:32:11 --> Helper loaded: util_helper
INFO - 2022-04-07 04:32:11 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:32:11 --> Form Validation Class Initialized
INFO - 2022-04-07 04:32:11 --> Controller Class Initialized
INFO - 2022-04-07 04:32:11 --> Model Class Initialized
INFO - 2022-04-07 04:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
INFO - 2022-04-07 04:32:11 --> Loader Class Initialized
INFO - 2022-04-07 04:32:11 --> Helper loaded: url_helper
INFO - 2022-04-07 04:32:11 --> Helper loaded: form_helper
INFO - 2022-04-07 04:32:11 --> Helper loaded: common_helper
INFO - 2022-04-07 04:32:11 --> Helper loaded: util_helper
INFO - 2022-04-07 04:32:11 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:32:11 --> Form Validation Class Initialized
INFO - 2022-04-07 04:32:11 --> Controller Class Initialized
INFO - 2022-04-07 04:32:11 --> Model Class Initialized
INFO - 2022-04-07 04:32:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:32:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:32:11 --> Final output sent to browser
DEBUG - 2022-04-07 04:32:11 --> Total execution time: 0.0809
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
ERROR - 2022-04-07 04:32:11 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
ERROR - 2022-04-07 04:32:11 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Config Class Initialized
INFO - 2022-04-07 04:32:11 --> Hooks Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
DEBUG - 2022-04-07 04:32:11 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
INFO - 2022-04-07 04:32:11 --> Utf8 Class Initialized
INFO - 2022-04-07 04:32:11 --> URI Class Initialized
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
ERROR - 2022-04-07 04:32:11 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:32:11 --> Router Class Initialized
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Output Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
INFO - 2022-04-07 04:32:11 --> Security Class Initialized
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
INFO - 2022-04-07 04:32:11 --> Input Class Initialized
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
INFO - 2022-04-07 04:32:11 --> Language Class Initialized
ERROR - 2022-04-07 04:32:11 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:32:11 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:34:45 --> Config Class Initialized
INFO - 2022-04-07 04:34:45 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:34:45 --> Utf8 Class Initialized
INFO - 2022-04-07 04:34:45 --> URI Class Initialized
INFO - 2022-04-07 04:34:45 --> Router Class Initialized
INFO - 2022-04-07 04:34:45 --> Output Class Initialized
INFO - 2022-04-07 04:34:45 --> Security Class Initialized
DEBUG - 2022-04-07 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:34:45 --> Input Class Initialized
INFO - 2022-04-07 04:34:45 --> Language Class Initialized
INFO - 2022-04-07 04:34:45 --> Loader Class Initialized
INFO - 2022-04-07 04:34:45 --> Helper loaded: url_helper
INFO - 2022-04-07 04:34:45 --> Helper loaded: form_helper
INFO - 2022-04-07 04:34:45 --> Helper loaded: common_helper
INFO - 2022-04-07 04:34:45 --> Helper loaded: util_helper
INFO - 2022-04-07 04:34:45 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:34:45 --> Form Validation Class Initialized
INFO - 2022-04-07 04:34:45 --> Controller Class Initialized
INFO - 2022-04-07 04:34:45 --> Model Class Initialized
INFO - 2022-04-07 04:34:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:34:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:34:45 --> Final output sent to browser
DEBUG - 2022-04-07 04:34:45 --> Total execution time: 0.0672
INFO - 2022-04-07 04:34:45 --> Config Class Initialized
INFO - 2022-04-07 04:34:45 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:34:45 --> Utf8 Class Initialized
INFO - 2022-04-07 04:34:45 --> URI Class Initialized
INFO - 2022-04-07 04:34:45 --> Config Class Initialized
INFO - 2022-04-07 04:34:45 --> Hooks Class Initialized
INFO - 2022-04-07 04:34:45 --> Router Class Initialized
DEBUG - 2022-04-07 04:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:34:45 --> Output Class Initialized
INFO - 2022-04-07 04:34:45 --> Utf8 Class Initialized
INFO - 2022-04-07 04:34:45 --> URI Class Initialized
INFO - 2022-04-07 04:34:45 --> Security Class Initialized
DEBUG - 2022-04-07 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:34:45 --> Router Class Initialized
INFO - 2022-04-07 04:34:45 --> Input Class Initialized
INFO - 2022-04-07 04:34:45 --> Language Class Initialized
INFO - 2022-04-07 04:34:45 --> Output Class Initialized
ERROR - 2022-04-07 04:34:45 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:34:45 --> Security Class Initialized
DEBUG - 2022-04-07 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:34:45 --> Input Class Initialized
INFO - 2022-04-07 04:34:45 --> Language Class Initialized
ERROR - 2022-04-07 04:34:45 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:34:45 --> Config Class Initialized
INFO - 2022-04-07 04:34:45 --> Hooks Class Initialized
INFO - 2022-04-07 04:34:45 --> Config Class Initialized
INFO - 2022-04-07 04:34:45 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:34:45 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:34:45 --> Utf8 Class Initialized
INFO - 2022-04-07 04:34:45 --> URI Class Initialized
INFO - 2022-04-07 04:34:45 --> URI Class Initialized
INFO - 2022-04-07 04:34:45 --> Router Class Initialized
INFO - 2022-04-07 04:34:45 --> Router Class Initialized
INFO - 2022-04-07 04:34:45 --> Output Class Initialized
INFO - 2022-04-07 04:34:45 --> Output Class Initialized
INFO - 2022-04-07 04:34:45 --> Security Class Initialized
INFO - 2022-04-07 04:34:45 --> Security Class Initialized
DEBUG - 2022-04-07 04:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:34:45 --> Input Class Initialized
INFO - 2022-04-07 04:34:45 --> Input Class Initialized
INFO - 2022-04-07 04:34:45 --> Language Class Initialized
ERROR - 2022-04-07 04:34:45 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:34:45 --> Language Class Initialized
INFO - 2022-04-07 04:34:45 --> Config Class Initialized
INFO - 2022-04-07 04:34:45 --> Hooks Class Initialized
ERROR - 2022-04-07 04:34:45 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:34:45 --> Utf8 Class Initialized
INFO - 2022-04-07 04:34:45 --> URI Class Initialized
INFO - 2022-04-07 04:34:45 --> Router Class Initialized
INFO - 2022-04-07 04:34:45 --> Output Class Initialized
INFO - 2022-04-07 04:34:45 --> Security Class Initialized
DEBUG - 2022-04-07 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:34:45 --> Input Class Initialized
INFO - 2022-04-07 04:34:45 --> Language Class Initialized
ERROR - 2022-04-07 04:34:45 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:35:12 --> Config Class Initialized
INFO - 2022-04-07 04:35:12 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:35:12 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:12 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:12 --> URI Class Initialized
INFO - 2022-04-07 04:35:12 --> Router Class Initialized
INFO - 2022-04-07 04:35:12 --> Output Class Initialized
INFO - 2022-04-07 04:35:12 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:12 --> Input Class Initialized
INFO - 2022-04-07 04:35:12 --> Language Class Initialized
INFO - 2022-04-07 04:35:12 --> Loader Class Initialized
INFO - 2022-04-07 04:35:12 --> Helper loaded: url_helper
INFO - 2022-04-07 04:35:12 --> Helper loaded: form_helper
INFO - 2022-04-07 04:35:12 --> Helper loaded: common_helper
INFO - 2022-04-07 04:35:12 --> Helper loaded: util_helper
INFO - 2022-04-07 04:35:12 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:35:12 --> Form Validation Class Initialized
INFO - 2022-04-07 04:35:12 --> Controller Class Initialized
INFO - 2022-04-07 04:35:12 --> Model Class Initialized
INFO - 2022-04-07 04:35:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:35:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:35:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:35:13 --> Final output sent to browser
DEBUG - 2022-04-07 04:35:13 --> Total execution time: 0.1499
INFO - 2022-04-07 04:35:13 --> Config Class Initialized
INFO - 2022-04-07 04:35:13 --> Config Class Initialized
INFO - 2022-04-07 04:35:13 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:13 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:13 --> Config Class Initialized
INFO - 2022-04-07 04:35:13 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:35:13 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:13 --> Config Class Initialized
INFO - 2022-04-07 04:35:13 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:13 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:35:13 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:13 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:35:13 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:13 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:13 --> URI Class Initialized
INFO - 2022-04-07 04:35:13 --> URI Class Initialized
INFO - 2022-04-07 04:35:13 --> Config Class Initialized
INFO - 2022-04-07 04:35:13 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:13 --> Router Class Initialized
INFO - 2022-04-07 04:35:13 --> Router Class Initialized
DEBUG - 2022-04-07 04:35:13 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:13 --> Output Class Initialized
INFO - 2022-04-07 04:35:13 --> Output Class Initialized
DEBUG - 2022-04-07 04:35:13 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:13 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:13 --> Security Class Initialized
INFO - 2022-04-07 04:35:13 --> URI Class Initialized
INFO - 2022-04-07 04:35:13 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:13 --> Input Class Initialized
INFO - 2022-04-07 04:35:13 --> Router Class Initialized
DEBUG - 2022-04-07 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:13 --> Input Class Initialized
INFO - 2022-04-07 04:35:13 --> Language Class Initialized
INFO - 2022-04-07 04:35:13 --> Output Class Initialized
INFO - 2022-04-07 04:35:13 --> Language Class Initialized
ERROR - 2022-04-07 04:35:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:35:13 --> Security Class Initialized
INFO - 2022-04-07 04:35:13 --> Utf8 Class Initialized
ERROR - 2022-04-07 04:35:13 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:13 --> Input Class Initialized
INFO - 2022-04-07 04:35:13 --> URI Class Initialized
INFO - 2022-04-07 04:35:13 --> Language Class Initialized
INFO - 2022-04-07 04:35:13 --> Router Class Initialized
ERROR - 2022-04-07 04:35:13 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:35:13 --> Output Class Initialized
INFO - 2022-04-07 04:35:13 --> Security Class Initialized
INFO - 2022-04-07 04:35:13 --> URI Class Initialized
DEBUG - 2022-04-07 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:13 --> Input Class Initialized
INFO - 2022-04-07 04:35:13 --> Router Class Initialized
INFO - 2022-04-07 04:35:13 --> Language Class Initialized
INFO - 2022-04-07 04:35:13 --> Output Class Initialized
INFO - 2022-04-07 04:35:13 --> Security Class Initialized
ERROR - 2022-04-07 04:35:13 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:13 --> Input Class Initialized
INFO - 2022-04-07 04:35:13 --> Language Class Initialized
ERROR - 2022-04-07 04:35:13 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
INFO - 2022-04-07 04:35:36 --> Loader Class Initialized
INFO - 2022-04-07 04:35:36 --> Helper loaded: url_helper
INFO - 2022-04-07 04:35:36 --> Helper loaded: form_helper
INFO - 2022-04-07 04:35:36 --> Helper loaded: common_helper
INFO - 2022-04-07 04:35:36 --> Helper loaded: util_helper
INFO - 2022-04-07 04:35:36 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:35:36 --> Form Validation Class Initialized
INFO - 2022-04-07 04:35:36 --> Controller Class Initialized
INFO - 2022-04-07 04:35:36 --> Model Class Initialized
INFO - 2022-04-07 04:35:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
INFO - 2022-04-07 04:35:36 --> Loader Class Initialized
INFO - 2022-04-07 04:35:36 --> Helper loaded: url_helper
INFO - 2022-04-07 04:35:36 --> Helper loaded: form_helper
INFO - 2022-04-07 04:35:36 --> Helper loaded: common_helper
INFO - 2022-04-07 04:35:36 --> Helper loaded: util_helper
INFO - 2022-04-07 04:35:36 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:35:36 --> Form Validation Class Initialized
INFO - 2022-04-07 04:35:36 --> Controller Class Initialized
INFO - 2022-04-07 04:35:36 --> Model Class Initialized
INFO - 2022-04-07 04:35:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:35:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:35:36 --> Final output sent to browser
DEBUG - 2022-04-07 04:35:36 --> Total execution time: 0.0796
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
ERROR - 2022-04-07 04:35:36 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:36 --> Config Class Initialized
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
INFO - 2022-04-07 04:35:36 --> Hooks Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
ERROR - 2022-04-07 04:35:36 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:35:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:35:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:35:36 --> URI Class Initialized
ERROR - 2022-04-07 04:35:36 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
INFO - 2022-04-07 04:35:36 --> Router Class Initialized
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
INFO - 2022-04-07 04:35:36 --> Output Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
INFO - 2022-04-07 04:35:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:35:36 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:35:36 --> Input Class Initialized
INFO - 2022-04-07 04:35:36 --> Language Class Initialized
ERROR - 2022-04-07 04:35:36 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:38:26 --> Config Class Initialized
INFO - 2022-04-07 04:38:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:26 --> URI Class Initialized
INFO - 2022-04-07 04:38:26 --> Router Class Initialized
INFO - 2022-04-07 04:38:26 --> Output Class Initialized
INFO - 2022-04-07 04:38:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:26 --> Input Class Initialized
INFO - 2022-04-07 04:38:26 --> Language Class Initialized
INFO - 2022-04-07 04:38:26 --> Loader Class Initialized
INFO - 2022-04-07 04:38:26 --> Helper loaded: url_helper
INFO - 2022-04-07 04:38:26 --> Helper loaded: form_helper
INFO - 2022-04-07 04:38:26 --> Helper loaded: common_helper
INFO - 2022-04-07 04:38:26 --> Helper loaded: util_helper
INFO - 2022-04-07 04:38:26 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:38:26 --> Form Validation Class Initialized
INFO - 2022-04-07 04:38:26 --> Controller Class Initialized
INFO - 2022-04-07 04:38:26 --> Model Class Initialized
INFO - 2022-04-07 04:38:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:38:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:38:26 --> Final output sent to browser
DEBUG - 2022-04-07 04:38:26 --> Total execution time: 0.0610
INFO - 2022-04-07 04:38:26 --> Config Class Initialized
INFO - 2022-04-07 04:38:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:26 --> URI Class Initialized
INFO - 2022-04-07 04:38:26 --> Router Class Initialized
INFO - 2022-04-07 04:38:26 --> Config Class Initialized
INFO - 2022-04-07 04:38:26 --> Hooks Class Initialized
INFO - 2022-04-07 04:38:26 --> Config Class Initialized
INFO - 2022-04-07 04:38:26 --> Config Class Initialized
INFO - 2022-04-07 04:38:26 --> Hooks Class Initialized
INFO - 2022-04-07 04:38:26 --> Hooks Class Initialized
INFO - 2022-04-07 04:38:26 --> Output Class Initialized
DEBUG - 2022-04-07 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:26 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:26 --> URI Class Initialized
INFO - 2022-04-07 04:38:26 --> URI Class Initialized
INFO - 2022-04-07 04:38:26 --> URI Class Initialized
INFO - 2022-04-07 04:38:26 --> Router Class Initialized
INFO - 2022-04-07 04:38:26 --> Router Class Initialized
INFO - 2022-04-07 04:38:26 --> Router Class Initialized
INFO - 2022-04-07 04:38:26 --> Output Class Initialized
INFO - 2022-04-07 04:38:26 --> Output Class Initialized
INFO - 2022-04-07 04:38:26 --> Security Class Initialized
INFO - 2022-04-07 04:38:26 --> Output Class Initialized
INFO - 2022-04-07 04:38:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:26 --> Security Class Initialized
INFO - 2022-04-07 04:38:26 --> Input Class Initialized
DEBUG - 2022-04-07 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:26 --> Input Class Initialized
INFO - 2022-04-07 04:38:26 --> Language Class Initialized
DEBUG - 2022-04-07 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:26 --> Language Class Initialized
INFO - 2022-04-07 04:38:26 --> Input Class Initialized
INFO - 2022-04-07 04:38:26 --> Language Class Initialized
INFO - 2022-04-07 04:38:26 --> Security Class Initialized
ERROR - 2022-04-07 04:38:26 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:38:26 --> 404 Page Not Found: provider/Profile/js
ERROR - 2022-04-07 04:38:26 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:26 --> Input Class Initialized
INFO - 2022-04-07 04:38:26 --> Language Class Initialized
ERROR - 2022-04-07 04:38:26 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:38:26 --> Config Class Initialized
INFO - 2022-04-07 04:38:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:26 --> URI Class Initialized
INFO - 2022-04-07 04:38:26 --> Router Class Initialized
INFO - 2022-04-07 04:38:26 --> Output Class Initialized
INFO - 2022-04-07 04:38:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:26 --> Input Class Initialized
INFO - 2022-04-07 04:38:26 --> Language Class Initialized
ERROR - 2022-04-07 04:38:26 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:38:44 --> Config Class Initialized
INFO - 2022-04-07 04:38:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:44 --> URI Class Initialized
INFO - 2022-04-07 04:38:44 --> Router Class Initialized
INFO - 2022-04-07 04:38:44 --> Output Class Initialized
INFO - 2022-04-07 04:38:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:44 --> Input Class Initialized
INFO - 2022-04-07 04:38:44 --> Language Class Initialized
INFO - 2022-04-07 04:38:44 --> Loader Class Initialized
INFO - 2022-04-07 04:38:44 --> Helper loaded: url_helper
INFO - 2022-04-07 04:38:44 --> Helper loaded: form_helper
INFO - 2022-04-07 04:38:44 --> Helper loaded: common_helper
INFO - 2022-04-07 04:38:44 --> Helper loaded: util_helper
INFO - 2022-04-07 04:38:44 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:38:44 --> Form Validation Class Initialized
INFO - 2022-04-07 04:38:44 --> Controller Class Initialized
INFO - 2022-04-07 04:38:44 --> Model Class Initialized
INFO - 2022-04-07 04:38:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:38:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:38:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:38:44 --> Final output sent to browser
DEBUG - 2022-04-07 04:38:44 --> Total execution time: 0.1571
INFO - 2022-04-07 04:38:44 --> Config Class Initialized
INFO - 2022-04-07 04:38:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:38:44 --> Config Class Initialized
INFO - 2022-04-07 04:38:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:44 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:44 --> URI Class Initialized
INFO - 2022-04-07 04:38:44 --> URI Class Initialized
INFO - 2022-04-07 04:38:44 --> Config Class Initialized
INFO - 2022-04-07 04:38:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:38:44 --> Router Class Initialized
INFO - 2022-04-07 04:38:44 --> Router Class Initialized
INFO - 2022-04-07 04:38:44 --> Output Class Initialized
INFO - 2022-04-07 04:38:44 --> Output Class Initialized
INFO - 2022-04-07 04:38:44 --> Security Class Initialized
INFO - 2022-04-07 04:38:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:44 --> Input Class Initialized
INFO - 2022-04-07 04:38:44 --> Input Class Initialized
INFO - 2022-04-07 04:38:44 --> Language Class Initialized
INFO - 2022-04-07 04:38:44 --> Language Class Initialized
ERROR - 2022-04-07 04:38:44 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:38:44 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:38:44 --> Config Class Initialized
INFO - 2022-04-07 04:38:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:44 --> URI Class Initialized
DEBUG - 2022-04-07 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:44 --> Router Class Initialized
INFO - 2022-04-07 04:38:44 --> URI Class Initialized
INFO - 2022-04-07 04:38:44 --> Output Class Initialized
INFO - 2022-04-07 04:38:44 --> Router Class Initialized
INFO - 2022-04-07 04:38:44 --> Security Class Initialized
INFO - 2022-04-07 04:38:44 --> Output Class Initialized
DEBUG - 2022-04-07 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:44 --> Config Class Initialized
INFO - 2022-04-07 04:38:44 --> Input Class Initialized
INFO - 2022-04-07 04:38:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:38:44 --> Language Class Initialized
ERROR - 2022-04-07 04:38:44 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:38:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:38:44 --> URI Class Initialized
INFO - 2022-04-07 04:38:44 --> Security Class Initialized
INFO - 2022-04-07 04:38:44 --> Router Class Initialized
DEBUG - 2022-04-07 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:44 --> Input Class Initialized
INFO - 2022-04-07 04:38:44 --> Language Class Initialized
INFO - 2022-04-07 04:38:44 --> Output Class Initialized
INFO - 2022-04-07 04:38:44 --> Security Class Initialized
ERROR - 2022-04-07 04:38:44 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:38:44 --> Input Class Initialized
INFO - 2022-04-07 04:38:44 --> Language Class Initialized
ERROR - 2022-04-07 04:38:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:39:02 --> Config Class Initialized
INFO - 2022-04-07 04:39:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:39:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:39:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:02 --> URI Class Initialized
INFO - 2022-04-07 04:39:02 --> Router Class Initialized
INFO - 2022-04-07 04:39:02 --> Output Class Initialized
INFO - 2022-04-07 04:39:02 --> Security Class Initialized
DEBUG - 2022-04-07 04:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:39:02 --> Input Class Initialized
INFO - 2022-04-07 04:39:02 --> Language Class Initialized
INFO - 2022-04-07 04:39:02 --> Loader Class Initialized
INFO - 2022-04-07 04:39:02 --> Helper loaded: url_helper
INFO - 2022-04-07 04:39:02 --> Helper loaded: form_helper
INFO - 2022-04-07 04:39:02 --> Helper loaded: common_helper
INFO - 2022-04-07 04:39:02 --> Helper loaded: util_helper
INFO - 2022-04-07 04:39:02 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:39:02 --> Form Validation Class Initialized
INFO - 2022-04-07 04:39:02 --> Controller Class Initialized
INFO - 2022-04-07 04:39:02 --> Model Class Initialized
INFO - 2022-04-07 04:39:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:39:02 --> Config Class Initialized
INFO - 2022-04-07 04:39:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:39:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:39:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:02 --> URI Class Initialized
INFO - 2022-04-07 04:39:02 --> Router Class Initialized
INFO - 2022-04-07 04:39:02 --> Output Class Initialized
INFO - 2022-04-07 04:39:02 --> Security Class Initialized
DEBUG - 2022-04-07 04:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:39:02 --> Input Class Initialized
INFO - 2022-04-07 04:39:02 --> Language Class Initialized
INFO - 2022-04-07 04:39:02 --> Loader Class Initialized
INFO - 2022-04-07 04:39:02 --> Helper loaded: url_helper
INFO - 2022-04-07 04:39:02 --> Helper loaded: form_helper
INFO - 2022-04-07 04:39:02 --> Helper loaded: common_helper
INFO - 2022-04-07 04:39:02 --> Helper loaded: util_helper
INFO - 2022-04-07 04:39:02 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:39:02 --> Form Validation Class Initialized
INFO - 2022-04-07 04:39:02 --> Controller Class Initialized
INFO - 2022-04-07 04:39:02 --> Model Class Initialized
INFO - 2022-04-07 04:39:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:39:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:39:02 --> Final output sent to browser
DEBUG - 2022-04-07 04:39:02 --> Total execution time: 0.0675
INFO - 2022-04-07 04:39:03 --> Config Class Initialized
INFO - 2022-04-07 04:39:03 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:39:03 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:03 --> URI Class Initialized
INFO - 2022-04-07 04:39:03 --> Router Class Initialized
INFO - 2022-04-07 04:39:03 --> Config Class Initialized
INFO - 2022-04-07 04:39:03 --> Hooks Class Initialized
INFO - 2022-04-07 04:39:03 --> Config Class Initialized
INFO - 2022-04-07 04:39:03 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:39:03 --> Output Class Initialized
INFO - 2022-04-07 04:39:03 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:03 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:03 --> URI Class Initialized
INFO - 2022-04-07 04:39:03 --> URI Class Initialized
INFO - 2022-04-07 04:39:03 --> Security Class Initialized
INFO - 2022-04-07 04:39:03 --> Config Class Initialized
INFO - 2022-04-07 04:39:03 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:39:03 --> Router Class Initialized
INFO - 2022-04-07 04:39:03 --> Input Class Initialized
INFO - 2022-04-07 04:39:03 --> Language Class Initialized
DEBUG - 2022-04-07 04:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:39:03 --> Output Class Initialized
INFO - 2022-04-07 04:39:03 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:03 --> URI Class Initialized
ERROR - 2022-04-07 04:39:03 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:39:03 --> Router Class Initialized
INFO - 2022-04-07 04:39:03 --> Output Class Initialized
INFO - 2022-04-07 04:39:03 --> Config Class Initialized
INFO - 2022-04-07 04:39:03 --> Hooks Class Initialized
INFO - 2022-04-07 04:39:03 --> Security Class Initialized
DEBUG - 2022-04-07 04:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:39:03 --> Utf8 Class Initialized
INFO - 2022-04-07 04:39:03 --> Router Class Initialized
INFO - 2022-04-07 04:39:03 --> URI Class Initialized
INFO - 2022-04-07 04:39:03 --> Input Class Initialized
INFO - 2022-04-07 04:39:03 --> Output Class Initialized
INFO - 2022-04-07 04:39:03 --> Router Class Initialized
INFO - 2022-04-07 04:39:03 --> Security Class Initialized
INFO - 2022-04-07 04:39:03 --> Security Class Initialized
INFO - 2022-04-07 04:39:03 --> Language Class Initialized
INFO - 2022-04-07 04:39:03 --> Output Class Initialized
DEBUG - 2022-04-07 04:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:39:03 --> Input Class Initialized
INFO - 2022-04-07 04:39:03 --> Input Class Initialized
INFO - 2022-04-07 04:39:03 --> Security Class Initialized
ERROR - 2022-04-07 04:39:03 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:39:03 --> Language Class Initialized
INFO - 2022-04-07 04:39:03 --> Language Class Initialized
ERROR - 2022-04-07 04:39:03 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:39:03 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:39:03 --> Input Class Initialized
INFO - 2022-04-07 04:39:03 --> Language Class Initialized
ERROR - 2022-04-07 04:39:03 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:40:15 --> Config Class Initialized
INFO - 2022-04-07 04:40:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:40:15 --> Config Class Initialized
INFO - 2022-04-07 04:40:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:15 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:40:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:15 --> URI Class Initialized
INFO - 2022-04-07 04:40:15 --> Config Class Initialized
INFO - 2022-04-07 04:40:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:40:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:40:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:15 --> Output Class Initialized
INFO - 2022-04-07 04:40:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:15 --> URI Class Initialized
INFO - 2022-04-07 04:40:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:15 --> Router Class Initialized
INFO - 2022-04-07 04:40:15 --> Input Class Initialized
INFO - 2022-04-07 04:40:15 --> Language Class Initialized
INFO - 2022-04-07 04:40:15 --> URI Class Initialized
INFO - 2022-04-07 04:40:15 --> Output Class Initialized
INFO - 2022-04-07 04:40:15 --> Router Class Initialized
INFO - 2022-04-07 04:40:15 --> Security Class Initialized
INFO - 2022-04-07 04:40:15 --> Output Class Initialized
DEBUG - 2022-04-07 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:15 --> Input Class Initialized
INFO - 2022-04-07 04:40:15 --> Language Class Initialized
INFO - 2022-04-07 04:40:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:40:15 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:40:15 --> Input Class Initialized
ERROR - 2022-04-07 04:40:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:40:15 --> Language Class Initialized
ERROR - 2022-04-07 04:40:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:40:15 --> Config Class Initialized
INFO - 2022-04-07 04:40:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:15 --> URI Class Initialized
INFO - 2022-04-07 04:40:15 --> Router Class Initialized
INFO - 2022-04-07 04:40:15 --> Output Class Initialized
INFO - 2022-04-07 04:40:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:15 --> Input Class Initialized
INFO - 2022-04-07 04:40:15 --> Language Class Initialized
ERROR - 2022-04-07 04:40:15 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:40:15 --> Config Class Initialized
INFO - 2022-04-07 04:40:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:15 --> URI Class Initialized
INFO - 2022-04-07 04:40:15 --> Router Class Initialized
INFO - 2022-04-07 04:40:15 --> Output Class Initialized
INFO - 2022-04-07 04:40:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:15 --> Input Class Initialized
INFO - 2022-04-07 04:40:15 --> Language Class Initialized
ERROR - 2022-04-07 04:40:15 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
INFO - 2022-04-07 04:40:46 --> Loader Class Initialized
INFO - 2022-04-07 04:40:46 --> Helper loaded: url_helper
INFO - 2022-04-07 04:40:46 --> Helper loaded: form_helper
INFO - 2022-04-07 04:40:46 --> Helper loaded: common_helper
INFO - 2022-04-07 04:40:46 --> Helper loaded: util_helper
INFO - 2022-04-07 04:40:46 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:40:46 --> Form Validation Class Initialized
INFO - 2022-04-07 04:40:46 --> Controller Class Initialized
INFO - 2022-04-07 04:40:46 --> Model Class Initialized
INFO - 2022-04-07 04:40:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:40:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:40:46 --> Final output sent to browser
DEBUG - 2022-04-07 04:40:46 --> Total execution time: 0.0709
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Vendor/bootstrap
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:40:46 --> Config Class Initialized
INFO - 2022-04-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:40:46 --> URI Class Initialized
INFO - 2022-04-07 04:40:46 --> Router Class Initialized
INFO - 2022-04-07 04:40:46 --> Output Class Initialized
INFO - 2022-04-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:40:46 --> Input Class Initialized
INFO - 2022-04-07 04:40:46 --> Language Class Initialized
ERROR - 2022-04-07 04:40:46 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:42:14 --> Config Class Initialized
INFO - 2022-04-07 04:42:14 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:14 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:14 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:14 --> URI Class Initialized
INFO - 2022-04-07 04:42:14 --> Router Class Initialized
INFO - 2022-04-07 04:42:14 --> Output Class Initialized
INFO - 2022-04-07 04:42:14 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:14 --> Input Class Initialized
INFO - 2022-04-07 04:42:14 --> Language Class Initialized
INFO - 2022-04-07 04:42:14 --> Loader Class Initialized
INFO - 2022-04-07 04:42:14 --> Helper loaded: url_helper
INFO - 2022-04-07 04:42:14 --> Helper loaded: form_helper
INFO - 2022-04-07 04:42:14 --> Helper loaded: common_helper
INFO - 2022-04-07 04:42:14 --> Helper loaded: util_helper
INFO - 2022-04-07 04:42:14 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:42:14 --> Form Validation Class Initialized
INFO - 2022-04-07 04:42:14 --> Controller Class Initialized
INFO - 2022-04-07 04:42:14 --> Model Class Initialized
INFO - 2022-04-07 04:42:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:42:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:42:14 --> Final output sent to browser
DEBUG - 2022-04-07 04:42:14 --> Total execution time: 0.0615
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:15 --> Config Class Initialized
INFO - 2022-04-07 04:42:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:15 --> URI Class Initialized
INFO - 2022-04-07 04:42:15 --> Router Class Initialized
INFO - 2022-04-07 04:42:15 --> Output Class Initialized
INFO - 2022-04-07 04:42:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:15 --> Input Class Initialized
INFO - 2022-04-07 04:42:15 --> Language Class Initialized
ERROR - 2022-04-07 04:42:15 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
INFO - 2022-04-07 04:42:26 --> Loader Class Initialized
INFO - 2022-04-07 04:42:26 --> Helper loaded: url_helper
INFO - 2022-04-07 04:42:26 --> Helper loaded: form_helper
INFO - 2022-04-07 04:42:26 --> Helper loaded: common_helper
INFO - 2022-04-07 04:42:26 --> Helper loaded: util_helper
INFO - 2022-04-07 04:42:26 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:42:26 --> Form Validation Class Initialized
INFO - 2022-04-07 04:42:26 --> Controller Class Initialized
INFO - 2022-04-07 04:42:26 --> Model Class Initialized
INFO - 2022-04-07 04:42:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:42:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:42:26 --> Final output sent to browser
DEBUG - 2022-04-07 04:42:26 --> Total execution time: 0.0612
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:26 --> Config Class Initialized
INFO - 2022-04-07 04:42:26 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:26 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:26 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:26 --> URI Class Initialized
INFO - 2022-04-07 04:42:26 --> Router Class Initialized
INFO - 2022-04-07 04:42:26 --> Output Class Initialized
INFO - 2022-04-07 04:42:26 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:26 --> Input Class Initialized
INFO - 2022-04-07 04:42:26 --> Language Class Initialized
ERROR - 2022-04-07 04:42:26 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:42:49 --> Config Class Initialized
INFO - 2022-04-07 04:42:49 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:49 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:49 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:49 --> URI Class Initialized
INFO - 2022-04-07 04:42:49 --> Router Class Initialized
INFO - 2022-04-07 04:42:49 --> Output Class Initialized
INFO - 2022-04-07 04:42:49 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:49 --> Input Class Initialized
INFO - 2022-04-07 04:42:49 --> Language Class Initialized
INFO - 2022-04-07 04:42:49 --> Loader Class Initialized
INFO - 2022-04-07 04:42:49 --> Helper loaded: url_helper
INFO - 2022-04-07 04:42:49 --> Helper loaded: form_helper
INFO - 2022-04-07 04:42:49 --> Helper loaded: common_helper
INFO - 2022-04-07 04:42:49 --> Helper loaded: util_helper
INFO - 2022-04-07 04:42:49 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:42:49 --> Form Validation Class Initialized
INFO - 2022-04-07 04:42:49 --> Controller Class Initialized
INFO - 2022-04-07 04:42:49 --> Model Class Initialized
INFO - 2022-04-07 04:42:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:42:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:42:49 --> Final output sent to browser
DEBUG - 2022-04-07 04:42:49 --> Total execution time: 0.0656
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:42:50 --> Config Class Initialized
INFO - 2022-04-07 04:42:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:42:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:42:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:42:50 --> URI Class Initialized
INFO - 2022-04-07 04:42:50 --> Router Class Initialized
INFO - 2022-04-07 04:42:50 --> Output Class Initialized
INFO - 2022-04-07 04:42:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:42:50 --> Input Class Initialized
INFO - 2022-04-07 04:42:50 --> Language Class Initialized
ERROR - 2022-04-07 04:42:50 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
INFO - 2022-04-07 04:43:40 --> Loader Class Initialized
INFO - 2022-04-07 04:43:40 --> Helper loaded: url_helper
INFO - 2022-04-07 04:43:40 --> Helper loaded: form_helper
INFO - 2022-04-07 04:43:40 --> Helper loaded: common_helper
INFO - 2022-04-07 04:43:40 --> Helper loaded: util_helper
INFO - 2022-04-07 04:43:40 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:43:40 --> Form Validation Class Initialized
INFO - 2022-04-07 04:43:40 --> Controller Class Initialized
INFO - 2022-04-07 04:43:40 --> Model Class Initialized
INFO - 2022-04-07 04:43:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:43:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:43:40 --> Final output sent to browser
DEBUG - 2022-04-07 04:43:40 --> Total execution time: 0.0833
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: provider/Profile/js
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Config Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:40 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> URI Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
INFO - 2022-04-07 04:43:40 --> Router Class Initialized
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:40 --> Output Class Initialized
INFO - 2022-04-07 04:43:40 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:40 --> Input Class Initialized
INFO - 2022-04-07 04:43:40 --> Language Class Initialized
ERROR - 2022-04-07 04:43:40 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:41 --> Config Class Initialized
INFO - 2022-04-07 04:43:41 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:41 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:41 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:41 --> URI Class Initialized
INFO - 2022-04-07 04:43:41 --> Router Class Initialized
INFO - 2022-04-07 04:43:41 --> Output Class Initialized
INFO - 2022-04-07 04:43:41 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:41 --> Input Class Initialized
INFO - 2022-04-07 04:43:41 --> Language Class Initialized
ERROR - 2022-04-07 04:43:41 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:43:57 --> Config Class Initialized
INFO - 2022-04-07 04:43:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:57 --> URI Class Initialized
INFO - 2022-04-07 04:43:57 --> Router Class Initialized
INFO - 2022-04-07 04:43:57 --> Output Class Initialized
INFO - 2022-04-07 04:43:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:57 --> Input Class Initialized
INFO - 2022-04-07 04:43:57 --> Language Class Initialized
INFO - 2022-04-07 04:43:57 --> Loader Class Initialized
INFO - 2022-04-07 04:43:57 --> Helper loaded: url_helper
INFO - 2022-04-07 04:43:57 --> Helper loaded: form_helper
INFO - 2022-04-07 04:43:57 --> Helper loaded: common_helper
INFO - 2022-04-07 04:43:57 --> Helper loaded: util_helper
INFO - 2022-04-07 04:43:57 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:43:57 --> Form Validation Class Initialized
INFO - 2022-04-07 04:43:57 --> Controller Class Initialized
INFO - 2022-04-07 04:43:57 --> Model Class Initialized
INFO - 2022-04-07 04:43:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:43:57 --> Config Class Initialized
INFO - 2022-04-07 04:43:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:57 --> URI Class Initialized
INFO - 2022-04-07 04:43:57 --> Router Class Initialized
INFO - 2022-04-07 04:43:57 --> Output Class Initialized
INFO - 2022-04-07 04:43:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:57 --> Input Class Initialized
INFO - 2022-04-07 04:43:57 --> Language Class Initialized
INFO - 2022-04-07 04:43:57 --> Loader Class Initialized
INFO - 2022-04-07 04:43:57 --> Helper loaded: url_helper
INFO - 2022-04-07 04:43:57 --> Helper loaded: form_helper
INFO - 2022-04-07 04:43:57 --> Helper loaded: common_helper
INFO - 2022-04-07 04:43:57 --> Helper loaded: util_helper
INFO - 2022-04-07 04:43:57 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:43:57 --> Form Validation Class Initialized
INFO - 2022-04-07 04:43:57 --> Controller Class Initialized
INFO - 2022-04-07 04:43:57 --> Model Class Initialized
INFO - 2022-04-07 04:43:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:43:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:43:57 --> Final output sent to browser
DEBUG - 2022-04-07 04:43:57 --> Total execution time: 0.0566
INFO - 2022-04-07 04:43:57 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:43:58 --> Config Class Initialized
INFO - 2022-04-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:43:58 --> Utf8 Class Initialized
INFO - 2022-04-07 04:43:58 --> URI Class Initialized
INFO - 2022-04-07 04:43:58 --> Router Class Initialized
INFO - 2022-04-07 04:43:58 --> Output Class Initialized
INFO - 2022-04-07 04:43:58 --> Security Class Initialized
DEBUG - 2022-04-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:43:58 --> Input Class Initialized
INFO - 2022-04-07 04:43:58 --> Language Class Initialized
ERROR - 2022-04-07 04:43:58 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:44:56 --> Config Class Initialized
INFO - 2022-04-07 04:44:56 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:56 --> URI Class Initialized
INFO - 2022-04-07 04:44:56 --> Router Class Initialized
INFO - 2022-04-07 04:44:56 --> Output Class Initialized
INFO - 2022-04-07 04:44:56 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:56 --> Input Class Initialized
INFO - 2022-04-07 04:44:56 --> Language Class Initialized
INFO - 2022-04-07 04:44:56 --> Loader Class Initialized
INFO - 2022-04-07 04:44:56 --> Helper loaded: url_helper
INFO - 2022-04-07 04:44:56 --> Helper loaded: form_helper
INFO - 2022-04-07 04:44:56 --> Helper loaded: common_helper
INFO - 2022-04-07 04:44:56 --> Helper loaded: util_helper
INFO - 2022-04-07 04:44:56 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:44:56 --> Form Validation Class Initialized
INFO - 2022-04-07 04:44:56 --> Controller Class Initialized
INFO - 2022-04-07 04:44:56 --> Model Class Initialized
INFO - 2022-04-07 04:44:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:44:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:44:56 --> Final output sent to browser
DEBUG - 2022-04-07 04:44:56 --> Total execution time: 0.0583
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:44:57 --> Config Class Initialized
INFO - 2022-04-07 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:44:57 --> Utf8 Class Initialized
INFO - 2022-04-07 04:44:57 --> URI Class Initialized
INFO - 2022-04-07 04:44:57 --> Router Class Initialized
INFO - 2022-04-07 04:44:57 --> Output Class Initialized
INFO - 2022-04-07 04:44:57 --> Security Class Initialized
DEBUG - 2022-04-07 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:44:57 --> Input Class Initialized
INFO - 2022-04-07 04:44:57 --> Language Class Initialized
ERROR - 2022-04-07 04:44:57 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
INFO - 2022-04-07 04:45:35 --> Loader Class Initialized
INFO - 2022-04-07 04:45:35 --> Helper loaded: url_helper
INFO - 2022-04-07 04:45:35 --> Helper loaded: form_helper
INFO - 2022-04-07 04:45:35 --> Helper loaded: common_helper
INFO - 2022-04-07 04:45:35 --> Helper loaded: util_helper
INFO - 2022-04-07 04:45:35 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:45:35 --> Form Validation Class Initialized
INFO - 2022-04-07 04:45:35 --> Controller Class Initialized
INFO - 2022-04-07 04:45:35 --> Model Class Initialized
INFO - 2022-04-07 04:45:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:45:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:45:35 --> Final output sent to browser
DEBUG - 2022-04-07 04:45:35 --> Total execution time: 0.0544
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: provider/Profile/js
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
INFO - 2022-04-07 04:45:35 --> Router Class Initialized
INFO - 2022-04-07 04:45:35 --> Output Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:45:35 --> Security Class Initialized
DEBUG - 2022-04-07 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:35 --> Input Class Initialized
INFO - 2022-04-07 04:45:35 --> Language Class Initialized
ERROR - 2022-04-07 04:45:35 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:35 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:35 --> URI Class Initialized
INFO - 2022-04-07 04:45:35 --> Config Class Initialized
INFO - 2022-04-07 04:45:35 --> Hooks Class Initialized
INFO - 2022-04-07 04:45:36 --> Router Class Initialized
DEBUG - 2022-04-07 04:45:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:36 --> Output Class Initialized
INFO - 2022-04-07 04:45:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:36 --> Security Class Initialized
INFO - 2022-04-07 04:45:36 --> URI Class Initialized
DEBUG - 2022-04-07 04:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:36 --> Input Class Initialized
INFO - 2022-04-07 04:45:36 --> Router Class Initialized
INFO - 2022-04-07 04:45:36 --> Language Class Initialized
INFO - 2022-04-07 04:45:36 --> Output Class Initialized
ERROR - 2022-04-07 04:45:36 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:45:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:36 --> Input Class Initialized
INFO - 2022-04-07 04:45:36 --> Language Class Initialized
ERROR - 2022-04-07 04:45:36 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:45:36 --> Config Class Initialized
INFO - 2022-04-07 04:45:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:45:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:45:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:45:36 --> URI Class Initialized
INFO - 2022-04-07 04:45:36 --> Router Class Initialized
INFO - 2022-04-07 04:45:36 --> Output Class Initialized
INFO - 2022-04-07 04:45:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:45:36 --> Input Class Initialized
INFO - 2022-04-07 04:45:36 --> Language Class Initialized
ERROR - 2022-04-07 04:45:36 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
INFO - 2022-04-07 04:46:59 --> Loader Class Initialized
INFO - 2022-04-07 04:46:59 --> Helper loaded: url_helper
INFO - 2022-04-07 04:46:59 --> Helper loaded: form_helper
INFO - 2022-04-07 04:46:59 --> Helper loaded: common_helper
INFO - 2022-04-07 04:46:59 --> Helper loaded: util_helper
INFO - 2022-04-07 04:46:59 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:46:59 --> Form Validation Class Initialized
INFO - 2022-04-07 04:46:59 --> Controller Class Initialized
INFO - 2022-04-07 04:46:59 --> Model Class Initialized
INFO - 2022-04-07 04:46:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:46:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:46:59 --> Final output sent to browser
DEBUG - 2022-04-07 04:46:59 --> Total execution time: 0.0591
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:46:59 --> Config Class Initialized
INFO - 2022-04-07 04:46:59 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:46:59 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:46:59 --> Utf8 Class Initialized
INFO - 2022-04-07 04:46:59 --> URI Class Initialized
INFO - 2022-04-07 04:46:59 --> Router Class Initialized
INFO - 2022-04-07 04:46:59 --> Output Class Initialized
INFO - 2022-04-07 04:46:59 --> Security Class Initialized
DEBUG - 2022-04-07 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:46:59 --> Input Class Initialized
INFO - 2022-04-07 04:46:59 --> Language Class Initialized
ERROR - 2022-04-07 04:46:59 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:47:00 --> Config Class Initialized
INFO - 2022-04-07 04:47:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:47:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:47:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:47:00 --> URI Class Initialized
INFO - 2022-04-07 04:47:00 --> Router Class Initialized
INFO - 2022-04-07 04:47:00 --> Output Class Initialized
INFO - 2022-04-07 04:47:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:47:00 --> Input Class Initialized
INFO - 2022-04-07 04:47:00 --> Config Class Initialized
INFO - 2022-04-07 04:47:00 --> Language Class Initialized
INFO - 2022-04-07 04:47:00 --> Hooks Class Initialized
ERROR - 2022-04-07 04:47:00 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:47:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:47:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:47:00 --> URI Class Initialized
INFO - 2022-04-07 04:47:00 --> Router Class Initialized
INFO - 2022-04-07 04:47:00 --> Output Class Initialized
INFO - 2022-04-07 04:47:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:47:00 --> Input Class Initialized
INFO - 2022-04-07 04:47:00 --> Language Class Initialized
ERROR - 2022-04-07 04:47:00 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:47:00 --> Config Class Initialized
INFO - 2022-04-07 04:47:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:47:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:47:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:47:00 --> URI Class Initialized
INFO - 2022-04-07 04:47:00 --> Router Class Initialized
INFO - 2022-04-07 04:47:00 --> Output Class Initialized
INFO - 2022-04-07 04:47:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:47:00 --> Input Class Initialized
INFO - 2022-04-07 04:47:00 --> Language Class Initialized
ERROR - 2022-04-07 04:47:00 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:48:08 --> Config Class Initialized
INFO - 2022-04-07 04:48:08 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:08 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:08 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:08 --> URI Class Initialized
INFO - 2022-04-07 04:48:08 --> Router Class Initialized
INFO - 2022-04-07 04:48:08 --> Output Class Initialized
INFO - 2022-04-07 04:48:08 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:08 --> Input Class Initialized
INFO - 2022-04-07 04:48:08 --> Language Class Initialized
INFO - 2022-04-07 04:48:08 --> Loader Class Initialized
INFO - 2022-04-07 04:48:08 --> Helper loaded: url_helper
INFO - 2022-04-07 04:48:08 --> Helper loaded: form_helper
INFO - 2022-04-07 04:48:08 --> Helper loaded: common_helper
INFO - 2022-04-07 04:48:08 --> Helper loaded: util_helper
INFO - 2022-04-07 04:48:08 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:48:08 --> Form Validation Class Initialized
INFO - 2022-04-07 04:48:08 --> Controller Class Initialized
INFO - 2022-04-07 04:48:08 --> Model Class Initialized
INFO - 2022-04-07 04:48:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:48:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:48:09 --> Final output sent to browser
DEBUG - 2022-04-07 04:48:09 --> Total execution time: 0.0753
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:48:09 --> Config Class Initialized
INFO - 2022-04-07 04:48:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:09 --> URI Class Initialized
INFO - 2022-04-07 04:48:09 --> Router Class Initialized
INFO - 2022-04-07 04:48:09 --> Output Class Initialized
INFO - 2022-04-07 04:48:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:09 --> Input Class Initialized
INFO - 2022-04-07 04:48:09 --> Language Class Initialized
ERROR - 2022-04-07 04:48:09 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:48:55 --> Config Class Initialized
INFO - 2022-04-07 04:48:55 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:55 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:55 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:55 --> URI Class Initialized
INFO - 2022-04-07 04:48:55 --> Router Class Initialized
INFO - 2022-04-07 04:48:55 --> Output Class Initialized
INFO - 2022-04-07 04:48:55 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:55 --> Input Class Initialized
INFO - 2022-04-07 04:48:55 --> Language Class Initialized
INFO - 2022-04-07 04:48:55 --> Loader Class Initialized
INFO - 2022-04-07 04:48:55 --> Helper loaded: url_helper
INFO - 2022-04-07 04:48:55 --> Helper loaded: form_helper
INFO - 2022-04-07 04:48:55 --> Helper loaded: common_helper
INFO - 2022-04-07 04:48:55 --> Helper loaded: util_helper
INFO - 2022-04-07 04:48:55 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:48:55 --> Form Validation Class Initialized
INFO - 2022-04-07 04:48:55 --> Controller Class Initialized
INFO - 2022-04-07 04:48:55 --> Model Class Initialized
INFO - 2022-04-07 04:48:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:48:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:48:55 --> Final output sent to browser
DEBUG - 2022-04-07 04:48:55 --> Total execution time: 0.0640
INFO - 2022-04-07 04:48:55 --> Config Class Initialized
INFO - 2022-04-07 04:48:55 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:55 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:55 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:55 --> URI Class Initialized
INFO - 2022-04-07 04:48:55 --> Router Class Initialized
INFO - 2022-04-07 04:48:55 --> Output Class Initialized
INFO - 2022-04-07 04:48:55 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:55 --> Input Class Initialized
INFO - 2022-04-07 04:48:55 --> Language Class Initialized
ERROR - 2022-04-07 04:48:55 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:48:55 --> Config Class Initialized
INFO - 2022-04-07 04:48:55 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:55 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:55 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:55 --> URI Class Initialized
INFO - 2022-04-07 04:48:55 --> Config Class Initialized
INFO - 2022-04-07 04:48:55 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:55 --> Router Class Initialized
INFO - 2022-04-07 04:48:55 --> Output Class Initialized
INFO - 2022-04-07 04:48:55 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:55 --> Input Class Initialized
INFO - 2022-04-07 04:48:55 --> Language Class Initialized
DEBUG - 2022-04-07 04:48:55 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:55 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:55 --> URI Class Initialized
ERROR - 2022-04-07 04:48:55 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:48:55 --> Router Class Initialized
INFO - 2022-04-07 04:48:55 --> Output Class Initialized
INFO - 2022-04-07 04:48:55 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:55 --> Input Class Initialized
INFO - 2022-04-07 04:48:55 --> Language Class Initialized
ERROR - 2022-04-07 04:48:55 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:48:55 --> Config Class Initialized
INFO - 2022-04-07 04:48:55 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> Config Class Initialized
INFO - 2022-04-07 04:48:56 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
INFO - 2022-04-07 04:48:56 --> Config Class Initialized
INFO - 2022-04-07 04:48:56 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:48:56 --> Config Class Initialized
INFO - 2022-04-07 04:48:56 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:56 --> Config Class Initialized
INFO - 2022-04-07 04:48:56 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
INFO - 2022-04-07 04:48:56 --> Config Class Initialized
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Hooks Class Initialized
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:48:56 --> Config Class Initialized
INFO - 2022-04-07 04:48:56 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:48:56 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:48:56 --> Utf8 Class Initialized
INFO - 2022-04-07 04:48:56 --> URI Class Initialized
INFO - 2022-04-07 04:48:56 --> Router Class Initialized
INFO - 2022-04-07 04:48:56 --> Output Class Initialized
INFO - 2022-04-07 04:48:56 --> Security Class Initialized
DEBUG - 2022-04-07 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:48:56 --> Input Class Initialized
INFO - 2022-04-07 04:48:56 --> Language Class Initialized
ERROR - 2022-04-07 04:48:56 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
INFO - 2022-04-07 04:49:44 --> Loader Class Initialized
INFO - 2022-04-07 04:49:44 --> Helper loaded: url_helper
INFO - 2022-04-07 04:49:44 --> Helper loaded: form_helper
INFO - 2022-04-07 04:49:44 --> Helper loaded: common_helper
INFO - 2022-04-07 04:49:44 --> Helper loaded: util_helper
INFO - 2022-04-07 04:49:44 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:49:44 --> Form Validation Class Initialized
INFO - 2022-04-07 04:49:44 --> Controller Class Initialized
INFO - 2022-04-07 04:49:44 --> Model Class Initialized
INFO - 2022-04-07 04:49:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:49:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:49:44 --> Final output sent to browser
DEBUG - 2022-04-07 04:49:44 --> Total execution time: 0.0611
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: provider/Profile/js
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
INFO - 2022-04-07 04:49:44 --> Config Class Initialized
INFO - 2022-04-07 04:49:44 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:49:44 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:44 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> URI Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Router Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Output Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
INFO - 2022-04-07 04:49:44 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
DEBUG - 2022-04-07 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:44 --> Input Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
INFO - 2022-04-07 04:49:44 --> Language Class Initialized
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:49:44 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:49:45 --> Config Class Initialized
INFO - 2022-04-07 04:49:45 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:49:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:49:45 --> Utf8 Class Initialized
INFO - 2022-04-07 04:49:45 --> URI Class Initialized
INFO - 2022-04-07 04:49:45 --> Router Class Initialized
INFO - 2022-04-07 04:49:45 --> Output Class Initialized
INFO - 2022-04-07 04:49:45 --> Security Class Initialized
DEBUG - 2022-04-07 04:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:49:45 --> Input Class Initialized
INFO - 2022-04-07 04:49:45 --> Language Class Initialized
ERROR - 2022-04-07 04:49:45 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
INFO - 2022-04-07 04:50:09 --> Loader Class Initialized
INFO - 2022-04-07 04:50:09 --> Helper loaded: url_helper
INFO - 2022-04-07 04:50:09 --> Helper loaded: form_helper
INFO - 2022-04-07 04:50:09 --> Helper loaded: common_helper
INFO - 2022-04-07 04:50:09 --> Helper loaded: util_helper
INFO - 2022-04-07 04:50:09 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:50:09 --> Form Validation Class Initialized
INFO - 2022-04-07 04:50:09 --> Controller Class Initialized
INFO - 2022-04-07 04:50:09 --> Model Class Initialized
INFO - 2022-04-07 04:50:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:50:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:50:09 --> Final output sent to browser
DEBUG - 2022-04-07 04:50:09 --> Total execution time: 0.0556
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/css
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:50:09 --> Config Class Initialized
INFO - 2022-04-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:09 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:09 --> URI Class Initialized
INFO - 2022-04-07 04:50:09 --> Router Class Initialized
INFO - 2022-04-07 04:50:09 --> Output Class Initialized
INFO - 2022-04-07 04:50:09 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:09 --> Input Class Initialized
INFO - 2022-04-07 04:50:09 --> Language Class Initialized
ERROR - 2022-04-07 04:50:09 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:50:46 --> Config Class Initialized
INFO - 2022-04-07 04:50:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:46 --> URI Class Initialized
INFO - 2022-04-07 04:50:46 --> Router Class Initialized
INFO - 2022-04-07 04:50:46 --> Output Class Initialized
INFO - 2022-04-07 04:50:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:46 --> Input Class Initialized
INFO - 2022-04-07 04:50:46 --> Language Class Initialized
INFO - 2022-04-07 04:50:46 --> Loader Class Initialized
INFO - 2022-04-07 04:50:46 --> Helper loaded: url_helper
INFO - 2022-04-07 04:50:46 --> Helper loaded: form_helper
INFO - 2022-04-07 04:50:46 --> Helper loaded: common_helper
INFO - 2022-04-07 04:50:46 --> Helper loaded: util_helper
INFO - 2022-04-07 04:50:46 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:50:46 --> Form Validation Class Initialized
INFO - 2022-04-07 04:50:46 --> Controller Class Initialized
INFO - 2022-04-07 04:50:46 --> Model Class Initialized
INFO - 2022-04-07 04:50:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:50:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:50:46 --> Final output sent to browser
DEBUG - 2022-04-07 04:50:46 --> Total execution time: 0.0536
INFO - 2022-04-07 04:50:46 --> Config Class Initialized
INFO - 2022-04-07 04:50:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:46 --> URI Class Initialized
INFO - 2022-04-07 04:50:46 --> Router Class Initialized
INFO - 2022-04-07 04:50:46 --> Output Class Initialized
INFO - 2022-04-07 04:50:46 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:46 --> Input Class Initialized
INFO - 2022-04-07 04:50:46 --> Language Class Initialized
ERROR - 2022-04-07 04:50:46 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:50:46 --> Config Class Initialized
INFO - 2022-04-07 04:50:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:46 --> URI Class Initialized
INFO - 2022-04-07 04:50:46 --> Config Class Initialized
INFO - 2022-04-07 04:50:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:46 --> Router Class Initialized
DEBUG - 2022-04-07 04:50:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:46 --> URI Class Initialized
INFO - 2022-04-07 04:50:46 --> Output Class Initialized
INFO - 2022-04-07 04:50:46 --> Security Class Initialized
INFO - 2022-04-07 04:50:46 --> Router Class Initialized
DEBUG - 2022-04-07 04:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:46 --> Input Class Initialized
INFO - 2022-04-07 04:50:46 --> Language Class Initialized
INFO - 2022-04-07 04:50:46 --> Output Class Initialized
INFO - 2022-04-07 04:50:46 --> Security Class Initialized
ERROR - 2022-04-07 04:50:46 --> 404 Page Not Found: provider/Profile/js
DEBUG - 2022-04-07 04:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:46 --> Input Class Initialized
INFO - 2022-04-07 04:50:46 --> Language Class Initialized
ERROR - 2022-04-07 04:50:46 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:50:46 --> Config Class Initialized
INFO - 2022-04-07 04:50:46 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:46 --> Config Class Initialized
INFO - 2022-04-07 04:50:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:46 --> URI Class Initialized
DEBUG - 2022-04-07 04:50:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:46 --> Router Class Initialized
INFO - 2022-04-07 04:50:46 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:46 --> URI Class Initialized
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Router Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:50:47 --> Config Class Initialized
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:47 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
INFO - 2022-04-07 04:50:47 --> URI Class Initialized
INFO - 2022-04-07 04:50:47 --> Router Class Initialized
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
INFO - 2022-04-07 04:50:47 --> Config Class Initialized
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:47 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
DEBUG - 2022-04-07 04:50:47 --> UTF-8 Support Enabled
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:50:47 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:47 --> URI Class Initialized
INFO - 2022-04-07 04:50:47 --> Router Class Initialized
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:50:47 --> Config Class Initialized
INFO - 2022-04-07 04:50:47 --> Hooks Class Initialized
INFO - 2022-04-07 04:50:47 --> Config Class Initialized
INFO - 2022-04-07 04:50:47 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:47 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:47 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:50:47 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:47 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:47 --> URI Class Initialized
INFO - 2022-04-07 04:50:47 --> URI Class Initialized
INFO - 2022-04-07 04:50:47 --> Router Class Initialized
INFO - 2022-04-07 04:50:47 --> Router Class Initialized
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:50:47 --> Config Class Initialized
INFO - 2022-04-07 04:50:47 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:50:47 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:50:47 --> Utf8 Class Initialized
INFO - 2022-04-07 04:50:47 --> URI Class Initialized
INFO - 2022-04-07 04:50:47 --> Router Class Initialized
INFO - 2022-04-07 04:50:47 --> Output Class Initialized
INFO - 2022-04-07 04:50:47 --> Security Class Initialized
DEBUG - 2022-04-07 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:50:47 --> Input Class Initialized
INFO - 2022-04-07 04:50:47 --> Language Class Initialized
ERROR - 2022-04-07 04:50:47 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
INFO - 2022-04-07 04:51:20 --> Loader Class Initialized
INFO - 2022-04-07 04:51:20 --> Helper loaded: url_helper
INFO - 2022-04-07 04:51:20 --> Helper loaded: form_helper
INFO - 2022-04-07 04:51:20 --> Helper loaded: common_helper
INFO - 2022-04-07 04:51:20 --> Helper loaded: util_helper
INFO - 2022-04-07 04:51:20 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:51:20 --> Form Validation Class Initialized
INFO - 2022-04-07 04:51:20 --> Controller Class Initialized
INFO - 2022-04-07 04:51:20 --> Model Class Initialized
INFO - 2022-04-07 04:51:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:51:20 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:51:20 --> Final output sent to browser
DEBUG - 2022-04-07 04:51:20 --> Total execution time: 0.0560
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:51:20 --> Config Class Initialized
INFO - 2022-04-07 04:51:20 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:20 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:20 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:20 --> URI Class Initialized
INFO - 2022-04-07 04:51:20 --> Router Class Initialized
INFO - 2022-04-07 04:51:20 --> Output Class Initialized
INFO - 2022-04-07 04:51:20 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:20 --> Input Class Initialized
INFO - 2022-04-07 04:51:20 --> Language Class Initialized
ERROR - 2022-04-07 04:51:20 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
INFO - 2022-04-07 04:51:51 --> Loader Class Initialized
INFO - 2022-04-07 04:51:51 --> Helper loaded: url_helper
INFO - 2022-04-07 04:51:51 --> Helper loaded: form_helper
INFO - 2022-04-07 04:51:51 --> Helper loaded: common_helper
INFO - 2022-04-07 04:51:51 --> Helper loaded: util_helper
INFO - 2022-04-07 04:51:51 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:51:51 --> Form Validation Class Initialized
INFO - 2022-04-07 04:51:51 --> Controller Class Initialized
INFO - 2022-04-07 04:51:51 --> Model Class Initialized
INFO - 2022-04-07 04:51:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:51:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:51:51 --> Final output sent to browser
DEBUG - 2022-04-07 04:51:51 --> Total execution time: 0.0562
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Vendor/bootstrap
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
INFO - 2022-04-07 04:51:51 --> Config Class Initialized
INFO - 2022-04-07 04:51:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:51 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> URI Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:51:51 --> Router Class Initialized
INFO - 2022-04-07 04:51:51 --> Output Class Initialized
INFO - 2022-04-07 04:51:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:51 --> Input Class Initialized
INFO - 2022-04-07 04:51:51 --> Language Class Initialized
ERROR - 2022-04-07 04:51:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:51:52 --> Config Class Initialized
INFO - 2022-04-07 04:51:52 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:52 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:52 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:52 --> URI Class Initialized
INFO - 2022-04-07 04:51:52 --> Router Class Initialized
INFO - 2022-04-07 04:51:52 --> Output Class Initialized
INFO - 2022-04-07 04:51:52 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:52 --> Input Class Initialized
INFO - 2022-04-07 04:51:52 --> Language Class Initialized
ERROR - 2022-04-07 04:51:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:51:52 --> Config Class Initialized
INFO - 2022-04-07 04:51:52 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:51:52 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:51:52 --> Utf8 Class Initialized
INFO - 2022-04-07 04:51:52 --> URI Class Initialized
INFO - 2022-04-07 04:51:52 --> Router Class Initialized
INFO - 2022-04-07 04:51:52 --> Output Class Initialized
INFO - 2022-04-07 04:51:52 --> Security Class Initialized
DEBUG - 2022-04-07 04:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:51:52 --> Input Class Initialized
INFO - 2022-04-07 04:51:52 --> Language Class Initialized
ERROR - 2022-04-07 04:51:52 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
INFO - 2022-04-07 04:53:51 --> Loader Class Initialized
INFO - 2022-04-07 04:53:51 --> Helper loaded: url_helper
INFO - 2022-04-07 04:53:51 --> Helper loaded: form_helper
INFO - 2022-04-07 04:53:51 --> Helper loaded: common_helper
INFO - 2022-04-07 04:53:51 --> Helper loaded: util_helper
INFO - 2022-04-07 04:53:51 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:53:51 --> Form Validation Class Initialized
INFO - 2022-04-07 04:53:51 --> Controller Class Initialized
INFO - 2022-04-07 04:53:51 --> Model Class Initialized
INFO - 2022-04-07 04:53:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:53:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:53:51 --> Final output sent to browser
DEBUG - 2022-04-07 04:53:51 --> Total execution time: 0.0575
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: provider/Profile/js
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Config Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
INFO - 2022-04-07 04:53:51 --> Hooks Class Initialized
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:51 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:51 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> URI Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
INFO - 2022-04-07 04:53:51 --> Router Class Initialized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:53:51 --> Output Class Initialized
INFO - 2022-04-07 04:53:51 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:51 --> Input Class Initialized
INFO - 2022-04-07 04:53:51 --> Language Class Initialized
ERROR - 2022-04-07 04:53:51 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:53:52 --> Config Class Initialized
INFO - 2022-04-07 04:53:52 --> Config Class Initialized
INFO - 2022-04-07 04:53:52 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:52 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:52 --> Hooks Class Initialized
INFO - 2022-04-07 04:53:52 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:52 --> URI Class Initialized
DEBUG - 2022-04-07 04:53:52 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:52 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:52 --> Router Class Initialized
INFO - 2022-04-07 04:53:52 --> URI Class Initialized
INFO - 2022-04-07 04:53:52 --> Output Class Initialized
INFO - 2022-04-07 04:53:52 --> Router Class Initialized
INFO - 2022-04-07 04:53:52 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:52 --> Input Class Initialized
INFO - 2022-04-07 04:53:52 --> Output Class Initialized
INFO - 2022-04-07 04:53:52 --> Language Class Initialized
INFO - 2022-04-07 04:53:52 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:52 --> Input Class Initialized
ERROR - 2022-04-07 04:53:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:53:52 --> Language Class Initialized
ERROR - 2022-04-07 04:53:52 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:53:52 --> Config Class Initialized
INFO - 2022-04-07 04:53:52 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:53:52 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:53:52 --> Utf8 Class Initialized
INFO - 2022-04-07 04:53:52 --> URI Class Initialized
INFO - 2022-04-07 04:53:52 --> Router Class Initialized
INFO - 2022-04-07 04:53:52 --> Output Class Initialized
INFO - 2022-04-07 04:53:52 --> Security Class Initialized
DEBUG - 2022-04-07 04:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:53:52 --> Input Class Initialized
INFO - 2022-04-07 04:53:52 --> Language Class Initialized
ERROR - 2022-04-07 04:53:52 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
INFO - 2022-04-07 04:54:07 --> Loader Class Initialized
INFO - 2022-04-07 04:54:07 --> Helper loaded: url_helper
INFO - 2022-04-07 04:54:07 --> Helper loaded: form_helper
INFO - 2022-04-07 04:54:07 --> Helper loaded: common_helper
INFO - 2022-04-07 04:54:07 --> Helper loaded: util_helper
INFO - 2022-04-07 04:54:07 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:54:07 --> Form Validation Class Initialized
INFO - 2022-04-07 04:54:07 --> Controller Class Initialized
INFO - 2022-04-07 04:54:07 --> Model Class Initialized
INFO - 2022-04-07 04:54:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:54:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:54:07 --> Final output sent to browser
DEBUG - 2022-04-07 04:54:07 --> Total execution time: 0.0639
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Config Class Initialized
INFO - 2022-04-07 04:54:07 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
DEBUG - 2022-04-07 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:07 --> URI Class Initialized
INFO - 2022-04-07 04:54:07 --> Router Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
INFO - 2022-04-07 04:54:07 --> Output Class Initialized
INFO - 2022-04-07 04:54:07 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Input Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
INFO - 2022-04-07 04:54:07 --> Language Class Initialized
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-07 04:54:07 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:54:08 --> Config Class Initialized
INFO - 2022-04-07 04:54:08 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:08 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:08 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:08 --> URI Class Initialized
INFO - 2022-04-07 04:54:08 --> Router Class Initialized
INFO - 2022-04-07 04:54:08 --> Output Class Initialized
INFO - 2022-04-07 04:54:08 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:08 --> Input Class Initialized
INFO - 2022-04-07 04:54:08 --> Language Class Initialized
ERROR - 2022-04-07 04:54:08 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:54:49 --> Config Class Initialized
INFO - 2022-04-07 04:54:49 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:49 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:49 --> URI Class Initialized
INFO - 2022-04-07 04:54:49 --> Router Class Initialized
INFO - 2022-04-07 04:54:49 --> Output Class Initialized
INFO - 2022-04-07 04:54:49 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:49 --> Input Class Initialized
INFO - 2022-04-07 04:54:49 --> Language Class Initialized
INFO - 2022-04-07 04:54:49 --> Loader Class Initialized
INFO - 2022-04-07 04:54:49 --> Helper loaded: url_helper
INFO - 2022-04-07 04:54:49 --> Helper loaded: form_helper
INFO - 2022-04-07 04:54:49 --> Helper loaded: common_helper
INFO - 2022-04-07 04:54:49 --> Helper loaded: util_helper
INFO - 2022-04-07 04:54:49 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:54:49 --> Form Validation Class Initialized
INFO - 2022-04-07 04:54:49 --> Controller Class Initialized
INFO - 2022-04-07 04:54:49 --> Model Class Initialized
INFO - 2022-04-07 04:54:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:54:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:54:49 --> Final output sent to browser
DEBUG - 2022-04-07 04:54:49 --> Total execution time: 0.0616
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:54:50 --> Config Class Initialized
INFO - 2022-04-07 04:54:50 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:54:50 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:54:50 --> Utf8 Class Initialized
INFO - 2022-04-07 04:54:50 --> URI Class Initialized
INFO - 2022-04-07 04:54:50 --> Router Class Initialized
INFO - 2022-04-07 04:54:50 --> Output Class Initialized
INFO - 2022-04-07 04:54:50 --> Security Class Initialized
DEBUG - 2022-04-07 04:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:54:50 --> Input Class Initialized
INFO - 2022-04-07 04:54:50 --> Language Class Initialized
ERROR - 2022-04-07 04:54:50 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
INFO - 2022-04-07 04:55:04 --> Loader Class Initialized
INFO - 2022-04-07 04:55:04 --> Helper loaded: url_helper
INFO - 2022-04-07 04:55:04 --> Helper loaded: form_helper
INFO - 2022-04-07 04:55:04 --> Helper loaded: common_helper
INFO - 2022-04-07 04:55:04 --> Helper loaded: util_helper
INFO - 2022-04-07 04:55:04 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:55:04 --> Form Validation Class Initialized
INFO - 2022-04-07 04:55:04 --> Controller Class Initialized
INFO - 2022-04-07 04:55:04 --> Model Class Initialized
INFO - 2022-04-07 04:55:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:55:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:55:04 --> Final output sent to browser
DEBUG - 2022-04-07 04:55:04 --> Total execution time: 0.0558
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Vendor/bootstrap
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:04 --> Config Class Initialized
INFO - 2022-04-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:04 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:04 --> URI Class Initialized
INFO - 2022-04-07 04:55:04 --> Router Class Initialized
INFO - 2022-04-07 04:55:04 --> Output Class Initialized
INFO - 2022-04-07 04:55:04 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:04 --> Input Class Initialized
INFO - 2022-04-07 04:55:04 --> Language Class Initialized
ERROR - 2022-04-07 04:55:04 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
INFO - 2022-04-07 04:55:21 --> Loader Class Initialized
INFO - 2022-04-07 04:55:21 --> Helper loaded: url_helper
INFO - 2022-04-07 04:55:21 --> Helper loaded: form_helper
INFO - 2022-04-07 04:55:21 --> Helper loaded: common_helper
INFO - 2022-04-07 04:55:21 --> Helper loaded: util_helper
INFO - 2022-04-07 04:55:21 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:55:21 --> Form Validation Class Initialized
INFO - 2022-04-07 04:55:21 --> Controller Class Initialized
INFO - 2022-04-07 04:55:21 --> Model Class Initialized
INFO - 2022-04-07 04:55:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:55:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:55:21 --> Final output sent to browser
DEBUG - 2022-04-07 04:55:21 --> Total execution time: 0.0552
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
INFO - 2022-04-07 04:55:21 --> Config Class Initialized
INFO - 2022-04-07 04:55:21 --> Hooks Class Initialized
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
DEBUG - 2022-04-07 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
INFO - 2022-04-07 04:55:21 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:21 --> URI Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
INFO - 2022-04-07 04:55:21 --> Router Class Initialized
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:55:21 --> Output Class Initialized
INFO - 2022-04-07 04:55:21 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:21 --> Input Class Initialized
INFO - 2022-04-07 04:55:21 --> Language Class Initialized
ERROR - 2022-04-07 04:55:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:22 --> Config Class Initialized
INFO - 2022-04-07 04:55:22 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:22 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:22 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:22 --> URI Class Initialized
INFO - 2022-04-07 04:55:22 --> Router Class Initialized
INFO - 2022-04-07 04:55:22 --> Output Class Initialized
INFO - 2022-04-07 04:55:22 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:22 --> Input Class Initialized
INFO - 2022-04-07 04:55:22 --> Language Class Initialized
INFO - 2022-04-07 04:55:22 --> Config Class Initialized
INFO - 2022-04-07 04:55:22 --> Hooks Class Initialized
ERROR - 2022-04-07 04:55:22 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:55:22 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:22 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:22 --> URI Class Initialized
INFO - 2022-04-07 04:55:22 --> Router Class Initialized
INFO - 2022-04-07 04:55:22 --> Output Class Initialized
INFO - 2022-04-07 04:55:22 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:22 --> Input Class Initialized
INFO - 2022-04-07 04:55:22 --> Language Class Initialized
ERROR - 2022-04-07 04:55:22 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:55:22 --> Config Class Initialized
INFO - 2022-04-07 04:55:22 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:55:22 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:55:22 --> Utf8 Class Initialized
INFO - 2022-04-07 04:55:22 --> URI Class Initialized
INFO - 2022-04-07 04:55:22 --> Router Class Initialized
INFO - 2022-04-07 04:55:22 --> Output Class Initialized
INFO - 2022-04-07 04:55:22 --> Security Class Initialized
DEBUG - 2022-04-07 04:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:55:22 --> Input Class Initialized
INFO - 2022-04-07 04:55:22 --> Language Class Initialized
ERROR - 2022-04-07 04:55:22 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:56:00 --> Config Class Initialized
INFO - 2022-04-07 04:56:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:56:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:00 --> URI Class Initialized
INFO - 2022-04-07 04:56:00 --> Router Class Initialized
INFO - 2022-04-07 04:56:00 --> Output Class Initialized
INFO - 2022-04-07 04:56:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:00 --> Input Class Initialized
INFO - 2022-04-07 04:56:00 --> Language Class Initialized
INFO - 2022-04-07 04:56:00 --> Loader Class Initialized
INFO - 2022-04-07 04:56:00 --> Helper loaded: url_helper
INFO - 2022-04-07 04:56:00 --> Helper loaded: form_helper
INFO - 2022-04-07 04:56:00 --> Helper loaded: common_helper
INFO - 2022-04-07 04:56:00 --> Helper loaded: util_helper
INFO - 2022-04-07 04:56:00 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:56:00 --> Form Validation Class Initialized
INFO - 2022-04-07 04:56:00 --> Controller Class Initialized
INFO - 2022-04-07 04:56:00 --> Model Class Initialized
INFO - 2022-04-07 04:56:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:56:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:56:00 --> Final output sent to browser
DEBUG - 2022-04-07 04:56:00 --> Total execution time: 0.0554
INFO - 2022-04-07 04:56:00 --> Config Class Initialized
INFO - 2022-04-07 04:56:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:56:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:00 --> URI Class Initialized
INFO - 2022-04-07 04:56:00 --> Router Class Initialized
INFO - 2022-04-07 04:56:00 --> Output Class Initialized
INFO - 2022-04-07 04:56:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:00 --> Input Class Initialized
INFO - 2022-04-07 04:56:00 --> Language Class Initialized
ERROR - 2022-04-07 04:56:00 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:56:00 --> Config Class Initialized
INFO - 2022-04-07 04:56:00 --> Hooks Class Initialized
INFO - 2022-04-07 04:56:00 --> Config Class Initialized
INFO - 2022-04-07 04:56:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:56:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:00 --> URI Class Initialized
INFO - 2022-04-07 04:56:00 --> Router Class Initialized
DEBUG - 2022-04-07 04:56:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:00 --> Output Class Initialized
INFO - 2022-04-07 04:56:00 --> URI Class Initialized
INFO - 2022-04-07 04:56:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:00 --> Router Class Initialized
INFO - 2022-04-07 04:56:00 --> Input Class Initialized
INFO - 2022-04-07 04:56:00 --> Language Class Initialized
INFO - 2022-04-07 04:56:00 --> Output Class Initialized
INFO - 2022-04-07 04:56:00 --> Security Class Initialized
ERROR - 2022-04-07 04:56:00 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:00 --> Input Class Initialized
INFO - 2022-04-07 04:56:00 --> Language Class Initialized
ERROR - 2022-04-07 04:56:00 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:56:00 --> Config Class Initialized
INFO - 2022-04-07 04:56:00 --> Config Class Initialized
INFO - 2022-04-07 04:56:00 --> Hooks Class Initialized
INFO - 2022-04-07 04:56:00 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:56:00 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:00 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:00 --> URI Class Initialized
INFO - 2022-04-07 04:56:00 --> URI Class Initialized
INFO - 2022-04-07 04:56:00 --> Router Class Initialized
INFO - 2022-04-07 04:56:00 --> Router Class Initialized
INFO - 2022-04-07 04:56:00 --> Output Class Initialized
INFO - 2022-04-07 04:56:00 --> Output Class Initialized
INFO - 2022-04-07 04:56:00 --> Security Class Initialized
INFO - 2022-04-07 04:56:00 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:00 --> Input Class Initialized
INFO - 2022-04-07 04:56:00 --> Input Class Initialized
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:56:01 --> Config Class Initialized
INFO - 2022-04-07 04:56:01 --> Hooks Class Initialized
INFO - 2022-04-07 04:56:01 --> Config Class Initialized
DEBUG - 2022-04-07 04:56:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:01 --> Hooks Class Initialized
INFO - 2022-04-07 04:56:01 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:01 --> URI Class Initialized
DEBUG - 2022-04-07 04:56:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:01 --> Router Class Initialized
INFO - 2022-04-07 04:56:01 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:01 --> URI Class Initialized
INFO - 2022-04-07 04:56:01 --> Output Class Initialized
INFO - 2022-04-07 04:56:01 --> Router Class Initialized
INFO - 2022-04-07 04:56:01 --> Security Class Initialized
INFO - 2022-04-07 04:56:01 --> Output Class Initialized
DEBUG - 2022-04-07 04:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:01 --> Input Class Initialized
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
INFO - 2022-04-07 04:56:01 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:01 --> Input Class Initialized
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:56:01 --> Config Class Initialized
INFO - 2022-04-07 04:56:01 --> Config Class Initialized
INFO - 2022-04-07 04:56:01 --> Hooks Class Initialized
INFO - 2022-04-07 04:56:01 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:56:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:01 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:56:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:01 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:01 --> URI Class Initialized
INFO - 2022-04-07 04:56:01 --> URI Class Initialized
INFO - 2022-04-07 04:56:01 --> Router Class Initialized
INFO - 2022-04-07 04:56:01 --> Output Class Initialized
INFO - 2022-04-07 04:56:01 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:01 --> Input Class Initialized
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
INFO - 2022-04-07 04:56:01 --> Router Class Initialized
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:56:01 --> Output Class Initialized
INFO - 2022-04-07 04:56:01 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:01 --> Input Class Initialized
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:56:01 --> Config Class Initialized
INFO - 2022-04-07 04:56:01 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:56:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:56:01 --> Utf8 Class Initialized
INFO - 2022-04-07 04:56:01 --> URI Class Initialized
INFO - 2022-04-07 04:56:01 --> Router Class Initialized
INFO - 2022-04-07 04:56:01 --> Output Class Initialized
INFO - 2022-04-07 04:56:01 --> Security Class Initialized
DEBUG - 2022-04-07 04:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:56:01 --> Input Class Initialized
INFO - 2022-04-07 04:56:01 --> Language Class Initialized
ERROR - 2022-04-07 04:56:01 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
INFO - 2022-04-07 04:57:15 --> Loader Class Initialized
INFO - 2022-04-07 04:57:15 --> Helper loaded: url_helper
INFO - 2022-04-07 04:57:15 --> Helper loaded: form_helper
INFO - 2022-04-07 04:57:15 --> Helper loaded: common_helper
INFO - 2022-04-07 04:57:15 --> Helper loaded: util_helper
INFO - 2022-04-07 04:57:15 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:57:15 --> Form Validation Class Initialized
INFO - 2022-04-07 04:57:15 --> Controller Class Initialized
INFO - 2022-04-07 04:57:15 --> Model Class Initialized
INFO - 2022-04-07 04:57:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:57:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:57:15 --> Final output sent to browser
DEBUG - 2022-04-07 04:57:15 --> Total execution time: 0.0573
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:15 --> Security Class Initialized
DEBUG - 2022-04-07 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:15 --> Input Class Initialized
INFO - 2022-04-07 04:57:15 --> Language Class Initialized
ERROR - 2022-04-07 04:57:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:57:15 --> Config Class Initialized
INFO - 2022-04-07 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:57:15 --> Utf8 Class Initialized
INFO - 2022-04-07 04:57:15 --> URI Class Initialized
INFO - 2022-04-07 04:57:15 --> Router Class Initialized
INFO - 2022-04-07 04:57:15 --> Output Class Initialized
INFO - 2022-04-07 04:57:16 --> Security Class Initialized
DEBUG - 2022-04-07 04:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:57:16 --> Input Class Initialized
INFO - 2022-04-07 04:57:16 --> Language Class Initialized
ERROR - 2022-04-07 04:57:16 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:58:01 --> Config Class Initialized
INFO - 2022-04-07 04:58:01 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:01 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:01 --> URI Class Initialized
INFO - 2022-04-07 04:58:01 --> Router Class Initialized
INFO - 2022-04-07 04:58:01 --> Output Class Initialized
INFO - 2022-04-07 04:58:01 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:01 --> Input Class Initialized
INFO - 2022-04-07 04:58:01 --> Language Class Initialized
INFO - 2022-04-07 04:58:01 --> Loader Class Initialized
INFO - 2022-04-07 04:58:01 --> Helper loaded: url_helper
INFO - 2022-04-07 04:58:01 --> Helper loaded: form_helper
INFO - 2022-04-07 04:58:01 --> Helper loaded: common_helper
INFO - 2022-04-07 04:58:01 --> Helper loaded: util_helper
INFO - 2022-04-07 04:58:01 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:58:01 --> Form Validation Class Initialized
INFO - 2022-04-07 04:58:01 --> Controller Class Initialized
INFO - 2022-04-07 04:58:01 --> Model Class Initialized
INFO - 2022-04-07 04:58:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:58:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:58:01 --> Final output sent to browser
DEBUG - 2022-04-07 04:58:01 --> Total execution time: 0.0674
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Fassets/js
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:58:02 --> Config Class Initialized
INFO - 2022-04-07 04:58:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:02 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:02 --> URI Class Initialized
INFO - 2022-04-07 04:58:02 --> Router Class Initialized
INFO - 2022-04-07 04:58:02 --> Output Class Initialized
INFO - 2022-04-07 04:58:02 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:02 --> Input Class Initialized
INFO - 2022-04-07 04:58:02 --> Language Class Initialized
ERROR - 2022-04-07 04:58:02 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:58:36 --> Config Class Initialized
INFO - 2022-04-07 04:58:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:36 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:36 --> URI Class Initialized
INFO - 2022-04-07 04:58:36 --> Router Class Initialized
INFO - 2022-04-07 04:58:36 --> Output Class Initialized
INFO - 2022-04-07 04:58:36 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:36 --> Input Class Initialized
INFO - 2022-04-07 04:58:36 --> Language Class Initialized
INFO - 2022-04-07 04:58:36 --> Loader Class Initialized
INFO - 2022-04-07 04:58:36 --> Helper loaded: url_helper
INFO - 2022-04-07 04:58:36 --> Helper loaded: form_helper
INFO - 2022-04-07 04:58:36 --> Helper loaded: common_helper
INFO - 2022-04-07 04:58:36 --> Helper loaded: util_helper
INFO - 2022-04-07 04:58:36 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:58:36 --> Form Validation Class Initialized
INFO - 2022-04-07 04:58:36 --> Controller Class Initialized
INFO - 2022-04-07 04:58:36 --> Model Class Initialized
INFO - 2022-04-07 04:58:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:58:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:58:36 --> Final output sent to browser
DEBUG - 2022-04-07 04:58:36 --> Total execution time: 0.0699
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: Fassets/js
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:58:37 --> Config Class Initialized
INFO - 2022-04-07 04:58:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:58:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:58:37 --> Utf8 Class Initialized
INFO - 2022-04-07 04:58:37 --> URI Class Initialized
INFO - 2022-04-07 04:58:37 --> Router Class Initialized
INFO - 2022-04-07 04:58:37 --> Output Class Initialized
INFO - 2022-04-07 04:58:37 --> Security Class Initialized
DEBUG - 2022-04-07 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:58:37 --> Input Class Initialized
INFO - 2022-04-07 04:58:37 --> Language Class Initialized
ERROR - 2022-04-07 04:58:37 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:59:29 --> Config Class Initialized
INFO - 2022-04-07 04:59:29 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:29 --> URI Class Initialized
INFO - 2022-04-07 04:59:29 --> Router Class Initialized
INFO - 2022-04-07 04:59:29 --> Output Class Initialized
INFO - 2022-04-07 04:59:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:29 --> Input Class Initialized
INFO - 2022-04-07 04:59:29 --> Language Class Initialized
INFO - 2022-04-07 04:59:29 --> Loader Class Initialized
INFO - 2022-04-07 04:59:29 --> Helper loaded: url_helper
INFO - 2022-04-07 04:59:29 --> Helper loaded: form_helper
INFO - 2022-04-07 04:59:29 --> Helper loaded: common_helper
INFO - 2022-04-07 04:59:29 --> Helper loaded: util_helper
INFO - 2022-04-07 04:59:29 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:59:29 --> Form Validation Class Initialized
INFO - 2022-04-07 04:59:29 --> Controller Class Initialized
INFO - 2022-04-07 04:59:29 --> Model Class Initialized
INFO - 2022-04-07 04:59:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:59:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:59:29 --> Final output sent to browser
DEBUG - 2022-04-07 04:59:29 --> Total execution time: 0.0638
INFO - 2022-04-07 04:59:29 --> Config Class Initialized
INFO - 2022-04-07 04:59:29 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:29 --> URI Class Initialized
INFO - 2022-04-07 04:59:29 --> Router Class Initialized
INFO - 2022-04-07 04:59:29 --> Output Class Initialized
INFO - 2022-04-07 04:59:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:29 --> Input Class Initialized
INFO - 2022-04-07 04:59:29 --> Language Class Initialized
ERROR - 2022-04-07 04:59:29 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:59:29 --> Config Class Initialized
INFO - 2022-04-07 04:59:29 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:29 --> URI Class Initialized
INFO - 2022-04-07 04:59:29 --> Router Class Initialized
INFO - 2022-04-07 04:59:29 --> Output Class Initialized
INFO - 2022-04-07 04:59:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:29 --> Input Class Initialized
INFO - 2022-04-07 04:59:29 --> Language Class Initialized
ERROR - 2022-04-07 04:59:29 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:59:29 --> Config Class Initialized
INFO - 2022-04-07 04:59:29 --> Config Class Initialized
INFO - 2022-04-07 04:59:29 --> Hooks Class Initialized
INFO - 2022-04-07 04:59:29 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:29 --> URI Class Initialized
INFO - 2022-04-07 04:59:29 --> Router Class Initialized
DEBUG - 2022-04-07 04:59:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:29 --> Output Class Initialized
INFO - 2022-04-07 04:59:29 --> URI Class Initialized
INFO - 2022-04-07 04:59:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:29 --> Input Class Initialized
INFO - 2022-04-07 04:59:29 --> Language Class Initialized
ERROR - 2022-04-07 04:59:29 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:59:29 --> Router Class Initialized
INFO - 2022-04-07 04:59:29 --> Output Class Initialized
INFO - 2022-04-07 04:59:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:29 --> Input Class Initialized
INFO - 2022-04-07 04:59:29 --> Language Class Initialized
INFO - 2022-04-07 04:59:29 --> Config Class Initialized
ERROR - 2022-04-07 04:59:29 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 04:59:29 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:29 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:29 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:29 --> URI Class Initialized
INFO - 2022-04-07 04:59:29 --> Router Class Initialized
INFO - 2022-04-07 04:59:29 --> Output Class Initialized
INFO - 2022-04-07 04:59:29 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:29 --> Input Class Initialized
INFO - 2022-04-07 04:59:29 --> Language Class Initialized
ERROR - 2022-04-07 04:59:29 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:59:30 --> Config Class Initialized
INFO - 2022-04-07 04:59:30 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:30 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:30 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:30 --> URI Class Initialized
INFO - 2022-04-07 04:59:30 --> Router Class Initialized
INFO - 2022-04-07 04:59:30 --> Output Class Initialized
INFO - 2022-04-07 04:59:30 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:30 --> Input Class Initialized
INFO - 2022-04-07 04:59:30 --> Language Class Initialized
ERROR - 2022-04-07 04:59:30 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:59:48 --> Config Class Initialized
INFO - 2022-04-07 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:48 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:48 --> URI Class Initialized
INFO - 2022-04-07 04:59:48 --> Router Class Initialized
INFO - 2022-04-07 04:59:48 --> Output Class Initialized
INFO - 2022-04-07 04:59:48 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:48 --> Input Class Initialized
INFO - 2022-04-07 04:59:48 --> Language Class Initialized
INFO - 2022-04-07 04:59:48 --> Loader Class Initialized
INFO - 2022-04-07 04:59:48 --> Helper loaded: url_helper
INFO - 2022-04-07 04:59:48 --> Helper loaded: form_helper
INFO - 2022-04-07 04:59:48 --> Helper loaded: common_helper
INFO - 2022-04-07 04:59:48 --> Helper loaded: util_helper
INFO - 2022-04-07 04:59:48 --> Database Driver Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 04:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 04:59:48 --> Form Validation Class Initialized
INFO - 2022-04-07 04:59:48 --> Controller Class Initialized
INFO - 2022-04-07 04:59:48 --> Model Class Initialized
INFO - 2022-04-07 04:59:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 04:59:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 04:59:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 04:59:48 --> Final output sent to browser
DEBUG - 2022-04-07 04:59:48 --> Total execution time: 0.1536
INFO - 2022-04-07 04:59:48 --> Config Class Initialized
INFO - 2022-04-07 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:48 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:48 --> URI Class Initialized
INFO - 2022-04-07 04:59:48 --> Router Class Initialized
INFO - 2022-04-07 04:59:48 --> Output Class Initialized
INFO - 2022-04-07 04:59:48 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:48 --> Input Class Initialized
INFO - 2022-04-07 04:59:48 --> Language Class Initialized
ERROR - 2022-04-07 04:59:48 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 04:59:48 --> Config Class Initialized
INFO - 2022-04-07 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:48 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:48 --> URI Class Initialized
INFO - 2022-04-07 04:59:48 --> Router Class Initialized
INFO - 2022-04-07 04:59:48 --> Output Class Initialized
INFO - 2022-04-07 04:59:48 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:48 --> Input Class Initialized
INFO - 2022-04-07 04:59:48 --> Language Class Initialized
ERROR - 2022-04-07 04:59:48 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:59:48 --> Config Class Initialized
INFO - 2022-04-07 04:59:48 --> Hooks Class Initialized
INFO - 2022-04-07 04:59:48 --> Config Class Initialized
INFO - 2022-04-07 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:48 --> Utf8 Class Initialized
DEBUG - 2022-04-07 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:48 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:48 --> URI Class Initialized
INFO - 2022-04-07 04:59:48 --> URI Class Initialized
INFO - 2022-04-07 04:59:48 --> Router Class Initialized
INFO - 2022-04-07 04:59:48 --> Router Class Initialized
INFO - 2022-04-07 04:59:48 --> Output Class Initialized
INFO - 2022-04-07 04:59:48 --> Output Class Initialized
INFO - 2022-04-07 04:59:48 --> Security Class Initialized
INFO - 2022-04-07 04:59:48 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:48 --> Input Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:48 --> Language Class Initialized
INFO - 2022-04-07 04:59:48 --> Input Class Initialized
INFO - 2022-04-07 04:59:48 --> Language Class Initialized
ERROR - 2022-04-07 04:59:48 --> 404 Page Not Found: Fassets/css
ERROR - 2022-04-07 04:59:48 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 04:59:48 --> Config Class Initialized
INFO - 2022-04-07 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:48 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:48 --> URI Class Initialized
INFO - 2022-04-07 04:59:48 --> Router Class Initialized
INFO - 2022-04-07 04:59:48 --> Output Class Initialized
INFO - 2022-04-07 04:59:48 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:48 --> Input Class Initialized
INFO - 2022-04-07 04:59:48 --> Language Class Initialized
ERROR - 2022-04-07 04:59:48 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 04:59:49 --> Config Class Initialized
INFO - 2022-04-07 04:59:49 --> Hooks Class Initialized
DEBUG - 2022-04-07 04:59:49 --> UTF-8 Support Enabled
INFO - 2022-04-07 04:59:49 --> Utf8 Class Initialized
INFO - 2022-04-07 04:59:49 --> URI Class Initialized
INFO - 2022-04-07 04:59:49 --> Router Class Initialized
INFO - 2022-04-07 04:59:49 --> Output Class Initialized
INFO - 2022-04-07 04:59:49 --> Security Class Initialized
DEBUG - 2022-04-07 04:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 04:59:49 --> Input Class Initialized
INFO - 2022-04-07 04:59:49 --> Language Class Initialized
ERROR - 2022-04-07 04:59:49 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:16 --> Config Class Initialized
INFO - 2022-04-07 05:00:16 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:16 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:16 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:16 --> URI Class Initialized
INFO - 2022-04-07 05:00:16 --> Router Class Initialized
INFO - 2022-04-07 05:00:16 --> Output Class Initialized
INFO - 2022-04-07 05:00:16 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:16 --> Input Class Initialized
INFO - 2022-04-07 05:00:16 --> Language Class Initialized
INFO - 2022-04-07 05:00:16 --> Loader Class Initialized
INFO - 2022-04-07 05:00:16 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:16 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:16 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:16 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:16 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:16 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:16 --> Controller Class Initialized
INFO - 2022-04-07 05:00:16 --> Model Class Initialized
INFO - 2022-04-07 05:00:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-07 05:00:16 --> Config Class Initialized
INFO - 2022-04-07 05:00:16 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:16 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:16 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:16 --> URI Class Initialized
INFO - 2022-04-07 05:00:16 --> Router Class Initialized
INFO - 2022-04-07 05:00:16 --> Output Class Initialized
INFO - 2022-04-07 05:00:16 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:16 --> Input Class Initialized
INFO - 2022-04-07 05:00:16 --> Language Class Initialized
INFO - 2022-04-07 05:00:16 --> Loader Class Initialized
INFO - 2022-04-07 05:00:16 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:16 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:16 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:16 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:16 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:16 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:16 --> Controller Class Initialized
INFO - 2022-04-07 05:00:16 --> Model Class Initialized
INFO - 2022-04-07 05:00:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-07 05:00:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-07 05:00:16 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:16 --> Total execution time: 0.0555
INFO - 2022-04-07 05:00:16 --> Config Class Initialized
INFO - 2022-04-07 05:00:16 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:16 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:16 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:16 --> URI Class Initialized
INFO - 2022-04-07 05:00:16 --> Router Class Initialized
INFO - 2022-04-07 05:00:16 --> Output Class Initialized
INFO - 2022-04-07 05:00:16 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:17 --> Input Class Initialized
INFO - 2022-04-07 05:00:17 --> Language Class Initialized
ERROR - 2022-04-07 05:00:17 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-07 05:00:17 --> Config Class Initialized
INFO - 2022-04-07 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:17 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:17 --> URI Class Initialized
INFO - 2022-04-07 05:00:17 --> Router Class Initialized
INFO - 2022-04-07 05:00:17 --> Output Class Initialized
INFO - 2022-04-07 05:00:17 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:17 --> Input Class Initialized
INFO - 2022-04-07 05:00:17 --> Language Class Initialized
ERROR - 2022-04-07 05:00:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 05:00:17 --> Config Class Initialized
INFO - 2022-04-07 05:00:17 --> Hooks Class Initialized
INFO - 2022-04-07 05:00:17 --> Config Class Initialized
INFO - 2022-04-07 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:17 --> Utf8 Class Initialized
DEBUG - 2022-04-07 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:17 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:17 --> URI Class Initialized
INFO - 2022-04-07 05:00:17 --> URI Class Initialized
INFO - 2022-04-07 05:00:17 --> Router Class Initialized
INFO - 2022-04-07 05:00:17 --> Router Class Initialized
INFO - 2022-04-07 05:00:17 --> Output Class Initialized
INFO - 2022-04-07 05:00:17 --> Output Class Initialized
INFO - 2022-04-07 05:00:17 --> Security Class Initialized
INFO - 2022-04-07 05:00:17 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:17 --> Input Class Initialized
INFO - 2022-04-07 05:00:17 --> Language Class Initialized
ERROR - 2022-04-07 05:00:17 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:17 --> Input Class Initialized
INFO - 2022-04-07 05:00:17 --> Language Class Initialized
INFO - 2022-04-07 05:00:17 --> Config Class Initialized
INFO - 2022-04-07 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:17 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:17 --> URI Class Initialized
ERROR - 2022-04-07 05:00:17 --> 404 Page Not Found: Fassets/css
INFO - 2022-04-07 05:00:17 --> Router Class Initialized
INFO - 2022-04-07 05:00:17 --> Output Class Initialized
INFO - 2022-04-07 05:00:17 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:17 --> Input Class Initialized
INFO - 2022-04-07 05:00:17 --> Language Class Initialized
ERROR - 2022-04-07 05:00:17 --> 404 Page Not Found: Fassets/js
INFO - 2022-04-07 05:00:17 --> Config Class Initialized
INFO - 2022-04-07 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:17 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:17 --> URI Class Initialized
INFO - 2022-04-07 05:00:17 --> Router Class Initialized
INFO - 2022-04-07 05:00:17 --> Output Class Initialized
INFO - 2022-04-07 05:00:17 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:17 --> Input Class Initialized
INFO - 2022-04-07 05:00:17 --> Language Class Initialized
ERROR - 2022-04-07 05:00:17 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:34 --> Config Class Initialized
INFO - 2022-04-07 05:00:34 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:34 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:34 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:34 --> URI Class Initialized
INFO - 2022-04-07 05:00:34 --> Router Class Initialized
INFO - 2022-04-07 05:00:34 --> Output Class Initialized
INFO - 2022-04-07 05:00:34 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:34 --> Input Class Initialized
INFO - 2022-04-07 05:00:34 --> Language Class Initialized
INFO - 2022-04-07 05:00:34 --> Loader Class Initialized
INFO - 2022-04-07 05:00:34 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:34 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:34 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:34 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:34 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:34 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:34 --> Controller Class Initialized
INFO - 2022-04-07 05:00:34 --> Model Class Initialized
INFO - 2022-04-07 05:00:34 --> Model Class Initialized
INFO - 2022-04-07 05:00:34 --> Config Class Initialized
INFO - 2022-04-07 05:00:34 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:34 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:34 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:34 --> URI Class Initialized
INFO - 2022-04-07 05:00:34 --> Router Class Initialized
INFO - 2022-04-07 05:00:34 --> Output Class Initialized
INFO - 2022-04-07 05:00:34 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:34 --> Input Class Initialized
INFO - 2022-04-07 05:00:34 --> Language Class Initialized
INFO - 2022-04-07 05:00:35 --> Loader Class Initialized
INFO - 2022-04-07 05:00:35 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:35 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:35 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:35 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:35 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:35 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:35 --> Controller Class Initialized
INFO - 2022-04-07 05:00:35 --> Model Class Initialized
INFO - 2022-04-07 05:00:35 --> Model Class Initialized
INFO - 2022-04-07 05:00:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:35 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:35 --> Total execution time: 0.0924
INFO - 2022-04-07 05:00:35 --> Config Class Initialized
INFO - 2022-04-07 05:00:35 --> Hooks Class Initialized
INFO - 2022-04-07 05:00:35 --> Config Class Initialized
INFO - 2022-04-07 05:00:35 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:35 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:35 --> URI Class Initialized
DEBUG - 2022-04-07 05:00:35 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:35 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:35 --> URI Class Initialized
INFO - 2022-04-07 05:00:35 --> Router Class Initialized
INFO - 2022-04-07 05:00:35 --> Router Class Initialized
INFO - 2022-04-07 05:00:35 --> Output Class Initialized
INFO - 2022-04-07 05:00:35 --> Output Class Initialized
INFO - 2022-04-07 05:00:35 --> Security Class Initialized
INFO - 2022-04-07 05:00:35 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:35 --> Input Class Initialized
INFO - 2022-04-07 05:00:35 --> Language Class Initialized
DEBUG - 2022-04-07 05:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:35 --> Input Class Initialized
ERROR - 2022-04-07 05:00:35 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:35 --> Language Class Initialized
ERROR - 2022-04-07 05:00:35 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:36 --> Config Class Initialized
INFO - 2022-04-07 05:00:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:36 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:36 --> URI Class Initialized
INFO - 2022-04-07 05:00:36 --> Router Class Initialized
INFO - 2022-04-07 05:00:36 --> Output Class Initialized
INFO - 2022-04-07 05:00:36 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:36 --> Input Class Initialized
INFO - 2022-04-07 05:00:36 --> Language Class Initialized
INFO - 2022-04-07 05:00:36 --> Loader Class Initialized
INFO - 2022-04-07 05:00:36 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:36 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:36 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:36 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:36 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:36 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:36 --> Controller Class Initialized
INFO - 2022-04-07 05:00:36 --> Model Class Initialized
INFO - 2022-04-07 05:00:36 --> Config Class Initialized
INFO - 2022-04-07 05:00:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:36 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:36 --> URI Class Initialized
INFO - 2022-04-07 05:00:36 --> Router Class Initialized
INFO - 2022-04-07 05:00:36 --> Output Class Initialized
INFO - 2022-04-07 05:00:36 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:36 --> Input Class Initialized
INFO - 2022-04-07 05:00:36 --> Language Class Initialized
INFO - 2022-04-07 05:00:36 --> Loader Class Initialized
INFO - 2022-04-07 05:00:36 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:36 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:36 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:36 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:36 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:36 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:36 --> Controller Class Initialized
INFO - 2022-04-07 05:00:36 --> Model Class Initialized
INFO - 2022-04-07 05:00:36 --> Model Class Initialized
INFO - 2022-04-07 05:00:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:36 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:36 --> Total execution time: 0.0594
INFO - 2022-04-07 05:00:36 --> Config Class Initialized
INFO - 2022-04-07 05:00:36 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:36 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:36 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:36 --> URI Class Initialized
INFO - 2022-04-07 05:00:36 --> Router Class Initialized
INFO - 2022-04-07 05:00:36 --> Output Class Initialized
INFO - 2022-04-07 05:00:36 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:36 --> Input Class Initialized
INFO - 2022-04-07 05:00:36 --> Language Class Initialized
ERROR - 2022-04-07 05:00:36 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:37 --> Config Class Initialized
INFO - 2022-04-07 05:00:37 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:37 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:37 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:37 --> URI Class Initialized
INFO - 2022-04-07 05:00:37 --> Router Class Initialized
INFO - 2022-04-07 05:00:37 --> Output Class Initialized
INFO - 2022-04-07 05:00:37 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:37 --> Input Class Initialized
INFO - 2022-04-07 05:00:37 --> Language Class Initialized
ERROR - 2022-04-07 05:00:37 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:38 --> Config Class Initialized
INFO - 2022-04-07 05:00:38 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:38 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:38 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:38 --> URI Class Initialized
INFO - 2022-04-07 05:00:38 --> Router Class Initialized
INFO - 2022-04-07 05:00:38 --> Output Class Initialized
INFO - 2022-04-07 05:00:38 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:38 --> Input Class Initialized
INFO - 2022-04-07 05:00:38 --> Language Class Initialized
INFO - 2022-04-07 05:00:38 --> Loader Class Initialized
INFO - 2022-04-07 05:00:38 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:38 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:38 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:38 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:38 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:38 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:38 --> Controller Class Initialized
INFO - 2022-04-07 05:00:38 --> Model Class Initialized
INFO - 2022-04-07 05:00:38 --> Config Class Initialized
INFO - 2022-04-07 05:00:38 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:38 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:39 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:39 --> URI Class Initialized
INFO - 2022-04-07 05:00:39 --> Router Class Initialized
INFO - 2022-04-07 05:00:39 --> Output Class Initialized
INFO - 2022-04-07 05:00:39 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:39 --> Input Class Initialized
INFO - 2022-04-07 05:00:39 --> Language Class Initialized
INFO - 2022-04-07 05:00:39 --> Loader Class Initialized
INFO - 2022-04-07 05:00:39 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:39 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:39 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:39 --> Controller Class Initialized
INFO - 2022-04-07 05:00:39 --> Model Class Initialized
INFO - 2022-04-07 05:00:39 --> Model Class Initialized
INFO - 2022-04-07 05:00:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:39 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:39 --> Total execution time: 0.0697
INFO - 2022-04-07 05:00:39 --> Config Class Initialized
INFO - 2022-04-07 05:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:39 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:39 --> URI Class Initialized
INFO - 2022-04-07 05:00:39 --> Router Class Initialized
INFO - 2022-04-07 05:00:39 --> Output Class Initialized
INFO - 2022-04-07 05:00:39 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:39 --> Input Class Initialized
INFO - 2022-04-07 05:00:39 --> Language Class Initialized
ERROR - 2022-04-07 05:00:39 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:39 --> Config Class Initialized
INFO - 2022-04-07 05:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:39 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:39 --> URI Class Initialized
INFO - 2022-04-07 05:00:39 --> Router Class Initialized
INFO - 2022-04-07 05:00:39 --> Output Class Initialized
INFO - 2022-04-07 05:00:39 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:39 --> Input Class Initialized
INFO - 2022-04-07 05:00:39 --> Language Class Initialized
ERROR - 2022-04-07 05:00:39 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:39 --> Config Class Initialized
INFO - 2022-04-07 05:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:39 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:39 --> URI Class Initialized
INFO - 2022-04-07 05:00:39 --> Router Class Initialized
INFO - 2022-04-07 05:00:39 --> Output Class Initialized
INFO - 2022-04-07 05:00:39 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:39 --> Input Class Initialized
INFO - 2022-04-07 05:00:39 --> Language Class Initialized
INFO - 2022-04-07 05:00:39 --> Loader Class Initialized
INFO - 2022-04-07 05:00:39 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:39 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:39 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:39 --> Controller Class Initialized
INFO - 2022-04-07 05:00:39 --> Model Class Initialized
INFO - 2022-04-07 05:00:39 --> Config Class Initialized
INFO - 2022-04-07 05:00:39 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:39 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:39 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:39 --> URI Class Initialized
INFO - 2022-04-07 05:00:39 --> Router Class Initialized
INFO - 2022-04-07 05:00:39 --> Output Class Initialized
INFO - 2022-04-07 05:00:39 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:39 --> Input Class Initialized
INFO - 2022-04-07 05:00:39 --> Language Class Initialized
INFO - 2022-04-07 05:00:39 --> Loader Class Initialized
INFO - 2022-04-07 05:00:39 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:39 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:39 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:39 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:39 --> Controller Class Initialized
INFO - 2022-04-07 05:00:39 --> Model Class Initialized
INFO - 2022-04-07 05:00:39 --> Model Class Initialized
INFO - 2022-04-07 05:00:39 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:39 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:39 --> Total execution time: 0.0569
INFO - 2022-04-07 05:00:40 --> Config Class Initialized
INFO - 2022-04-07 05:00:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:40 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:40 --> URI Class Initialized
INFO - 2022-04-07 05:00:40 --> Router Class Initialized
INFO - 2022-04-07 05:00:40 --> Output Class Initialized
INFO - 2022-04-07 05:00:40 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:40 --> Input Class Initialized
INFO - 2022-04-07 05:00:40 --> Language Class Initialized
ERROR - 2022-04-07 05:00:40 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:40 --> Config Class Initialized
INFO - 2022-04-07 05:00:40 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:40 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:40 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:40 --> URI Class Initialized
INFO - 2022-04-07 05:00:40 --> Router Class Initialized
INFO - 2022-04-07 05:00:40 --> Output Class Initialized
INFO - 2022-04-07 05:00:40 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:40 --> Input Class Initialized
INFO - 2022-04-07 05:00:40 --> Language Class Initialized
ERROR - 2022-04-07 05:00:40 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:41 --> Config Class Initialized
INFO - 2022-04-07 05:00:41 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:41 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:41 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:41 --> URI Class Initialized
INFO - 2022-04-07 05:00:41 --> Router Class Initialized
INFO - 2022-04-07 05:00:41 --> Output Class Initialized
INFO - 2022-04-07 05:00:41 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:41 --> Input Class Initialized
INFO - 2022-04-07 05:00:41 --> Language Class Initialized
INFO - 2022-04-07 05:00:41 --> Loader Class Initialized
INFO - 2022-04-07 05:00:41 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:41 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:41 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:41 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:41 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:41 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:41 --> Controller Class Initialized
INFO - 2022-04-07 05:00:41 --> Model Class Initialized
INFO - 2022-04-07 05:00:41 --> Config Class Initialized
INFO - 2022-04-07 05:00:41 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:41 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:41 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:41 --> URI Class Initialized
INFO - 2022-04-07 05:00:41 --> Router Class Initialized
INFO - 2022-04-07 05:00:41 --> Output Class Initialized
INFO - 2022-04-07 05:00:41 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:41 --> Input Class Initialized
INFO - 2022-04-07 05:00:41 --> Language Class Initialized
INFO - 2022-04-07 05:00:41 --> Loader Class Initialized
INFO - 2022-04-07 05:00:41 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:41 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:41 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:41 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:41 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:41 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:41 --> Controller Class Initialized
INFO - 2022-04-07 05:00:41 --> Model Class Initialized
INFO - 2022-04-07 05:00:41 --> Model Class Initialized
INFO - 2022-04-07 05:00:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:41 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:41 --> Total execution time: 0.0661
INFO - 2022-04-07 05:00:43 --> Config Class Initialized
INFO - 2022-04-07 05:00:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:43 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:43 --> URI Class Initialized
INFO - 2022-04-07 05:00:43 --> Router Class Initialized
INFO - 2022-04-07 05:00:43 --> Output Class Initialized
INFO - 2022-04-07 05:00:43 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:43 --> Input Class Initialized
INFO - 2022-04-07 05:00:43 --> Language Class Initialized
INFO - 2022-04-07 05:00:43 --> Loader Class Initialized
INFO - 2022-04-07 05:00:43 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:43 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:43 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:43 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:43 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:43 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:43 --> Controller Class Initialized
INFO - 2022-04-07 05:00:43 --> Model Class Initialized
INFO - 2022-04-07 05:00:43 --> Config Class Initialized
INFO - 2022-04-07 05:00:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:43 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:43 --> URI Class Initialized
INFO - 2022-04-07 05:00:43 --> Router Class Initialized
INFO - 2022-04-07 05:00:43 --> Output Class Initialized
INFO - 2022-04-07 05:00:43 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:43 --> Input Class Initialized
INFO - 2022-04-07 05:00:43 --> Language Class Initialized
INFO - 2022-04-07 05:00:43 --> Loader Class Initialized
INFO - 2022-04-07 05:00:43 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:43 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:43 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:43 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:43 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:43 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:43 --> Controller Class Initialized
INFO - 2022-04-07 05:00:43 --> Model Class Initialized
INFO - 2022-04-07 05:00:43 --> Model Class Initialized
INFO - 2022-04-07 05:00:43 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:43 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:43 --> Total execution time: 0.0626
INFO - 2022-04-07 05:00:43 --> Config Class Initialized
INFO - 2022-04-07 05:00:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:43 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:43 --> URI Class Initialized
INFO - 2022-04-07 05:00:43 --> Router Class Initialized
INFO - 2022-04-07 05:00:43 --> Output Class Initialized
INFO - 2022-04-07 05:00:43 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:43 --> Input Class Initialized
INFO - 2022-04-07 05:00:43 --> Language Class Initialized
ERROR - 2022-04-07 05:00:43 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:43 --> Config Class Initialized
INFO - 2022-04-07 05:00:43 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:43 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:43 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:43 --> URI Class Initialized
INFO - 2022-04-07 05:00:43 --> Router Class Initialized
INFO - 2022-04-07 05:00:43 --> Output Class Initialized
INFO - 2022-04-07 05:00:43 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:43 --> Input Class Initialized
INFO - 2022-04-07 05:00:43 --> Language Class Initialized
ERROR - 2022-04-07 05:00:43 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:45 --> Config Class Initialized
INFO - 2022-04-07 05:00:45 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:45 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:45 --> URI Class Initialized
INFO - 2022-04-07 05:00:45 --> Router Class Initialized
INFO - 2022-04-07 05:00:45 --> Output Class Initialized
INFO - 2022-04-07 05:00:45 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:45 --> Input Class Initialized
INFO - 2022-04-07 05:00:45 --> Language Class Initialized
INFO - 2022-04-07 05:00:45 --> Loader Class Initialized
INFO - 2022-04-07 05:00:45 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:45 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:45 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:45 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:45 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:45 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:45 --> Controller Class Initialized
INFO - 2022-04-07 05:00:45 --> Model Class Initialized
INFO - 2022-04-07 05:00:45 --> Config Class Initialized
INFO - 2022-04-07 05:00:45 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:45 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:45 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:45 --> URI Class Initialized
INFO - 2022-04-07 05:00:45 --> Router Class Initialized
INFO - 2022-04-07 05:00:45 --> Output Class Initialized
INFO - 2022-04-07 05:00:45 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:45 --> Input Class Initialized
INFO - 2022-04-07 05:00:45 --> Language Class Initialized
INFO - 2022-04-07 05:00:45 --> Loader Class Initialized
INFO - 2022-04-07 05:00:45 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:45 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:45 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:45 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:45 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:45 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:45 --> Controller Class Initialized
INFO - 2022-04-07 05:00:45 --> Model Class Initialized
INFO - 2022-04-07 05:00:45 --> Model Class Initialized
INFO - 2022-04-07 05:00:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:45 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:45 --> Total execution time: 0.0718
INFO - 2022-04-07 05:00:46 --> Config Class Initialized
INFO - 2022-04-07 05:00:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:46 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:46 --> URI Class Initialized
INFO - 2022-04-07 05:00:46 --> Router Class Initialized
INFO - 2022-04-07 05:00:46 --> Output Class Initialized
INFO - 2022-04-07 05:00:46 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:46 --> Input Class Initialized
INFO - 2022-04-07 05:00:46 --> Language Class Initialized
ERROR - 2022-04-07 05:00:46 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:46 --> Config Class Initialized
INFO - 2022-04-07 05:00:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:46 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:46 --> URI Class Initialized
INFO - 2022-04-07 05:00:46 --> Router Class Initialized
INFO - 2022-04-07 05:00:46 --> Output Class Initialized
INFO - 2022-04-07 05:00:46 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:46 --> Input Class Initialized
INFO - 2022-04-07 05:00:46 --> Language Class Initialized
ERROR - 2022-04-07 05:00:46 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:46 --> Config Class Initialized
INFO - 2022-04-07 05:00:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:46 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:46 --> URI Class Initialized
INFO - 2022-04-07 05:00:46 --> Router Class Initialized
INFO - 2022-04-07 05:00:46 --> Output Class Initialized
INFO - 2022-04-07 05:00:46 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:46 --> Input Class Initialized
INFO - 2022-04-07 05:00:46 --> Language Class Initialized
INFO - 2022-04-07 05:00:46 --> Loader Class Initialized
INFO - 2022-04-07 05:00:46 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:46 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:46 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:46 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:46 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:46 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:46 --> Controller Class Initialized
INFO - 2022-04-07 05:00:46 --> Model Class Initialized
INFO - 2022-04-07 05:00:46 --> Config Class Initialized
INFO - 2022-04-07 05:00:46 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:46 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:46 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:46 --> URI Class Initialized
INFO - 2022-04-07 05:00:46 --> Router Class Initialized
INFO - 2022-04-07 05:00:46 --> Output Class Initialized
INFO - 2022-04-07 05:00:46 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:46 --> Input Class Initialized
INFO - 2022-04-07 05:00:46 --> Language Class Initialized
INFO - 2022-04-07 05:00:46 --> Loader Class Initialized
INFO - 2022-04-07 05:00:46 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:46 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:46 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:46 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:46 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:46 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:46 --> Controller Class Initialized
INFO - 2022-04-07 05:00:46 --> Model Class Initialized
INFO - 2022-04-07 05:00:46 --> Model Class Initialized
INFO - 2022-04-07 05:00:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:46 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:46 --> Total execution time: 0.0728
INFO - 2022-04-07 05:00:47 --> Config Class Initialized
INFO - 2022-04-07 05:00:47 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:47 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:47 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:47 --> URI Class Initialized
INFO - 2022-04-07 05:00:47 --> Router Class Initialized
INFO - 2022-04-07 05:00:47 --> Output Class Initialized
INFO - 2022-04-07 05:00:47 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:47 --> Input Class Initialized
INFO - 2022-04-07 05:00:47 --> Language Class Initialized
ERROR - 2022-04-07 05:00:47 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:47 --> Config Class Initialized
INFO - 2022-04-07 05:00:47 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:47 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:47 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:47 --> URI Class Initialized
INFO - 2022-04-07 05:00:47 --> Router Class Initialized
INFO - 2022-04-07 05:00:47 --> Output Class Initialized
INFO - 2022-04-07 05:00:47 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:47 --> Input Class Initialized
INFO - 2022-04-07 05:00:47 --> Language Class Initialized
ERROR - 2022-04-07 05:00:47 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:49 --> Config Class Initialized
INFO - 2022-04-07 05:00:49 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:49 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:49 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:49 --> URI Class Initialized
INFO - 2022-04-07 05:00:49 --> Router Class Initialized
INFO - 2022-04-07 05:00:49 --> Output Class Initialized
INFO - 2022-04-07 05:00:49 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:49 --> Input Class Initialized
INFO - 2022-04-07 05:00:49 --> Language Class Initialized
INFO - 2022-04-07 05:00:49 --> Loader Class Initialized
INFO - 2022-04-07 05:00:49 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:49 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:49 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:49 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:49 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:49 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:49 --> Controller Class Initialized
INFO - 2022-04-07 05:00:49 --> Model Class Initialized
INFO - 2022-04-07 05:00:49 --> Model Class Initialized
INFO - 2022-04-07 05:00:49 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:49 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:49 --> Total execution time: 0.0638
INFO - 2022-04-07 05:00:49 --> Config Class Initialized
INFO - 2022-04-07 05:00:49 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:49 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:49 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:49 --> URI Class Initialized
INFO - 2022-04-07 05:00:49 --> Router Class Initialized
INFO - 2022-04-07 05:00:49 --> Output Class Initialized
INFO - 2022-04-07 05:00:49 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:49 --> Input Class Initialized
INFO - 2022-04-07 05:00:49 --> Language Class Initialized
ERROR - 2022-04-07 05:00:49 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:49 --> Config Class Initialized
INFO - 2022-04-07 05:00:49 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:49 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:49 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:49 --> URI Class Initialized
INFO - 2022-04-07 05:00:49 --> Router Class Initialized
INFO - 2022-04-07 05:00:49 --> Output Class Initialized
INFO - 2022-04-07 05:00:49 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:49 --> Input Class Initialized
INFO - 2022-04-07 05:00:49 --> Language Class Initialized
ERROR - 2022-04-07 05:00:49 --> 404 Page Not Found: Vendor/bootstrap
INFO - 2022-04-07 05:00:54 --> Config Class Initialized
INFO - 2022-04-07 05:00:54 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:54 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:54 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:54 --> URI Class Initialized
DEBUG - 2022-04-07 05:00:54 --> No URI present. Default controller set.
INFO - 2022-04-07 05:00:54 --> Router Class Initialized
INFO - 2022-04-07 05:00:54 --> Output Class Initialized
INFO - 2022-04-07 05:00:54 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:54 --> Input Class Initialized
INFO - 2022-04-07 05:00:54 --> Language Class Initialized
INFO - 2022-04-07 05:00:54 --> Loader Class Initialized
INFO - 2022-04-07 05:00:54 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:54 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:54 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:54 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:54 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:54 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:54 --> Controller Class Initialized
INFO - 2022-04-07 05:00:54 --> Model Class Initialized
INFO - 2022-04-07 05:00:54 --> Model Class Initialized
INFO - 2022-04-07 05:00:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:54 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:54 --> Total execution time: 0.0632
INFO - 2022-04-07 05:00:57 --> Config Class Initialized
INFO - 2022-04-07 05:00:57 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:00:57 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:00:57 --> Utf8 Class Initialized
INFO - 2022-04-07 05:00:57 --> URI Class Initialized
DEBUG - 2022-04-07 05:00:57 --> No URI present. Default controller set.
INFO - 2022-04-07 05:00:57 --> Router Class Initialized
INFO - 2022-04-07 05:00:57 --> Output Class Initialized
INFO - 2022-04-07 05:00:57 --> Security Class Initialized
DEBUG - 2022-04-07 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:00:57 --> Input Class Initialized
INFO - 2022-04-07 05:00:57 --> Language Class Initialized
INFO - 2022-04-07 05:00:57 --> Loader Class Initialized
INFO - 2022-04-07 05:00:57 --> Helper loaded: url_helper
INFO - 2022-04-07 05:00:57 --> Helper loaded: form_helper
INFO - 2022-04-07 05:00:57 --> Helper loaded: common_helper
INFO - 2022-04-07 05:00:57 --> Helper loaded: util_helper
INFO - 2022-04-07 05:00:57 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:00:57 --> Form Validation Class Initialized
INFO - 2022-04-07 05:00:57 --> Controller Class Initialized
INFO - 2022-04-07 05:00:57 --> Model Class Initialized
INFO - 2022-04-07 05:00:57 --> Model Class Initialized
INFO - 2022-04-07 05:00:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:00:57 --> Final output sent to browser
DEBUG - 2022-04-07 05:00:57 --> Total execution time: 0.0799
INFO - 2022-04-07 05:01:01 --> Config Class Initialized
INFO - 2022-04-07 05:01:01 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:01 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:01 --> URI Class Initialized
INFO - 2022-04-07 05:01:01 --> Router Class Initialized
INFO - 2022-04-07 05:01:01 --> Output Class Initialized
INFO - 2022-04-07 05:01:01 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:01 --> Input Class Initialized
INFO - 2022-04-07 05:01:01 --> Language Class Initialized
INFO - 2022-04-07 05:01:01 --> Loader Class Initialized
INFO - 2022-04-07 05:01:01 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:01 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:01 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:01 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:01 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:01 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:01 --> Controller Class Initialized
INFO - 2022-04-07 05:01:01 --> Model Class Initialized
INFO - 2022-04-07 05:01:01 --> Model Class Initialized
INFO - 2022-04-07 05:01:01 --> Config Class Initialized
INFO - 2022-04-07 05:01:01 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:01 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:01 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:01 --> URI Class Initialized
INFO - 2022-04-07 05:01:01 --> Router Class Initialized
INFO - 2022-04-07 05:01:01 --> Output Class Initialized
INFO - 2022-04-07 05:01:01 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:01 --> Input Class Initialized
INFO - 2022-04-07 05:01:01 --> Language Class Initialized
INFO - 2022-04-07 05:01:01 --> Loader Class Initialized
INFO - 2022-04-07 05:01:01 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:01 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:01 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:01 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:01 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:01 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:01 --> Controller Class Initialized
INFO - 2022-04-07 05:01:01 --> Model Class Initialized
INFO - 2022-04-07 05:01:01 --> Model Class Initialized
INFO - 2022-04-07 05:01:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:01 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:01 --> Total execution time: 0.0739
INFO - 2022-04-07 05:01:02 --> Config Class Initialized
INFO - 2022-04-07 05:01:02 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:02 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:02 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:02 --> URI Class Initialized
DEBUG - 2022-04-07 05:01:02 --> No URI present. Default controller set.
INFO - 2022-04-07 05:01:02 --> Router Class Initialized
INFO - 2022-04-07 05:01:02 --> Output Class Initialized
INFO - 2022-04-07 05:01:02 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:02 --> Input Class Initialized
INFO - 2022-04-07 05:01:02 --> Language Class Initialized
INFO - 2022-04-07 05:01:02 --> Loader Class Initialized
INFO - 2022-04-07 05:01:02 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:02 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:02 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:02 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:02 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:02 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:02 --> Controller Class Initialized
INFO - 2022-04-07 05:01:02 --> Model Class Initialized
INFO - 2022-04-07 05:01:02 --> Model Class Initialized
INFO - 2022-04-07 05:01:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:02 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:02 --> Total execution time: 0.0858
INFO - 2022-04-07 05:01:03 --> Config Class Initialized
INFO - 2022-04-07 05:01:03 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:03 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:03 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:03 --> URI Class Initialized
INFO - 2022-04-07 05:01:03 --> Router Class Initialized
INFO - 2022-04-07 05:01:03 --> Output Class Initialized
INFO - 2022-04-07 05:01:03 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:03 --> Input Class Initialized
INFO - 2022-04-07 05:01:03 --> Language Class Initialized
INFO - 2022-04-07 05:01:03 --> Loader Class Initialized
INFO - 2022-04-07 05:01:03 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:03 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:03 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:03 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:03 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:03 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:03 --> Controller Class Initialized
INFO - 2022-04-07 05:01:03 --> Model Class Initialized
INFO - 2022-04-07 05:01:03 --> Config Class Initialized
INFO - 2022-04-07 05:01:03 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:03 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:03 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:03 --> URI Class Initialized
INFO - 2022-04-07 05:01:03 --> Router Class Initialized
INFO - 2022-04-07 05:01:03 --> Output Class Initialized
INFO - 2022-04-07 05:01:03 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:03 --> Input Class Initialized
INFO - 2022-04-07 05:01:03 --> Language Class Initialized
INFO - 2022-04-07 05:01:03 --> Loader Class Initialized
INFO - 2022-04-07 05:01:03 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:03 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:03 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:03 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:03 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:03 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:03 --> Controller Class Initialized
INFO - 2022-04-07 05:01:03 --> Model Class Initialized
INFO - 2022-04-07 05:01:03 --> Model Class Initialized
INFO - 2022-04-07 05:01:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:03 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:03 --> Total execution time: 0.0542
INFO - 2022-04-07 05:01:04 --> Config Class Initialized
INFO - 2022-04-07 05:01:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:04 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:04 --> URI Class Initialized
INFO - 2022-04-07 05:01:04 --> Router Class Initialized
INFO - 2022-04-07 05:01:04 --> Output Class Initialized
INFO - 2022-04-07 05:01:04 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:04 --> Input Class Initialized
INFO - 2022-04-07 05:01:04 --> Language Class Initialized
INFO - 2022-04-07 05:01:04 --> Loader Class Initialized
INFO - 2022-04-07 05:01:04 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:04 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:04 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:04 --> Controller Class Initialized
INFO - 2022-04-07 05:01:04 --> Model Class Initialized
INFO - 2022-04-07 05:01:04 --> Config Class Initialized
INFO - 2022-04-07 05:01:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:04 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:04 --> URI Class Initialized
INFO - 2022-04-07 05:01:04 --> Router Class Initialized
INFO - 2022-04-07 05:01:04 --> Output Class Initialized
INFO - 2022-04-07 05:01:04 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:04 --> Input Class Initialized
INFO - 2022-04-07 05:01:04 --> Language Class Initialized
INFO - 2022-04-07 05:01:04 --> Loader Class Initialized
INFO - 2022-04-07 05:01:04 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:04 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:04 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:04 --> Controller Class Initialized
INFO - 2022-04-07 05:01:04 --> Model Class Initialized
INFO - 2022-04-07 05:01:04 --> Model Class Initialized
INFO - 2022-04-07 05:01:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:04 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:04 --> Total execution time: 0.0663
INFO - 2022-04-07 05:01:04 --> Config Class Initialized
INFO - 2022-04-07 05:01:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:04 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:04 --> URI Class Initialized
INFO - 2022-04-07 05:01:04 --> Router Class Initialized
INFO - 2022-04-07 05:01:04 --> Output Class Initialized
INFO - 2022-04-07 05:01:04 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:04 --> Input Class Initialized
INFO - 2022-04-07 05:01:04 --> Language Class Initialized
INFO - 2022-04-07 05:01:04 --> Loader Class Initialized
INFO - 2022-04-07 05:01:04 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:04 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:04 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:04 --> Controller Class Initialized
INFO - 2022-04-07 05:01:04 --> Model Class Initialized
INFO - 2022-04-07 05:01:04 --> Config Class Initialized
INFO - 2022-04-07 05:01:04 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:04 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:04 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:04 --> URI Class Initialized
INFO - 2022-04-07 05:01:04 --> Router Class Initialized
INFO - 2022-04-07 05:01:04 --> Output Class Initialized
INFO - 2022-04-07 05:01:04 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:04 --> Input Class Initialized
INFO - 2022-04-07 05:01:04 --> Language Class Initialized
INFO - 2022-04-07 05:01:04 --> Loader Class Initialized
INFO - 2022-04-07 05:01:04 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:04 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:04 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:04 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:04 --> Controller Class Initialized
INFO - 2022-04-07 05:01:04 --> Model Class Initialized
INFO - 2022-04-07 05:01:04 --> Model Class Initialized
INFO - 2022-04-07 05:01:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:04 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:04 --> Total execution time: 0.0616
INFO - 2022-04-07 05:01:05 --> Config Class Initialized
INFO - 2022-04-07 05:01:05 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:05 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:05 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:05 --> URI Class Initialized
INFO - 2022-04-07 05:01:05 --> Router Class Initialized
INFO - 2022-04-07 05:01:05 --> Output Class Initialized
INFO - 2022-04-07 05:01:05 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:05 --> Input Class Initialized
INFO - 2022-04-07 05:01:05 --> Language Class Initialized
INFO - 2022-04-07 05:01:05 --> Loader Class Initialized
INFO - 2022-04-07 05:01:05 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:05 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:05 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:05 --> Controller Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:05 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:05 --> Total execution time: 0.0645
INFO - 2022-04-07 05:01:05 --> Config Class Initialized
INFO - 2022-04-07 05:01:05 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:05 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:05 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:05 --> URI Class Initialized
INFO - 2022-04-07 05:01:05 --> Router Class Initialized
INFO - 2022-04-07 05:01:05 --> Output Class Initialized
INFO - 2022-04-07 05:01:05 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:05 --> Input Class Initialized
INFO - 2022-04-07 05:01:05 --> Language Class Initialized
INFO - 2022-04-07 05:01:05 --> Loader Class Initialized
INFO - 2022-04-07 05:01:05 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:05 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:05 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:05 --> Controller Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> Config Class Initialized
INFO - 2022-04-07 05:01:05 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:05 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:05 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:05 --> URI Class Initialized
INFO - 2022-04-07 05:01:05 --> Router Class Initialized
INFO - 2022-04-07 05:01:05 --> Output Class Initialized
INFO - 2022-04-07 05:01:05 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:05 --> Input Class Initialized
INFO - 2022-04-07 05:01:05 --> Language Class Initialized
INFO - 2022-04-07 05:01:05 --> Loader Class Initialized
INFO - 2022-04-07 05:01:05 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:05 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:05 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:05 --> Controller Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:05 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:05 --> Total execution time: 0.0611
INFO - 2022-04-07 05:01:05 --> Config Class Initialized
INFO - 2022-04-07 05:01:05 --> Hooks Class Initialized
DEBUG - 2022-04-07 05:01:05 --> UTF-8 Support Enabled
INFO - 2022-04-07 05:01:05 --> Utf8 Class Initialized
INFO - 2022-04-07 05:01:05 --> URI Class Initialized
DEBUG - 2022-04-07 05:01:05 --> No URI present. Default controller set.
INFO - 2022-04-07 05:01:05 --> Router Class Initialized
INFO - 2022-04-07 05:01:05 --> Output Class Initialized
INFO - 2022-04-07 05:01:05 --> Security Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-07 05:01:05 --> Input Class Initialized
INFO - 2022-04-07 05:01:05 --> Language Class Initialized
INFO - 2022-04-07 05:01:05 --> Loader Class Initialized
INFO - 2022-04-07 05:01:05 --> Helper loaded: url_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: form_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: common_helper
INFO - 2022-04-07 05:01:05 --> Helper loaded: util_helper
INFO - 2022-04-07 05:01:05 --> Database Driver Class Initialized
DEBUG - 2022-04-07 05:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-07 05:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-07 05:01:05 --> Form Validation Class Initialized
INFO - 2022-04-07 05:01:05 --> Controller Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> Model Class Initialized
INFO - 2022-04-07 05:01:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-07 05:01:05 --> Final output sent to browser
DEBUG - 2022-04-07 05:01:05 --> Total execution time: 0.0564
