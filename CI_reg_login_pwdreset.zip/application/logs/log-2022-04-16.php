<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-16 15:15:37 --> Config Class Initialized
INFO - 2022-04-16 15:15:37 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:37 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:37 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:37 --> URI Class Initialized
DEBUG - 2022-04-16 15:15:37 --> No URI present. Default controller set.
INFO - 2022-04-16 15:15:37 --> Router Class Initialized
INFO - 2022-04-16 15:15:37 --> Output Class Initialized
INFO - 2022-04-16 15:15:37 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:37 --> Input Class Initialized
INFO - 2022-04-16 15:15:37 --> Language Class Initialized
INFO - 2022-04-16 15:15:38 --> Loader Class Initialized
INFO - 2022-04-16 15:15:38 --> Helper loaded: url_helper
INFO - 2022-04-16 15:15:38 --> Helper loaded: form_helper
INFO - 2022-04-16 15:15:38 --> Helper loaded: common_helper
INFO - 2022-04-16 15:15:38 --> Helper loaded: util_helper
INFO - 2022-04-16 15:15:38 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:15:38 --> Form Validation Class Initialized
INFO - 2022-04-16 15:15:38 --> Controller Class Initialized
INFO - 2022-04-16 15:15:38 --> Model Class Initialized
INFO - 2022-04-16 15:15:38 --> Model Class Initialized
INFO - 2022-04-16 15:15:38 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\_layout.php
INFO - 2022-04-16 15:15:38 --> Final output sent to browser
DEBUG - 2022-04-16 15:15:38 --> Total execution time: 0.8575
INFO - 2022-04-16 15:15:42 --> Config Class Initialized
INFO - 2022-04-16 15:15:42 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:42 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:42 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:42 --> URI Class Initialized
INFO - 2022-04-16 15:15:42 --> Router Class Initialized
INFO - 2022-04-16 15:15:42 --> Output Class Initialized
INFO - 2022-04-16 15:15:42 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:42 --> Input Class Initialized
INFO - 2022-04-16 15:15:42 --> Language Class Initialized
INFO - 2022-04-16 15:15:42 --> Loader Class Initialized
INFO - 2022-04-16 15:15:42 --> Helper loaded: url_helper
INFO - 2022-04-16 15:15:42 --> Helper loaded: form_helper
INFO - 2022-04-16 15:15:42 --> Helper loaded: common_helper
INFO - 2022-04-16 15:15:42 --> Helper loaded: util_helper
INFO - 2022-04-16 15:15:42 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:15:42 --> Form Validation Class Initialized
INFO - 2022-04-16 15:15:42 --> Controller Class Initialized
INFO - 2022-04-16 15:15:42 --> Model Class Initialized
INFO - 2022-04-16 15:15:42 --> Model Class Initialized
INFO - 2022-04-16 15:15:42 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\login.php
INFO - 2022-04-16 15:15:42 --> Final output sent to browser
DEBUG - 2022-04-16 15:15:42 --> Total execution time: 0.0843
INFO - 2022-04-16 15:15:43 --> Config Class Initialized
INFO - 2022-04-16 15:15:43 --> Hooks Class Initialized
INFO - 2022-04-16 15:15:43 --> Config Class Initialized
INFO - 2022-04-16 15:15:43 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:43 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:43 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:43 --> URI Class Initialized
DEBUG - 2022-04-16 15:15:43 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:43 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:43 --> URI Class Initialized
INFO - 2022-04-16 15:15:43 --> Router Class Initialized
INFO - 2022-04-16 15:15:43 --> Router Class Initialized
INFO - 2022-04-16 15:15:43 --> Output Class Initialized
INFO - 2022-04-16 15:15:43 --> Output Class Initialized
INFO - 2022-04-16 15:15:43 --> Security Class Initialized
INFO - 2022-04-16 15:15:43 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:43 --> Input Class Initialized
DEBUG - 2022-04-16 15:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:43 --> Input Class Initialized
INFO - 2022-04-16 15:15:43 --> Language Class Initialized
INFO - 2022-04-16 15:15:43 --> Language Class Initialized
ERROR - 2022-04-16 15:15:43 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-16 15:15:43 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-16 15:15:43 --> Config Class Initialized
INFO - 2022-04-16 15:15:43 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:43 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:43 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:43 --> URI Class Initialized
INFO - 2022-04-16 15:15:43 --> Router Class Initialized
INFO - 2022-04-16 15:15:43 --> Output Class Initialized
INFO - 2022-04-16 15:15:43 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:43 --> Input Class Initialized
INFO - 2022-04-16 15:15:43 --> Language Class Initialized
ERROR - 2022-04-16 15:15:43 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-16 15:15:46 --> Config Class Initialized
INFO - 2022-04-16 15:15:46 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:46 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:46 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:46 --> URI Class Initialized
INFO - 2022-04-16 15:15:46 --> Router Class Initialized
INFO - 2022-04-16 15:15:46 --> Output Class Initialized
INFO - 2022-04-16 15:15:46 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:46 --> Input Class Initialized
INFO - 2022-04-16 15:15:46 --> Language Class Initialized
INFO - 2022-04-16 15:15:46 --> Loader Class Initialized
INFO - 2022-04-16 15:15:46 --> Helper loaded: url_helper
INFO - 2022-04-16 15:15:46 --> Helper loaded: form_helper
INFO - 2022-04-16 15:15:46 --> Helper loaded: common_helper
INFO - 2022-04-16 15:15:46 --> Helper loaded: util_helper
INFO - 2022-04-16 15:15:46 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:15:46 --> Form Validation Class Initialized
INFO - 2022-04-16 15:15:46 --> Controller Class Initialized
INFO - 2022-04-16 15:15:46 --> Model Class Initialized
INFO - 2022-04-16 15:15:46 --> Model Class Initialized
INFO - 2022-04-16 15:15:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-16 15:15:46 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\login.php
INFO - 2022-04-16 15:15:46 --> Final output sent to browser
DEBUG - 2022-04-16 15:15:46 --> Total execution time: 0.0913
INFO - 2022-04-16 15:15:46 --> Config Class Initialized
INFO - 2022-04-16 15:15:46 --> Hooks Class Initialized
INFO - 2022-04-16 15:15:46 --> Config Class Initialized
INFO - 2022-04-16 15:15:46 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-16 15:15:46 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:46 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:46 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:46 --> URI Class Initialized
INFO - 2022-04-16 15:15:46 --> URI Class Initialized
INFO - 2022-04-16 15:15:46 --> Router Class Initialized
INFO - 2022-04-16 15:15:46 --> Router Class Initialized
INFO - 2022-04-16 15:15:46 --> Output Class Initialized
INFO - 2022-04-16 15:15:46 --> Output Class Initialized
INFO - 2022-04-16 15:15:46 --> Security Class Initialized
INFO - 2022-04-16 15:15:46 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:46 --> Input Class Initialized
INFO - 2022-04-16 15:15:46 --> Language Class Initialized
DEBUG - 2022-04-16 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:46 --> Input Class Initialized
INFO - 2022-04-16 15:15:46 --> Language Class Initialized
ERROR - 2022-04-16 15:15:46 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-16 15:15:46 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-16 15:15:56 --> Config Class Initialized
INFO - 2022-04-16 15:15:56 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:56 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:56 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:56 --> URI Class Initialized
INFO - 2022-04-16 15:15:56 --> Router Class Initialized
INFO - 2022-04-16 15:15:56 --> Output Class Initialized
INFO - 2022-04-16 15:15:56 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:56 --> Input Class Initialized
INFO - 2022-04-16 15:15:56 --> Language Class Initialized
INFO - 2022-04-16 15:15:56 --> Loader Class Initialized
INFO - 2022-04-16 15:15:56 --> Helper loaded: url_helper
INFO - 2022-04-16 15:15:56 --> Helper loaded: form_helper
INFO - 2022-04-16 15:15:56 --> Helper loaded: common_helper
INFO - 2022-04-16 15:15:56 --> Helper loaded: util_helper
INFO - 2022-04-16 15:15:56 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:15:56 --> Form Validation Class Initialized
INFO - 2022-04-16 15:15:56 --> Controller Class Initialized
INFO - 2022-04-16 15:15:56 --> Model Class Initialized
INFO - 2022-04-16 15:15:56 --> Model Class Initialized
INFO - 2022-04-16 15:15:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-16 15:15:56 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\login.php
INFO - 2022-04-16 15:15:56 --> Final output sent to browser
DEBUG - 2022-04-16 15:15:56 --> Total execution time: 0.0668
INFO - 2022-04-16 15:15:56 --> Config Class Initialized
INFO - 2022-04-16 15:15:56 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:15:56 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:15:56 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:56 --> URI Class Initialized
INFO - 2022-04-16 15:15:56 --> Router Class Initialized
INFO - 2022-04-16 15:15:56 --> Config Class Initialized
INFO - 2022-04-16 15:15:56 --> Hooks Class Initialized
INFO - 2022-04-16 15:15:56 --> Output Class Initialized
INFO - 2022-04-16 15:15:56 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-16 15:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:56 --> Utf8 Class Initialized
INFO - 2022-04-16 15:15:56 --> Input Class Initialized
INFO - 2022-04-16 15:15:56 --> Language Class Initialized
INFO - 2022-04-16 15:15:56 --> URI Class Initialized
ERROR - 2022-04-16 15:15:56 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-16 15:15:56 --> Router Class Initialized
INFO - 2022-04-16 15:15:56 --> Output Class Initialized
INFO - 2022-04-16 15:15:56 --> Security Class Initialized
DEBUG - 2022-04-16 15:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:15:56 --> Input Class Initialized
INFO - 2022-04-16 15:15:56 --> Language Class Initialized
ERROR - 2022-04-16 15:15:56 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-16 15:16:19 --> Config Class Initialized
INFO - 2022-04-16 15:16:19 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:19 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:19 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:19 --> URI Class Initialized
INFO - 2022-04-16 15:16:19 --> Router Class Initialized
INFO - 2022-04-16 15:16:19 --> Output Class Initialized
INFO - 2022-04-16 15:16:19 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:19 --> Input Class Initialized
INFO - 2022-04-16 15:16:19 --> Language Class Initialized
INFO - 2022-04-16 15:16:19 --> Loader Class Initialized
INFO - 2022-04-16 15:16:19 --> Helper loaded: url_helper
INFO - 2022-04-16 15:16:19 --> Helper loaded: form_helper
INFO - 2022-04-16 15:16:19 --> Helper loaded: common_helper
INFO - 2022-04-16 15:16:19 --> Helper loaded: util_helper
INFO - 2022-04-16 15:16:19 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:16:19 --> Form Validation Class Initialized
INFO - 2022-04-16 15:16:19 --> Controller Class Initialized
INFO - 2022-04-16 15:16:19 --> Model Class Initialized
INFO - 2022-04-16 15:16:19 --> Model Class Initialized
INFO - 2022-04-16 15:16:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-16 15:16:19 --> Config Class Initialized
INFO - 2022-04-16 15:16:19 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:19 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:19 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:19 --> URI Class Initialized
INFO - 2022-04-16 15:16:19 --> Router Class Initialized
INFO - 2022-04-16 15:16:19 --> Output Class Initialized
INFO - 2022-04-16 15:16:19 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:19 --> Input Class Initialized
INFO - 2022-04-16 15:16:19 --> Language Class Initialized
INFO - 2022-04-16 15:16:19 --> Loader Class Initialized
INFO - 2022-04-16 15:16:19 --> Helper loaded: url_helper
INFO - 2022-04-16 15:16:19 --> Helper loaded: form_helper
INFO - 2022-04-16 15:16:19 --> Helper loaded: common_helper
INFO - 2022-04-16 15:16:19 --> Helper loaded: util_helper
INFO - 2022-04-16 15:16:19 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:16:19 --> Form Validation Class Initialized
INFO - 2022-04-16 15:16:19 --> Controller Class Initialized
INFO - 2022-04-16 15:16:19 --> Model Class Initialized
INFO - 2022-04-16 15:16:20 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/dashboard.php
INFO - 2022-04-16 15:16:20 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:16:20 --> Final output sent to browser
DEBUG - 2022-04-16 15:16:20 --> Total execution time: 0.1620
INFO - 2022-04-16 15:16:20 --> Config Class Initialized
INFO - 2022-04-16 15:16:20 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:20 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:20 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:20 --> URI Class Initialized
INFO - 2022-04-16 15:16:20 --> Router Class Initialized
INFO - 2022-04-16 15:16:20 --> Output Class Initialized
INFO - 2022-04-16 15:16:20 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:20 --> Input Class Initialized
INFO - 2022-04-16 15:16:20 --> Language Class Initialized
ERROR - 2022-04-16 15:16:20 --> 404 Page Not Found: provider/Js/front.js
INFO - 2022-04-16 15:16:32 --> Config Class Initialized
INFO - 2022-04-16 15:16:32 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:32 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:32 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:32 --> URI Class Initialized
INFO - 2022-04-16 15:16:32 --> Router Class Initialized
INFO - 2022-04-16 15:16:32 --> Output Class Initialized
INFO - 2022-04-16 15:16:32 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:32 --> Input Class Initialized
INFO - 2022-04-16 15:16:32 --> Language Class Initialized
INFO - 2022-04-16 15:16:32 --> Loader Class Initialized
INFO - 2022-04-16 15:16:32 --> Helper loaded: url_helper
INFO - 2022-04-16 15:16:32 --> Helper loaded: form_helper
INFO - 2022-04-16 15:16:32 --> Helper loaded: common_helper
INFO - 2022-04-16 15:16:32 --> Helper loaded: util_helper
INFO - 2022-04-16 15:16:32 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:16:32 --> Form Validation Class Initialized
INFO - 2022-04-16 15:16:32 --> Controller Class Initialized
INFO - 2022-04-16 15:16:32 --> Model Class Initialized
INFO - 2022-04-16 15:16:32 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/changepassword.php
INFO - 2022-04-16 15:16:32 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:16:32 --> Final output sent to browser
DEBUG - 2022-04-16 15:16:32 --> Total execution time: 0.1049
INFO - 2022-04-16 15:16:32 --> Config Class Initialized
INFO - 2022-04-16 15:16:32 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:32 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:32 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:32 --> URI Class Initialized
INFO - 2022-04-16 15:16:32 --> Router Class Initialized
INFO - 2022-04-16 15:16:32 --> Output Class Initialized
INFO - 2022-04-16 15:16:32 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:32 --> Input Class Initialized
INFO - 2022-04-16 15:16:32 --> Language Class Initialized
ERROR - 2022-04-16 15:16:32 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-16 15:16:55 --> Config Class Initialized
INFO - 2022-04-16 15:16:55 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:55 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:55 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:55 --> URI Class Initialized
INFO - 2022-04-16 15:16:55 --> Router Class Initialized
INFO - 2022-04-16 15:16:55 --> Output Class Initialized
INFO - 2022-04-16 15:16:55 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:55 --> Input Class Initialized
INFO - 2022-04-16 15:16:55 --> Language Class Initialized
INFO - 2022-04-16 15:16:55 --> Loader Class Initialized
INFO - 2022-04-16 15:16:55 --> Helper loaded: url_helper
INFO - 2022-04-16 15:16:55 --> Helper loaded: form_helper
INFO - 2022-04-16 15:16:55 --> Helper loaded: common_helper
INFO - 2022-04-16 15:16:55 --> Helper loaded: util_helper
INFO - 2022-04-16 15:16:55 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:16:55 --> Form Validation Class Initialized
INFO - 2022-04-16 15:16:55 --> Controller Class Initialized
INFO - 2022-04-16 15:16:55 --> Model Class Initialized
INFO - 2022-04-16 15:16:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-16 15:16:55 --> Config Class Initialized
INFO - 2022-04-16 15:16:55 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:55 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:55 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:55 --> URI Class Initialized
INFO - 2022-04-16 15:16:55 --> Router Class Initialized
INFO - 2022-04-16 15:16:55 --> Output Class Initialized
INFO - 2022-04-16 15:16:55 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:55 --> Input Class Initialized
INFO - 2022-04-16 15:16:55 --> Language Class Initialized
INFO - 2022-04-16 15:16:55 --> Loader Class Initialized
INFO - 2022-04-16 15:16:55 --> Helper loaded: url_helper
INFO - 2022-04-16 15:16:55 --> Helper loaded: form_helper
INFO - 2022-04-16 15:16:55 --> Helper loaded: common_helper
INFO - 2022-04-16 15:16:55 --> Helper loaded: util_helper
INFO - 2022-04-16 15:16:55 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:16:55 --> Form Validation Class Initialized
INFO - 2022-04-16 15:16:55 --> Controller Class Initialized
INFO - 2022-04-16 15:16:55 --> Model Class Initialized
INFO - 2022-04-16 15:16:55 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/changepassword.php
INFO - 2022-04-16 15:16:55 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:16:55 --> Final output sent to browser
DEBUG - 2022-04-16 15:16:55 --> Total execution time: 0.0638
INFO - 2022-04-16 15:16:55 --> Config Class Initialized
INFO - 2022-04-16 15:16:55 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:16:55 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:16:55 --> Utf8 Class Initialized
INFO - 2022-04-16 15:16:55 --> URI Class Initialized
INFO - 2022-04-16 15:16:55 --> Router Class Initialized
INFO - 2022-04-16 15:16:55 --> Output Class Initialized
INFO - 2022-04-16 15:16:55 --> Security Class Initialized
DEBUG - 2022-04-16 15:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:16:55 --> Input Class Initialized
INFO - 2022-04-16 15:16:55 --> Language Class Initialized
ERROR - 2022-04-16 15:16:55 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-16 15:17:01 --> Config Class Initialized
INFO - 2022-04-16 15:17:01 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:01 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:01 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:01 --> URI Class Initialized
INFO - 2022-04-16 15:17:01 --> Router Class Initialized
INFO - 2022-04-16 15:17:01 --> Output Class Initialized
INFO - 2022-04-16 15:17:01 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:01 --> Input Class Initialized
INFO - 2022-04-16 15:17:01 --> Language Class Initialized
INFO - 2022-04-16 15:17:01 --> Loader Class Initialized
INFO - 2022-04-16 15:17:01 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:01 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:01 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:01 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:01 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:01 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:01 --> Controller Class Initialized
INFO - 2022-04-16 15:17:01 --> Model Class Initialized
INFO - 2022-04-16 15:17:01 --> Model Class Initialized
INFO - 2022-04-16 15:17:01 --> Config Class Initialized
INFO - 2022-04-16 15:17:01 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:01 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:01 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:01 --> URI Class Initialized
INFO - 2022-04-16 15:17:01 --> Router Class Initialized
INFO - 2022-04-16 15:17:01 --> Output Class Initialized
INFO - 2022-04-16 15:17:01 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:01 --> Input Class Initialized
INFO - 2022-04-16 15:17:01 --> Language Class Initialized
INFO - 2022-04-16 15:17:01 --> Loader Class Initialized
INFO - 2022-04-16 15:17:01 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:01 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:01 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:01 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:01 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:01 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:01 --> Controller Class Initialized
INFO - 2022-04-16 15:17:01 --> Model Class Initialized
INFO - 2022-04-16 15:17:01 --> Model Class Initialized
INFO - 2022-04-16 15:17:01 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\_layout.php
INFO - 2022-04-16 15:17:01 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:01 --> Total execution time: 0.0867
INFO - 2022-04-16 15:17:04 --> Config Class Initialized
INFO - 2022-04-16 15:17:04 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:04 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:04 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:04 --> URI Class Initialized
INFO - 2022-04-16 15:17:04 --> Router Class Initialized
INFO - 2022-04-16 15:17:04 --> Output Class Initialized
INFO - 2022-04-16 15:17:04 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:04 --> Input Class Initialized
INFO - 2022-04-16 15:17:04 --> Language Class Initialized
INFO - 2022-04-16 15:17:04 --> Loader Class Initialized
INFO - 2022-04-16 15:17:04 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:04 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:04 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:04 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:04 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:04 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:04 --> Controller Class Initialized
INFO - 2022-04-16 15:17:04 --> Model Class Initialized
INFO - 2022-04-16 15:17:04 --> Config Class Initialized
INFO - 2022-04-16 15:17:04 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:04 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:04 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:04 --> URI Class Initialized
INFO - 2022-04-16 15:17:04 --> Router Class Initialized
INFO - 2022-04-16 15:17:04 --> Output Class Initialized
INFO - 2022-04-16 15:17:04 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:04 --> Input Class Initialized
INFO - 2022-04-16 15:17:04 --> Language Class Initialized
INFO - 2022-04-16 15:17:04 --> Loader Class Initialized
INFO - 2022-04-16 15:17:04 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:04 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:04 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:04 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:04 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:04 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:04 --> Controller Class Initialized
INFO - 2022-04-16 15:17:04 --> Model Class Initialized
INFO - 2022-04-16 15:17:04 --> Model Class Initialized
INFO - 2022-04-16 15:17:04 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\_layout.php
INFO - 2022-04-16 15:17:04 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:04 --> Total execution time: 0.0797
INFO - 2022-04-16 15:17:05 --> Config Class Initialized
INFO - 2022-04-16 15:17:05 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:05 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:05 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:05 --> URI Class Initialized
INFO - 2022-04-16 15:17:05 --> Router Class Initialized
INFO - 2022-04-16 15:17:05 --> Output Class Initialized
INFO - 2022-04-16 15:17:05 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:05 --> Input Class Initialized
INFO - 2022-04-16 15:17:05 --> Language Class Initialized
INFO - 2022-04-16 15:17:05 --> Loader Class Initialized
INFO - 2022-04-16 15:17:05 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:05 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:05 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:05 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:05 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:05 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:05 --> Controller Class Initialized
INFO - 2022-04-16 15:17:05 --> Model Class Initialized
INFO - 2022-04-16 15:17:05 --> Config Class Initialized
INFO - 2022-04-16 15:17:05 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:05 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:05 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:05 --> URI Class Initialized
INFO - 2022-04-16 15:17:05 --> Router Class Initialized
INFO - 2022-04-16 15:17:05 --> Output Class Initialized
INFO - 2022-04-16 15:17:05 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:05 --> Input Class Initialized
INFO - 2022-04-16 15:17:05 --> Language Class Initialized
INFO - 2022-04-16 15:17:05 --> Loader Class Initialized
INFO - 2022-04-16 15:17:05 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:05 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:05 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:05 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:05 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:05 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:05 --> Controller Class Initialized
INFO - 2022-04-16 15:17:05 --> Model Class Initialized
INFO - 2022-04-16 15:17:05 --> Model Class Initialized
INFO - 2022-04-16 15:17:05 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\_layout.php
INFO - 2022-04-16 15:17:05 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:05 --> Total execution time: 0.0755
INFO - 2022-04-16 15:17:07 --> Config Class Initialized
INFO - 2022-04-16 15:17:07 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:07 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:07 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:07 --> URI Class Initialized
INFO - 2022-04-16 15:17:07 --> Router Class Initialized
INFO - 2022-04-16 15:17:07 --> Output Class Initialized
INFO - 2022-04-16 15:17:07 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:07 --> Input Class Initialized
INFO - 2022-04-16 15:17:07 --> Language Class Initialized
INFO - 2022-04-16 15:17:07 --> Loader Class Initialized
INFO - 2022-04-16 15:17:07 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:07 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:07 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:07 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:07 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:07 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:07 --> Controller Class Initialized
INFO - 2022-04-16 15:17:07 --> Model Class Initialized
INFO - 2022-04-16 15:17:07 --> Config Class Initialized
INFO - 2022-04-16 15:17:07 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:07 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:07 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:07 --> URI Class Initialized
INFO - 2022-04-16 15:17:07 --> Router Class Initialized
INFO - 2022-04-16 15:17:07 --> Output Class Initialized
INFO - 2022-04-16 15:17:07 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:07 --> Input Class Initialized
INFO - 2022-04-16 15:17:07 --> Language Class Initialized
INFO - 2022-04-16 15:17:07 --> Loader Class Initialized
INFO - 2022-04-16 15:17:07 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:07 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:07 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:07 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:07 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:07 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:07 --> Controller Class Initialized
INFO - 2022-04-16 15:17:07 --> Model Class Initialized
INFO - 2022-04-16 15:17:07 --> Model Class Initialized
INFO - 2022-04-16 15:17:07 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\_layout.php
INFO - 2022-04-16 15:17:07 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:07 --> Total execution time: 0.0770
INFO - 2022-04-16 15:17:09 --> Config Class Initialized
INFO - 2022-04-16 15:17:09 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:09 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:09 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:09 --> URI Class Initialized
INFO - 2022-04-16 15:17:09 --> Router Class Initialized
INFO - 2022-04-16 15:17:09 --> Output Class Initialized
INFO - 2022-04-16 15:17:09 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:09 --> Input Class Initialized
INFO - 2022-04-16 15:17:09 --> Language Class Initialized
INFO - 2022-04-16 15:17:09 --> Loader Class Initialized
INFO - 2022-04-16 15:17:09 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:09 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:09 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:09 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:09 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:09 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:09 --> Controller Class Initialized
INFO - 2022-04-16 15:17:09 --> Model Class Initialized
INFO - 2022-04-16 15:17:09 --> Model Class Initialized
INFO - 2022-04-16 15:17:09 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\login.php
INFO - 2022-04-16 15:17:09 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:09 --> Total execution time: 0.0650
INFO - 2022-04-16 15:17:18 --> Config Class Initialized
INFO - 2022-04-16 15:17:18 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:18 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:18 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:18 --> URI Class Initialized
INFO - 2022-04-16 15:17:18 --> Router Class Initialized
INFO - 2022-04-16 15:17:18 --> Output Class Initialized
INFO - 2022-04-16 15:17:18 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:18 --> Input Class Initialized
INFO - 2022-04-16 15:17:18 --> Language Class Initialized
INFO - 2022-04-16 15:17:18 --> Loader Class Initialized
INFO - 2022-04-16 15:17:18 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:18 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:18 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:18 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:18 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:18 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:18 --> Controller Class Initialized
INFO - 2022-04-16 15:17:18 --> Model Class Initialized
INFO - 2022-04-16 15:17:18 --> Model Class Initialized
INFO - 2022-04-16 15:17:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-16 15:17:18 --> Config Class Initialized
INFO - 2022-04-16 15:17:18 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:18 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:18 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:18 --> URI Class Initialized
INFO - 2022-04-16 15:17:18 --> Router Class Initialized
INFO - 2022-04-16 15:17:18 --> Output Class Initialized
INFO - 2022-04-16 15:17:18 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:18 --> Input Class Initialized
INFO - 2022-04-16 15:17:18 --> Language Class Initialized
INFO - 2022-04-16 15:17:18 --> Loader Class Initialized
INFO - 2022-04-16 15:17:18 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:18 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:18 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:18 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:18 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:18 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:18 --> Controller Class Initialized
INFO - 2022-04-16 15:17:18 --> Model Class Initialized
INFO - 2022-04-16 15:17:18 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/dashboard.php
INFO - 2022-04-16 15:17:18 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:17:18 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:18 --> Total execution time: 0.0768
INFO - 2022-04-16 15:17:18 --> Config Class Initialized
INFO - 2022-04-16 15:17:18 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:18 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:18 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:18 --> URI Class Initialized
INFO - 2022-04-16 15:17:18 --> Router Class Initialized
INFO - 2022-04-16 15:17:18 --> Output Class Initialized
INFO - 2022-04-16 15:17:18 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:18 --> Input Class Initialized
INFO - 2022-04-16 15:17:18 --> Language Class Initialized
ERROR - 2022-04-16 15:17:18 --> 404 Page Not Found: provider/Js/front.js
INFO - 2022-04-16 15:17:29 --> Config Class Initialized
INFO - 2022-04-16 15:17:29 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:29 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:29 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:29 --> URI Class Initialized
INFO - 2022-04-16 15:17:29 --> Router Class Initialized
INFO - 2022-04-16 15:17:29 --> Output Class Initialized
INFO - 2022-04-16 15:17:29 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:29 --> Input Class Initialized
INFO - 2022-04-16 15:17:29 --> Language Class Initialized
INFO - 2022-04-16 15:17:29 --> Loader Class Initialized
INFO - 2022-04-16 15:17:29 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:29 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:29 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:29 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:29 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:29 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:29 --> Controller Class Initialized
INFO - 2022-04-16 15:17:29 --> Model Class Initialized
INFO - 2022-04-16 15:17:29 --> Model Class Initialized
INFO - 2022-04-16 15:17:29 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\admin/cms/list.php
INFO - 2022-04-16 15:17:29 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:17:29 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:29 --> Total execution time: 0.1740
INFO - 2022-04-16 15:17:29 --> Config Class Initialized
INFO - 2022-04-16 15:17:29 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:29 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:29 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:29 --> URI Class Initialized
INFO - 2022-04-16 15:17:29 --> Router Class Initialized
INFO - 2022-04-16 15:17:29 --> Output Class Initialized
INFO - 2022-04-16 15:17:29 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:29 --> Input Class Initialized
INFO - 2022-04-16 15:17:29 --> Language Class Initialized
ERROR - 2022-04-16 15:17:29 --> 404 Page Not Found: administrator/Cms/js
INFO - 2022-04-16 15:17:37 --> Config Class Initialized
INFO - 2022-04-16 15:17:37 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:37 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:37 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:37 --> URI Class Initialized
INFO - 2022-04-16 15:17:37 --> Router Class Initialized
INFO - 2022-04-16 15:17:37 --> Output Class Initialized
INFO - 2022-04-16 15:17:37 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:37 --> Input Class Initialized
INFO - 2022-04-16 15:17:37 --> Language Class Initialized
INFO - 2022-04-16 15:17:37 --> Loader Class Initialized
INFO - 2022-04-16 15:17:37 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:37 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:37 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:37 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:37 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:37 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:37 --> Controller Class Initialized
INFO - 2022-04-16 15:17:37 --> Model Class Initialized
INFO - 2022-04-16 15:17:37 --> Model Class Initialized
INFO - 2022-04-16 15:17:37 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\admin/cms/add.php
INFO - 2022-04-16 15:17:37 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:17:37 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:37 --> Total execution time: 0.0810
INFO - 2022-04-16 15:17:37 --> Config Class Initialized
INFO - 2022-04-16 15:17:37 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:37 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:37 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:37 --> URI Class Initialized
INFO - 2022-04-16 15:17:37 --> Router Class Initialized
INFO - 2022-04-16 15:17:37 --> Output Class Initialized
INFO - 2022-04-16 15:17:37 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:37 --> Input Class Initialized
INFO - 2022-04-16 15:17:37 --> Language Class Initialized
ERROR - 2022-04-16 15:17:37 --> 404 Page Not Found: administrator/Cms/js
INFO - 2022-04-16 15:17:48 --> Config Class Initialized
INFO - 2022-04-16 15:17:48 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:48 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:48 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:48 --> URI Class Initialized
INFO - 2022-04-16 15:17:48 --> Router Class Initialized
INFO - 2022-04-16 15:17:48 --> Output Class Initialized
INFO - 2022-04-16 15:17:48 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:48 --> Input Class Initialized
INFO - 2022-04-16 15:17:48 --> Language Class Initialized
INFO - 2022-04-16 15:17:48 --> Loader Class Initialized
INFO - 2022-04-16 15:17:48 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:48 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:48 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:48 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:48 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:48 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:48 --> Controller Class Initialized
INFO - 2022-04-16 15:17:48 --> Model Class Initialized
INFO - 2022-04-16 15:17:48 --> Model Class Initialized
INFO - 2022-04-16 15:17:48 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\admin/cms/list.php
INFO - 2022-04-16 15:17:48 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:17:48 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:48 --> Total execution time: 0.0676
INFO - 2022-04-16 15:17:49 --> Config Class Initialized
INFO - 2022-04-16 15:17:49 --> Hooks Class Initialized
DEBUG - 2022-04-16 15:17:49 --> UTF-8 Support Enabled
INFO - 2022-04-16 15:17:49 --> Utf8 Class Initialized
INFO - 2022-04-16 15:17:49 --> URI Class Initialized
INFO - 2022-04-16 15:17:49 --> Router Class Initialized
INFO - 2022-04-16 15:17:49 --> Output Class Initialized
INFO - 2022-04-16 15:17:49 --> Security Class Initialized
DEBUG - 2022-04-16 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-16 15:17:49 --> Input Class Initialized
INFO - 2022-04-16 15:17:49 --> Language Class Initialized
INFO - 2022-04-16 15:17:49 --> Loader Class Initialized
INFO - 2022-04-16 15:17:49 --> Helper loaded: url_helper
INFO - 2022-04-16 15:17:49 --> Helper loaded: form_helper
INFO - 2022-04-16 15:17:49 --> Helper loaded: common_helper
INFO - 2022-04-16 15:17:49 --> Helper loaded: util_helper
INFO - 2022-04-16 15:17:49 --> Database Driver Class Initialized
DEBUG - 2022-04-16 15:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-16 15:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-16 15:17:49 --> Form Validation Class Initialized
INFO - 2022-04-16 15:17:49 --> Controller Class Initialized
INFO - 2022-04-16 15:17:49 --> Model Class Initialized
INFO - 2022-04-16 15:17:49 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/dashboard.php
INFO - 2022-04-16 15:17:49 --> File loaded: C:\xampp\htdocs\CI_admin\application\views\provider/_layout.php
INFO - 2022-04-16 15:17:49 --> Final output sent to browser
DEBUG - 2022-04-16 15:17:49 --> Total execution time: 0.0756
