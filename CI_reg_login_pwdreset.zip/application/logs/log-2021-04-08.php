<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-08 18:22:51 --> Config Class Initialized
INFO - 2021-04-08 18:22:51 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:22:51 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:22:51 --> Utf8 Class Initialized
INFO - 2021-04-08 18:22:51 --> URI Class Initialized
INFO - 2021-04-08 18:22:51 --> Router Class Initialized
INFO - 2021-04-08 18:22:51 --> Output Class Initialized
INFO - 2021-04-08 18:22:51 --> Security Class Initialized
DEBUG - 2021-04-08 18:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:22:51 --> Input Class Initialized
INFO - 2021-04-08 18:22:51 --> Language Class Initialized
ERROR - 2021-04-08 18:22:51 --> 404 Page Not Found: administrator//index
INFO - 2021-04-08 18:24:02 --> Config Class Initialized
INFO - 2021-04-08 18:24:02 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:02 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:02 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:02 --> URI Class Initialized
INFO - 2021-04-08 18:24:02 --> Router Class Initialized
INFO - 2021-04-08 18:24:02 --> Output Class Initialized
INFO - 2021-04-08 18:24:02 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:02 --> Input Class Initialized
INFO - 2021-04-08 18:24:02 --> Language Class Initialized
ERROR - 2021-04-08 18:24:02 --> 404 Page Not Found: administrator//index
INFO - 2021-04-08 18:24:28 --> Config Class Initialized
INFO - 2021-04-08 18:24:28 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:28 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:28 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:28 --> URI Class Initialized
INFO - 2021-04-08 18:24:28 --> Router Class Initialized
INFO - 2021-04-08 18:24:28 --> Output Class Initialized
INFO - 2021-04-08 18:24:28 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:28 --> Input Class Initialized
INFO - 2021-04-08 18:24:28 --> Language Class Initialized
INFO - 2021-04-08 18:24:28 --> Loader Class Initialized
INFO - 2021-04-08 18:24:28 --> Helper loaded: url_helper
INFO - 2021-04-08 18:24:28 --> Helper loaded: form_helper
INFO - 2021-04-08 18:24:28 --> Helper loaded: common_helper
INFO - 2021-04-08 18:24:28 --> Helper loaded: util_helper
INFO - 2021-04-08 18:24:28 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:24:28 --> Form Validation Class Initialized
INFO - 2021-04-08 18:24:28 --> Controller Class Initialized
INFO - 2021-04-08 18:24:28 --> Model Class Initialized
INFO - 2021-04-08 18:24:28 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/login.php
INFO - 2021-04-08 18:24:28 --> Final output sent to browser
DEBUG - 2021-04-08 18:24:28 --> Total execution time: 0.2477
INFO - 2021-04-08 18:24:31 --> Config Class Initialized
INFO - 2021-04-08 18:24:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:31 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:31 --> URI Class Initialized
INFO - 2021-04-08 18:24:31 --> Router Class Initialized
INFO - 2021-04-08 18:24:31 --> Output Class Initialized
INFO - 2021-04-08 18:24:31 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:31 --> Input Class Initialized
INFO - 2021-04-08 18:24:31 --> Language Class Initialized
INFO - 2021-04-08 18:24:31 --> Loader Class Initialized
INFO - 2021-04-08 18:24:31 --> Helper loaded: url_helper
INFO - 2021-04-08 18:24:31 --> Helper loaded: form_helper
INFO - 2021-04-08 18:24:31 --> Helper loaded: common_helper
INFO - 2021-04-08 18:24:31 --> Helper loaded: util_helper
INFO - 2021-04-08 18:24:31 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:24:31 --> Form Validation Class Initialized
INFO - 2021-04-08 18:24:31 --> Controller Class Initialized
INFO - 2021-04-08 18:24:31 --> Model Class Initialized
INFO - 2021-04-08 18:24:31 --> Config Class Initialized
INFO - 2021-04-08 18:24:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:31 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:31 --> URI Class Initialized
INFO - 2021-04-08 18:24:31 --> Router Class Initialized
INFO - 2021-04-08 18:24:31 --> Output Class Initialized
INFO - 2021-04-08 18:24:31 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:31 --> Input Class Initialized
INFO - 2021-04-08 18:24:31 --> Language Class Initialized
INFO - 2021-04-08 18:24:31 --> Loader Class Initialized
INFO - 2021-04-08 18:24:31 --> Helper loaded: url_helper
INFO - 2021-04-08 18:24:31 --> Helper loaded: form_helper
INFO - 2021-04-08 18:24:31 --> Helper loaded: common_helper
INFO - 2021-04-08 18:24:31 --> Helper loaded: util_helper
INFO - 2021-04-08 18:24:31 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:24:31 --> Form Validation Class Initialized
INFO - 2021-04-08 18:24:31 --> Controller Class Initialized
INFO - 2021-04-08 18:24:31 --> Model Class Initialized
INFO - 2021-04-08 18:24:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 18:24:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 18:24:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 18:24:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 18:24:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 18:24:31 --> Final output sent to browser
DEBUG - 2021-04-08 18:24:31 --> Total execution time: 0.0613
INFO - 2021-04-08 18:24:31 --> Config Class Initialized
INFO - 2021-04-08 18:24:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:31 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:31 --> URI Class Initialized
INFO - 2021-04-08 18:24:31 --> Router Class Initialized
INFO - 2021-04-08 18:24:31 --> Output Class Initialized
INFO - 2021-04-08 18:24:31 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:31 --> Input Class Initialized
INFO - 2021-04-08 18:24:31 --> Language Class Initialized
ERROR - 2021-04-08 18:24:31 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:24:31 --> Config Class Initialized
INFO - 2021-04-08 18:24:31 --> Config Class Initialized
INFO - 2021-04-08 18:24:31 --> Hooks Class Initialized
INFO - 2021-04-08 18:24:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:31 --> Utf8 Class Initialized
DEBUG - 2021-04-08 18:24:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:31 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:31 --> URI Class Initialized
INFO - 2021-04-08 18:24:31 --> URI Class Initialized
INFO - 2021-04-08 18:24:31 --> Router Class Initialized
INFO - 2021-04-08 18:24:31 --> Router Class Initialized
INFO - 2021-04-08 18:24:31 --> Config Class Initialized
INFO - 2021-04-08 18:24:31 --> Hooks Class Initialized
INFO - 2021-04-08 18:24:31 --> Output Class Initialized
INFO - 2021-04-08 18:24:31 --> Output Class Initialized
INFO - 2021-04-08 18:24:31 --> Security Class Initialized
INFO - 2021-04-08 18:24:31 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:31 --> Utf8 Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:31 --> Input Class Initialized
INFO - 2021-04-08 18:24:31 --> Input Class Initialized
INFO - 2021-04-08 18:24:31 --> Language Class Initialized
INFO - 2021-04-08 18:24:31 --> Language Class Initialized
ERROR - 2021-04-08 18:24:31 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:24:31 --> URI Class Initialized
ERROR - 2021-04-08 18:24:31 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:24:31 --> Router Class Initialized
INFO - 2021-04-08 18:24:31 --> Output Class Initialized
INFO - 2021-04-08 18:24:31 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:31 --> Input Class Initialized
INFO - 2021-04-08 18:24:31 --> Language Class Initialized
ERROR - 2021-04-08 18:24:31 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:24:39 --> Config Class Initialized
INFO - 2021-04-08 18:24:39 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:39 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:39 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:39 --> URI Class Initialized
INFO - 2021-04-08 18:24:39 --> Router Class Initialized
INFO - 2021-04-08 18:24:39 --> Output Class Initialized
INFO - 2021-04-08 18:24:39 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:39 --> Input Class Initialized
INFO - 2021-04-08 18:24:39 --> Language Class Initialized
INFO - 2021-04-08 18:24:39 --> Loader Class Initialized
INFO - 2021-04-08 18:24:40 --> Helper loaded: url_helper
INFO - 2021-04-08 18:24:40 --> Helper loaded: form_helper
INFO - 2021-04-08 18:24:40 --> Helper loaded: common_helper
INFO - 2021-04-08 18:24:40 --> Helper loaded: util_helper
INFO - 2021-04-08 18:24:40 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:24:40 --> Form Validation Class Initialized
INFO - 2021-04-08 18:24:40 --> Controller Class Initialized
INFO - 2021-04-08 18:24:40 --> Model Class Initialized
INFO - 2021-04-08 18:24:40 --> Config Class Initialized
INFO - 2021-04-08 18:24:40 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:24:40 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:24:40 --> Utf8 Class Initialized
INFO - 2021-04-08 18:24:40 --> URI Class Initialized
INFO - 2021-04-08 18:24:40 --> Router Class Initialized
INFO - 2021-04-08 18:24:40 --> Output Class Initialized
INFO - 2021-04-08 18:24:40 --> Security Class Initialized
DEBUG - 2021-04-08 18:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:24:40 --> Input Class Initialized
INFO - 2021-04-08 18:24:40 --> Language Class Initialized
INFO - 2021-04-08 18:24:40 --> Loader Class Initialized
INFO - 2021-04-08 18:24:40 --> Helper loaded: url_helper
INFO - 2021-04-08 18:24:40 --> Helper loaded: form_helper
INFO - 2021-04-08 18:24:40 --> Helper loaded: common_helper
INFO - 2021-04-08 18:24:40 --> Helper loaded: util_helper
INFO - 2021-04-08 18:24:40 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:24:40 --> Form Validation Class Initialized
INFO - 2021-04-08 18:24:40 --> Controller Class Initialized
INFO - 2021-04-08 18:24:40 --> Model Class Initialized
INFO - 2021-04-08 18:24:40 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/login.php
INFO - 2021-04-08 18:24:40 --> Final output sent to browser
DEBUG - 2021-04-08 18:24:40 --> Total execution time: 0.0423
INFO - 2021-04-08 18:54:08 --> Config Class Initialized
INFO - 2021-04-08 18:54:08 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:54:08 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:54:08 --> Utf8 Class Initialized
INFO - 2021-04-08 18:54:08 --> URI Class Initialized
INFO - 2021-04-08 18:54:08 --> Router Class Initialized
INFO - 2021-04-08 18:54:08 --> Output Class Initialized
INFO - 2021-04-08 18:54:08 --> Security Class Initialized
DEBUG - 2021-04-08 18:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:54:08 --> Input Class Initialized
INFO - 2021-04-08 18:54:08 --> Language Class Initialized
INFO - 2021-04-08 18:54:08 --> Loader Class Initialized
INFO - 2021-04-08 18:54:08 --> Helper loaded: url_helper
INFO - 2021-04-08 18:54:08 --> Helper loaded: form_helper
INFO - 2021-04-08 18:54:08 --> Helper loaded: common_helper
INFO - 2021-04-08 18:54:08 --> Helper loaded: util_helper
INFO - 2021-04-08 18:54:08 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:54:08 --> Form Validation Class Initialized
INFO - 2021-04-08 18:54:08 --> Controller Class Initialized
INFO - 2021-04-08 18:54:08 --> Model Class Initialized
INFO - 2021-04-08 18:54:08 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/login.php
INFO - 2021-04-08 18:54:08 --> Final output sent to browser
DEBUG - 2021-04-08 18:54:08 --> Total execution time: 0.0335
INFO - 2021-04-08 18:56:21 --> Config Class Initialized
INFO - 2021-04-08 18:56:21 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:56:21 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:56:21 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:21 --> URI Class Initialized
INFO - 2021-04-08 18:56:21 --> Router Class Initialized
INFO - 2021-04-08 18:56:21 --> Output Class Initialized
INFO - 2021-04-08 18:56:21 --> Security Class Initialized
DEBUG - 2021-04-08 18:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:56:21 --> Input Class Initialized
INFO - 2021-04-08 18:56:21 --> Language Class Initialized
INFO - 2021-04-08 18:56:21 --> Loader Class Initialized
INFO - 2021-04-08 18:56:21 --> Helper loaded: url_helper
INFO - 2021-04-08 18:56:21 --> Helper loaded: form_helper
INFO - 2021-04-08 18:56:21 --> Helper loaded: common_helper
INFO - 2021-04-08 18:56:21 --> Helper loaded: util_helper
INFO - 2021-04-08 18:56:21 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:56:21 --> Form Validation Class Initialized
INFO - 2021-04-08 18:56:21 --> Controller Class Initialized
INFO - 2021-04-08 18:56:21 --> Model Class Initialized
INFO - 2021-04-08 18:56:21 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/login.php
INFO - 2021-04-08 18:56:21 --> Final output sent to browser
DEBUG - 2021-04-08 18:56:21 --> Total execution time: 0.0351
INFO - 2021-04-08 18:56:23 --> Config Class Initialized
INFO - 2021-04-08 18:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:56:23 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:56:23 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:23 --> URI Class Initialized
INFO - 2021-04-08 18:56:23 --> Router Class Initialized
INFO - 2021-04-08 18:56:23 --> Output Class Initialized
INFO - 2021-04-08 18:56:23 --> Security Class Initialized
DEBUG - 2021-04-08 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:56:23 --> Input Class Initialized
INFO - 2021-04-08 18:56:23 --> Language Class Initialized
INFO - 2021-04-08 18:56:23 --> Loader Class Initialized
INFO - 2021-04-08 18:56:23 --> Helper loaded: url_helper
INFO - 2021-04-08 18:56:23 --> Helper loaded: form_helper
INFO - 2021-04-08 18:56:23 --> Helper loaded: common_helper
INFO - 2021-04-08 18:56:23 --> Helper loaded: util_helper
INFO - 2021-04-08 18:56:23 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:56:23 --> Form Validation Class Initialized
INFO - 2021-04-08 18:56:23 --> Controller Class Initialized
INFO - 2021-04-08 18:56:23 --> Model Class Initialized
INFO - 2021-04-08 18:56:23 --> Config Class Initialized
INFO - 2021-04-08 18:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:56:23 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:56:23 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:23 --> URI Class Initialized
INFO - 2021-04-08 18:56:23 --> Router Class Initialized
INFO - 2021-04-08 18:56:23 --> Output Class Initialized
INFO - 2021-04-08 18:56:23 --> Security Class Initialized
DEBUG - 2021-04-08 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:56:23 --> Input Class Initialized
INFO - 2021-04-08 18:56:23 --> Language Class Initialized
INFO - 2021-04-08 18:56:23 --> Loader Class Initialized
INFO - 2021-04-08 18:56:23 --> Helper loaded: url_helper
INFO - 2021-04-08 18:56:23 --> Helper loaded: form_helper
INFO - 2021-04-08 18:56:23 --> Helper loaded: common_helper
INFO - 2021-04-08 18:56:23 --> Helper loaded: util_helper
INFO - 2021-04-08 18:56:23 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:56:23 --> Form Validation Class Initialized
INFO - 2021-04-08 18:56:23 --> Controller Class Initialized
INFO - 2021-04-08 18:56:23 --> Model Class Initialized
INFO - 2021-04-08 18:56:23 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 18:56:23 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 18:56:23 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 18:56:23 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 18:56:23 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 18:56:23 --> Final output sent to browser
DEBUG - 2021-04-08 18:56:23 --> Total execution time: 0.0378
INFO - 2021-04-08 18:56:23 --> Config Class Initialized
INFO - 2021-04-08 18:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:56:23 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:56:23 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:23 --> URI Class Initialized
INFO - 2021-04-08 18:56:23 --> Router Class Initialized
INFO - 2021-04-08 18:56:23 --> Output Class Initialized
INFO - 2021-04-08 18:56:23 --> Security Class Initialized
DEBUG - 2021-04-08 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:56:23 --> Input Class Initialized
INFO - 2021-04-08 18:56:23 --> Language Class Initialized
ERROR - 2021-04-08 18:56:23 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:56:23 --> Config Class Initialized
INFO - 2021-04-08 18:56:23 --> Hooks Class Initialized
INFO - 2021-04-08 18:56:23 --> Config Class Initialized
INFO - 2021-04-08 18:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:56:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 18:56:23 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:56:23 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:23 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:23 --> URI Class Initialized
INFO - 2021-04-08 18:56:23 --> URI Class Initialized
INFO - 2021-04-08 18:56:23 --> Router Class Initialized
INFO - 2021-04-08 18:56:23 --> Router Class Initialized
INFO - 2021-04-08 18:56:23 --> Output Class Initialized
INFO - 2021-04-08 18:56:23 --> Output Class Initialized
INFO - 2021-04-08 18:56:23 --> Security Class Initialized
INFO - 2021-04-08 18:56:23 --> Security Class Initialized
DEBUG - 2021-04-08 18:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:56:23 --> Input Class Initialized
INFO - 2021-04-08 18:56:23 --> Input Class Initialized
INFO - 2021-04-08 18:56:23 --> Language Class Initialized
INFO - 2021-04-08 18:56:23 --> Language Class Initialized
ERROR - 2021-04-08 18:56:23 --> 404 Page Not Found: Admin/dist
ERROR - 2021-04-08 18:56:23 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:56:23 --> Config Class Initialized
INFO - 2021-04-08 18:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:56:24 --> Utf8 Class Initialized
INFO - 2021-04-08 18:56:24 --> URI Class Initialized
INFO - 2021-04-08 18:56:24 --> Router Class Initialized
INFO - 2021-04-08 18:56:24 --> Output Class Initialized
INFO - 2021-04-08 18:56:24 --> Security Class Initialized
DEBUG - 2021-04-08 18:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:56:24 --> Input Class Initialized
INFO - 2021-04-08 18:56:24 --> Language Class Initialized
ERROR - 2021-04-08 18:56:24 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:58:16 --> Config Class Initialized
INFO - 2021-04-08 18:58:16 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:58:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:58:16 --> Utf8 Class Initialized
INFO - 2021-04-08 18:58:16 --> URI Class Initialized
INFO - 2021-04-08 18:58:16 --> Router Class Initialized
INFO - 2021-04-08 18:58:16 --> Output Class Initialized
INFO - 2021-04-08 18:58:16 --> Security Class Initialized
DEBUG - 2021-04-08 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:58:16 --> Input Class Initialized
INFO - 2021-04-08 18:58:16 --> Language Class Initialized
INFO - 2021-04-08 18:58:16 --> Loader Class Initialized
INFO - 2021-04-08 18:58:16 --> Helper loaded: url_helper
INFO - 2021-04-08 18:58:16 --> Helper loaded: form_helper
INFO - 2021-04-08 18:58:16 --> Helper loaded: common_helper
INFO - 2021-04-08 18:58:16 --> Helper loaded: util_helper
INFO - 2021-04-08 18:58:16 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:58:16 --> Form Validation Class Initialized
INFO - 2021-04-08 18:58:16 --> Controller Class Initialized
INFO - 2021-04-08 18:58:16 --> Model Class Initialized
INFO - 2021-04-08 18:58:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 18:58:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 18:58:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 18:58:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 18:58:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 18:58:16 --> Final output sent to browser
DEBUG - 2021-04-08 18:58:16 --> Total execution time: 0.0362
INFO - 2021-04-08 18:58:16 --> Config Class Initialized
INFO - 2021-04-08 18:58:16 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:58:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:58:16 --> Utf8 Class Initialized
INFO - 2021-04-08 18:58:16 --> URI Class Initialized
INFO - 2021-04-08 18:58:16 --> Router Class Initialized
INFO - 2021-04-08 18:58:16 --> Output Class Initialized
INFO - 2021-04-08 18:58:16 --> Security Class Initialized
DEBUG - 2021-04-08 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:58:16 --> Input Class Initialized
INFO - 2021-04-08 18:58:16 --> Config Class Initialized
INFO - 2021-04-08 18:58:16 --> Hooks Class Initialized
INFO - 2021-04-08 18:58:16 --> Language Class Initialized
DEBUG - 2021-04-08 18:58:16 --> UTF-8 Support Enabled
ERROR - 2021-04-08 18:58:16 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:58:16 --> Utf8 Class Initialized
INFO - 2021-04-08 18:58:16 --> URI Class Initialized
INFO - 2021-04-08 18:58:16 --> Router Class Initialized
INFO - 2021-04-08 18:58:16 --> Output Class Initialized
INFO - 2021-04-08 18:58:16 --> Security Class Initialized
DEBUG - 2021-04-08 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:58:16 --> Input Class Initialized
INFO - 2021-04-08 18:58:16 --> Language Class Initialized
ERROR - 2021-04-08 18:58:16 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:58:16 --> Config Class Initialized
INFO - 2021-04-08 18:58:16 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:58:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:58:16 --> Utf8 Class Initialized
INFO - 2021-04-08 18:58:16 --> URI Class Initialized
INFO - 2021-04-08 18:58:16 --> Router Class Initialized
INFO - 2021-04-08 18:58:16 --> Output Class Initialized
INFO - 2021-04-08 18:58:16 --> Security Class Initialized
DEBUG - 2021-04-08 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:58:16 --> Input Class Initialized
INFO - 2021-04-08 18:58:16 --> Language Class Initialized
INFO - 2021-04-08 18:58:16 --> Config Class Initialized
INFO - 2021-04-08 18:58:16 --> Hooks Class Initialized
ERROR - 2021-04-08 18:58:16 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-04-08 18:58:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:58:16 --> Utf8 Class Initialized
INFO - 2021-04-08 18:58:16 --> URI Class Initialized
INFO - 2021-04-08 18:58:16 --> Router Class Initialized
INFO - 2021-04-08 18:58:16 --> Output Class Initialized
INFO - 2021-04-08 18:58:16 --> Security Class Initialized
DEBUG - 2021-04-08 18:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:58:16 --> Input Class Initialized
INFO - 2021-04-08 18:58:16 --> Language Class Initialized
ERROR - 2021-04-08 18:58:16 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:59:22 --> Config Class Initialized
INFO - 2021-04-08 18:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:59:22 --> Utf8 Class Initialized
INFO - 2021-04-08 18:59:22 --> URI Class Initialized
INFO - 2021-04-08 18:59:22 --> Router Class Initialized
INFO - 2021-04-08 18:59:22 --> Output Class Initialized
INFO - 2021-04-08 18:59:22 --> Security Class Initialized
DEBUG - 2021-04-08 18:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:59:22 --> Input Class Initialized
INFO - 2021-04-08 18:59:22 --> Language Class Initialized
INFO - 2021-04-08 18:59:22 --> Loader Class Initialized
INFO - 2021-04-08 18:59:22 --> Helper loaded: url_helper
INFO - 2021-04-08 18:59:22 --> Helper loaded: form_helper
INFO - 2021-04-08 18:59:22 --> Helper loaded: common_helper
INFO - 2021-04-08 18:59:22 --> Helper loaded: util_helper
INFO - 2021-04-08 18:59:22 --> Database Driver Class Initialized
DEBUG - 2021-04-08 18:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 18:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 18:59:22 --> Form Validation Class Initialized
INFO - 2021-04-08 18:59:22 --> Controller Class Initialized
INFO - 2021-04-08 18:59:22 --> Model Class Initialized
INFO - 2021-04-08 18:59:22 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 18:59:22 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 18:59:22 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 18:59:22 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 18:59:22 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 18:59:22 --> Final output sent to browser
DEBUG - 2021-04-08 18:59:22 --> Total execution time: 0.0379
INFO - 2021-04-08 18:59:22 --> Config Class Initialized
INFO - 2021-04-08 18:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:59:22 --> Utf8 Class Initialized
INFO - 2021-04-08 18:59:22 --> URI Class Initialized
INFO - 2021-04-08 18:59:22 --> Router Class Initialized
INFO - 2021-04-08 18:59:22 --> Config Class Initialized
INFO - 2021-04-08 18:59:22 --> Output Class Initialized
INFO - 2021-04-08 18:59:22 --> Hooks Class Initialized
INFO - 2021-04-08 18:59:22 --> Security Class Initialized
DEBUG - 2021-04-08 18:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 18:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:59:22 --> Input Class Initialized
INFO - 2021-04-08 18:59:22 --> Utf8 Class Initialized
INFO - 2021-04-08 18:59:22 --> Language Class Initialized
INFO - 2021-04-08 18:59:22 --> URI Class Initialized
INFO - 2021-04-08 18:59:22 --> Router Class Initialized
ERROR - 2021-04-08 18:59:22 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:59:22 --> Output Class Initialized
INFO - 2021-04-08 18:59:22 --> Security Class Initialized
DEBUG - 2021-04-08 18:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:59:22 --> Input Class Initialized
INFO - 2021-04-08 18:59:22 --> Language Class Initialized
ERROR - 2021-04-08 18:59:22 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:59:22 --> Config Class Initialized
INFO - 2021-04-08 18:59:22 --> Hooks Class Initialized
INFO - 2021-04-08 18:59:22 --> Config Class Initialized
INFO - 2021-04-08 18:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-08 18:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:59:22 --> Utf8 Class Initialized
INFO - 2021-04-08 18:59:22 --> URI Class Initialized
DEBUG - 2021-04-08 18:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-08 18:59:22 --> Router Class Initialized
INFO - 2021-04-08 18:59:22 --> Utf8 Class Initialized
INFO - 2021-04-08 18:59:22 --> URI Class Initialized
INFO - 2021-04-08 18:59:22 --> Output Class Initialized
INFO - 2021-04-08 18:59:22 --> Router Class Initialized
INFO - 2021-04-08 18:59:22 --> Security Class Initialized
DEBUG - 2021-04-08 18:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 18:59:22 --> Output Class Initialized
INFO - 2021-04-08 18:59:22 --> Input Class Initialized
INFO - 2021-04-08 18:59:22 --> Language Class Initialized
INFO - 2021-04-08 18:59:22 --> Security Class Initialized
DEBUG - 2021-04-08 18:59:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 18:59:22 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 18:59:22 --> Input Class Initialized
INFO - 2021-04-08 18:59:22 --> Language Class Initialized
ERROR - 2021-04-08 18:59:22 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:00:05 --> Config Class Initialized
INFO - 2021-04-08 19:00:05 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:00:05 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:05 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:05 --> URI Class Initialized
INFO - 2021-04-08 19:00:05 --> Router Class Initialized
INFO - 2021-04-08 19:00:05 --> Output Class Initialized
INFO - 2021-04-08 19:00:05 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:05 --> Input Class Initialized
INFO - 2021-04-08 19:00:05 --> Language Class Initialized
INFO - 2021-04-08 19:00:05 --> Loader Class Initialized
INFO - 2021-04-08 19:00:05 --> Helper loaded: url_helper
INFO - 2021-04-08 19:00:05 --> Helper loaded: form_helper
INFO - 2021-04-08 19:00:05 --> Helper loaded: common_helper
INFO - 2021-04-08 19:00:05 --> Helper loaded: util_helper
INFO - 2021-04-08 19:00:05 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:00:05 --> Form Validation Class Initialized
INFO - 2021-04-08 19:00:05 --> Controller Class Initialized
INFO - 2021-04-08 19:00:05 --> Model Class Initialized
INFO - 2021-04-08 19:00:05 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:00:05 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:00:05 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:00:05 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:00:05 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:00:05 --> Final output sent to browser
DEBUG - 2021-04-08 19:00:05 --> Total execution time: 0.0357
INFO - 2021-04-08 19:00:05 --> Config Class Initialized
INFO - 2021-04-08 19:00:05 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:00:05 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:05 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:05 --> URI Class Initialized
INFO - 2021-04-08 19:00:05 --> Router Class Initialized
INFO - 2021-04-08 19:00:05 --> Output Class Initialized
INFO - 2021-04-08 19:00:05 --> Config Class Initialized
INFO - 2021-04-08 19:00:05 --> Hooks Class Initialized
INFO - 2021-04-08 19:00:05 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:05 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:05 --> Utf8 Class Initialized
DEBUG - 2021-04-08 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:05 --> URI Class Initialized
INFO - 2021-04-08 19:00:05 --> Input Class Initialized
INFO - 2021-04-08 19:00:05 --> Router Class Initialized
INFO - 2021-04-08 19:00:05 --> Language Class Initialized
INFO - 2021-04-08 19:00:05 --> Output Class Initialized
ERROR - 2021-04-08 19:00:05 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:00:05 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:05 --> Input Class Initialized
INFO - 2021-04-08 19:00:05 --> Language Class Initialized
ERROR - 2021-04-08 19:00:05 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:00:05 --> Config Class Initialized
INFO - 2021-04-08 19:00:05 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:00:05 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:05 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:05 --> URI Class Initialized
INFO - 2021-04-08 19:00:05 --> Router Class Initialized
INFO - 2021-04-08 19:00:05 --> Output Class Initialized
INFO - 2021-04-08 19:00:05 --> Security Class Initialized
INFO - 2021-04-08 19:00:05 --> Config Class Initialized
INFO - 2021-04-08 19:00:05 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:05 --> Input Class Initialized
INFO - 2021-04-08 19:00:05 --> Language Class Initialized
DEBUG - 2021-04-08 19:00:05 --> UTF-8 Support Enabled
ERROR - 2021-04-08 19:00:05 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:00:05 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:05 --> URI Class Initialized
INFO - 2021-04-08 19:00:05 --> Router Class Initialized
INFO - 2021-04-08 19:00:05 --> Output Class Initialized
INFO - 2021-04-08 19:00:05 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:05 --> Input Class Initialized
INFO - 2021-04-08 19:00:05 --> Language Class Initialized
ERROR - 2021-04-08 19:00:05 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:00:49 --> Config Class Initialized
INFO - 2021-04-08 19:00:49 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:00:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:49 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:49 --> URI Class Initialized
INFO - 2021-04-08 19:00:49 --> Router Class Initialized
INFO - 2021-04-08 19:00:49 --> Output Class Initialized
INFO - 2021-04-08 19:00:49 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:49 --> Input Class Initialized
INFO - 2021-04-08 19:00:49 --> Language Class Initialized
INFO - 2021-04-08 19:00:49 --> Loader Class Initialized
INFO - 2021-04-08 19:00:49 --> Helper loaded: url_helper
INFO - 2021-04-08 19:00:49 --> Helper loaded: form_helper
INFO - 2021-04-08 19:00:49 --> Helper loaded: common_helper
INFO - 2021-04-08 19:00:49 --> Helper loaded: util_helper
INFO - 2021-04-08 19:00:49 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:00:49 --> Form Validation Class Initialized
INFO - 2021-04-08 19:00:49 --> Controller Class Initialized
INFO - 2021-04-08 19:00:49 --> Model Class Initialized
INFO - 2021-04-08 19:00:49 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:00:49 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:00:49 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:00:49 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:00:49 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:00:49 --> Final output sent to browser
DEBUG - 2021-04-08 19:00:49 --> Total execution time: 0.0365
INFO - 2021-04-08 19:00:49 --> Config Class Initialized
INFO - 2021-04-08 19:00:49 --> Hooks Class Initialized
INFO - 2021-04-08 19:00:49 --> Config Class Initialized
INFO - 2021-04-08 19:00:49 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:00:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:49 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:49 --> URI Class Initialized
INFO - 2021-04-08 19:00:49 --> Router Class Initialized
DEBUG - 2021-04-08 19:00:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:49 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:49 --> Output Class Initialized
INFO - 2021-04-08 19:00:49 --> URI Class Initialized
INFO - 2021-04-08 19:00:49 --> Security Class Initialized
INFO - 2021-04-08 19:00:49 --> Router Class Initialized
DEBUG - 2021-04-08 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:49 --> Input Class Initialized
INFO - 2021-04-08 19:00:49 --> Language Class Initialized
INFO - 2021-04-08 19:00:49 --> Output Class Initialized
ERROR - 2021-04-08 19:00:49 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:00:49 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:49 --> Input Class Initialized
INFO - 2021-04-08 19:00:49 --> Config Class Initialized
INFO - 2021-04-08 19:00:49 --> Hooks Class Initialized
INFO - 2021-04-08 19:00:49 --> Language Class Initialized
ERROR - 2021-04-08 19:00:49 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-04-08 19:00:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:49 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:49 --> URI Class Initialized
INFO - 2021-04-08 19:00:49 --> Router Class Initialized
INFO - 2021-04-08 19:00:49 --> Output Class Initialized
INFO - 2021-04-08 19:00:49 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:49 --> Input Class Initialized
INFO - 2021-04-08 19:00:49 --> Language Class Initialized
INFO - 2021-04-08 19:00:49 --> Config Class Initialized
INFO - 2021-04-08 19:00:49 --> Hooks Class Initialized
ERROR - 2021-04-08 19:00:49 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-04-08 19:00:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:00:49 --> Utf8 Class Initialized
INFO - 2021-04-08 19:00:49 --> URI Class Initialized
INFO - 2021-04-08 19:00:49 --> Router Class Initialized
INFO - 2021-04-08 19:00:49 --> Output Class Initialized
INFO - 2021-04-08 19:00:49 --> Security Class Initialized
DEBUG - 2021-04-08 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:00:49 --> Input Class Initialized
INFO - 2021-04-08 19:00:49 --> Language Class Initialized
ERROR - 2021-04-08 19:00:49 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:12 --> Config Class Initialized
INFO - 2021-04-08 19:01:12 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:12 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:12 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:12 --> URI Class Initialized
INFO - 2021-04-08 19:01:12 --> Router Class Initialized
INFO - 2021-04-08 19:01:12 --> Output Class Initialized
INFO - 2021-04-08 19:01:12 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:12 --> Input Class Initialized
INFO - 2021-04-08 19:01:12 --> Language Class Initialized
INFO - 2021-04-08 19:01:12 --> Loader Class Initialized
INFO - 2021-04-08 19:01:12 --> Helper loaded: url_helper
INFO - 2021-04-08 19:01:12 --> Helper loaded: form_helper
INFO - 2021-04-08 19:01:12 --> Helper loaded: common_helper
INFO - 2021-04-08 19:01:12 --> Helper loaded: util_helper
INFO - 2021-04-08 19:01:12 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:01:12 --> Form Validation Class Initialized
INFO - 2021-04-08 19:01:12 --> Controller Class Initialized
INFO - 2021-04-08 19:01:12 --> Model Class Initialized
INFO - 2021-04-08 19:01:12 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:01:12 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:01:12 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:01:12 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:01:12 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:01:12 --> Final output sent to browser
DEBUG - 2021-04-08 19:01:12 --> Total execution time: 0.0505
INFO - 2021-04-08 19:01:12 --> Config Class Initialized
INFO - 2021-04-08 19:01:12 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:12 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:12 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:12 --> Config Class Initialized
INFO - 2021-04-08 19:01:12 --> Hooks Class Initialized
INFO - 2021-04-08 19:01:12 --> URI Class Initialized
DEBUG - 2021-04-08 19:01:12 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:12 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:12 --> URI Class Initialized
INFO - 2021-04-08 19:01:12 --> Router Class Initialized
INFO - 2021-04-08 19:01:12 --> Router Class Initialized
INFO - 2021-04-08 19:01:12 --> Output Class Initialized
INFO - 2021-04-08 19:01:12 --> Output Class Initialized
INFO - 2021-04-08 19:01:12 --> Security Class Initialized
INFO - 2021-04-08 19:01:12 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:12 --> Input Class Initialized
DEBUG - 2021-04-08 19:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:12 --> Input Class Initialized
INFO - 2021-04-08 19:01:12 --> Language Class Initialized
INFO - 2021-04-08 19:01:12 --> Language Class Initialized
ERROR - 2021-04-08 19:01:12 --> 404 Page Not Found: Admin/dist
ERROR - 2021-04-08 19:01:12 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:12 --> Config Class Initialized
INFO - 2021-04-08 19:01:12 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:12 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:12 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:12 --> URI Class Initialized
INFO - 2021-04-08 19:01:12 --> Config Class Initialized
INFO - 2021-04-08 19:01:12 --> Router Class Initialized
INFO - 2021-04-08 19:01:12 --> Hooks Class Initialized
INFO - 2021-04-08 19:01:12 --> Output Class Initialized
DEBUG - 2021-04-08 19:01:12 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:12 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:12 --> Security Class Initialized
INFO - 2021-04-08 19:01:12 --> URI Class Initialized
DEBUG - 2021-04-08 19:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:12 --> Input Class Initialized
INFO - 2021-04-08 19:01:12 --> Router Class Initialized
INFO - 2021-04-08 19:01:12 --> Language Class Initialized
INFO - 2021-04-08 19:01:12 --> Output Class Initialized
ERROR - 2021-04-08 19:01:12 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:12 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:12 --> Input Class Initialized
INFO - 2021-04-08 19:01:12 --> Language Class Initialized
ERROR - 2021-04-08 19:01:12 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:34 --> Config Class Initialized
INFO - 2021-04-08 19:01:34 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:34 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:34 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:34 --> URI Class Initialized
INFO - 2021-04-08 19:01:34 --> Router Class Initialized
INFO - 2021-04-08 19:01:34 --> Output Class Initialized
INFO - 2021-04-08 19:01:34 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:34 --> Input Class Initialized
INFO - 2021-04-08 19:01:34 --> Language Class Initialized
INFO - 2021-04-08 19:01:34 --> Loader Class Initialized
INFO - 2021-04-08 19:01:34 --> Helper loaded: url_helper
INFO - 2021-04-08 19:01:34 --> Helper loaded: form_helper
INFO - 2021-04-08 19:01:34 --> Helper loaded: common_helper
INFO - 2021-04-08 19:01:34 --> Helper loaded: util_helper
INFO - 2021-04-08 19:01:34 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:01:34 --> Form Validation Class Initialized
INFO - 2021-04-08 19:01:34 --> Controller Class Initialized
INFO - 2021-04-08 19:01:34 --> Model Class Initialized
INFO - 2021-04-08 19:01:34 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:01:34 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:01:34 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:01:34 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:01:34 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:01:34 --> Final output sent to browser
DEBUG - 2021-04-08 19:01:34 --> Total execution time: 0.0403
INFO - 2021-04-08 19:01:34 --> Config Class Initialized
INFO - 2021-04-08 19:01:34 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:34 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:34 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:34 --> URI Class Initialized
INFO - 2021-04-08 19:01:34 --> Router Class Initialized
INFO - 2021-04-08 19:01:34 --> Config Class Initialized
INFO - 2021-04-08 19:01:34 --> Hooks Class Initialized
INFO - 2021-04-08 19:01:34 --> Output Class Initialized
INFO - 2021-04-08 19:01:34 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:34 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:34 --> Utf8 Class Initialized
DEBUG - 2021-04-08 19:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:34 --> Input Class Initialized
INFO - 2021-04-08 19:01:34 --> URI Class Initialized
INFO - 2021-04-08 19:01:34 --> Language Class Initialized
INFO - 2021-04-08 19:01:34 --> Router Class Initialized
INFO - 2021-04-08 19:01:34 --> Output Class Initialized
ERROR - 2021-04-08 19:01:34 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:34 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:34 --> Input Class Initialized
INFO - 2021-04-08 19:01:34 --> Language Class Initialized
ERROR - 2021-04-08 19:01:34 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:34 --> Config Class Initialized
INFO - 2021-04-08 19:01:34 --> Hooks Class Initialized
INFO - 2021-04-08 19:01:34 --> Config Class Initialized
INFO - 2021-04-08 19:01:34 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:34 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:34 --> Utf8 Class Initialized
DEBUG - 2021-04-08 19:01:34 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:34 --> URI Class Initialized
INFO - 2021-04-08 19:01:34 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:34 --> URI Class Initialized
INFO - 2021-04-08 19:01:34 --> Router Class Initialized
INFO - 2021-04-08 19:01:34 --> Router Class Initialized
INFO - 2021-04-08 19:01:34 --> Output Class Initialized
INFO - 2021-04-08 19:01:34 --> Security Class Initialized
INFO - 2021-04-08 19:01:34 --> Output Class Initialized
DEBUG - 2021-04-08 19:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:34 --> Input Class Initialized
INFO - 2021-04-08 19:01:34 --> Security Class Initialized
INFO - 2021-04-08 19:01:34 --> Language Class Initialized
DEBUG - 2021-04-08 19:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:34 --> Input Class Initialized
ERROR - 2021-04-08 19:01:34 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:34 --> Language Class Initialized
ERROR - 2021-04-08 19:01:34 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:57 --> Config Class Initialized
INFO - 2021-04-08 19:01:57 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:57 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:57 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:57 --> URI Class Initialized
INFO - 2021-04-08 19:01:57 --> Router Class Initialized
INFO - 2021-04-08 19:01:57 --> Output Class Initialized
INFO - 2021-04-08 19:01:57 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:57 --> Input Class Initialized
INFO - 2021-04-08 19:01:57 --> Language Class Initialized
INFO - 2021-04-08 19:01:57 --> Loader Class Initialized
INFO - 2021-04-08 19:01:57 --> Helper loaded: url_helper
INFO - 2021-04-08 19:01:57 --> Helper loaded: form_helper
INFO - 2021-04-08 19:01:57 --> Helper loaded: common_helper
INFO - 2021-04-08 19:01:57 --> Helper loaded: util_helper
INFO - 2021-04-08 19:01:57 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:01:57 --> Form Validation Class Initialized
INFO - 2021-04-08 19:01:57 --> Controller Class Initialized
INFO - 2021-04-08 19:01:57 --> Model Class Initialized
INFO - 2021-04-08 19:01:57 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:01:57 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:01:57 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:01:57 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:01:57 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:01:57 --> Final output sent to browser
DEBUG - 2021-04-08 19:01:57 --> Total execution time: 0.0366
INFO - 2021-04-08 19:01:57 --> Config Class Initialized
INFO - 2021-04-08 19:01:57 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:57 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:57 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:57 --> URI Class Initialized
INFO - 2021-04-08 19:01:57 --> Router Class Initialized
INFO - 2021-04-08 19:01:57 --> Config Class Initialized
INFO - 2021-04-08 19:01:57 --> Output Class Initialized
INFO - 2021-04-08 19:01:57 --> Hooks Class Initialized
INFO - 2021-04-08 19:01:57 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:57 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:57 --> Utf8 Class Initialized
DEBUG - 2021-04-08 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:57 --> Input Class Initialized
INFO - 2021-04-08 19:01:57 --> Language Class Initialized
INFO - 2021-04-08 19:01:57 --> URI Class Initialized
INFO - 2021-04-08 19:01:57 --> Router Class Initialized
ERROR - 2021-04-08 19:01:57 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:57 --> Output Class Initialized
INFO - 2021-04-08 19:01:57 --> Security Class Initialized
DEBUG - 2021-04-08 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:57 --> Input Class Initialized
INFO - 2021-04-08 19:01:57 --> Language Class Initialized
ERROR - 2021-04-08 19:01:57 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:01:57 --> Config Class Initialized
INFO - 2021-04-08 19:01:57 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:01:57 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:57 --> Config Class Initialized
INFO - 2021-04-08 19:01:57 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:57 --> Hooks Class Initialized
INFO - 2021-04-08 19:01:57 --> URI Class Initialized
INFO - 2021-04-08 19:01:57 --> Router Class Initialized
DEBUG - 2021-04-08 19:01:57 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:01:57 --> Utf8 Class Initialized
INFO - 2021-04-08 19:01:57 --> Output Class Initialized
INFO - 2021-04-08 19:01:57 --> URI Class Initialized
INFO - 2021-04-08 19:01:57 --> Security Class Initialized
INFO - 2021-04-08 19:01:57 --> Router Class Initialized
DEBUG - 2021-04-08 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:57 --> Input Class Initialized
INFO - 2021-04-08 19:01:57 --> Output Class Initialized
INFO - 2021-04-08 19:01:57 --> Language Class Initialized
INFO - 2021-04-08 19:01:57 --> Security Class Initialized
ERROR - 2021-04-08 19:01:57 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-04-08 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:01:57 --> Input Class Initialized
INFO - 2021-04-08 19:01:57 --> Language Class Initialized
ERROR - 2021-04-08 19:01:57 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:24:51 --> Config Class Initialized
INFO - 2021-04-08 19:24:51 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:24:51 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:24:51 --> Utf8 Class Initialized
INFO - 2021-04-08 19:24:51 --> URI Class Initialized
INFO - 2021-04-08 19:24:51 --> Router Class Initialized
INFO - 2021-04-08 19:24:51 --> Output Class Initialized
INFO - 2021-04-08 19:24:51 --> Security Class Initialized
DEBUG - 2021-04-08 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:24:51 --> Input Class Initialized
INFO - 2021-04-08 19:24:51 --> Language Class Initialized
INFO - 2021-04-08 19:24:51 --> Loader Class Initialized
INFO - 2021-04-08 19:24:51 --> Helper loaded: url_helper
INFO - 2021-04-08 19:24:51 --> Helper loaded: form_helper
INFO - 2021-04-08 19:24:51 --> Helper loaded: common_helper
INFO - 2021-04-08 19:24:51 --> Helper loaded: util_helper
INFO - 2021-04-08 19:24:51 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:24:51 --> Form Validation Class Initialized
INFO - 2021-04-08 19:24:51 --> Controller Class Initialized
INFO - 2021-04-08 19:24:51 --> Model Class Initialized
INFO - 2021-04-08 19:24:51 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:24:51 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:24:51 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:24:51 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:24:51 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:24:51 --> Final output sent to browser
DEBUG - 2021-04-08 19:24:51 --> Total execution time: 0.0361
INFO - 2021-04-08 19:24:51 --> Config Class Initialized
INFO - 2021-04-08 19:24:51 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:24:51 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:24:51 --> Utf8 Class Initialized
INFO - 2021-04-08 19:24:51 --> URI Class Initialized
INFO - 2021-04-08 19:24:51 --> Router Class Initialized
INFO - 2021-04-08 19:24:51 --> Output Class Initialized
INFO - 2021-04-08 19:24:51 --> Security Class Initialized
DEBUG - 2021-04-08 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:24:51 --> Input Class Initialized
INFO - 2021-04-08 19:24:51 --> Language Class Initialized
ERROR - 2021-04-08 19:24:51 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:24:51 --> Config Class Initialized
INFO - 2021-04-08 19:24:51 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:24:51 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:24:51 --> Utf8 Class Initialized
INFO - 2021-04-08 19:24:51 --> URI Class Initialized
INFO - 2021-04-08 19:24:51 --> Router Class Initialized
INFO - 2021-04-08 19:24:51 --> Output Class Initialized
INFO - 2021-04-08 19:24:51 --> Security Class Initialized
DEBUG - 2021-04-08 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:24:51 --> Input Class Initialized
INFO - 2021-04-08 19:24:51 --> Language Class Initialized
ERROR - 2021-04-08 19:24:51 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:24:51 --> Config Class Initialized
INFO - 2021-04-08 19:24:51 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:24:51 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:24:51 --> Utf8 Class Initialized
INFO - 2021-04-08 19:24:51 --> URI Class Initialized
INFO - 2021-04-08 19:24:51 --> Router Class Initialized
INFO - 2021-04-08 19:24:51 --> Output Class Initialized
INFO - 2021-04-08 19:24:51 --> Security Class Initialized
INFO - 2021-04-08 19:24:51 --> Config Class Initialized
INFO - 2021-04-08 19:24:51 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:24:51 --> Input Class Initialized
INFO - 2021-04-08 19:24:51 --> Language Class Initialized
DEBUG - 2021-04-08 19:24:51 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:24:51 --> Utf8 Class Initialized
ERROR - 2021-04-08 19:24:51 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:24:51 --> URI Class Initialized
INFO - 2021-04-08 19:24:51 --> Router Class Initialized
INFO - 2021-04-08 19:24:51 --> Output Class Initialized
INFO - 2021-04-08 19:24:51 --> Security Class Initialized
DEBUG - 2021-04-08 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:24:51 --> Input Class Initialized
INFO - 2021-04-08 19:24:51 --> Language Class Initialized
ERROR - 2021-04-08 19:24:51 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:25:19 --> Config Class Initialized
INFO - 2021-04-08 19:25:19 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:25:19 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:25:19 --> Utf8 Class Initialized
INFO - 2021-04-08 19:25:19 --> URI Class Initialized
INFO - 2021-04-08 19:25:19 --> Router Class Initialized
INFO - 2021-04-08 19:25:19 --> Output Class Initialized
INFO - 2021-04-08 19:25:19 --> Security Class Initialized
DEBUG - 2021-04-08 19:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:25:19 --> Input Class Initialized
INFO - 2021-04-08 19:25:19 --> Language Class Initialized
INFO - 2021-04-08 19:25:19 --> Loader Class Initialized
INFO - 2021-04-08 19:25:19 --> Helper loaded: url_helper
INFO - 2021-04-08 19:25:19 --> Helper loaded: form_helper
INFO - 2021-04-08 19:25:19 --> Helper loaded: common_helper
INFO - 2021-04-08 19:25:19 --> Helper loaded: util_helper
INFO - 2021-04-08 19:25:19 --> Database Driver Class Initialized
DEBUG - 2021-04-08 19:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 19:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 19:25:19 --> Form Validation Class Initialized
INFO - 2021-04-08 19:25:19 --> Controller Class Initialized
INFO - 2021-04-08 19:25:19 --> Model Class Initialized
INFO - 2021-04-08 19:25:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 19:25:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 19:25:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 19:25:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 19:25:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 19:25:19 --> Final output sent to browser
DEBUG - 2021-04-08 19:25:19 --> Total execution time: 0.0466
INFO - 2021-04-08 19:25:20 --> Config Class Initialized
INFO - 2021-04-08 19:25:20 --> Hooks Class Initialized
INFO - 2021-04-08 19:25:20 --> Config Class Initialized
DEBUG - 2021-04-08 19:25:20 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:25:20 --> Hooks Class Initialized
INFO - 2021-04-08 19:25:20 --> Utf8 Class Initialized
INFO - 2021-04-08 19:25:20 --> URI Class Initialized
DEBUG - 2021-04-08 19:25:20 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:25:20 --> Utf8 Class Initialized
INFO - 2021-04-08 19:25:20 --> Router Class Initialized
INFO - 2021-04-08 19:25:20 --> URI Class Initialized
INFO - 2021-04-08 19:25:20 --> Output Class Initialized
INFO - 2021-04-08 19:25:20 --> Router Class Initialized
INFO - 2021-04-08 19:25:20 --> Security Class Initialized
DEBUG - 2021-04-08 19:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:25:20 --> Output Class Initialized
INFO - 2021-04-08 19:25:20 --> Input Class Initialized
INFO - 2021-04-08 19:25:20 --> Language Class Initialized
INFO - 2021-04-08 19:25:20 --> Security Class Initialized
ERROR - 2021-04-08 19:25:20 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-04-08 19:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:25:20 --> Input Class Initialized
INFO - 2021-04-08 19:25:20 --> Language Class Initialized
ERROR - 2021-04-08 19:25:20 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:25:20 --> Config Class Initialized
INFO - 2021-04-08 19:25:20 --> Hooks Class Initialized
DEBUG - 2021-04-08 19:25:20 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:25:20 --> Utf8 Class Initialized
INFO - 2021-04-08 19:25:20 --> URI Class Initialized
INFO - 2021-04-08 19:25:20 --> Router Class Initialized
INFO - 2021-04-08 19:25:20 --> Config Class Initialized
INFO - 2021-04-08 19:25:20 --> Hooks Class Initialized
INFO - 2021-04-08 19:25:20 --> Output Class Initialized
INFO - 2021-04-08 19:25:20 --> Security Class Initialized
DEBUG - 2021-04-08 19:25:20 --> UTF-8 Support Enabled
INFO - 2021-04-08 19:25:20 --> Utf8 Class Initialized
DEBUG - 2021-04-08 19:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:25:20 --> Input Class Initialized
INFO - 2021-04-08 19:25:20 --> Language Class Initialized
INFO - 2021-04-08 19:25:20 --> URI Class Initialized
INFO - 2021-04-08 19:25:20 --> Router Class Initialized
ERROR - 2021-04-08 19:25:20 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 19:25:20 --> Output Class Initialized
INFO - 2021-04-08 19:25:20 --> Security Class Initialized
DEBUG - 2021-04-08 19:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 19:25:20 --> Input Class Initialized
INFO - 2021-04-08 19:25:20 --> Language Class Initialized
ERROR - 2021-04-08 19:25:20 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 20:11:13 --> Config Class Initialized
INFO - 2021-04-08 20:11:13 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:11:13 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:11:13 --> Utf8 Class Initialized
INFO - 2021-04-08 20:11:13 --> URI Class Initialized
INFO - 2021-04-08 20:11:13 --> Router Class Initialized
INFO - 2021-04-08 20:11:13 --> Output Class Initialized
INFO - 2021-04-08 20:11:13 --> Security Class Initialized
DEBUG - 2021-04-08 20:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:13 --> Input Class Initialized
INFO - 2021-04-08 20:11:13 --> Language Class Initialized
ERROR - 2021-04-08 20:11:13 --> 404 Page Not Found: Admin/Permission
INFO - 2021-04-08 20:11:42 --> Config Class Initialized
INFO - 2021-04-08 20:11:42 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:11:42 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:11:42 --> Utf8 Class Initialized
INFO - 2021-04-08 20:11:42 --> URI Class Initialized
INFO - 2021-04-08 20:11:42 --> Router Class Initialized
INFO - 2021-04-08 20:11:42 --> Output Class Initialized
INFO - 2021-04-08 20:11:42 --> Security Class Initialized
DEBUG - 2021-04-08 20:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:42 --> Input Class Initialized
INFO - 2021-04-08 20:11:43 --> Language Class Initialized
INFO - 2021-04-08 20:11:43 --> Loader Class Initialized
INFO - 2021-04-08 20:11:43 --> Helper loaded: url_helper
INFO - 2021-04-08 20:11:43 --> Helper loaded: form_helper
INFO - 2021-04-08 20:11:43 --> Helper loaded: common_helper
INFO - 2021-04-08 20:11:43 --> Helper loaded: util_helper
INFO - 2021-04-08 20:11:43 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:11:43 --> Form Validation Class Initialized
INFO - 2021-04-08 20:11:43 --> Controller Class Initialized
INFO - 2021-04-08 20:11:43 --> Model Class Initialized
INFO - 2021-04-08 20:11:43 --> Model Class Initialized
INFO - 2021-04-08 20:11:43 --> Model Class Initialized
INFO - 2021-04-08 20:11:43 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:11:43 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:11:43 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/permission/role.php
INFO - 2021-04-08 20:11:43 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:11:43 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:11:43 --> Final output sent to browser
DEBUG - 2021-04-08 20:11:43 --> Total execution time: 0.1278
INFO - 2021-04-08 20:11:43 --> Config Class Initialized
INFO - 2021-04-08 20:11:43 --> Hooks Class Initialized
INFO - 2021-04-08 20:11:43 --> Config Class Initialized
INFO - 2021-04-08 20:11:43 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:11:43 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:11:43 --> Utf8 Class Initialized
INFO - 2021-04-08 20:11:43 --> URI Class Initialized
INFO - 2021-04-08 20:11:43 --> Config Class Initialized
INFO - 2021-04-08 20:11:43 --> Hooks Class Initialized
INFO - 2021-04-08 20:11:43 --> Router Class Initialized
INFO - 2021-04-08 20:11:43 --> Config Class Initialized
INFO - 2021-04-08 20:11:43 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:11:43 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:11:43 --> Output Class Initialized
INFO - 2021-04-08 20:11:43 --> Utf8 Class Initialized
INFO - 2021-04-08 20:11:43 --> URI Class Initialized
INFO - 2021-04-08 20:11:43 --> Security Class Initialized
DEBUG - 2021-04-08 20:11:43 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:11:43 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:43 --> URI Class Initialized
INFO - 2021-04-08 20:11:43 --> Input Class Initialized
INFO - 2021-04-08 20:11:43 --> Router Class Initialized
INFO - 2021-04-08 20:11:43 --> Language Class Initialized
INFO - 2021-04-08 20:11:43 --> Router Class Initialized
INFO - 2021-04-08 20:11:43 --> Output Class Initialized
ERROR - 2021-04-08 20:11:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:11:43 --> Security Class Initialized
INFO - 2021-04-08 20:11:43 --> Output Class Initialized
DEBUG - 2021-04-08 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:43 --> Input Class Initialized
INFO - 2021-04-08 20:11:43 --> Security Class Initialized
INFO - 2021-04-08 20:11:43 --> Language Class Initialized
DEBUG - 2021-04-08 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:43 --> Input Class Initialized
INFO - 2021-04-08 20:11:43 --> Language Class Initialized
ERROR - 2021-04-08 20:11:43 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-08 20:11:43 --> UTF-8 Support Enabled
ERROR - 2021-04-08 20:11:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:11:43 --> Utf8 Class Initialized
INFO - 2021-04-08 20:11:43 --> URI Class Initialized
INFO - 2021-04-08 20:11:43 --> Router Class Initialized
INFO - 2021-04-08 20:11:43 --> Output Class Initialized
INFO - 2021-04-08 20:11:43 --> Security Class Initialized
DEBUG - 2021-04-08 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:43 --> Input Class Initialized
INFO - 2021-04-08 20:11:43 --> Language Class Initialized
ERROR - 2021-04-08 20:11:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:11:49 --> Config Class Initialized
INFO - 2021-04-08 20:11:49 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:11:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:11:49 --> Utf8 Class Initialized
INFO - 2021-04-08 20:11:49 --> URI Class Initialized
INFO - 2021-04-08 20:11:49 --> Router Class Initialized
INFO - 2021-04-08 20:11:49 --> Output Class Initialized
INFO - 2021-04-08 20:11:49 --> Security Class Initialized
DEBUG - 2021-04-08 20:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:11:49 --> Input Class Initialized
INFO - 2021-04-08 20:11:49 --> Language Class Initialized
INFO - 2021-04-08 20:11:49 --> Loader Class Initialized
INFO - 2021-04-08 20:11:49 --> Helper loaded: url_helper
INFO - 2021-04-08 20:11:49 --> Helper loaded: form_helper
INFO - 2021-04-08 20:11:49 --> Helper loaded: common_helper
INFO - 2021-04-08 20:11:49 --> Helper loaded: util_helper
INFO - 2021-04-08 20:11:49 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:11:49 --> Form Validation Class Initialized
INFO - 2021-04-08 20:11:49 --> Controller Class Initialized
INFO - 2021-04-08 20:11:49 --> Model Class Initialized
INFO - 2021-04-08 20:11:49 --> Model Class Initialized
INFO - 2021-04-08 20:11:49 --> Model Class Initialized
INFO - 2021-04-08 20:11:49 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/permission/list.php
INFO - 2021-04-08 20:11:49 --> Final output sent to browser
DEBUG - 2021-04-08 20:11:49 --> Total execution time: 0.1232
INFO - 2021-04-08 20:12:04 --> Config Class Initialized
INFO - 2021-04-08 20:12:04 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:12:04 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:12:04 --> Utf8 Class Initialized
INFO - 2021-04-08 20:12:04 --> URI Class Initialized
INFO - 2021-04-08 20:12:04 --> Router Class Initialized
INFO - 2021-04-08 20:12:04 --> Output Class Initialized
INFO - 2021-04-08 20:12:04 --> Security Class Initialized
DEBUG - 2021-04-08 20:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:12:04 --> Input Class Initialized
INFO - 2021-04-08 20:12:04 --> Language Class Initialized
INFO - 2021-04-08 20:12:04 --> Loader Class Initialized
INFO - 2021-04-08 20:12:04 --> Helper loaded: url_helper
INFO - 2021-04-08 20:12:04 --> Helper loaded: form_helper
INFO - 2021-04-08 20:12:04 --> Helper loaded: common_helper
INFO - 2021-04-08 20:12:04 --> Helper loaded: util_helper
INFO - 2021-04-08 20:12:04 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:12:04 --> Form Validation Class Initialized
INFO - 2021-04-08 20:12:04 --> Controller Class Initialized
INFO - 2021-04-08 20:12:04 --> Model Class Initialized
INFO - 2021-04-08 20:12:04 --> Model Class Initialized
INFO - 2021-04-08 20:12:04 --> Model Class Initialized
INFO - 2021-04-08 20:12:04 --> Final output sent to browser
DEBUG - 2021-04-08 20:12:04 --> Total execution time: 0.1042
INFO - 2021-04-08 20:12:19 --> Config Class Initialized
INFO - 2021-04-08 20:12:19 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:12:19 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:12:19 --> Utf8 Class Initialized
INFO - 2021-04-08 20:12:19 --> URI Class Initialized
INFO - 2021-04-08 20:12:19 --> Router Class Initialized
INFO - 2021-04-08 20:12:19 --> Output Class Initialized
INFO - 2021-04-08 20:12:19 --> Security Class Initialized
DEBUG - 2021-04-08 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:12:19 --> Input Class Initialized
INFO - 2021-04-08 20:12:19 --> Language Class Initialized
INFO - 2021-04-08 20:12:19 --> Loader Class Initialized
INFO - 2021-04-08 20:12:19 --> Helper loaded: url_helper
INFO - 2021-04-08 20:12:19 --> Helper loaded: form_helper
INFO - 2021-04-08 20:12:19 --> Helper loaded: common_helper
INFO - 2021-04-08 20:12:19 --> Helper loaded: util_helper
INFO - 2021-04-08 20:12:19 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:12:19 --> Form Validation Class Initialized
INFO - 2021-04-08 20:12:19 --> Controller Class Initialized
INFO - 2021-04-08 20:12:19 --> Model Class Initialized
INFO - 2021-04-08 20:12:19 --> Model Class Initialized
INFO - 2021-04-08 20:12:19 --> Model Class Initialized
INFO - 2021-04-08 20:12:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:12:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:12:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/permission/role.php
INFO - 2021-04-08 20:12:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:12:19 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:12:19 --> Final output sent to browser
DEBUG - 2021-04-08 20:12:19 --> Total execution time: 0.0376
INFO - 2021-04-08 20:12:19 --> Config Class Initialized
INFO - 2021-04-08 20:12:19 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:12:19 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:12:19 --> Utf8 Class Initialized
INFO - 2021-04-08 20:12:19 --> URI Class Initialized
INFO - 2021-04-08 20:12:19 --> Config Class Initialized
INFO - 2021-04-08 20:12:19 --> Hooks Class Initialized
INFO - 2021-04-08 20:12:19 --> Router Class Initialized
DEBUG - 2021-04-08 20:12:19 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:12:19 --> Utf8 Class Initialized
INFO - 2021-04-08 20:12:19 --> Output Class Initialized
INFO - 2021-04-08 20:12:19 --> URI Class Initialized
INFO - 2021-04-08 20:12:19 --> Security Class Initialized
INFO - 2021-04-08 20:12:19 --> Router Class Initialized
DEBUG - 2021-04-08 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:12:19 --> Input Class Initialized
INFO - 2021-04-08 20:12:19 --> Output Class Initialized
INFO - 2021-04-08 20:12:19 --> Language Class Initialized
INFO - 2021-04-08 20:12:19 --> Security Class Initialized
ERROR - 2021-04-08 20:12:19 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-08 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:12:19 --> Input Class Initialized
INFO - 2021-04-08 20:12:19 --> Language Class Initialized
ERROR - 2021-04-08 20:12:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:12:19 --> Config Class Initialized
INFO - 2021-04-08 20:12:19 --> Hooks Class Initialized
INFO - 2021-04-08 20:12:19 --> Config Class Initialized
INFO - 2021-04-08 20:12:19 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:12:19 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:12:19 --> Utf8 Class Initialized
INFO - 2021-04-08 20:12:19 --> URI Class Initialized
DEBUG - 2021-04-08 20:12:19 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:12:19 --> Utf8 Class Initialized
INFO - 2021-04-08 20:12:19 --> Router Class Initialized
INFO - 2021-04-08 20:12:19 --> URI Class Initialized
INFO - 2021-04-08 20:12:19 --> Output Class Initialized
INFO - 2021-04-08 20:12:19 --> Router Class Initialized
INFO - 2021-04-08 20:12:19 --> Security Class Initialized
DEBUG - 2021-04-08 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:12:19 --> Input Class Initialized
INFO - 2021-04-08 20:12:19 --> Output Class Initialized
INFO - 2021-04-08 20:12:19 --> Language Class Initialized
INFO - 2021-04-08 20:12:19 --> Security Class Initialized
ERROR - 2021-04-08 20:12:19 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-08 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:12:19 --> Input Class Initialized
INFO - 2021-04-08 20:12:19 --> Language Class Initialized
ERROR - 2021-04-08 20:12:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:13:48 --> Config Class Initialized
INFO - 2021-04-08 20:13:48 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:13:48 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:13:48 --> Utf8 Class Initialized
INFO - 2021-04-08 20:13:48 --> URI Class Initialized
INFO - 2021-04-08 20:13:48 --> Router Class Initialized
INFO - 2021-04-08 20:13:48 --> Output Class Initialized
INFO - 2021-04-08 20:13:48 --> Security Class Initialized
DEBUG - 2021-04-08 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:13:48 --> Input Class Initialized
INFO - 2021-04-08 20:13:48 --> Language Class Initialized
INFO - 2021-04-08 20:13:48 --> Loader Class Initialized
INFO - 2021-04-08 20:13:48 --> Helper loaded: url_helper
INFO - 2021-04-08 20:13:48 --> Helper loaded: form_helper
INFO - 2021-04-08 20:13:48 --> Helper loaded: common_helper
INFO - 2021-04-08 20:13:48 --> Helper loaded: util_helper
INFO - 2021-04-08 20:13:48 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:13:48 --> Form Validation Class Initialized
INFO - 2021-04-08 20:13:48 --> Controller Class Initialized
INFO - 2021-04-08 20:13:48 --> Model Class Initialized
INFO - 2021-04-08 20:13:48 --> Model Class Initialized
INFO - 2021-04-08 20:13:48 --> Model Class Initialized
INFO - 2021-04-08 20:13:48 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:13:48 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:13:48 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/permission/role.php
INFO - 2021-04-08 20:13:48 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:13:48 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:13:48 --> Final output sent to browser
DEBUG - 2021-04-08 20:13:48 --> Total execution time: 0.0360
INFO - 2021-04-08 20:13:48 --> Config Class Initialized
INFO - 2021-04-08 20:13:48 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:13:48 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:13:48 --> Utf8 Class Initialized
INFO - 2021-04-08 20:13:48 --> URI Class Initialized
INFO - 2021-04-08 20:13:48 --> Config Class Initialized
INFO - 2021-04-08 20:13:48 --> Hooks Class Initialized
INFO - 2021-04-08 20:13:48 --> Router Class Initialized
DEBUG - 2021-04-08 20:13:48 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:13:48 --> Utf8 Class Initialized
INFO - 2021-04-08 20:13:48 --> Output Class Initialized
INFO - 2021-04-08 20:13:48 --> URI Class Initialized
INFO - 2021-04-08 20:13:48 --> Security Class Initialized
INFO - 2021-04-08 20:13:48 --> Router Class Initialized
DEBUG - 2021-04-08 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:13:48 --> Input Class Initialized
INFO - 2021-04-08 20:13:48 --> Language Class Initialized
INFO - 2021-04-08 20:13:48 --> Output Class Initialized
ERROR - 2021-04-08 20:13:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:13:48 --> Security Class Initialized
DEBUG - 2021-04-08 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:13:48 --> Input Class Initialized
INFO - 2021-04-08 20:13:48 --> Language Class Initialized
ERROR - 2021-04-08 20:13:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:13:48 --> Config Class Initialized
INFO - 2021-04-08 20:13:48 --> Hooks Class Initialized
INFO - 2021-04-08 20:13:48 --> Config Class Initialized
DEBUG - 2021-04-08 20:13:48 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:13:48 --> Hooks Class Initialized
INFO - 2021-04-08 20:13:48 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:13:48 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:13:48 --> URI Class Initialized
INFO - 2021-04-08 20:13:48 --> Utf8 Class Initialized
INFO - 2021-04-08 20:13:48 --> Router Class Initialized
INFO - 2021-04-08 20:13:48 --> URI Class Initialized
INFO - 2021-04-08 20:13:48 --> Output Class Initialized
INFO - 2021-04-08 20:13:48 --> Router Class Initialized
INFO - 2021-04-08 20:13:48 --> Security Class Initialized
INFO - 2021-04-08 20:13:48 --> Output Class Initialized
DEBUG - 2021-04-08 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:13:48 --> Input Class Initialized
INFO - 2021-04-08 20:13:48 --> Security Class Initialized
INFO - 2021-04-08 20:13:48 --> Language Class Initialized
DEBUG - 2021-04-08 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:13:48 --> Input Class Initialized
ERROR - 2021-04-08 20:13:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:13:48 --> Language Class Initialized
ERROR - 2021-04-08 20:13:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:14:55 --> Config Class Initialized
INFO - 2021-04-08 20:14:55 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:14:55 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:55 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:55 --> URI Class Initialized
INFO - 2021-04-08 20:14:55 --> Router Class Initialized
INFO - 2021-04-08 20:14:55 --> Output Class Initialized
INFO - 2021-04-08 20:14:55 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:55 --> Input Class Initialized
INFO - 2021-04-08 20:14:55 --> Language Class Initialized
INFO - 2021-04-08 20:14:55 --> Loader Class Initialized
INFO - 2021-04-08 20:14:55 --> Helper loaded: url_helper
INFO - 2021-04-08 20:14:55 --> Helper loaded: form_helper
INFO - 2021-04-08 20:14:55 --> Helper loaded: common_helper
INFO - 2021-04-08 20:14:55 --> Helper loaded: util_helper
INFO - 2021-04-08 20:14:55 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:14:55 --> Form Validation Class Initialized
INFO - 2021-04-08 20:14:55 --> Controller Class Initialized
INFO - 2021-04-08 20:14:55 --> Model Class Initialized
INFO - 2021-04-08 20:14:55 --> Model Class Initialized
INFO - 2021-04-08 20:14:55 --> Model Class Initialized
INFO - 2021-04-08 20:14:55 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:14:55 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:14:55 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/list.php
INFO - 2021-04-08 20:14:55 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:14:55 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:14:55 --> Final output sent to browser
DEBUG - 2021-04-08 20:14:55 --> Total execution time: 0.0930
INFO - 2021-04-08 20:14:55 --> Config Class Initialized
INFO - 2021-04-08 20:14:55 --> Hooks Class Initialized
INFO - 2021-04-08 20:14:55 --> Config Class Initialized
INFO - 2021-04-08 20:14:55 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:14:55 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:55 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:14:55 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:55 --> URI Class Initialized
INFO - 2021-04-08 20:14:55 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:55 --> URI Class Initialized
INFO - 2021-04-08 20:14:55 --> Router Class Initialized
INFO - 2021-04-08 20:14:55 --> Router Class Initialized
INFO - 2021-04-08 20:14:55 --> Output Class Initialized
INFO - 2021-04-08 20:14:55 --> Output Class Initialized
INFO - 2021-04-08 20:14:55 --> Security Class Initialized
INFO - 2021-04-08 20:14:55 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:55 --> Input Class Initialized
DEBUG - 2021-04-08 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:55 --> Input Class Initialized
INFO - 2021-04-08 20:14:55 --> Language Class Initialized
INFO - 2021-04-08 20:14:55 --> Language Class Initialized
ERROR - 2021-04-08 20:14:55 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-08 20:14:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:14:55 --> Config Class Initialized
INFO - 2021-04-08 20:14:55 --> Hooks Class Initialized
INFO - 2021-04-08 20:14:55 --> Config Class Initialized
INFO - 2021-04-08 20:14:55 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:14:55 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:55 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:14:55 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:55 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:55 --> URI Class Initialized
INFO - 2021-04-08 20:14:55 --> URI Class Initialized
INFO - 2021-04-08 20:14:55 --> Router Class Initialized
INFO - 2021-04-08 20:14:55 --> Router Class Initialized
INFO - 2021-04-08 20:14:55 --> Output Class Initialized
INFO - 2021-04-08 20:14:55 --> Security Class Initialized
INFO - 2021-04-08 20:14:55 --> Output Class Initialized
DEBUG - 2021-04-08 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:55 --> Input Class Initialized
INFO - 2021-04-08 20:14:55 --> Language Class Initialized
INFO - 2021-04-08 20:14:55 --> Security Class Initialized
ERROR - 2021-04-08 20:14:55 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-08 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:55 --> Input Class Initialized
INFO - 2021-04-08 20:14:55 --> Language Class Initialized
ERROR - 2021-04-08 20:14:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:14:58 --> Config Class Initialized
INFO - 2021-04-08 20:14:58 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:14:58 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:58 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:58 --> URI Class Initialized
INFO - 2021-04-08 20:14:58 --> Router Class Initialized
INFO - 2021-04-08 20:14:58 --> Output Class Initialized
INFO - 2021-04-08 20:14:58 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:58 --> Input Class Initialized
INFO - 2021-04-08 20:14:58 --> Language Class Initialized
INFO - 2021-04-08 20:14:58 --> Loader Class Initialized
INFO - 2021-04-08 20:14:58 --> Helper loaded: url_helper
INFO - 2021-04-08 20:14:58 --> Helper loaded: form_helper
INFO - 2021-04-08 20:14:58 --> Helper loaded: common_helper
INFO - 2021-04-08 20:14:58 --> Helper loaded: util_helper
INFO - 2021-04-08 20:14:58 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:14:58 --> Form Validation Class Initialized
INFO - 2021-04-08 20:14:58 --> Controller Class Initialized
INFO - 2021-04-08 20:14:58 --> Model Class Initialized
INFO - 2021-04-08 20:14:58 --> Model Class Initialized
INFO - 2021-04-08 20:14:58 --> Model Class Initialized
INFO - 2021-04-08 20:14:58 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:14:58 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:14:58 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/add.php
INFO - 2021-04-08 20:14:58 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:14:58 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:14:58 --> Final output sent to browser
DEBUG - 2021-04-08 20:14:58 --> Total execution time: 0.0481
INFO - 2021-04-08 20:14:58 --> Config Class Initialized
INFO - 2021-04-08 20:14:58 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:14:58 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:58 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:58 --> Config Class Initialized
INFO - 2021-04-08 20:14:58 --> Hooks Class Initialized
INFO - 2021-04-08 20:14:58 --> URI Class Initialized
INFO - 2021-04-08 20:14:58 --> Router Class Initialized
DEBUG - 2021-04-08 20:14:58 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:58 --> Output Class Initialized
INFO - 2021-04-08 20:14:58 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:58 --> URI Class Initialized
INFO - 2021-04-08 20:14:58 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:58 --> Input Class Initialized
INFO - 2021-04-08 20:14:58 --> Language Class Initialized
ERROR - 2021-04-08 20:14:58 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:14:58 --> Router Class Initialized
INFO - 2021-04-08 20:14:58 --> Output Class Initialized
INFO - 2021-04-08 20:14:58 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:58 --> Input Class Initialized
INFO - 2021-04-08 20:14:58 --> Language Class Initialized
ERROR - 2021-04-08 20:14:58 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:14:58 --> Config Class Initialized
INFO - 2021-04-08 20:14:58 --> Hooks Class Initialized
INFO - 2021-04-08 20:14:58 --> Config Class Initialized
INFO - 2021-04-08 20:14:58 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:14:58 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:58 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:14:58 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:14:58 --> URI Class Initialized
INFO - 2021-04-08 20:14:58 --> Utf8 Class Initialized
INFO - 2021-04-08 20:14:58 --> URI Class Initialized
INFO - 2021-04-08 20:14:58 --> Router Class Initialized
INFO - 2021-04-08 20:14:58 --> Output Class Initialized
INFO - 2021-04-08 20:14:58 --> Router Class Initialized
INFO - 2021-04-08 20:14:58 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:58 --> Input Class Initialized
INFO - 2021-04-08 20:14:58 --> Language Class Initialized
INFO - 2021-04-08 20:14:58 --> Output Class Initialized
ERROR - 2021-04-08 20:14:58 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:14:58 --> Security Class Initialized
DEBUG - 2021-04-08 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:14:58 --> Input Class Initialized
INFO - 2021-04-08 20:14:58 --> Language Class Initialized
ERROR - 2021-04-08 20:14:58 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:18:07 --> Config Class Initialized
INFO - 2021-04-08 20:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:07 --> URI Class Initialized
INFO - 2021-04-08 20:18:07 --> Router Class Initialized
INFO - 2021-04-08 20:18:07 --> Output Class Initialized
INFO - 2021-04-08 20:18:07 --> Security Class Initialized
DEBUG - 2021-04-08 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:07 --> Input Class Initialized
INFO - 2021-04-08 20:18:07 --> Language Class Initialized
INFO - 2021-04-08 20:18:07 --> Loader Class Initialized
INFO - 2021-04-08 20:18:07 --> Helper loaded: url_helper
INFO - 2021-04-08 20:18:07 --> Helper loaded: form_helper
INFO - 2021-04-08 20:18:07 --> Helper loaded: common_helper
INFO - 2021-04-08 20:18:07 --> Helper loaded: util_helper
INFO - 2021-04-08 20:18:07 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:18:07 --> Form Validation Class Initialized
INFO - 2021-04-08 20:18:07 --> Controller Class Initialized
INFO - 2021-04-08 20:18:07 --> Model Class Initialized
INFO - 2021-04-08 20:18:07 --> Model Class Initialized
INFO - 2021-04-08 20:18:07 --> Model Class Initialized
INFO - 2021-04-08 20:18:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:18:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:18:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/add.php
INFO - 2021-04-08 20:18:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:18:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:18:07 --> Final output sent to browser
DEBUG - 2021-04-08 20:18:07 --> Total execution time: 0.0519
INFO - 2021-04-08 20:18:07 --> Config Class Initialized
INFO - 2021-04-08 20:18:07 --> Hooks Class Initialized
INFO - 2021-04-08 20:18:07 --> Config Class Initialized
INFO - 2021-04-08 20:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:07 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:07 --> URI Class Initialized
INFO - 2021-04-08 20:18:07 --> URI Class Initialized
INFO - 2021-04-08 20:18:07 --> Router Class Initialized
INFO - 2021-04-08 20:18:07 --> Router Class Initialized
INFO - 2021-04-08 20:18:07 --> Output Class Initialized
INFO - 2021-04-08 20:18:07 --> Security Class Initialized
INFO - 2021-04-08 20:18:07 --> Output Class Initialized
DEBUG - 2021-04-08 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:07 --> Input Class Initialized
INFO - 2021-04-08 20:18:07 --> Language Class Initialized
INFO - 2021-04-08 20:18:07 --> Security Class Initialized
DEBUG - 2021-04-08 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:07 --> Input Class Initialized
ERROR - 2021-04-08 20:18:07 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:18:07 --> Language Class Initialized
ERROR - 2021-04-08 20:18:07 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:18:07 --> Config Class Initialized
INFO - 2021-04-08 20:18:07 --> Hooks Class Initialized
INFO - 2021-04-08 20:18:07 --> Config Class Initialized
INFO - 2021-04-08 20:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 20:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:07 --> URI Class Initialized
INFO - 2021-04-08 20:18:07 --> URI Class Initialized
INFO - 2021-04-08 20:18:07 --> Router Class Initialized
INFO - 2021-04-08 20:18:07 --> Router Class Initialized
INFO - 2021-04-08 20:18:07 --> Output Class Initialized
INFO - 2021-04-08 20:18:07 --> Output Class Initialized
INFO - 2021-04-08 20:18:07 --> Security Class Initialized
INFO - 2021-04-08 20:18:07 --> Security Class Initialized
DEBUG - 2021-04-08 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:07 --> Input Class Initialized
DEBUG - 2021-04-08 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:07 --> Input Class Initialized
INFO - 2021-04-08 20:18:07 --> Language Class Initialized
INFO - 2021-04-08 20:18:07 --> Language Class Initialized
ERROR - 2021-04-08 20:18:07 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-04-08 20:18:07 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:18:31 --> Config Class Initialized
INFO - 2021-04-08 20:18:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:18:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:31 --> URI Class Initialized
INFO - 2021-04-08 20:18:31 --> Router Class Initialized
INFO - 2021-04-08 20:18:31 --> Output Class Initialized
INFO - 2021-04-08 20:18:31 --> Security Class Initialized
DEBUG - 2021-04-08 20:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:31 --> Input Class Initialized
INFO - 2021-04-08 20:18:31 --> Language Class Initialized
INFO - 2021-04-08 20:18:31 --> Loader Class Initialized
INFO - 2021-04-08 20:18:31 --> Helper loaded: url_helper
INFO - 2021-04-08 20:18:31 --> Helper loaded: form_helper
INFO - 2021-04-08 20:18:31 --> Helper loaded: common_helper
INFO - 2021-04-08 20:18:31 --> Helper loaded: util_helper
INFO - 2021-04-08 20:18:31 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:18:31 --> Form Validation Class Initialized
INFO - 2021-04-08 20:18:31 --> Controller Class Initialized
INFO - 2021-04-08 20:18:31 --> Model Class Initialized
INFO - 2021-04-08 20:18:31 --> Model Class Initialized
INFO - 2021-04-08 20:18:31 --> Model Class Initialized
INFO - 2021-04-08 20:18:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:18:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:18:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/add.php
INFO - 2021-04-08 20:18:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:18:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:18:31 --> Final output sent to browser
DEBUG - 2021-04-08 20:18:31 --> Total execution time: 0.0521
INFO - 2021-04-08 20:18:31 --> Config Class Initialized
INFO - 2021-04-08 20:18:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:18:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:31 --> Config Class Initialized
INFO - 2021-04-08 20:18:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:31 --> Hooks Class Initialized
INFO - 2021-04-08 20:18:31 --> URI Class Initialized
DEBUG - 2021-04-08 20:18:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:31 --> Router Class Initialized
INFO - 2021-04-08 20:18:31 --> URI Class Initialized
INFO - 2021-04-08 20:18:31 --> Output Class Initialized
INFO - 2021-04-08 20:18:31 --> Router Class Initialized
INFO - 2021-04-08 20:18:31 --> Security Class Initialized
INFO - 2021-04-08 20:18:31 --> Output Class Initialized
DEBUG - 2021-04-08 20:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:31 --> Input Class Initialized
INFO - 2021-04-08 20:18:31 --> Security Class Initialized
INFO - 2021-04-08 20:18:31 --> Language Class Initialized
DEBUG - 2021-04-08 20:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:31 --> Input Class Initialized
INFO - 2021-04-08 20:18:31 --> Language Class Initialized
ERROR - 2021-04-08 20:18:31 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-04-08 20:18:31 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:18:31 --> Config Class Initialized
INFO - 2021-04-08 20:18:31 --> Hooks Class Initialized
INFO - 2021-04-08 20:18:31 --> Config Class Initialized
INFO - 2021-04-08 20:18:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:18:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:31 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:18:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:18:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:18:31 --> URI Class Initialized
INFO - 2021-04-08 20:18:31 --> URI Class Initialized
INFO - 2021-04-08 20:18:31 --> Router Class Initialized
INFO - 2021-04-08 20:18:31 --> Router Class Initialized
INFO - 2021-04-08 20:18:31 --> Output Class Initialized
INFO - 2021-04-08 20:18:31 --> Output Class Initialized
INFO - 2021-04-08 20:18:31 --> Security Class Initialized
INFO - 2021-04-08 20:18:31 --> Security Class Initialized
DEBUG - 2021-04-08 20:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 20:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:18:31 --> Input Class Initialized
INFO - 2021-04-08 20:18:31 --> Input Class Initialized
INFO - 2021-04-08 20:18:31 --> Language Class Initialized
INFO - 2021-04-08 20:18:31 --> Language Class Initialized
ERROR - 2021-04-08 20:18:31 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-04-08 20:18:31 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:19:24 --> Config Class Initialized
INFO - 2021-04-08 20:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:24 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:24 --> URI Class Initialized
INFO - 2021-04-08 20:19:24 --> Router Class Initialized
INFO - 2021-04-08 20:19:24 --> Output Class Initialized
INFO - 2021-04-08 20:19:24 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:24 --> Input Class Initialized
INFO - 2021-04-08 20:19:24 --> Language Class Initialized
INFO - 2021-04-08 20:19:24 --> Loader Class Initialized
INFO - 2021-04-08 20:19:24 --> Helper loaded: url_helper
INFO - 2021-04-08 20:19:24 --> Helper loaded: form_helper
INFO - 2021-04-08 20:19:24 --> Helper loaded: common_helper
INFO - 2021-04-08 20:19:24 --> Helper loaded: util_helper
INFO - 2021-04-08 20:19:24 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:19:24 --> Form Validation Class Initialized
INFO - 2021-04-08 20:19:24 --> Controller Class Initialized
INFO - 2021-04-08 20:19:24 --> Model Class Initialized
INFO - 2021-04-08 20:19:24 --> Model Class Initialized
INFO - 2021-04-08 20:19:24 --> Model Class Initialized
INFO - 2021-04-08 20:19:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-08 20:19:24 --> Config Class Initialized
INFO - 2021-04-08 20:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:24 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:24 --> URI Class Initialized
INFO - 2021-04-08 20:19:24 --> Router Class Initialized
INFO - 2021-04-08 20:19:24 --> Output Class Initialized
INFO - 2021-04-08 20:19:24 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:24 --> Input Class Initialized
INFO - 2021-04-08 20:19:24 --> Language Class Initialized
INFO - 2021-04-08 20:19:24 --> Loader Class Initialized
INFO - 2021-04-08 20:19:24 --> Helper loaded: url_helper
INFO - 2021-04-08 20:19:24 --> Helper loaded: form_helper
INFO - 2021-04-08 20:19:24 --> Helper loaded: common_helper
INFO - 2021-04-08 20:19:24 --> Helper loaded: util_helper
INFO - 2021-04-08 20:19:24 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:19:24 --> Form Validation Class Initialized
INFO - 2021-04-08 20:19:24 --> Controller Class Initialized
INFO - 2021-04-08 20:19:24 --> Model Class Initialized
INFO - 2021-04-08 20:19:24 --> Model Class Initialized
INFO - 2021-04-08 20:19:24 --> Model Class Initialized
INFO - 2021-04-08 20:19:24 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:19:24 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:19:24 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/add.php
INFO - 2021-04-08 20:19:24 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:19:24 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:19:24 --> Final output sent to browser
DEBUG - 2021-04-08 20:19:24 --> Total execution time: 0.0499
INFO - 2021-04-08 20:19:24 --> Config Class Initialized
INFO - 2021-04-08 20:19:24 --> Hooks Class Initialized
INFO - 2021-04-08 20:19:24 --> Config Class Initialized
INFO - 2021-04-08 20:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:24 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:24 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:24 --> URI Class Initialized
INFO - 2021-04-08 20:19:24 --> URI Class Initialized
INFO - 2021-04-08 20:19:24 --> Router Class Initialized
INFO - 2021-04-08 20:19:24 --> Router Class Initialized
INFO - 2021-04-08 20:19:24 --> Output Class Initialized
INFO - 2021-04-08 20:19:24 --> Output Class Initialized
INFO - 2021-04-08 20:19:24 --> Security Class Initialized
INFO - 2021-04-08 20:19:24 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:24 --> Input Class Initialized
INFO - 2021-04-08 20:19:24 --> Input Class Initialized
INFO - 2021-04-08 20:19:24 --> Language Class Initialized
INFO - 2021-04-08 20:19:24 --> Language Class Initialized
ERROR - 2021-04-08 20:19:24 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-04-08 20:19:24 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:19:24 --> Config Class Initialized
INFO - 2021-04-08 20:19:24 --> Hooks Class Initialized
INFO - 2021-04-08 20:19:24 --> Config Class Initialized
INFO - 2021-04-08 20:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 20:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:24 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:24 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:24 --> URI Class Initialized
INFO - 2021-04-08 20:19:24 --> URI Class Initialized
INFO - 2021-04-08 20:19:24 --> Router Class Initialized
INFO - 2021-04-08 20:19:24 --> Router Class Initialized
INFO - 2021-04-08 20:19:24 --> Output Class Initialized
INFO - 2021-04-08 20:19:24 --> Output Class Initialized
INFO - 2021-04-08 20:19:24 --> Security Class Initialized
INFO - 2021-04-08 20:19:24 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:24 --> Input Class Initialized
DEBUG - 2021-04-08 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:24 --> Input Class Initialized
INFO - 2021-04-08 20:19:24 --> Language Class Initialized
INFO - 2021-04-08 20:19:24 --> Language Class Initialized
ERROR - 2021-04-08 20:19:24 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-04-08 20:19:24 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-04-08 20:19:31 --> Config Class Initialized
INFO - 2021-04-08 20:19:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:31 --> URI Class Initialized
INFO - 2021-04-08 20:19:31 --> Router Class Initialized
INFO - 2021-04-08 20:19:31 --> Output Class Initialized
INFO - 2021-04-08 20:19:31 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:31 --> Input Class Initialized
INFO - 2021-04-08 20:19:31 --> Language Class Initialized
INFO - 2021-04-08 20:19:31 --> Loader Class Initialized
INFO - 2021-04-08 20:19:31 --> Helper loaded: url_helper
INFO - 2021-04-08 20:19:31 --> Helper loaded: form_helper
INFO - 2021-04-08 20:19:31 --> Helper loaded: common_helper
INFO - 2021-04-08 20:19:31 --> Helper loaded: util_helper
INFO - 2021-04-08 20:19:31 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:19:31 --> Form Validation Class Initialized
INFO - 2021-04-08 20:19:31 --> Controller Class Initialized
INFO - 2021-04-08 20:19:31 --> Model Class Initialized
INFO - 2021-04-08 20:19:31 --> Model Class Initialized
INFO - 2021-04-08 20:19:31 --> Model Class Initialized
INFO - 2021-04-08 20:19:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:19:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:19:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/list.php
INFO - 2021-04-08 20:19:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:19:31 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:19:31 --> Final output sent to browser
DEBUG - 2021-04-08 20:19:31 --> Total execution time: 0.0498
INFO - 2021-04-08 20:19:31 --> Config Class Initialized
INFO - 2021-04-08 20:19:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:31 --> URI Class Initialized
INFO - 2021-04-08 20:19:31 --> Config Class Initialized
INFO - 2021-04-08 20:19:31 --> Hooks Class Initialized
INFO - 2021-04-08 20:19:31 --> Router Class Initialized
DEBUG - 2021-04-08 20:19:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:31 --> Output Class Initialized
INFO - 2021-04-08 20:19:31 --> URI Class Initialized
INFO - 2021-04-08 20:19:31 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:31 --> Input Class Initialized
INFO - 2021-04-08 20:19:31 --> Router Class Initialized
INFO - 2021-04-08 20:19:31 --> Language Class Initialized
INFO - 2021-04-08 20:19:31 --> Output Class Initialized
ERROR - 2021-04-08 20:19:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:19:31 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:31 --> Input Class Initialized
INFO - 2021-04-08 20:19:31 --> Language Class Initialized
ERROR - 2021-04-08 20:19:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:19:31 --> Config Class Initialized
INFO - 2021-04-08 20:19:31 --> Hooks Class Initialized
INFO - 2021-04-08 20:19:31 --> Config Class Initialized
INFO - 2021-04-08 20:19:31 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:31 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:19:31 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:31 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:31 --> URI Class Initialized
INFO - 2021-04-08 20:19:31 --> URI Class Initialized
INFO - 2021-04-08 20:19:31 --> Router Class Initialized
INFO - 2021-04-08 20:19:31 --> Router Class Initialized
INFO - 2021-04-08 20:19:31 --> Output Class Initialized
INFO - 2021-04-08 20:19:31 --> Output Class Initialized
INFO - 2021-04-08 20:19:31 --> Security Class Initialized
INFO - 2021-04-08 20:19:31 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:31 --> Input Class Initialized
INFO - 2021-04-08 20:19:31 --> Language Class Initialized
DEBUG - 2021-04-08 20:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:31 --> Input Class Initialized
ERROR - 2021-04-08 20:19:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:19:31 --> Language Class Initialized
ERROR - 2021-04-08 20:19:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:19:37 --> Config Class Initialized
INFO - 2021-04-08 20:19:37 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:37 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:37 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:37 --> URI Class Initialized
INFO - 2021-04-08 20:19:37 --> Router Class Initialized
INFO - 2021-04-08 20:19:37 --> Output Class Initialized
INFO - 2021-04-08 20:19:37 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:37 --> Input Class Initialized
INFO - 2021-04-08 20:19:37 --> Language Class Initialized
INFO - 2021-04-08 20:19:37 --> Loader Class Initialized
INFO - 2021-04-08 20:19:37 --> Helper loaded: url_helper
INFO - 2021-04-08 20:19:37 --> Helper loaded: form_helper
INFO - 2021-04-08 20:19:37 --> Helper loaded: common_helper
INFO - 2021-04-08 20:19:37 --> Helper loaded: util_helper
INFO - 2021-04-08 20:19:37 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:19:37 --> Form Validation Class Initialized
INFO - 2021-04-08 20:19:37 --> Controller Class Initialized
INFO - 2021-04-08 20:19:37 --> Model Class Initialized
INFO - 2021-04-08 20:19:37 --> Model Class Initialized
INFO - 2021-04-08 20:19:37 --> Model Class Initialized
INFO - 2021-04-08 20:19:37 --> Final output sent to browser
DEBUG - 2021-04-08 20:19:37 --> Total execution time: 0.0704
INFO - 2021-04-08 20:19:41 --> Config Class Initialized
INFO - 2021-04-08 20:19:41 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:41 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:41 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:41 --> URI Class Initialized
INFO - 2021-04-08 20:19:41 --> Router Class Initialized
INFO - 2021-04-08 20:19:41 --> Output Class Initialized
INFO - 2021-04-08 20:19:41 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:41 --> Input Class Initialized
INFO - 2021-04-08 20:19:41 --> Language Class Initialized
INFO - 2021-04-08 20:19:41 --> Loader Class Initialized
INFO - 2021-04-08 20:19:41 --> Helper loaded: url_helper
INFO - 2021-04-08 20:19:41 --> Helper loaded: form_helper
INFO - 2021-04-08 20:19:41 --> Helper loaded: common_helper
INFO - 2021-04-08 20:19:41 --> Helper loaded: util_helper
INFO - 2021-04-08 20:19:41 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:19:41 --> Form Validation Class Initialized
INFO - 2021-04-08 20:19:41 --> Controller Class Initialized
INFO - 2021-04-08 20:19:41 --> Model Class Initialized
INFO - 2021-04-08 20:19:41 --> Model Class Initialized
INFO - 2021-04-08 20:19:41 --> Model Class Initialized
INFO - 2021-04-08 20:19:41 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:19:41 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:19:41 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/list.php
INFO - 2021-04-08 20:19:41 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:19:41 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:19:41 --> Final output sent to browser
DEBUG - 2021-04-08 20:19:41 --> Total execution time: 0.0381
INFO - 2021-04-08 20:19:41 --> Config Class Initialized
INFO - 2021-04-08 20:19:41 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:41 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:41 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:41 --> Config Class Initialized
INFO - 2021-04-08 20:19:41 --> Hooks Class Initialized
INFO - 2021-04-08 20:19:41 --> URI Class Initialized
INFO - 2021-04-08 20:19:41 --> Router Class Initialized
DEBUG - 2021-04-08 20:19:41 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:41 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:41 --> URI Class Initialized
INFO - 2021-04-08 20:19:41 --> Output Class Initialized
INFO - 2021-04-08 20:19:41 --> Router Class Initialized
INFO - 2021-04-08 20:19:41 --> Security Class Initialized
INFO - 2021-04-08 20:19:41 --> Output Class Initialized
DEBUG - 2021-04-08 20:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:41 --> Input Class Initialized
INFO - 2021-04-08 20:19:41 --> Security Class Initialized
INFO - 2021-04-08 20:19:41 --> Language Class Initialized
DEBUG - 2021-04-08 20:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:41 --> Input Class Initialized
INFO - 2021-04-08 20:19:41 --> Language Class Initialized
ERROR - 2021-04-08 20:19:41 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-08 20:19:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:19:41 --> Config Class Initialized
INFO - 2021-04-08 20:19:41 --> Hooks Class Initialized
INFO - 2021-04-08 20:19:41 --> Config Class Initialized
INFO - 2021-04-08 20:19:41 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:41 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:41 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:19:41 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:41 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:41 --> URI Class Initialized
INFO - 2021-04-08 20:19:41 --> URI Class Initialized
INFO - 2021-04-08 20:19:41 --> Router Class Initialized
INFO - 2021-04-08 20:19:41 --> Router Class Initialized
INFO - 2021-04-08 20:19:41 --> Output Class Initialized
INFO - 2021-04-08 20:19:41 --> Output Class Initialized
INFO - 2021-04-08 20:19:41 --> Security Class Initialized
INFO - 2021-04-08 20:19:41 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 20:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:41 --> Input Class Initialized
INFO - 2021-04-08 20:19:41 --> Input Class Initialized
INFO - 2021-04-08 20:19:41 --> Language Class Initialized
INFO - 2021-04-08 20:19:41 --> Language Class Initialized
ERROR - 2021-04-08 20:19:41 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-08 20:19:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:19:49 --> Config Class Initialized
INFO - 2021-04-08 20:19:49 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:19:49 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:19:49 --> Utf8 Class Initialized
INFO - 2021-04-08 20:19:49 --> URI Class Initialized
INFO - 2021-04-08 20:19:49 --> Router Class Initialized
INFO - 2021-04-08 20:19:49 --> Output Class Initialized
INFO - 2021-04-08 20:19:49 --> Security Class Initialized
DEBUG - 2021-04-08 20:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:19:49 --> Input Class Initialized
INFO - 2021-04-08 20:19:49 --> Language Class Initialized
INFO - 2021-04-08 20:19:49 --> Loader Class Initialized
INFO - 2021-04-08 20:19:49 --> Helper loaded: url_helper
INFO - 2021-04-08 20:19:49 --> Helper loaded: form_helper
INFO - 2021-04-08 20:19:49 --> Helper loaded: common_helper
INFO - 2021-04-08 20:19:49 --> Helper loaded: util_helper
INFO - 2021-04-08 20:19:49 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:19:49 --> Form Validation Class Initialized
INFO - 2021-04-08 20:19:49 --> Controller Class Initialized
INFO - 2021-04-08 20:19:49 --> Model Class Initialized
INFO - 2021-04-08 20:19:49 --> Model Class Initialized
INFO - 2021-04-08 20:19:49 --> Model Class Initialized
INFO - 2021-04-08 20:19:49 --> Final output sent to browser
DEBUG - 2021-04-08 20:19:49 --> Total execution time: 0.0745
INFO - 2021-04-08 20:20:07 --> Config Class Initialized
INFO - 2021-04-08 20:20:07 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:07 --> URI Class Initialized
INFO - 2021-04-08 20:20:07 --> Router Class Initialized
INFO - 2021-04-08 20:20:07 --> Output Class Initialized
INFO - 2021-04-08 20:20:07 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:07 --> Input Class Initialized
INFO - 2021-04-08 20:20:07 --> Language Class Initialized
INFO - 2021-04-08 20:20:07 --> Loader Class Initialized
INFO - 2021-04-08 20:20:07 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:07 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:07 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:07 --> Controller Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:07 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:07 --> Total execution time: 0.0429
INFO - 2021-04-08 20:20:07 --> Config Class Initialized
INFO - 2021-04-08 20:20:07 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:07 --> Config Class Initialized
INFO - 2021-04-08 20:20:07 --> URI Class Initialized
INFO - 2021-04-08 20:20:07 --> Hooks Class Initialized
INFO - 2021-04-08 20:20:07 --> Router Class Initialized
DEBUG - 2021-04-08 20:20:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:07 --> Output Class Initialized
INFO - 2021-04-08 20:20:07 --> URI Class Initialized
INFO - 2021-04-08 20:20:07 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:07 --> Router Class Initialized
INFO - 2021-04-08 20:20:07 --> Input Class Initialized
INFO - 2021-04-08 20:20:07 --> Language Class Initialized
INFO - 2021-04-08 20:20:07 --> Output Class Initialized
INFO - 2021-04-08 20:20:07 --> Security Class Initialized
INFO - 2021-04-08 20:20:07 --> Loader Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:07 --> Input Class Initialized
INFO - 2021-04-08 20:20:07 --> Language Class Initialized
INFO - 2021-04-08 20:20:07 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:07 --> Loader Class Initialized
INFO - 2021-04-08 20:20:07 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:07 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:07 --> Database Driver Class Initialized
INFO - 2021-04-08 20:20:07 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:07 --> Controller Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:07 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:07 --> Total execution time: 0.0413
INFO - 2021-04-08 20:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:07 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:07 --> Controller Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:07 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:07 --> Total execution time: 0.0514
INFO - 2021-04-08 20:20:07 --> Config Class Initialized
INFO - 2021-04-08 20:20:07 --> Hooks Class Initialized
INFO - 2021-04-08 20:20:07 --> Config Class Initialized
INFO - 2021-04-08 20:20:07 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:07 --> URI Class Initialized
DEBUG - 2021-04-08 20:20:07 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:07 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:07 --> URI Class Initialized
INFO - 2021-04-08 20:20:07 --> Router Class Initialized
INFO - 2021-04-08 20:20:07 --> Router Class Initialized
INFO - 2021-04-08 20:20:07 --> Output Class Initialized
INFO - 2021-04-08 20:20:07 --> Output Class Initialized
INFO - 2021-04-08 20:20:07 --> Security Class Initialized
INFO - 2021-04-08 20:20:07 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 20:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:07 --> Input Class Initialized
INFO - 2021-04-08 20:20:07 --> Input Class Initialized
INFO - 2021-04-08 20:20:07 --> Language Class Initialized
INFO - 2021-04-08 20:20:07 --> Language Class Initialized
INFO - 2021-04-08 20:20:07 --> Loader Class Initialized
INFO - 2021-04-08 20:20:07 --> Loader Class Initialized
INFO - 2021-04-08 20:20:07 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:07 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:07 --> Database Driver Class Initialized
INFO - 2021-04-08 20:20:07 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:07 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:07 --> Controller Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
DEBUG - 2021-04-08 20:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:07 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:07 --> Total execution time: 0.0474
INFO - 2021-04-08 20:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:07 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:07 --> Controller Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> Model Class Initialized
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:07 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:07 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:07 --> Total execution time: 0.0660
INFO - 2021-04-08 20:20:14 --> Config Class Initialized
INFO - 2021-04-08 20:20:14 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:14 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:14 --> URI Class Initialized
INFO - 2021-04-08 20:20:14 --> Router Class Initialized
INFO - 2021-04-08 20:20:14 --> Output Class Initialized
INFO - 2021-04-08 20:20:14 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:14 --> Input Class Initialized
INFO - 2021-04-08 20:20:14 --> Language Class Initialized
INFO - 2021-04-08 20:20:14 --> Loader Class Initialized
INFO - 2021-04-08 20:20:14 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:14 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:14 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:14 --> Controller Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-08 20:20:14 --> Config Class Initialized
INFO - 2021-04-08 20:20:14 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:14 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:14 --> URI Class Initialized
INFO - 2021-04-08 20:20:14 --> Router Class Initialized
INFO - 2021-04-08 20:20:14 --> Output Class Initialized
INFO - 2021-04-08 20:20:14 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:14 --> Input Class Initialized
INFO - 2021-04-08 20:20:14 --> Language Class Initialized
INFO - 2021-04-08 20:20:14 --> Loader Class Initialized
INFO - 2021-04-08 20:20:14 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:14 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:14 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:14 --> Controller Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:14 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:14 --> Total execution time: 0.0396
INFO - 2021-04-08 20:20:14 --> Config Class Initialized
INFO - 2021-04-08 20:20:14 --> Hooks Class Initialized
INFO - 2021-04-08 20:20:14 --> Config Class Initialized
INFO - 2021-04-08 20:20:14 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:14 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:14 --> URI Class Initialized
INFO - 2021-04-08 20:20:14 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:14 --> URI Class Initialized
INFO - 2021-04-08 20:20:14 --> Router Class Initialized
INFO - 2021-04-08 20:20:14 --> Router Class Initialized
INFO - 2021-04-08 20:20:14 --> Output Class Initialized
INFO - 2021-04-08 20:20:14 --> Output Class Initialized
INFO - 2021-04-08 20:20:14 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:14 --> Input Class Initialized
INFO - 2021-04-08 20:20:14 --> Security Class Initialized
INFO - 2021-04-08 20:20:14 --> Language Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:14 --> Input Class Initialized
INFO - 2021-04-08 20:20:14 --> Language Class Initialized
INFO - 2021-04-08 20:20:14 --> Loader Class Initialized
INFO - 2021-04-08 20:20:14 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:14 --> Loader Class Initialized
INFO - 2021-04-08 20:20:14 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:14 --> Database Driver Class Initialized
INFO - 2021-04-08 20:20:14 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-04-08 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:14 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:14 --> Controller Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:14 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:14 --> Total execution time: 0.0466
INFO - 2021-04-08 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:14 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:14 --> Controller Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:14 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:14 --> Total execution time: 0.0608
INFO - 2021-04-08 20:20:14 --> Config Class Initialized
INFO - 2021-04-08 20:20:14 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:14 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:14 --> Config Class Initialized
INFO - 2021-04-08 20:20:14 --> Hooks Class Initialized
INFO - 2021-04-08 20:20:14 --> URI Class Initialized
DEBUG - 2021-04-08 20:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:14 --> Router Class Initialized
INFO - 2021-04-08 20:20:14 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:14 --> URI Class Initialized
INFO - 2021-04-08 20:20:14 --> Output Class Initialized
INFO - 2021-04-08 20:20:14 --> Router Class Initialized
INFO - 2021-04-08 20:20:14 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:14 --> Output Class Initialized
INFO - 2021-04-08 20:20:14 --> Input Class Initialized
INFO - 2021-04-08 20:20:14 --> Language Class Initialized
INFO - 2021-04-08 20:20:14 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:14 --> Input Class Initialized
INFO - 2021-04-08 20:20:14 --> Loader Class Initialized
INFO - 2021-04-08 20:20:14 --> Language Class Initialized
INFO - 2021-04-08 20:20:14 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:14 --> Loader Class Initialized
INFO - 2021-04-08 20:20:14 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:14 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:14 --> Database Driver Class Initialized
INFO - 2021-04-08 20:20:14 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-04-08 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:14 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:14 --> Controller Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:14 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:14 --> Total execution time: 0.0453
INFO - 2021-04-08 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:14 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:14 --> Controller Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> Model Class Initialized
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/edit.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:14 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:14 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:14 --> Total execution time: 0.0654
INFO - 2021-04-08 20:20:16 --> Config Class Initialized
INFO - 2021-04-08 20:20:16 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:16 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:16 --> URI Class Initialized
INFO - 2021-04-08 20:20:16 --> Router Class Initialized
INFO - 2021-04-08 20:20:16 --> Output Class Initialized
INFO - 2021-04-08 20:20:16 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:16 --> Input Class Initialized
INFO - 2021-04-08 20:20:16 --> Language Class Initialized
INFO - 2021-04-08 20:20:16 --> Loader Class Initialized
INFO - 2021-04-08 20:20:16 --> Helper loaded: url_helper
INFO - 2021-04-08 20:20:16 --> Helper loaded: form_helper
INFO - 2021-04-08 20:20:16 --> Helper loaded: common_helper
INFO - 2021-04-08 20:20:16 --> Helper loaded: util_helper
INFO - 2021-04-08 20:20:16 --> Database Driver Class Initialized
DEBUG - 2021-04-08 20:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 20:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 20:20:16 --> Form Validation Class Initialized
INFO - 2021-04-08 20:20:16 --> Controller Class Initialized
INFO - 2021-04-08 20:20:16 --> Model Class Initialized
INFO - 2021-04-08 20:20:16 --> Model Class Initialized
INFO - 2021-04-08 20:20:16 --> Model Class Initialized
INFO - 2021-04-08 20:20:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 20:20:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 20:20:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/list.php
INFO - 2021-04-08 20:20:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 20:20:16 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 20:20:16 --> Final output sent to browser
DEBUG - 2021-04-08 20:20:16 --> Total execution time: 0.0342
INFO - 2021-04-08 20:20:16 --> Config Class Initialized
INFO - 2021-04-08 20:20:16 --> Hooks Class Initialized
INFO - 2021-04-08 20:20:16 --> Config Class Initialized
INFO - 2021-04-08 20:20:16 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 20:20:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:16 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:16 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:16 --> URI Class Initialized
INFO - 2021-04-08 20:20:16 --> URI Class Initialized
INFO - 2021-04-08 20:20:16 --> Router Class Initialized
INFO - 2021-04-08 20:20:16 --> Router Class Initialized
INFO - 2021-04-08 20:20:16 --> Output Class Initialized
INFO - 2021-04-08 20:20:16 --> Output Class Initialized
INFO - 2021-04-08 20:20:16 --> Security Class Initialized
INFO - 2021-04-08 20:20:16 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:16 --> Input Class Initialized
INFO - 2021-04-08 20:20:16 --> Input Class Initialized
INFO - 2021-04-08 20:20:16 --> Language Class Initialized
INFO - 2021-04-08 20:20:16 --> Language Class Initialized
ERROR - 2021-04-08 20:20:16 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-08 20:20:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 20:20:16 --> Config Class Initialized
INFO - 2021-04-08 20:20:16 --> Hooks Class Initialized
INFO - 2021-04-08 20:20:16 --> Config Class Initialized
INFO - 2021-04-08 20:20:16 --> Hooks Class Initialized
DEBUG - 2021-04-08 20:20:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:16 --> Utf8 Class Initialized
DEBUG - 2021-04-08 20:20:16 --> UTF-8 Support Enabled
INFO - 2021-04-08 20:20:16 --> Utf8 Class Initialized
INFO - 2021-04-08 20:20:16 --> URI Class Initialized
INFO - 2021-04-08 20:20:16 --> URI Class Initialized
INFO - 2021-04-08 20:20:16 --> Router Class Initialized
INFO - 2021-04-08 20:20:16 --> Router Class Initialized
INFO - 2021-04-08 20:20:16 --> Output Class Initialized
INFO - 2021-04-08 20:20:16 --> Output Class Initialized
INFO - 2021-04-08 20:20:16 --> Security Class Initialized
INFO - 2021-04-08 20:20:16 --> Security Class Initialized
DEBUG - 2021-04-08 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:16 --> Input Class Initialized
INFO - 2021-04-08 20:20:16 --> Language Class Initialized
DEBUG - 2021-04-08 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 20:20:16 --> Input Class Initialized
INFO - 2021-04-08 20:20:16 --> Language Class Initialized
ERROR - 2021-04-08 20:20:16 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-08 20:20:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:45 --> Config Class Initialized
INFO - 2021-04-08 21:07:45 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:45 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:45 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:45 --> URI Class Initialized
INFO - 2021-04-08 21:07:45 --> Router Class Initialized
INFO - 2021-04-08 21:07:45 --> Output Class Initialized
INFO - 2021-04-08 21:07:45 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:45 --> Input Class Initialized
INFO - 2021-04-08 21:07:45 --> Language Class Initialized
INFO - 2021-04-08 21:07:45 --> Loader Class Initialized
INFO - 2021-04-08 21:07:45 --> Helper loaded: url_helper
INFO - 2021-04-08 21:07:45 --> Helper loaded: form_helper
INFO - 2021-04-08 21:07:45 --> Helper loaded: common_helper
INFO - 2021-04-08 21:07:45 --> Helper loaded: util_helper
INFO - 2021-04-08 21:07:45 --> Database Driver Class Initialized
DEBUG - 2021-04-08 21:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 21:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 21:07:45 --> Form Validation Class Initialized
INFO - 2021-04-08 21:07:45 --> Controller Class Initialized
INFO - 2021-04-08 21:07:45 --> Model Class Initialized
INFO - 2021-04-08 21:07:45 --> Model Class Initialized
INFO - 2021-04-08 21:07:45 --> Model Class Initialized
INFO - 2021-04-08 21:07:45 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 21:07:45 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 21:07:45 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/list.php
INFO - 2021-04-08 21:07:45 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 21:07:45 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 21:07:45 --> Final output sent to browser
DEBUG - 2021-04-08 21:07:45 --> Total execution time: 0.0386
INFO - 2021-04-08 21:07:45 --> Config Class Initialized
INFO - 2021-04-08 21:07:45 --> Hooks Class Initialized
INFO - 2021-04-08 21:07:45 --> Config Class Initialized
INFO - 2021-04-08 21:07:45 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:45 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:45 --> Utf8 Class Initialized
DEBUG - 2021-04-08 21:07:45 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:45 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:45 --> URI Class Initialized
INFO - 2021-04-08 21:07:45 --> URI Class Initialized
INFO - 2021-04-08 21:07:45 --> Router Class Initialized
INFO - 2021-04-08 21:07:45 --> Router Class Initialized
INFO - 2021-04-08 21:07:45 --> Output Class Initialized
INFO - 2021-04-08 21:07:45 --> Security Class Initialized
INFO - 2021-04-08 21:07:45 --> Output Class Initialized
DEBUG - 2021-04-08 21:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:45 --> Security Class Initialized
INFO - 2021-04-08 21:07:45 --> Input Class Initialized
INFO - 2021-04-08 21:07:45 --> Language Class Initialized
ERROR - 2021-04-08 21:07:45 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-08 21:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:45 --> Input Class Initialized
INFO - 2021-04-08 21:07:45 --> Language Class Initialized
ERROR - 2021-04-08 21:07:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:45 --> Config Class Initialized
INFO - 2021-04-08 21:07:45 --> Config Class Initialized
INFO - 2021-04-08 21:07:45 --> Hooks Class Initialized
INFO - 2021-04-08 21:07:45 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 21:07:45 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:45 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:45 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:45 --> URI Class Initialized
INFO - 2021-04-08 21:07:45 --> URI Class Initialized
INFO - 2021-04-08 21:07:45 --> Router Class Initialized
INFO - 2021-04-08 21:07:45 --> Router Class Initialized
INFO - 2021-04-08 21:07:45 --> Output Class Initialized
INFO - 2021-04-08 21:07:45 --> Output Class Initialized
INFO - 2021-04-08 21:07:45 --> Security Class Initialized
INFO - 2021-04-08 21:07:45 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 21:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:45 --> Input Class Initialized
INFO - 2021-04-08 21:07:45 --> Input Class Initialized
INFO - 2021-04-08 21:07:45 --> Language Class Initialized
INFO - 2021-04-08 21:07:45 --> Language Class Initialized
ERROR - 2021-04-08 21:07:45 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-08 21:07:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:47 --> Config Class Initialized
INFO - 2021-04-08 21:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:47 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:47 --> URI Class Initialized
INFO - 2021-04-08 21:07:47 --> Router Class Initialized
INFO - 2021-04-08 21:07:47 --> Output Class Initialized
INFO - 2021-04-08 21:07:47 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:47 --> Input Class Initialized
INFO - 2021-04-08 21:07:47 --> Language Class Initialized
INFO - 2021-04-08 21:07:47 --> Loader Class Initialized
INFO - 2021-04-08 21:07:47 --> Helper loaded: url_helper
INFO - 2021-04-08 21:07:47 --> Helper loaded: form_helper
INFO - 2021-04-08 21:07:47 --> Helper loaded: common_helper
INFO - 2021-04-08 21:07:47 --> Helper loaded: util_helper
INFO - 2021-04-08 21:07:47 --> Database Driver Class Initialized
DEBUG - 2021-04-08 21:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 21:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 21:07:47 --> Form Validation Class Initialized
INFO - 2021-04-08 21:07:47 --> Controller Class Initialized
INFO - 2021-04-08 21:07:47 --> Model Class Initialized
INFO - 2021-04-08 21:07:47 --> Model Class Initialized
INFO - 2021-04-08 21:07:47 --> Model Class Initialized
INFO - 2021-04-08 21:07:47 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 21:07:47 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 21:07:47 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/user/list.php
INFO - 2021-04-08 21:07:47 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 21:07:47 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 21:07:47 --> Final output sent to browser
DEBUG - 2021-04-08 21:07:47 --> Total execution time: 0.0509
INFO - 2021-04-08 21:07:47 --> Config Class Initialized
INFO - 2021-04-08 21:07:47 --> Hooks Class Initialized
INFO - 2021-04-08 21:07:47 --> Config Class Initialized
INFO - 2021-04-08 21:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:47 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:47 --> URI Class Initialized
DEBUG - 2021-04-08 21:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:47 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:47 --> Router Class Initialized
INFO - 2021-04-08 21:07:47 --> URI Class Initialized
INFO - 2021-04-08 21:07:47 --> Router Class Initialized
INFO - 2021-04-08 21:07:47 --> Output Class Initialized
INFO - 2021-04-08 21:07:47 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:47 --> Input Class Initialized
INFO - 2021-04-08 21:07:47 --> Language Class Initialized
ERROR - 2021-04-08 21:07:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:47 --> Output Class Initialized
INFO - 2021-04-08 21:07:47 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:47 --> Input Class Initialized
INFO - 2021-04-08 21:07:47 --> Language Class Initialized
ERROR - 2021-04-08 21:07:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:47 --> Config Class Initialized
INFO - 2021-04-08 21:07:47 --> Hooks Class Initialized
INFO - 2021-04-08 21:07:47 --> Config Class Initialized
INFO - 2021-04-08 21:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:47 --> Utf8 Class Initialized
DEBUG - 2021-04-08 21:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:47 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:47 --> URI Class Initialized
INFO - 2021-04-08 21:07:47 --> URI Class Initialized
INFO - 2021-04-08 21:07:47 --> Router Class Initialized
INFO - 2021-04-08 21:07:47 --> Router Class Initialized
INFO - 2021-04-08 21:07:47 --> Output Class Initialized
INFO - 2021-04-08 21:07:47 --> Security Class Initialized
INFO - 2021-04-08 21:07:47 --> Output Class Initialized
DEBUG - 2021-04-08 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:47 --> Input Class Initialized
INFO - 2021-04-08 21:07:47 --> Security Class Initialized
INFO - 2021-04-08 21:07:47 --> Language Class Initialized
DEBUG - 2021-04-08 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:47 --> Input Class Initialized
ERROR - 2021-04-08 21:07:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:47 --> Language Class Initialized
ERROR - 2021-04-08 21:07:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-08 21:07:50 --> Config Class Initialized
INFO - 2021-04-08 21:07:50 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:50 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:50 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:50 --> URI Class Initialized
INFO - 2021-04-08 21:07:50 --> Router Class Initialized
INFO - 2021-04-08 21:07:50 --> Output Class Initialized
INFO - 2021-04-08 21:07:50 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:50 --> Input Class Initialized
INFO - 2021-04-08 21:07:50 --> Language Class Initialized
INFO - 2021-04-08 21:07:50 --> Loader Class Initialized
INFO - 2021-04-08 21:07:50 --> Helper loaded: url_helper
INFO - 2021-04-08 21:07:50 --> Helper loaded: form_helper
INFO - 2021-04-08 21:07:50 --> Helper loaded: common_helper
INFO - 2021-04-08 21:07:50 --> Helper loaded: util_helper
INFO - 2021-04-08 21:07:50 --> Database Driver Class Initialized
DEBUG - 2021-04-08 21:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 21:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 21:07:50 --> Form Validation Class Initialized
INFO - 2021-04-08 21:07:50 --> Controller Class Initialized
INFO - 2021-04-08 21:07:50 --> Model Class Initialized
INFO - 2021-04-08 21:07:50 --> Config Class Initialized
INFO - 2021-04-08 21:07:50 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:50 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:50 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:50 --> URI Class Initialized
INFO - 2021-04-08 21:07:50 --> Router Class Initialized
INFO - 2021-04-08 21:07:50 --> Output Class Initialized
INFO - 2021-04-08 21:07:50 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:50 --> Input Class Initialized
INFO - 2021-04-08 21:07:50 --> Language Class Initialized
INFO - 2021-04-08 21:07:50 --> Loader Class Initialized
INFO - 2021-04-08 21:07:50 --> Helper loaded: url_helper
INFO - 2021-04-08 21:07:50 --> Helper loaded: form_helper
INFO - 2021-04-08 21:07:50 --> Helper loaded: common_helper
INFO - 2021-04-08 21:07:50 --> Helper loaded: util_helper
INFO - 2021-04-08 21:07:50 --> Database Driver Class Initialized
DEBUG - 2021-04-08 21:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 21:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 21:07:50 --> Form Validation Class Initialized
INFO - 2021-04-08 21:07:50 --> Controller Class Initialized
INFO - 2021-04-08 21:07:50 --> Model Class Initialized
INFO - 2021-04-08 21:07:50 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/login.php
INFO - 2021-04-08 21:07:50 --> Final output sent to browser
DEBUG - 2021-04-08 21:07:50 --> Total execution time: 0.0324
INFO - 2021-04-08 21:07:52 --> Config Class Initialized
INFO - 2021-04-08 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:52 --> URI Class Initialized
INFO - 2021-04-08 21:07:52 --> Router Class Initialized
INFO - 2021-04-08 21:07:52 --> Output Class Initialized
INFO - 2021-04-08 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:52 --> Input Class Initialized
INFO - 2021-04-08 21:07:52 --> Language Class Initialized
INFO - 2021-04-08 21:07:52 --> Loader Class Initialized
INFO - 2021-04-08 21:07:52 --> Helper loaded: url_helper
INFO - 2021-04-08 21:07:52 --> Helper loaded: form_helper
INFO - 2021-04-08 21:07:52 --> Helper loaded: common_helper
INFO - 2021-04-08 21:07:52 --> Helper loaded: util_helper
INFO - 2021-04-08 21:07:52 --> Database Driver Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 21:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 21:07:52 --> Form Validation Class Initialized
INFO - 2021-04-08 21:07:52 --> Controller Class Initialized
INFO - 2021-04-08 21:07:52 --> Model Class Initialized
INFO - 2021-04-08 21:07:52 --> Config Class Initialized
INFO - 2021-04-08 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:52 --> URI Class Initialized
INFO - 2021-04-08 21:07:52 --> Router Class Initialized
INFO - 2021-04-08 21:07:52 --> Output Class Initialized
INFO - 2021-04-08 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:52 --> Input Class Initialized
INFO - 2021-04-08 21:07:52 --> Language Class Initialized
INFO - 2021-04-08 21:07:52 --> Loader Class Initialized
INFO - 2021-04-08 21:07:52 --> Helper loaded: url_helper
INFO - 2021-04-08 21:07:52 --> Helper loaded: form_helper
INFO - 2021-04-08 21:07:52 --> Helper loaded: common_helper
INFO - 2021-04-08 21:07:52 --> Helper loaded: util_helper
INFO - 2021-04-08 21:07:52 --> Database Driver Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-08 21:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-08 21:07:52 --> Form Validation Class Initialized
INFO - 2021-04-08 21:07:52 --> Controller Class Initialized
INFO - 2021-04-08 21:07:52 --> Model Class Initialized
INFO - 2021-04-08 21:07:52 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-08 21:07:52 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-08 21:07:52 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/dashboard.php
INFO - 2021-04-08 21:07:52 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-08 21:07:52 --> File loaded: C:\xampp\htdocs\foodtruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-08 21:07:52 --> Final output sent to browser
DEBUG - 2021-04-08 21:07:52 --> Total execution time: 0.0476
INFO - 2021-04-08 21:07:52 --> Config Class Initialized
INFO - 2021-04-08 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-08 21:07:52 --> Config Class Initialized
INFO - 2021-04-08 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:52 --> URI Class Initialized
DEBUG - 2021-04-08 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:52 --> Router Class Initialized
INFO - 2021-04-08 21:07:52 --> URI Class Initialized
INFO - 2021-04-08 21:07:52 --> Router Class Initialized
INFO - 2021-04-08 21:07:52 --> Output Class Initialized
INFO - 2021-04-08 21:07:52 --> Output Class Initialized
INFO - 2021-04-08 21:07:52 --> Security Class Initialized
INFO - 2021-04-08 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:52 --> Input Class Initialized
INFO - 2021-04-08 21:07:52 --> Input Class Initialized
INFO - 2021-04-08 21:07:52 --> Language Class Initialized
INFO - 2021-04-08 21:07:52 --> Language Class Initialized
ERROR - 2021-04-08 21:07:52 --> 404 Page Not Found: Admin/dist
ERROR - 2021-04-08 21:07:52 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 21:07:52 --> Config Class Initialized
INFO - 2021-04-08 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-08 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-08 21:07:52 --> URI Class Initialized
INFO - 2021-04-08 21:07:52 --> Router Class Initialized
INFO - 2021-04-08 21:07:52 --> Output Class Initialized
INFO - 2021-04-08 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:52 --> Config Class Initialized
INFO - 2021-04-08 21:07:52 --> Input Class Initialized
INFO - 2021-04-08 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-08 21:07:52 --> Language Class Initialized
DEBUG - 2021-04-08 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-08 21:07:52 --> Utf8 Class Initialized
ERROR - 2021-04-08 21:07:52 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-08 21:07:52 --> URI Class Initialized
INFO - 2021-04-08 21:07:52 --> Router Class Initialized
INFO - 2021-04-08 21:07:52 --> Output Class Initialized
INFO - 2021-04-08 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-08 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-08 21:07:52 --> Input Class Initialized
INFO - 2021-04-08 21:07:52 --> Language Class Initialized
ERROR - 2021-04-08 21:07:52 --> 404 Page Not Found: Admin/dist
