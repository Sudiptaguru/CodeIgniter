<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-08 04:53:12 --> Config Class Initialized
INFO - 2022-04-08 04:53:12 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:12 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:12 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:12 --> URI Class Initialized
DEBUG - 2022-04-08 04:53:12 --> No URI present. Default controller set.
INFO - 2022-04-08 04:53:12 --> Router Class Initialized
INFO - 2022-04-08 04:53:12 --> Output Class Initialized
INFO - 2022-04-08 04:53:12 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:12 --> Input Class Initialized
INFO - 2022-04-08 04:53:12 --> Language Class Initialized
INFO - 2022-04-08 04:53:12 --> Loader Class Initialized
INFO - 2022-04-08 04:53:12 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:12 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:12 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:12 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:12 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:12 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:12 --> Controller Class Initialized
INFO - 2022-04-08 04:53:12 --> Model Class Initialized
INFO - 2022-04-08 04:53:12 --> Model Class Initialized
INFO - 2022-04-08 04:53:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:53:12 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:12 --> Total execution time: 0.3426
INFO - 2022-04-08 04:53:17 --> Config Class Initialized
INFO - 2022-04-08 04:53:17 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:17 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:17 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:17 --> URI Class Initialized
INFO - 2022-04-08 04:53:17 --> Router Class Initialized
INFO - 2022-04-08 04:53:17 --> Output Class Initialized
INFO - 2022-04-08 04:53:17 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:17 --> Input Class Initialized
INFO - 2022-04-08 04:53:17 --> Language Class Initialized
INFO - 2022-04-08 04:53:17 --> Loader Class Initialized
INFO - 2022-04-08 04:53:17 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:17 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:17 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:17 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:17 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:17 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:17 --> Controller Class Initialized
INFO - 2022-04-08 04:53:17 --> Model Class Initialized
INFO - 2022-04-08 04:53:17 --> Model Class Initialized
INFO - 2022-04-08 04:53:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:53:17 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:17 --> Total execution time: 0.1086
INFO - 2022-04-08 04:53:17 --> Config Class Initialized
INFO - 2022-04-08 04:53:17 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:17 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:17 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:17 --> URI Class Initialized
INFO - 2022-04-08 04:53:17 --> Router Class Initialized
INFO - 2022-04-08 04:53:17 --> Output Class Initialized
INFO - 2022-04-08 04:53:17 --> Config Class Initialized
INFO - 2022-04-08 04:53:17 --> Hooks Class Initialized
INFO - 2022-04-08 04:53:17 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:17 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:17 --> Input Class Initialized
INFO - 2022-04-08 04:53:17 --> Language Class Initialized
INFO - 2022-04-08 04:53:17 --> URI Class Initialized
ERROR - 2022-04-08 04:53:17 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:53:17 --> Router Class Initialized
INFO - 2022-04-08 04:53:17 --> Output Class Initialized
INFO - 2022-04-08 04:53:17 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:17 --> Input Class Initialized
INFO - 2022-04-08 04:53:17 --> Language Class Initialized
ERROR - 2022-04-08 04:53:17 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:53:17 --> Config Class Initialized
INFO - 2022-04-08 04:53:17 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:17 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:17 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:17 --> URI Class Initialized
INFO - 2022-04-08 04:53:17 --> Router Class Initialized
INFO - 2022-04-08 04:53:17 --> Output Class Initialized
INFO - 2022-04-08 04:53:17 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:17 --> Input Class Initialized
INFO - 2022-04-08 04:53:17 --> Language Class Initialized
ERROR - 2022-04-08 04:53:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-08 04:53:20 --> Config Class Initialized
INFO - 2022-04-08 04:53:20 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:20 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:20 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:20 --> URI Class Initialized
INFO - 2022-04-08 04:53:20 --> Router Class Initialized
INFO - 2022-04-08 04:53:20 --> Output Class Initialized
INFO - 2022-04-08 04:53:20 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:20 --> Input Class Initialized
INFO - 2022-04-08 04:53:20 --> Language Class Initialized
INFO - 2022-04-08 04:53:20 --> Loader Class Initialized
INFO - 2022-04-08 04:53:20 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:20 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:20 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:20 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:20 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:20 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:20 --> Controller Class Initialized
INFO - 2022-04-08 04:53:20 --> Model Class Initialized
INFO - 2022-04-08 04:53:20 --> Model Class Initialized
INFO - 2022-04-08 04:53:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-08 04:53:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:53:21 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:21 --> Total execution time: 0.2248
INFO - 2022-04-08 04:53:25 --> Config Class Initialized
INFO - 2022-04-08 04:53:25 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:25 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:25 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:25 --> URI Class Initialized
INFO - 2022-04-08 04:53:25 --> Router Class Initialized
INFO - 2022-04-08 04:53:25 --> Output Class Initialized
INFO - 2022-04-08 04:53:25 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:25 --> Input Class Initialized
INFO - 2022-04-08 04:53:25 --> Language Class Initialized
INFO - 2022-04-08 04:53:25 --> Loader Class Initialized
INFO - 2022-04-08 04:53:25 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:25 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:25 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:25 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:25 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:25 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:25 --> Controller Class Initialized
INFO - 2022-04-08 04:53:25 --> Model Class Initialized
INFO - 2022-04-08 04:53:25 --> Model Class Initialized
INFO - 2022-04-08 04:53:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:53:25 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:25 --> Total execution time: 0.0611
INFO - 2022-04-08 04:53:33 --> Config Class Initialized
INFO - 2022-04-08 04:53:33 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:33 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:33 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:33 --> URI Class Initialized
INFO - 2022-04-08 04:53:33 --> Router Class Initialized
INFO - 2022-04-08 04:53:33 --> Output Class Initialized
INFO - 2022-04-08 04:53:33 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:33 --> Input Class Initialized
INFO - 2022-04-08 04:53:33 --> Language Class Initialized
INFO - 2022-04-08 04:53:33 --> Loader Class Initialized
INFO - 2022-04-08 04:53:33 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:33 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:33 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:33 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:33 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:33 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:33 --> Controller Class Initialized
INFO - 2022-04-08 04:53:33 --> Model Class Initialized
INFO - 2022-04-08 04:53:33 --> Model Class Initialized
INFO - 2022-04-08 04:53:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-08 04:53:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:53:33 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:33 --> Total execution time: 0.1447
INFO - 2022-04-08 04:53:35 --> Config Class Initialized
INFO - 2022-04-08 04:53:35 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:35 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:35 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:35 --> URI Class Initialized
INFO - 2022-04-08 04:53:35 --> Router Class Initialized
INFO - 2022-04-08 04:53:35 --> Output Class Initialized
INFO - 2022-04-08 04:53:35 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:35 --> Input Class Initialized
INFO - 2022-04-08 04:53:35 --> Language Class Initialized
INFO - 2022-04-08 04:53:35 --> Loader Class Initialized
INFO - 2022-04-08 04:53:35 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:35 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:35 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:35 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:35 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:35 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:35 --> Controller Class Initialized
INFO - 2022-04-08 04:53:35 --> Model Class Initialized
INFO - 2022-04-08 04:53:35 --> Model Class Initialized
INFO - 2022-04-08 04:53:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:53:35 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:35 --> Total execution time: 0.0698
INFO - 2022-04-08 04:53:36 --> Config Class Initialized
INFO - 2022-04-08 04:53:36 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:36 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:36 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:36 --> URI Class Initialized
DEBUG - 2022-04-08 04:53:36 --> No URI present. Default controller set.
INFO - 2022-04-08 04:53:36 --> Router Class Initialized
INFO - 2022-04-08 04:53:36 --> Output Class Initialized
INFO - 2022-04-08 04:53:36 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:36 --> Input Class Initialized
INFO - 2022-04-08 04:53:36 --> Language Class Initialized
INFO - 2022-04-08 04:53:36 --> Loader Class Initialized
INFO - 2022-04-08 04:53:36 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:36 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:36 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:36 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:36 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:36 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:36 --> Controller Class Initialized
INFO - 2022-04-08 04:53:36 --> Model Class Initialized
INFO - 2022-04-08 04:53:36 --> Model Class Initialized
INFO - 2022-04-08 04:53:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:53:36 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:36 --> Total execution time: 0.0589
INFO - 2022-04-08 04:53:37 --> Config Class Initialized
INFO - 2022-04-08 04:53:37 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:53:37 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:53:37 --> Utf8 Class Initialized
INFO - 2022-04-08 04:53:37 --> URI Class Initialized
DEBUG - 2022-04-08 04:53:37 --> No URI present. Default controller set.
INFO - 2022-04-08 04:53:37 --> Router Class Initialized
INFO - 2022-04-08 04:53:37 --> Output Class Initialized
INFO - 2022-04-08 04:53:37 --> Security Class Initialized
DEBUG - 2022-04-08 04:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:53:37 --> Input Class Initialized
INFO - 2022-04-08 04:53:37 --> Language Class Initialized
INFO - 2022-04-08 04:53:37 --> Loader Class Initialized
INFO - 2022-04-08 04:53:37 --> Helper loaded: url_helper
INFO - 2022-04-08 04:53:37 --> Helper loaded: form_helper
INFO - 2022-04-08 04:53:37 --> Helper loaded: common_helper
INFO - 2022-04-08 04:53:37 --> Helper loaded: util_helper
INFO - 2022-04-08 04:53:37 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:53:38 --> Form Validation Class Initialized
INFO - 2022-04-08 04:53:38 --> Controller Class Initialized
INFO - 2022-04-08 04:53:38 --> Model Class Initialized
INFO - 2022-04-08 04:53:38 --> Model Class Initialized
INFO - 2022-04-08 04:53:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:53:38 --> Final output sent to browser
DEBUG - 2022-04-08 04:53:38 --> Total execution time: 0.0714
INFO - 2022-04-08 04:54:07 --> Config Class Initialized
INFO - 2022-04-08 04:54:07 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:54:07 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:54:07 --> Utf8 Class Initialized
INFO - 2022-04-08 04:54:07 --> URI Class Initialized
INFO - 2022-04-08 04:54:07 --> Router Class Initialized
INFO - 2022-04-08 04:54:07 --> Output Class Initialized
INFO - 2022-04-08 04:54:07 --> Security Class Initialized
DEBUG - 2022-04-08 04:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:54:07 --> Input Class Initialized
INFO - 2022-04-08 04:54:07 --> Language Class Initialized
INFO - 2022-04-08 04:54:07 --> Loader Class Initialized
INFO - 2022-04-08 04:54:07 --> Helper loaded: url_helper
INFO - 2022-04-08 04:54:07 --> Helper loaded: form_helper
INFO - 2022-04-08 04:54:07 --> Helper loaded: common_helper
INFO - 2022-04-08 04:54:07 --> Helper loaded: util_helper
INFO - 2022-04-08 04:54:07 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:54:07 --> Form Validation Class Initialized
INFO - 2022-04-08 04:54:07 --> Controller Class Initialized
INFO - 2022-04-08 04:54:07 --> Model Class Initialized
INFO - 2022-04-08 04:54:07 --> Model Class Initialized
INFO - 2022-04-08 04:54:08 --> Config Class Initialized
INFO - 2022-04-08 04:54:08 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:54:08 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:54:08 --> Utf8 Class Initialized
INFO - 2022-04-08 04:54:08 --> URI Class Initialized
INFO - 2022-04-08 04:54:08 --> Router Class Initialized
INFO - 2022-04-08 04:54:08 --> Output Class Initialized
INFO - 2022-04-08 04:54:08 --> Security Class Initialized
DEBUG - 2022-04-08 04:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:54:08 --> Input Class Initialized
INFO - 2022-04-08 04:54:08 --> Language Class Initialized
INFO - 2022-04-08 04:54:08 --> Loader Class Initialized
INFO - 2022-04-08 04:54:08 --> Helper loaded: url_helper
INFO - 2022-04-08 04:54:08 --> Helper loaded: form_helper
INFO - 2022-04-08 04:54:08 --> Helper loaded: common_helper
INFO - 2022-04-08 04:54:08 --> Helper loaded: util_helper
INFO - 2022-04-08 04:54:08 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:54:08 --> Form Validation Class Initialized
INFO - 2022-04-08 04:54:08 --> Controller Class Initialized
INFO - 2022-04-08 04:54:08 --> Model Class Initialized
INFO - 2022-04-08 04:54:08 --> Model Class Initialized
INFO - 2022-04-08 04:54:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:54:08 --> Final output sent to browser
DEBUG - 2022-04-08 04:54:08 --> Total execution time: 0.0748
INFO - 2022-04-08 04:56:07 --> Config Class Initialized
INFO - 2022-04-08 04:56:07 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:07 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:07 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:07 --> URI Class Initialized
INFO - 2022-04-08 04:56:07 --> Router Class Initialized
INFO - 2022-04-08 04:56:07 --> Output Class Initialized
INFO - 2022-04-08 04:56:07 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:07 --> Input Class Initialized
INFO - 2022-04-08 04:56:07 --> Language Class Initialized
INFO - 2022-04-08 04:56:07 --> Loader Class Initialized
INFO - 2022-04-08 04:56:07 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:07 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:07 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:07 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:07 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:07 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:07 --> Controller Class Initialized
INFO - 2022-04-08 04:56:07 --> Model Class Initialized
INFO - 2022-04-08 04:56:07 --> Model Class Initialized
INFO - 2022-04-08 04:56:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:07 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:07 --> Total execution time: 0.0691
INFO - 2022-04-08 04:56:08 --> Config Class Initialized
INFO - 2022-04-08 04:56:08 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:08 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:08 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:08 --> URI Class Initialized
INFO - 2022-04-08 04:56:08 --> Router Class Initialized
INFO - 2022-04-08 04:56:08 --> Output Class Initialized
INFO - 2022-04-08 04:56:08 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:08 --> Input Class Initialized
INFO - 2022-04-08 04:56:08 --> Language Class Initialized
INFO - 2022-04-08 04:56:08 --> Loader Class Initialized
INFO - 2022-04-08 04:56:08 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:08 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:08 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:08 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:08 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:08 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:08 --> Controller Class Initialized
INFO - 2022-04-08 04:56:08 --> Model Class Initialized
INFO - 2022-04-08 04:56:08 --> Model Class Initialized
INFO - 2022-04-08 04:56:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:08 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:08 --> Total execution time: 0.0571
INFO - 2022-04-08 04:56:11 --> Config Class Initialized
INFO - 2022-04-08 04:56:11 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:11 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:11 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:11 --> URI Class Initialized
INFO - 2022-04-08 04:56:11 --> Router Class Initialized
INFO - 2022-04-08 04:56:11 --> Output Class Initialized
INFO - 2022-04-08 04:56:11 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:11 --> Input Class Initialized
INFO - 2022-04-08 04:56:11 --> Language Class Initialized
INFO - 2022-04-08 04:56:11 --> Loader Class Initialized
INFO - 2022-04-08 04:56:11 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:11 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:11 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:11 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:11 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:11 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:11 --> Controller Class Initialized
INFO - 2022-04-08 04:56:11 --> Model Class Initialized
INFO - 2022-04-08 04:56:11 --> Model Class Initialized
INFO - 2022-04-08 04:56:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:11 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:11 --> Total execution time: 0.0637
INFO - 2022-04-08 04:56:51 --> Config Class Initialized
INFO - 2022-04-08 04:56:51 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:51 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:51 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:51 --> URI Class Initialized
INFO - 2022-04-08 04:56:51 --> Router Class Initialized
INFO - 2022-04-08 04:56:51 --> Output Class Initialized
INFO - 2022-04-08 04:56:51 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:51 --> Input Class Initialized
INFO - 2022-04-08 04:56:51 --> Language Class Initialized
INFO - 2022-04-08 04:56:51 --> Loader Class Initialized
INFO - 2022-04-08 04:56:51 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:51 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:51 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:51 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:51 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:51 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:51 --> Controller Class Initialized
INFO - 2022-04-08 04:56:51 --> Model Class Initialized
INFO - 2022-04-08 04:56:51 --> Model Class Initialized
INFO - 2022-04-08 04:56:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:51 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:51 --> Total execution time: 0.0718
INFO - 2022-04-08 04:56:52 --> Config Class Initialized
INFO - 2022-04-08 04:56:52 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:52 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:52 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:52 --> URI Class Initialized
INFO - 2022-04-08 04:56:52 --> Router Class Initialized
INFO - 2022-04-08 04:56:52 --> Output Class Initialized
INFO - 2022-04-08 04:56:52 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:52 --> Input Class Initialized
INFO - 2022-04-08 04:56:52 --> Language Class Initialized
INFO - 2022-04-08 04:56:52 --> Loader Class Initialized
INFO - 2022-04-08 04:56:52 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:52 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:52 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:52 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:52 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:52 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:52 --> Controller Class Initialized
INFO - 2022-04-08 04:56:52 --> Model Class Initialized
INFO - 2022-04-08 04:56:52 --> Model Class Initialized
INFO - 2022-04-08 04:56:52 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:52 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:52 --> Total execution time: 0.0634
INFO - 2022-04-08 04:56:53 --> Config Class Initialized
INFO - 2022-04-08 04:56:53 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:53 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:53 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:53 --> URI Class Initialized
INFO - 2022-04-08 04:56:53 --> Router Class Initialized
INFO - 2022-04-08 04:56:53 --> Output Class Initialized
INFO - 2022-04-08 04:56:53 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:53 --> Input Class Initialized
INFO - 2022-04-08 04:56:53 --> Language Class Initialized
INFO - 2022-04-08 04:56:53 --> Loader Class Initialized
INFO - 2022-04-08 04:56:53 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:53 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:53 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:53 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:53 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:53 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:53 --> Controller Class Initialized
INFO - 2022-04-08 04:56:53 --> Model Class Initialized
INFO - 2022-04-08 04:56:53 --> Model Class Initialized
INFO - 2022-04-08 04:56:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:53 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:53 --> Total execution time: 0.0602
INFO - 2022-04-08 04:56:54 --> Config Class Initialized
INFO - 2022-04-08 04:56:54 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:54 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:54 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:54 --> URI Class Initialized
INFO - 2022-04-08 04:56:54 --> Router Class Initialized
INFO - 2022-04-08 04:56:54 --> Output Class Initialized
INFO - 2022-04-08 04:56:54 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:54 --> Input Class Initialized
INFO - 2022-04-08 04:56:54 --> Language Class Initialized
INFO - 2022-04-08 04:56:54 --> Loader Class Initialized
INFO - 2022-04-08 04:56:54 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:54 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:54 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:54 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:54 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:54 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:54 --> Controller Class Initialized
INFO - 2022-04-08 04:56:54 --> Model Class Initialized
INFO - 2022-04-08 04:56:54 --> Model Class Initialized
INFO - 2022-04-08 04:56:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:56:54 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:54 --> Total execution time: 0.0765
INFO - 2022-04-08 04:56:55 --> Config Class Initialized
INFO - 2022-04-08 04:56:55 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:55 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:55 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:55 --> URI Class Initialized
INFO - 2022-04-08 04:56:55 --> Router Class Initialized
INFO - 2022-04-08 04:56:55 --> Output Class Initialized
INFO - 2022-04-08 04:56:55 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:55 --> Input Class Initialized
INFO - 2022-04-08 04:56:55 --> Language Class Initialized
INFO - 2022-04-08 04:56:55 --> Loader Class Initialized
INFO - 2022-04-08 04:56:55 --> Helper loaded: url_helper
INFO - 2022-04-08 04:56:55 --> Helper loaded: form_helper
INFO - 2022-04-08 04:56:55 --> Helper loaded: common_helper
INFO - 2022-04-08 04:56:55 --> Helper loaded: util_helper
INFO - 2022-04-08 04:56:55 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:56:55 --> Form Validation Class Initialized
INFO - 2022-04-08 04:56:55 --> Controller Class Initialized
INFO - 2022-04-08 04:56:55 --> Model Class Initialized
INFO - 2022-04-08 04:56:55 --> Model Class Initialized
INFO - 2022-04-08 04:56:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:56:55 --> Final output sent to browser
DEBUG - 2022-04-08 04:56:55 --> Total execution time: 0.0657
INFO - 2022-04-08 04:56:55 --> Config Class Initialized
INFO - 2022-04-08 04:56:55 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:55 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:55 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:55 --> URI Class Initialized
INFO - 2022-04-08 04:56:56 --> Router Class Initialized
INFO - 2022-04-08 04:56:56 --> Output Class Initialized
INFO - 2022-04-08 04:56:56 --> Security Class Initialized
INFO - 2022-04-08 04:56:56 --> Config Class Initialized
INFO - 2022-04-08 04:56:56 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:56 --> Input Class Initialized
INFO - 2022-04-08 04:56:56 --> Language Class Initialized
DEBUG - 2022-04-08 04:56:56 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:56:56 --> Utf8 Class Initialized
INFO - 2022-04-08 04:56:56 --> URI Class Initialized
ERROR - 2022-04-08 04:56:56 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:56:56 --> Router Class Initialized
INFO - 2022-04-08 04:56:56 --> Output Class Initialized
INFO - 2022-04-08 04:56:56 --> Security Class Initialized
DEBUG - 2022-04-08 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:56:56 --> Input Class Initialized
INFO - 2022-04-08 04:56:56 --> Language Class Initialized
ERROR - 2022-04-08 04:56:56 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:57:03 --> Config Class Initialized
INFO - 2022-04-08 04:57:03 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:03 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:03 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:03 --> URI Class Initialized
INFO - 2022-04-08 04:57:03 --> Router Class Initialized
INFO - 2022-04-08 04:57:03 --> Output Class Initialized
INFO - 2022-04-08 04:57:03 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:03 --> Input Class Initialized
INFO - 2022-04-08 04:57:03 --> Language Class Initialized
INFO - 2022-04-08 04:57:03 --> Loader Class Initialized
INFO - 2022-04-08 04:57:03 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:03 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:03 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:03 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:03 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:03 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:03 --> Controller Class Initialized
INFO - 2022-04-08 04:57:03 --> Model Class Initialized
INFO - 2022-04-08 04:57:03 --> Model Class Initialized
INFO - 2022-04-08 04:57:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-08 04:57:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:57:03 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:03 --> Total execution time: 0.1513
INFO - 2022-04-08 04:57:03 --> Config Class Initialized
INFO - 2022-04-08 04:57:03 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:03 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:03 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:03 --> Config Class Initialized
INFO - 2022-04-08 04:57:03 --> URI Class Initialized
INFO - 2022-04-08 04:57:03 --> Hooks Class Initialized
INFO - 2022-04-08 04:57:03 --> Router Class Initialized
INFO - 2022-04-08 04:57:03 --> Output Class Initialized
INFO - 2022-04-08 04:57:03 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:03 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:03 --> Utf8 Class Initialized
DEBUG - 2022-04-08 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:03 --> Input Class Initialized
INFO - 2022-04-08 04:57:03 --> URI Class Initialized
INFO - 2022-04-08 04:57:03 --> Language Class Initialized
INFO - 2022-04-08 04:57:03 --> Router Class Initialized
ERROR - 2022-04-08 04:57:03 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:57:03 --> Output Class Initialized
INFO - 2022-04-08 04:57:03 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:03 --> Input Class Initialized
INFO - 2022-04-08 04:57:03 --> Language Class Initialized
ERROR - 2022-04-08 04:57:03 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:57:05 --> Config Class Initialized
INFO - 2022-04-08 04:57:05 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:05 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:05 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:05 --> URI Class Initialized
INFO - 2022-04-08 04:57:05 --> Router Class Initialized
INFO - 2022-04-08 04:57:05 --> Output Class Initialized
INFO - 2022-04-08 04:57:05 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:05 --> Input Class Initialized
INFO - 2022-04-08 04:57:05 --> Language Class Initialized
INFO - 2022-04-08 04:57:05 --> Loader Class Initialized
INFO - 2022-04-08 04:57:05 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:05 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:05 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:05 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:05 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:05 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:05 --> Controller Class Initialized
INFO - 2022-04-08 04:57:05 --> Model Class Initialized
INFO - 2022-04-08 04:57:05 --> Model Class Initialized
INFO - 2022-04-08 04:57:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:57:05 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:05 --> Total execution time: 0.0703
INFO - 2022-04-08 04:57:06 --> Config Class Initialized
INFO - 2022-04-08 04:57:06 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:06 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:06 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:06 --> URI Class Initialized
INFO - 2022-04-08 04:57:06 --> Router Class Initialized
INFO - 2022-04-08 04:57:06 --> Output Class Initialized
INFO - 2022-04-08 04:57:06 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:06 --> Input Class Initialized
INFO - 2022-04-08 04:57:06 --> Language Class Initialized
INFO - 2022-04-08 04:57:06 --> Loader Class Initialized
INFO - 2022-04-08 04:57:06 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:06 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:06 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:06 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:06 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:06 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:06 --> Controller Class Initialized
INFO - 2022-04-08 04:57:06 --> Model Class Initialized
INFO - 2022-04-08 04:57:06 --> Model Class Initialized
INFO - 2022-04-08 04:57:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:57:06 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:06 --> Total execution time: 0.0582
INFO - 2022-04-08 04:57:09 --> Config Class Initialized
INFO - 2022-04-08 04:57:09 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:09 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:09 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:09 --> URI Class Initialized
INFO - 2022-04-08 04:57:09 --> Router Class Initialized
INFO - 2022-04-08 04:57:09 --> Output Class Initialized
INFO - 2022-04-08 04:57:09 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:09 --> Input Class Initialized
INFO - 2022-04-08 04:57:09 --> Language Class Initialized
INFO - 2022-04-08 04:57:09 --> Loader Class Initialized
INFO - 2022-04-08 04:57:09 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:09 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:09 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:09 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:09 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:09 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:09 --> Controller Class Initialized
INFO - 2022-04-08 04:57:09 --> Model Class Initialized
INFO - 2022-04-08 04:57:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-08 04:57:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-08 04:57:09 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:09 --> Total execution time: 0.0647
INFO - 2022-04-08 04:57:09 --> Config Class Initialized
INFO - 2022-04-08 04:57:09 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:09 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:09 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:09 --> URI Class Initialized
INFO - 2022-04-08 04:57:09 --> Router Class Initialized
INFO - 2022-04-08 04:57:09 --> Output Class Initialized
INFO - 2022-04-08 04:57:09 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:09 --> Input Class Initialized
INFO - 2022-04-08 04:57:09 --> Language Class Initialized
ERROR - 2022-04-08 04:57:09 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-08 04:57:22 --> Config Class Initialized
INFO - 2022-04-08 04:57:22 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:22 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:22 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:22 --> URI Class Initialized
INFO - 2022-04-08 04:57:22 --> Router Class Initialized
INFO - 2022-04-08 04:57:22 --> Output Class Initialized
INFO - 2022-04-08 04:57:22 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:22 --> Input Class Initialized
INFO - 2022-04-08 04:57:22 --> Language Class Initialized
INFO - 2022-04-08 04:57:22 --> Loader Class Initialized
INFO - 2022-04-08 04:57:22 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:22 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:22 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:22 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:22 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:22 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:22 --> Controller Class Initialized
INFO - 2022-04-08 04:57:22 --> Model Class Initialized
INFO - 2022-04-08 04:57:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-08 04:57:22 --> Config Class Initialized
INFO - 2022-04-08 04:57:22 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:22 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:22 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:22 --> URI Class Initialized
INFO - 2022-04-08 04:57:22 --> Router Class Initialized
INFO - 2022-04-08 04:57:22 --> Output Class Initialized
INFO - 2022-04-08 04:57:22 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:22 --> Input Class Initialized
INFO - 2022-04-08 04:57:22 --> Language Class Initialized
INFO - 2022-04-08 04:57:22 --> Loader Class Initialized
INFO - 2022-04-08 04:57:23 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:23 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:23 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:23 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:23 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:23 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:23 --> Controller Class Initialized
INFO - 2022-04-08 04:57:23 --> Model Class Initialized
INFO - 2022-04-08 04:57:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-08 04:57:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-08 04:57:23 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:23 --> Total execution time: 0.0561
INFO - 2022-04-08 04:57:23 --> Config Class Initialized
INFO - 2022-04-08 04:57:23 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:23 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:23 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:23 --> URI Class Initialized
INFO - 2022-04-08 04:57:23 --> Router Class Initialized
INFO - 2022-04-08 04:57:23 --> Output Class Initialized
INFO - 2022-04-08 04:57:23 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:23 --> Input Class Initialized
INFO - 2022-04-08 04:57:23 --> Language Class Initialized
ERROR - 2022-04-08 04:57:23 --> 404 Page Not Found: provider/Profile/js
INFO - 2022-04-08 04:57:30 --> Config Class Initialized
INFO - 2022-04-08 04:57:30 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:30 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:30 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:30 --> URI Class Initialized
INFO - 2022-04-08 04:57:30 --> Router Class Initialized
INFO - 2022-04-08 04:57:30 --> Output Class Initialized
INFO - 2022-04-08 04:57:30 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:30 --> Input Class Initialized
INFO - 2022-04-08 04:57:30 --> Language Class Initialized
INFO - 2022-04-08 04:57:30 --> Loader Class Initialized
INFO - 2022-04-08 04:57:30 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:30 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:30 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:30 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:30 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:30 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:30 --> Controller Class Initialized
INFO - 2022-04-08 04:57:30 --> Model Class Initialized
INFO - 2022-04-08 04:57:30 --> Model Class Initialized
INFO - 2022-04-08 04:57:30 --> Config Class Initialized
INFO - 2022-04-08 04:57:30 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:30 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:30 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:30 --> URI Class Initialized
INFO - 2022-04-08 04:57:30 --> Router Class Initialized
INFO - 2022-04-08 04:57:30 --> Output Class Initialized
INFO - 2022-04-08 04:57:30 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:30 --> Input Class Initialized
INFO - 2022-04-08 04:57:30 --> Language Class Initialized
INFO - 2022-04-08 04:57:30 --> Loader Class Initialized
INFO - 2022-04-08 04:57:30 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:30 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:30 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:30 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:30 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:30 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:30 --> Controller Class Initialized
INFO - 2022-04-08 04:57:30 --> Model Class Initialized
INFO - 2022-04-08 04:57:30 --> Model Class Initialized
INFO - 2022-04-08 04:57:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:57:30 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:30 --> Total execution time: 0.0729
INFO - 2022-04-08 04:57:34 --> Config Class Initialized
INFO - 2022-04-08 04:57:34 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:34 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:34 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:34 --> URI Class Initialized
INFO - 2022-04-08 04:57:34 --> Router Class Initialized
INFO - 2022-04-08 04:57:34 --> Output Class Initialized
INFO - 2022-04-08 04:57:34 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:34 --> Input Class Initialized
INFO - 2022-04-08 04:57:34 --> Language Class Initialized
INFO - 2022-04-08 04:57:34 --> Loader Class Initialized
INFO - 2022-04-08 04:57:34 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:34 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:34 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:34 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:34 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:34 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:34 --> Controller Class Initialized
INFO - 2022-04-08 04:57:34 --> Model Class Initialized
INFO - 2022-04-08 04:57:34 --> Model Class Initialized
INFO - 2022-04-08 04:57:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:57:34 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:34 --> Total execution time: 0.0642
INFO - 2022-04-08 04:57:42 --> Config Class Initialized
INFO - 2022-04-08 04:57:42 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:42 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:42 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:42 --> URI Class Initialized
INFO - 2022-04-08 04:57:42 --> Router Class Initialized
INFO - 2022-04-08 04:57:42 --> Output Class Initialized
INFO - 2022-04-08 04:57:42 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:42 --> Input Class Initialized
INFO - 2022-04-08 04:57:42 --> Language Class Initialized
INFO - 2022-04-08 04:57:42 --> Loader Class Initialized
INFO - 2022-04-08 04:57:42 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:42 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:42 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:42 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:42 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:42 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:42 --> Controller Class Initialized
INFO - 2022-04-08 04:57:42 --> Model Class Initialized
INFO - 2022-04-08 04:57:42 --> Model Class Initialized
INFO - 2022-04-08 04:57:42 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 04:57:42 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:42 --> Total execution time: 0.0608
INFO - 2022-04-08 04:57:42 --> Config Class Initialized
INFO - 2022-04-08 04:57:42 --> Hooks Class Initialized
INFO - 2022-04-08 04:57:42 --> Config Class Initialized
INFO - 2022-04-08 04:57:42 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:42 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:42 --> Utf8 Class Initialized
DEBUG - 2022-04-08 04:57:42 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:42 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:42 --> URI Class Initialized
INFO - 2022-04-08 04:57:42 --> URI Class Initialized
INFO - 2022-04-08 04:57:42 --> Router Class Initialized
INFO - 2022-04-08 04:57:42 --> Router Class Initialized
INFO - 2022-04-08 04:57:42 --> Output Class Initialized
INFO - 2022-04-08 04:57:42 --> Security Class Initialized
INFO - 2022-04-08 04:57:42 --> Output Class Initialized
DEBUG - 2022-04-08 04:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:42 --> Input Class Initialized
INFO - 2022-04-08 04:57:42 --> Security Class Initialized
INFO - 2022-04-08 04:57:42 --> Language Class Initialized
DEBUG - 2022-04-08 04:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:42 --> Input Class Initialized
ERROR - 2022-04-08 04:57:42 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:57:42 --> Language Class Initialized
ERROR - 2022-04-08 04:57:42 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 04:57:44 --> Config Class Initialized
INFO - 2022-04-08 04:57:44 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:57:44 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:57:44 --> Utf8 Class Initialized
INFO - 2022-04-08 04:57:44 --> URI Class Initialized
INFO - 2022-04-08 04:57:44 --> Router Class Initialized
INFO - 2022-04-08 04:57:44 --> Output Class Initialized
INFO - 2022-04-08 04:57:44 --> Security Class Initialized
DEBUG - 2022-04-08 04:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:57:44 --> Input Class Initialized
INFO - 2022-04-08 04:57:44 --> Language Class Initialized
INFO - 2022-04-08 04:57:44 --> Loader Class Initialized
INFO - 2022-04-08 04:57:44 --> Helper loaded: url_helper
INFO - 2022-04-08 04:57:44 --> Helper loaded: form_helper
INFO - 2022-04-08 04:57:44 --> Helper loaded: common_helper
INFO - 2022-04-08 04:57:44 --> Helper loaded: util_helper
INFO - 2022-04-08 04:57:44 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:57:44 --> Form Validation Class Initialized
INFO - 2022-04-08 04:57:44 --> Controller Class Initialized
INFO - 2022-04-08 04:57:44 --> Model Class Initialized
INFO - 2022-04-08 04:57:44 --> Model Class Initialized
INFO - 2022-04-08 04:57:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:57:44 --> Final output sent to browser
DEBUG - 2022-04-08 04:57:44 --> Total execution time: 0.0739
INFO - 2022-04-08 04:59:10 --> Config Class Initialized
INFO - 2022-04-08 04:59:10 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:59:10 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:59:10 --> Utf8 Class Initialized
INFO - 2022-04-08 04:59:10 --> URI Class Initialized
INFO - 2022-04-08 04:59:10 --> Router Class Initialized
INFO - 2022-04-08 04:59:10 --> Output Class Initialized
INFO - 2022-04-08 04:59:11 --> Security Class Initialized
DEBUG - 2022-04-08 04:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:59:11 --> Input Class Initialized
INFO - 2022-04-08 04:59:11 --> Language Class Initialized
INFO - 2022-04-08 04:59:11 --> Loader Class Initialized
INFO - 2022-04-08 04:59:11 --> Helper loaded: url_helper
INFO - 2022-04-08 04:59:11 --> Helper loaded: form_helper
INFO - 2022-04-08 04:59:11 --> Helper loaded: common_helper
INFO - 2022-04-08 04:59:11 --> Helper loaded: util_helper
INFO - 2022-04-08 04:59:11 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:59:11 --> Form Validation Class Initialized
INFO - 2022-04-08 04:59:11 --> Controller Class Initialized
INFO - 2022-04-08 04:59:11 --> Model Class Initialized
INFO - 2022-04-08 04:59:11 --> Model Class Initialized
INFO - 2022-04-08 04:59:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:59:11 --> Final output sent to browser
DEBUG - 2022-04-08 04:59:11 --> Total execution time: 0.0696
INFO - 2022-04-08 04:59:51 --> Config Class Initialized
INFO - 2022-04-08 04:59:51 --> Hooks Class Initialized
DEBUG - 2022-04-08 04:59:51 --> UTF-8 Support Enabled
INFO - 2022-04-08 04:59:51 --> Utf8 Class Initialized
INFO - 2022-04-08 04:59:51 --> URI Class Initialized
INFO - 2022-04-08 04:59:51 --> Router Class Initialized
INFO - 2022-04-08 04:59:51 --> Output Class Initialized
INFO - 2022-04-08 04:59:51 --> Security Class Initialized
DEBUG - 2022-04-08 04:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 04:59:51 --> Input Class Initialized
INFO - 2022-04-08 04:59:51 --> Language Class Initialized
INFO - 2022-04-08 04:59:51 --> Loader Class Initialized
INFO - 2022-04-08 04:59:51 --> Helper loaded: url_helper
INFO - 2022-04-08 04:59:51 --> Helper loaded: form_helper
INFO - 2022-04-08 04:59:51 --> Helper loaded: common_helper
INFO - 2022-04-08 04:59:51 --> Helper loaded: util_helper
INFO - 2022-04-08 04:59:51 --> Database Driver Class Initialized
DEBUG - 2022-04-08 04:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 04:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 04:59:51 --> Form Validation Class Initialized
INFO - 2022-04-08 04:59:51 --> Controller Class Initialized
INFO - 2022-04-08 04:59:51 --> Model Class Initialized
INFO - 2022-04-08 04:59:51 --> Model Class Initialized
INFO - 2022-04-08 04:59:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 04:59:51 --> Final output sent to browser
DEBUG - 2022-04-08 04:59:51 --> Total execution time: 0.0673
INFO - 2022-04-08 05:00:14 --> Config Class Initialized
INFO - 2022-04-08 05:00:14 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:14 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:14 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:14 --> URI Class Initialized
INFO - 2022-04-08 05:00:14 --> Router Class Initialized
INFO - 2022-04-08 05:00:14 --> Output Class Initialized
INFO - 2022-04-08 05:00:14 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:14 --> Input Class Initialized
INFO - 2022-04-08 05:00:14 --> Language Class Initialized
INFO - 2022-04-08 05:00:14 --> Loader Class Initialized
INFO - 2022-04-08 05:00:14 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:14 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:14 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:14 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:14 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:14 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:14 --> Controller Class Initialized
INFO - 2022-04-08 05:00:14 --> Model Class Initialized
INFO - 2022-04-08 05:00:14 --> Model Class Initialized
INFO - 2022-04-08 05:00:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 05:00:14 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:14 --> Total execution time: 0.0682
INFO - 2022-04-08 05:00:17 --> Config Class Initialized
INFO - 2022-04-08 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:17 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:17 --> URI Class Initialized
INFO - 2022-04-08 05:00:17 --> Router Class Initialized
INFO - 2022-04-08 05:00:17 --> Output Class Initialized
INFO - 2022-04-08 05:00:17 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:17 --> Input Class Initialized
INFO - 2022-04-08 05:00:17 --> Language Class Initialized
INFO - 2022-04-08 05:00:17 --> Loader Class Initialized
INFO - 2022-04-08 05:00:17 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:17 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:17 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:17 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:17 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:17 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:17 --> Controller Class Initialized
INFO - 2022-04-08 05:00:17 --> Model Class Initialized
INFO - 2022-04-08 05:00:17 --> Model Class Initialized
INFO - 2022-04-08 05:00:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 05:00:17 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:17 --> Total execution time: 0.0647
INFO - 2022-04-08 05:00:17 --> Config Class Initialized
INFO - 2022-04-08 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:17 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:17 --> URI Class Initialized
INFO - 2022-04-08 05:00:17 --> Router Class Initialized
INFO - 2022-04-08 05:00:17 --> Output Class Initialized
INFO - 2022-04-08 05:00:17 --> Security Class Initialized
INFO - 2022-04-08 05:00:17 --> Config Class Initialized
INFO - 2022-04-08 05:00:17 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:17 --> Input Class Initialized
INFO - 2022-04-08 05:00:17 --> Language Class Initialized
DEBUG - 2022-04-08 05:00:17 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:17 --> Utf8 Class Initialized
ERROR - 2022-04-08 05:00:17 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 05:00:17 --> URI Class Initialized
INFO - 2022-04-08 05:00:17 --> Router Class Initialized
INFO - 2022-04-08 05:00:17 --> Output Class Initialized
INFO - 2022-04-08 05:00:17 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:17 --> Input Class Initialized
INFO - 2022-04-08 05:00:17 --> Language Class Initialized
ERROR - 2022-04-08 05:00:17 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-08 05:00:19 --> Config Class Initialized
INFO - 2022-04-08 05:00:19 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:19 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:19 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:19 --> URI Class Initialized
INFO - 2022-04-08 05:00:19 --> Router Class Initialized
INFO - 2022-04-08 05:00:19 --> Output Class Initialized
INFO - 2022-04-08 05:00:19 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:19 --> Input Class Initialized
INFO - 2022-04-08 05:00:19 --> Language Class Initialized
INFO - 2022-04-08 05:00:19 --> Loader Class Initialized
INFO - 2022-04-08 05:00:19 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:19 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:19 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:19 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:19 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:19 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:19 --> Controller Class Initialized
INFO - 2022-04-08 05:00:19 --> Model Class Initialized
INFO - 2022-04-08 05:00:19 --> Model Class Initialized
INFO - 2022-04-08 05:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-08 05:00:19 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 05:00:19 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:19 --> Total execution time: 0.1535
INFO - 2022-04-08 05:00:21 --> Config Class Initialized
INFO - 2022-04-08 05:00:21 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:21 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:21 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:21 --> URI Class Initialized
INFO - 2022-04-08 05:00:21 --> Router Class Initialized
INFO - 2022-04-08 05:00:21 --> Output Class Initialized
INFO - 2022-04-08 05:00:21 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:21 --> Input Class Initialized
INFO - 2022-04-08 05:00:21 --> Language Class Initialized
INFO - 2022-04-08 05:00:21 --> Loader Class Initialized
INFO - 2022-04-08 05:00:21 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:21 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:21 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:21 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:21 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:21 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:21 --> Controller Class Initialized
INFO - 2022-04-08 05:00:21 --> Model Class Initialized
INFO - 2022-04-08 05:00:21 --> Model Class Initialized
INFO - 2022-04-08 05:00:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-08 05:00:21 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:21 --> Total execution time: 0.0694
INFO - 2022-04-08 05:00:21 --> Config Class Initialized
INFO - 2022-04-08 05:00:21 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:21 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:21 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:21 --> URI Class Initialized
INFO - 2022-04-08 05:00:21 --> Router Class Initialized
INFO - 2022-04-08 05:00:21 --> Output Class Initialized
INFO - 2022-04-08 05:00:21 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:21 --> Input Class Initialized
INFO - 2022-04-08 05:00:21 --> Language Class Initialized
INFO - 2022-04-08 05:00:21 --> Loader Class Initialized
INFO - 2022-04-08 05:00:21 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:21 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:21 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:21 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:21 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:21 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:21 --> Controller Class Initialized
INFO - 2022-04-08 05:00:21 --> Model Class Initialized
INFO - 2022-04-08 05:00:21 --> Model Class Initialized
INFO - 2022-04-08 05:00:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 05:00:21 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:21 --> Total execution time: 0.0602
INFO - 2022-04-08 05:00:23 --> Config Class Initialized
INFO - 2022-04-08 05:00:23 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:23 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:23 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:23 --> URI Class Initialized
INFO - 2022-04-08 05:00:23 --> Router Class Initialized
INFO - 2022-04-08 05:00:23 --> Output Class Initialized
INFO - 2022-04-08 05:00:23 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:23 --> Input Class Initialized
INFO - 2022-04-08 05:00:23 --> Language Class Initialized
INFO - 2022-04-08 05:00:23 --> Loader Class Initialized
INFO - 2022-04-08 05:00:23 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:23 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:23 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:23 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:23 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:23 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:23 --> Controller Class Initialized
INFO - 2022-04-08 05:00:23 --> Model Class Initialized
INFO - 2022-04-08 05:00:23 --> Model Class Initialized
INFO - 2022-04-08 05:00:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 05:00:23 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:23 --> Total execution time: 0.0745
INFO - 2022-04-08 05:00:26 --> Config Class Initialized
INFO - 2022-04-08 05:00:26 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:26 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:26 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:26 --> URI Class Initialized
INFO - 2022-04-08 05:00:26 --> Router Class Initialized
INFO - 2022-04-08 05:00:26 --> Output Class Initialized
INFO - 2022-04-08 05:00:26 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:26 --> Input Class Initialized
INFO - 2022-04-08 05:00:26 --> Language Class Initialized
INFO - 2022-04-08 05:00:26 --> Loader Class Initialized
INFO - 2022-04-08 05:00:26 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:26 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:26 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:26 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:26 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:26 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:26 --> Controller Class Initialized
INFO - 2022-04-08 05:00:26 --> Model Class Initialized
INFO - 2022-04-08 05:00:26 --> Model Class Initialized
INFO - 2022-04-08 05:00:26 --> Config Class Initialized
INFO - 2022-04-08 05:00:26 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:26 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:26 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:26 --> URI Class Initialized
INFO - 2022-04-08 05:00:26 --> Router Class Initialized
INFO - 2022-04-08 05:00:26 --> Output Class Initialized
INFO - 2022-04-08 05:00:26 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:26 --> Input Class Initialized
INFO - 2022-04-08 05:00:26 --> Language Class Initialized
INFO - 2022-04-08 05:00:26 --> Loader Class Initialized
INFO - 2022-04-08 05:00:26 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:26 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:26 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:26 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:26 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:26 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:26 --> Controller Class Initialized
INFO - 2022-04-08 05:00:26 --> Model Class Initialized
INFO - 2022-04-08 05:00:26 --> Model Class Initialized
INFO - 2022-04-08 05:00:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 05:00:26 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:26 --> Total execution time: 0.0774
INFO - 2022-04-08 05:00:29 --> Config Class Initialized
INFO - 2022-04-08 05:00:29 --> Hooks Class Initialized
DEBUG - 2022-04-08 05:00:29 --> UTF-8 Support Enabled
INFO - 2022-04-08 05:00:29 --> Utf8 Class Initialized
INFO - 2022-04-08 05:00:29 --> URI Class Initialized
INFO - 2022-04-08 05:00:29 --> Router Class Initialized
INFO - 2022-04-08 05:00:29 --> Output Class Initialized
INFO - 2022-04-08 05:00:29 --> Security Class Initialized
DEBUG - 2022-04-08 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-08 05:00:29 --> Input Class Initialized
INFO - 2022-04-08 05:00:29 --> Language Class Initialized
INFO - 2022-04-08 05:00:29 --> Loader Class Initialized
INFO - 2022-04-08 05:00:29 --> Helper loaded: url_helper
INFO - 2022-04-08 05:00:29 --> Helper loaded: form_helper
INFO - 2022-04-08 05:00:29 --> Helper loaded: common_helper
INFO - 2022-04-08 05:00:29 --> Helper loaded: util_helper
INFO - 2022-04-08 05:00:29 --> Database Driver Class Initialized
DEBUG - 2022-04-08 05:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-08 05:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-08 05:00:29 --> Form Validation Class Initialized
INFO - 2022-04-08 05:00:29 --> Controller Class Initialized
INFO - 2022-04-08 05:00:29 --> Model Class Initialized
INFO - 2022-04-08 05:00:29 --> Model Class Initialized
INFO - 2022-04-08 05:00:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-08 05:00:29 --> Final output sent to browser
DEBUG - 2022-04-08 05:00:29 --> Total execution time: 0.0712
