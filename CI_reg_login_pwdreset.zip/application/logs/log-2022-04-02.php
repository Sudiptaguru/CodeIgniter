<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-02 18:09:46 --> Config Class Initialized
INFO - 2022-04-02 18:09:46 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:09:46 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:09:46 --> Utf8 Class Initialized
INFO - 2022-04-02 18:09:46 --> URI Class Initialized
DEBUG - 2022-04-02 18:09:46 --> No URI present. Default controller set.
INFO - 2022-04-02 18:09:46 --> Router Class Initialized
INFO - 2022-04-02 18:09:46 --> Output Class Initialized
INFO - 2022-04-02 18:09:46 --> Security Class Initialized
DEBUG - 2022-04-02 18:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:09:46 --> Input Class Initialized
INFO - 2022-04-02 18:09:46 --> Language Class Initialized
INFO - 2022-04-02 18:09:46 --> Loader Class Initialized
INFO - 2022-04-02 18:09:46 --> Helper loaded: url_helper
INFO - 2022-04-02 18:09:46 --> Helper loaded: form_helper
INFO - 2022-04-02 18:09:46 --> Helper loaded: common_helper
INFO - 2022-04-02 18:09:46 --> Helper loaded: util_helper
INFO - 2022-04-02 18:09:46 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:09:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:09:46 --> Unable to connect to the database
DEBUG - 2022-04-02 18:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:09:46 --> Form Validation Class Initialized
INFO - 2022-04-02 18:09:46 --> Controller Class Initialized
INFO - 2022-04-02 18:09:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:09:46 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:09:46 --> Final output sent to browser
DEBUG - 2022-04-02 18:09:46 --> Total execution time: 0.0867
INFO - 2022-04-02 18:09:47 --> Config Class Initialized
INFO - 2022-04-02 18:09:47 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:09:47 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:09:47 --> Utf8 Class Initialized
INFO - 2022-04-02 18:09:47 --> URI Class Initialized
INFO - 2022-04-02 18:09:47 --> Router Class Initialized
INFO - 2022-04-02 18:09:47 --> Output Class Initialized
INFO - 2022-04-02 18:09:47 --> Security Class Initialized
DEBUG - 2022-04-02 18:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:09:47 --> Input Class Initialized
INFO - 2022-04-02 18:09:47 --> Language Class Initialized
ERROR - 2022-04-02 18:09:47 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:10:18 --> Config Class Initialized
INFO - 2022-04-02 18:10:18 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:18 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:18 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:18 --> URI Class Initialized
DEBUG - 2022-04-02 18:10:18 --> No URI present. Default controller set.
INFO - 2022-04-02 18:10:18 --> Router Class Initialized
INFO - 2022-04-02 18:10:18 --> Output Class Initialized
INFO - 2022-04-02 18:10:18 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:18 --> Input Class Initialized
INFO - 2022-04-02 18:10:18 --> Language Class Initialized
INFO - 2022-04-02 18:10:18 --> Loader Class Initialized
INFO - 2022-04-02 18:10:18 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:18 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:18 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:18 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:18 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:18 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:18 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:18 --> Controller Class Initialized
INFO - 2022-04-02 18:10:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:10:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:10:18 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:18 --> Total execution time: 0.0712
INFO - 2022-04-02 18:10:21 --> Config Class Initialized
INFO - 2022-04-02 18:10:21 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:21 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:21 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:21 --> URI Class Initialized
DEBUG - 2022-04-02 18:10:21 --> No URI present. Default controller set.
INFO - 2022-04-02 18:10:21 --> Router Class Initialized
INFO - 2022-04-02 18:10:21 --> Output Class Initialized
INFO - 2022-04-02 18:10:21 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:21 --> Input Class Initialized
INFO - 2022-04-02 18:10:21 --> Language Class Initialized
INFO - 2022-04-02 18:10:21 --> Loader Class Initialized
INFO - 2022-04-02 18:10:21 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:21 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:21 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:21 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:21 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:21 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:21 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:21 --> Controller Class Initialized
INFO - 2022-04-02 18:10:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:10:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:10:21 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:21 --> Total execution time: 0.0756
INFO - 2022-04-02 18:10:29 --> Config Class Initialized
INFO - 2022-04-02 18:10:29 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:29 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:29 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:29 --> URI Class Initialized
INFO - 2022-04-02 18:10:29 --> Router Class Initialized
INFO - 2022-04-02 18:10:29 --> Output Class Initialized
INFO - 2022-04-02 18:10:29 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:29 --> Input Class Initialized
INFO - 2022-04-02 18:10:29 --> Language Class Initialized
INFO - 2022-04-02 18:10:29 --> Loader Class Initialized
INFO - 2022-04-02 18:10:29 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:29 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:29 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:29 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:29 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:29 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:29 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:29 --> Controller Class Initialized
INFO - 2022-04-02 18:10:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:10:29 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:29 --> Total execution time: 0.0640
INFO - 2022-04-02 18:10:29 --> Config Class Initialized
INFO - 2022-04-02 18:10:29 --> Hooks Class Initialized
INFO - 2022-04-02 18:10:29 --> Config Class Initialized
INFO - 2022-04-02 18:10:29 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:29 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:29 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:29 --> URI Class Initialized
INFO - 2022-04-02 18:10:29 --> Router Class Initialized
DEBUG - 2022-04-02 18:10:29 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:29 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:29 --> Output Class Initialized
INFO - 2022-04-02 18:10:29 --> URI Class Initialized
INFO - 2022-04-02 18:10:29 --> Security Class Initialized
INFO - 2022-04-02 18:10:29 --> Router Class Initialized
DEBUG - 2022-04-02 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:29 --> Input Class Initialized
INFO - 2022-04-02 18:10:29 --> Output Class Initialized
INFO - 2022-04-02 18:10:29 --> Language Class Initialized
INFO - 2022-04-02 18:10:29 --> Security Class Initialized
ERROR - 2022-04-02 18:10:29 --> 404 Page Not Found: Fasset/img
DEBUG - 2022-04-02 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:29 --> Input Class Initialized
INFO - 2022-04-02 18:10:29 --> Language Class Initialized
ERROR - 2022-04-02 18:10:29 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:10:32 --> Config Class Initialized
INFO - 2022-04-02 18:10:32 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:32 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:32 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:32 --> URI Class Initialized
DEBUG - 2022-04-02 18:10:32 --> No URI present. Default controller set.
INFO - 2022-04-02 18:10:32 --> Router Class Initialized
INFO - 2022-04-02 18:10:32 --> Output Class Initialized
INFO - 2022-04-02 18:10:32 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:32 --> Input Class Initialized
INFO - 2022-04-02 18:10:32 --> Language Class Initialized
INFO - 2022-04-02 18:10:32 --> Loader Class Initialized
INFO - 2022-04-02 18:10:32 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:32 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:32 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:32 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:32 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:32 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:32 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:32 --> Controller Class Initialized
INFO - 2022-04-02 18:10:32 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:10:32 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:10:32 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:32 --> Total execution time: 0.0778
INFO - 2022-04-02 18:10:34 --> Config Class Initialized
INFO - 2022-04-02 18:10:34 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:34 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:34 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:34 --> URI Class Initialized
INFO - 2022-04-02 18:10:34 --> Router Class Initialized
INFO - 2022-04-02 18:10:34 --> Output Class Initialized
INFO - 2022-04-02 18:10:34 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:34 --> Input Class Initialized
INFO - 2022-04-02 18:10:34 --> Language Class Initialized
INFO - 2022-04-02 18:10:34 --> Loader Class Initialized
INFO - 2022-04-02 18:10:34 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:34 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:34 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:34 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:34 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:34 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:34 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:34 --> Controller Class Initialized
INFO - 2022-04-02 18:10:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:10:34 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:34 --> Total execution time: 0.0632
INFO - 2022-04-02 18:10:37 --> Config Class Initialized
INFO - 2022-04-02 18:10:37 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:37 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:37 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:37 --> URI Class Initialized
DEBUG - 2022-04-02 18:10:37 --> No URI present. Default controller set.
INFO - 2022-04-02 18:10:37 --> Router Class Initialized
INFO - 2022-04-02 18:10:37 --> Output Class Initialized
INFO - 2022-04-02 18:10:37 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:38 --> Input Class Initialized
INFO - 2022-04-02 18:10:38 --> Language Class Initialized
INFO - 2022-04-02 18:10:38 --> Loader Class Initialized
INFO - 2022-04-02 18:10:38 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:38 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:38 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:38 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:38 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:38 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:38 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:38 --> Controller Class Initialized
INFO - 2022-04-02 18:10:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:10:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:10:38 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:38 --> Total execution time: 0.0729
INFO - 2022-04-02 18:10:42 --> Config Class Initialized
INFO - 2022-04-02 18:10:42 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:42 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:42 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:42 --> URI Class Initialized
INFO - 2022-04-02 18:10:42 --> Router Class Initialized
INFO - 2022-04-02 18:10:42 --> Output Class Initialized
INFO - 2022-04-02 18:10:42 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:42 --> Input Class Initialized
INFO - 2022-04-02 18:10:42 --> Language Class Initialized
INFO - 2022-04-02 18:10:42 --> Loader Class Initialized
INFO - 2022-04-02 18:10:42 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:42 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:42 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:42 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:42 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:42 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:42 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:42 --> Controller Class Initialized
INFO - 2022-04-02 18:10:42 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:10:42 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:42 --> Total execution time: 0.0595
INFO - 2022-04-02 18:10:44 --> Config Class Initialized
INFO - 2022-04-02 18:10:44 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:44 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:44 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:44 --> URI Class Initialized
INFO - 2022-04-02 18:10:44 --> Router Class Initialized
INFO - 2022-04-02 18:10:44 --> Output Class Initialized
INFO - 2022-04-02 18:10:44 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:44 --> Input Class Initialized
INFO - 2022-04-02 18:10:44 --> Language Class Initialized
INFO - 2022-04-02 18:10:44 --> Loader Class Initialized
INFO - 2022-04-02 18:10:44 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:44 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:44 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:44 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:44 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:44 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:44 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:44 --> Controller Class Initialized
INFO - 2022-04-02 18:10:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:10:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:10:44 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:44 --> Total execution time: 0.0697
INFO - 2022-04-02 18:10:47 --> Config Class Initialized
INFO - 2022-04-02 18:10:47 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:47 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:47 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:47 --> URI Class Initialized
INFO - 2022-04-02 18:10:47 --> Router Class Initialized
INFO - 2022-04-02 18:10:47 --> Output Class Initialized
INFO - 2022-04-02 18:10:47 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:47 --> Input Class Initialized
INFO - 2022-04-02 18:10:47 --> Language Class Initialized
INFO - 2022-04-02 18:10:47 --> Loader Class Initialized
INFO - 2022-04-02 18:10:47 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:47 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:47 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:47 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:47 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:47 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:47 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:47 --> Controller Class Initialized
INFO - 2022-04-02 18:10:47 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:10:47 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:47 --> Total execution time: 0.0727
INFO - 2022-04-02 18:10:56 --> Config Class Initialized
INFO - 2022-04-02 18:10:56 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:10:56 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:10:56 --> Utf8 Class Initialized
INFO - 2022-04-02 18:10:56 --> URI Class Initialized
DEBUG - 2022-04-02 18:10:56 --> No URI present. Default controller set.
INFO - 2022-04-02 18:10:56 --> Router Class Initialized
INFO - 2022-04-02 18:10:56 --> Output Class Initialized
INFO - 2022-04-02 18:10:56 --> Security Class Initialized
DEBUG - 2022-04-02 18:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:10:56 --> Input Class Initialized
INFO - 2022-04-02 18:10:56 --> Language Class Initialized
INFO - 2022-04-02 18:10:56 --> Loader Class Initialized
INFO - 2022-04-02 18:10:56 --> Helper loaded: url_helper
INFO - 2022-04-02 18:10:56 --> Helper loaded: form_helper
INFO - 2022-04-02 18:10:56 --> Helper loaded: common_helper
INFO - 2022-04-02 18:10:56 --> Helper loaded: util_helper
INFO - 2022-04-02 18:10:56 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:10:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:10:56 --> Unable to connect to the database
DEBUG - 2022-04-02 18:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:10:56 --> Form Validation Class Initialized
INFO - 2022-04-02 18:10:56 --> Controller Class Initialized
INFO - 2022-04-02 18:10:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:10:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:10:56 --> Final output sent to browser
DEBUG - 2022-04-02 18:10:56 --> Total execution time: 0.0630
INFO - 2022-04-02 18:11:11 --> Config Class Initialized
INFO - 2022-04-02 18:11:11 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:11:11 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:11:11 --> Utf8 Class Initialized
INFO - 2022-04-02 18:11:11 --> URI Class Initialized
INFO - 2022-04-02 18:11:11 --> Router Class Initialized
INFO - 2022-04-02 18:11:11 --> Output Class Initialized
INFO - 2022-04-02 18:11:11 --> Security Class Initialized
DEBUG - 2022-04-02 18:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:11:11 --> Input Class Initialized
INFO - 2022-04-02 18:11:11 --> Language Class Initialized
INFO - 2022-04-02 18:11:11 --> Loader Class Initialized
INFO - 2022-04-02 18:11:11 --> Helper loaded: url_helper
INFO - 2022-04-02 18:11:11 --> Helper loaded: form_helper
INFO - 2022-04-02 18:11:11 --> Helper loaded: common_helper
INFO - 2022-04-02 18:11:11 --> Helper loaded: util_helper
INFO - 2022-04-02 18:11:11 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:11:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:11:11 --> Unable to connect to the database
DEBUG - 2022-04-02 18:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:11:11 --> Form Validation Class Initialized
INFO - 2022-04-02 18:11:11 --> Controller Class Initialized
INFO - 2022-04-02 18:11:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:11:11 --> Final output sent to browser
DEBUG - 2022-04-02 18:11:11 --> Total execution time: 0.0685
INFO - 2022-04-02 18:12:02 --> Config Class Initialized
INFO - 2022-04-02 18:12:02 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:12:02 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:12:02 --> Utf8 Class Initialized
INFO - 2022-04-02 18:12:02 --> URI Class Initialized
INFO - 2022-04-02 18:12:02 --> Router Class Initialized
INFO - 2022-04-02 18:12:02 --> Output Class Initialized
INFO - 2022-04-02 18:12:02 --> Security Class Initialized
DEBUG - 2022-04-02 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:12:02 --> Input Class Initialized
INFO - 2022-04-02 18:12:02 --> Language Class Initialized
INFO - 2022-04-02 18:12:02 --> Loader Class Initialized
INFO - 2022-04-02 18:12:02 --> Helper loaded: url_helper
INFO - 2022-04-02 18:12:02 --> Helper loaded: form_helper
INFO - 2022-04-02 18:12:02 --> Helper loaded: common_helper
INFO - 2022-04-02 18:12:02 --> Helper loaded: util_helper
INFO - 2022-04-02 18:12:02 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:12:02 --> Unable to connect to the database
DEBUG - 2022-04-02 18:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:12:02 --> Form Validation Class Initialized
INFO - 2022-04-02 18:12:02 --> Controller Class Initialized
INFO - 2022-04-02 18:12:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-04-02 18:12:02 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2022-04-02 18:12:05 --> Config Class Initialized
INFO - 2022-04-02 18:12:05 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:12:05 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:12:05 --> Utf8 Class Initialized
INFO - 2022-04-02 18:12:05 --> URI Class Initialized
DEBUG - 2022-04-02 18:12:05 --> No URI present. Default controller set.
INFO - 2022-04-02 18:12:05 --> Router Class Initialized
INFO - 2022-04-02 18:12:05 --> Output Class Initialized
INFO - 2022-04-02 18:12:05 --> Security Class Initialized
DEBUG - 2022-04-02 18:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:12:05 --> Input Class Initialized
INFO - 2022-04-02 18:12:05 --> Language Class Initialized
INFO - 2022-04-02 18:12:05 --> Loader Class Initialized
INFO - 2022-04-02 18:12:05 --> Helper loaded: url_helper
INFO - 2022-04-02 18:12:05 --> Helper loaded: form_helper
INFO - 2022-04-02 18:12:05 --> Helper loaded: common_helper
INFO - 2022-04-02 18:12:05 --> Helper loaded: util_helper
INFO - 2022-04-02 18:12:05 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:12:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:12:05 --> Unable to connect to the database
DEBUG - 2022-04-02 18:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:12:05 --> Form Validation Class Initialized
INFO - 2022-04-02 18:12:05 --> Controller Class Initialized
INFO - 2022-04-02 18:12:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:12:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:12:05 --> Final output sent to browser
DEBUG - 2022-04-02 18:12:05 --> Total execution time: 0.0735
INFO - 2022-04-02 18:12:15 --> Config Class Initialized
INFO - 2022-04-02 18:12:15 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:12:15 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:12:15 --> Utf8 Class Initialized
INFO - 2022-04-02 18:12:15 --> URI Class Initialized
DEBUG - 2022-04-02 18:12:15 --> No URI present. Default controller set.
INFO - 2022-04-02 18:12:15 --> Router Class Initialized
INFO - 2022-04-02 18:12:15 --> Output Class Initialized
INFO - 2022-04-02 18:12:15 --> Security Class Initialized
DEBUG - 2022-04-02 18:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:12:15 --> Input Class Initialized
INFO - 2022-04-02 18:12:15 --> Language Class Initialized
INFO - 2022-04-02 18:12:15 --> Loader Class Initialized
INFO - 2022-04-02 18:12:15 --> Helper loaded: url_helper
INFO - 2022-04-02 18:12:15 --> Helper loaded: form_helper
INFO - 2022-04-02 18:12:15 --> Helper loaded: common_helper
INFO - 2022-04-02 18:12:15 --> Helper loaded: util_helper
INFO - 2022-04-02 18:12:15 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:12:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:12:15 --> Unable to connect to the database
DEBUG - 2022-04-02 18:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:12:15 --> Form Validation Class Initialized
INFO - 2022-04-02 18:12:15 --> Controller Class Initialized
INFO - 2022-04-02 18:12:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:12:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:12:15 --> Final output sent to browser
DEBUG - 2022-04-02 18:12:15 --> Total execution time: 0.0725
INFO - 2022-04-02 18:12:18 --> Config Class Initialized
INFO - 2022-04-02 18:12:18 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:12:18 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:12:18 --> Utf8 Class Initialized
INFO - 2022-04-02 18:12:18 --> URI Class Initialized
DEBUG - 2022-04-02 18:12:18 --> No URI present. Default controller set.
INFO - 2022-04-02 18:12:18 --> Router Class Initialized
INFO - 2022-04-02 18:12:18 --> Output Class Initialized
INFO - 2022-04-02 18:12:18 --> Security Class Initialized
DEBUG - 2022-04-02 18:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:12:18 --> Input Class Initialized
INFO - 2022-04-02 18:12:18 --> Language Class Initialized
INFO - 2022-04-02 18:12:18 --> Loader Class Initialized
INFO - 2022-04-02 18:12:18 --> Helper loaded: url_helper
INFO - 2022-04-02 18:12:18 --> Helper loaded: form_helper
INFO - 2022-04-02 18:12:18 --> Helper loaded: common_helper
INFO - 2022-04-02 18:12:18 --> Helper loaded: util_helper
INFO - 2022-04-02 18:12:18 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:12:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:12:18 --> Unable to connect to the database
DEBUG - 2022-04-02 18:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:12:18 --> Form Validation Class Initialized
INFO - 2022-04-02 18:12:18 --> Controller Class Initialized
INFO - 2022-04-02 18:12:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:12:18 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:12:18 --> Final output sent to browser
DEBUG - 2022-04-02 18:12:18 --> Total execution time: 0.0714
INFO - 2022-04-02 18:14:29 --> Config Class Initialized
INFO - 2022-04-02 18:14:29 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:14:29 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:14:29 --> Utf8 Class Initialized
INFO - 2022-04-02 18:14:29 --> URI Class Initialized
DEBUG - 2022-04-02 18:14:29 --> No URI present. Default controller set.
INFO - 2022-04-02 18:14:29 --> Router Class Initialized
INFO - 2022-04-02 18:14:29 --> Output Class Initialized
INFO - 2022-04-02 18:14:29 --> Security Class Initialized
DEBUG - 2022-04-02 18:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:14:29 --> Input Class Initialized
INFO - 2022-04-02 18:14:29 --> Language Class Initialized
INFO - 2022-04-02 18:14:29 --> Loader Class Initialized
INFO - 2022-04-02 18:14:29 --> Helper loaded: url_helper
INFO - 2022-04-02 18:14:29 --> Helper loaded: form_helper
INFO - 2022-04-02 18:14:29 --> Helper loaded: common_helper
INFO - 2022-04-02 18:14:29 --> Helper loaded: util_helper
INFO - 2022-04-02 18:14:29 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:14:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:14:29 --> Unable to connect to the database
DEBUG - 2022-04-02 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:14:29 --> Form Validation Class Initialized
INFO - 2022-04-02 18:14:29 --> Controller Class Initialized
INFO - 2022-04-02 18:14:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:14:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:14:29 --> Final output sent to browser
DEBUG - 2022-04-02 18:14:29 --> Total execution time: 0.0688
INFO - 2022-04-02 18:14:41 --> Config Class Initialized
INFO - 2022-04-02 18:14:41 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:14:41 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:14:41 --> Utf8 Class Initialized
INFO - 2022-04-02 18:14:41 --> URI Class Initialized
INFO - 2022-04-02 18:14:41 --> Router Class Initialized
INFO - 2022-04-02 18:14:41 --> Output Class Initialized
INFO - 2022-04-02 18:14:41 --> Security Class Initialized
DEBUG - 2022-04-02 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:14:41 --> Input Class Initialized
INFO - 2022-04-02 18:14:41 --> Language Class Initialized
INFO - 2022-04-02 18:14:41 --> Loader Class Initialized
INFO - 2022-04-02 18:14:41 --> Helper loaded: url_helper
INFO - 2022-04-02 18:14:41 --> Helper loaded: form_helper
INFO - 2022-04-02 18:14:41 --> Helper loaded: common_helper
INFO - 2022-04-02 18:14:41 --> Helper loaded: util_helper
INFO - 2022-04-02 18:14:41 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:14:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:14:41 --> Unable to connect to the database
DEBUG - 2022-04-02 18:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:14:41 --> Form Validation Class Initialized
INFO - 2022-04-02 18:14:41 --> Controller Class Initialized
INFO - 2022-04-02 18:14:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:14:41 --> Final output sent to browser
DEBUG - 2022-04-02 18:14:41 --> Total execution time: 0.0612
INFO - 2022-04-02 18:14:41 --> Config Class Initialized
INFO - 2022-04-02 18:14:41 --> Hooks Class Initialized
INFO - 2022-04-02 18:14:41 --> Config Class Initialized
INFO - 2022-04-02 18:14:41 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-02 18:14:41 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:14:41 --> Utf8 Class Initialized
INFO - 2022-04-02 18:14:41 --> Utf8 Class Initialized
INFO - 2022-04-02 18:14:41 --> URI Class Initialized
INFO - 2022-04-02 18:14:41 --> URI Class Initialized
INFO - 2022-04-02 18:14:41 --> Router Class Initialized
INFO - 2022-04-02 18:14:41 --> Router Class Initialized
INFO - 2022-04-02 18:14:41 --> Output Class Initialized
INFO - 2022-04-02 18:14:41 --> Output Class Initialized
INFO - 2022-04-02 18:14:41 --> Security Class Initialized
INFO - 2022-04-02 18:14:41 --> Security Class Initialized
DEBUG - 2022-04-02 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:14:41 --> Input Class Initialized
DEBUG - 2022-04-02 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:14:41 --> Input Class Initialized
INFO - 2022-04-02 18:14:41 --> Language Class Initialized
INFO - 2022-04-02 18:14:41 --> Language Class Initialized
ERROR - 2022-04-02 18:14:41 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-02 18:14:41 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:14:48 --> Config Class Initialized
INFO - 2022-04-02 18:14:48 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:14:48 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:14:48 --> Utf8 Class Initialized
INFO - 2022-04-02 18:14:48 --> URI Class Initialized
DEBUG - 2022-04-02 18:14:48 --> No URI present. Default controller set.
INFO - 2022-04-02 18:14:48 --> Router Class Initialized
INFO - 2022-04-02 18:14:48 --> Output Class Initialized
INFO - 2022-04-02 18:14:48 --> Security Class Initialized
DEBUG - 2022-04-02 18:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:14:48 --> Input Class Initialized
INFO - 2022-04-02 18:14:48 --> Language Class Initialized
INFO - 2022-04-02 18:14:48 --> Loader Class Initialized
INFO - 2022-04-02 18:14:48 --> Helper loaded: url_helper
INFO - 2022-04-02 18:14:48 --> Helper loaded: form_helper
INFO - 2022-04-02 18:14:48 --> Helper loaded: common_helper
INFO - 2022-04-02 18:14:48 --> Helper loaded: util_helper
INFO - 2022-04-02 18:14:48 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:14:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:14:48 --> Unable to connect to the database
DEBUG - 2022-04-02 18:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:14:48 --> Form Validation Class Initialized
INFO - 2022-04-02 18:14:48 --> Controller Class Initialized
INFO - 2022-04-02 18:14:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:14:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:14:48 --> Final output sent to browser
DEBUG - 2022-04-02 18:14:48 --> Total execution time: 0.0686
INFO - 2022-04-02 18:15:30 --> Config Class Initialized
INFO - 2022-04-02 18:15:30 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:15:30 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:15:30 --> Utf8 Class Initialized
INFO - 2022-04-02 18:15:30 --> URI Class Initialized
INFO - 2022-04-02 18:15:30 --> Router Class Initialized
INFO - 2022-04-02 18:15:30 --> Output Class Initialized
INFO - 2022-04-02 18:15:30 --> Security Class Initialized
DEBUG - 2022-04-02 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:15:30 --> Input Class Initialized
INFO - 2022-04-02 18:15:30 --> Language Class Initialized
INFO - 2022-04-02 18:15:30 --> Loader Class Initialized
INFO - 2022-04-02 18:15:30 --> Helper loaded: url_helper
INFO - 2022-04-02 18:15:30 --> Helper loaded: form_helper
INFO - 2022-04-02 18:15:30 --> Helper loaded: common_helper
INFO - 2022-04-02 18:15:30 --> Helper loaded: util_helper
INFO - 2022-04-02 18:15:30 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:15:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:15:30 --> Unable to connect to the database
DEBUG - 2022-04-02 18:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:15:30 --> Form Validation Class Initialized
INFO - 2022-04-02 18:15:30 --> Controller Class Initialized
INFO - 2022-04-02 18:15:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:15:30 --> Final output sent to browser
DEBUG - 2022-04-02 18:15:30 --> Total execution time: 0.0568
INFO - 2022-04-02 18:15:30 --> Config Class Initialized
INFO - 2022-04-02 18:15:30 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:15:30 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:15:30 --> Utf8 Class Initialized
INFO - 2022-04-02 18:15:30 --> URI Class Initialized
INFO - 2022-04-02 18:15:30 --> Router Class Initialized
INFO - 2022-04-02 18:15:30 --> Config Class Initialized
INFO - 2022-04-02 18:15:30 --> Hooks Class Initialized
INFO - 2022-04-02 18:15:30 --> Output Class Initialized
INFO - 2022-04-02 18:15:30 --> Security Class Initialized
DEBUG - 2022-04-02 18:15:30 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:15:30 --> Utf8 Class Initialized
INFO - 2022-04-02 18:15:30 --> URI Class Initialized
DEBUG - 2022-04-02 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:15:30 --> Input Class Initialized
INFO - 2022-04-02 18:15:30 --> Router Class Initialized
INFO - 2022-04-02 18:15:30 --> Language Class Initialized
INFO - 2022-04-02 18:15:30 --> Output Class Initialized
ERROR - 2022-04-02 18:15:30 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:15:30 --> Security Class Initialized
DEBUG - 2022-04-02 18:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:15:30 --> Input Class Initialized
INFO - 2022-04-02 18:15:30 --> Language Class Initialized
ERROR - 2022-04-02 18:15:30 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:16:02 --> Config Class Initialized
INFO - 2022-04-02 18:16:02 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:16:02 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:16:02 --> Utf8 Class Initialized
INFO - 2022-04-02 18:16:02 --> URI Class Initialized
INFO - 2022-04-02 18:16:02 --> Router Class Initialized
INFO - 2022-04-02 18:16:02 --> Output Class Initialized
INFO - 2022-04-02 18:16:02 --> Security Class Initialized
DEBUG - 2022-04-02 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:16:02 --> Input Class Initialized
INFO - 2022-04-02 18:16:02 --> Language Class Initialized
INFO - 2022-04-02 18:16:02 --> Loader Class Initialized
INFO - 2022-04-02 18:16:02 --> Helper loaded: url_helper
INFO - 2022-04-02 18:16:02 --> Helper loaded: form_helper
INFO - 2022-04-02 18:16:02 --> Helper loaded: common_helper
INFO - 2022-04-02 18:16:02 --> Helper loaded: util_helper
INFO - 2022-04-02 18:16:02 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:16:02 --> Unable to connect to the database
DEBUG - 2022-04-02 18:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:16:02 --> Form Validation Class Initialized
INFO - 2022-04-02 18:16:02 --> Controller Class Initialized
INFO - 2022-04-02 18:16:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-04-02 18:16:02 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2022-04-02 18:16:06 --> Config Class Initialized
INFO - 2022-04-02 18:16:06 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:16:06 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:16:06 --> Utf8 Class Initialized
INFO - 2022-04-02 18:16:06 --> URI Class Initialized
DEBUG - 2022-04-02 18:16:06 --> No URI present. Default controller set.
INFO - 2022-04-02 18:16:06 --> Router Class Initialized
INFO - 2022-04-02 18:16:06 --> Output Class Initialized
INFO - 2022-04-02 18:16:06 --> Security Class Initialized
DEBUG - 2022-04-02 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:16:06 --> Input Class Initialized
INFO - 2022-04-02 18:16:06 --> Language Class Initialized
INFO - 2022-04-02 18:16:06 --> Loader Class Initialized
INFO - 2022-04-02 18:16:06 --> Helper loaded: url_helper
INFO - 2022-04-02 18:16:06 --> Helper loaded: form_helper
INFO - 2022-04-02 18:16:06 --> Helper loaded: common_helper
INFO - 2022-04-02 18:16:06 --> Helper loaded: util_helper
INFO - 2022-04-02 18:16:06 --> Database Driver Class Initialized
ERROR - 2022-04-02 18:16:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-02 18:16:06 --> Unable to connect to the database
DEBUG - 2022-04-02 18:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:16:06 --> Form Validation Class Initialized
INFO - 2022-04-02 18:16:06 --> Controller Class Initialized
INFO - 2022-04-02 18:16:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:16:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:16:06 --> Final output sent to browser
DEBUG - 2022-04-02 18:16:06 --> Total execution time: 0.0997
INFO - 2022-04-02 18:17:09 --> Config Class Initialized
INFO - 2022-04-02 18:17:09 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:17:09 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:17:09 --> Utf8 Class Initialized
INFO - 2022-04-02 18:17:09 --> URI Class Initialized
DEBUG - 2022-04-02 18:17:09 --> No URI present. Default controller set.
INFO - 2022-04-02 18:17:09 --> Router Class Initialized
INFO - 2022-04-02 18:17:09 --> Output Class Initialized
INFO - 2022-04-02 18:17:09 --> Security Class Initialized
DEBUG - 2022-04-02 18:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:17:09 --> Input Class Initialized
INFO - 2022-04-02 18:17:09 --> Language Class Initialized
INFO - 2022-04-02 18:17:09 --> Loader Class Initialized
INFO - 2022-04-02 18:17:09 --> Helper loaded: url_helper
INFO - 2022-04-02 18:17:09 --> Helper loaded: form_helper
INFO - 2022-04-02 18:17:09 --> Helper loaded: common_helper
INFO - 2022-04-02 18:17:09 --> Helper loaded: util_helper
INFO - 2022-04-02 18:17:09 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:17:09 --> Form Validation Class Initialized
INFO - 2022-04-02 18:17:09 --> Controller Class Initialized
INFO - 2022-04-02 18:17:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:17:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:17:09 --> Final output sent to browser
DEBUG - 2022-04-02 18:17:09 --> Total execution time: 0.0620
INFO - 2022-04-02 18:17:11 --> Config Class Initialized
INFO - 2022-04-02 18:17:11 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:17:11 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:17:11 --> Utf8 Class Initialized
INFO - 2022-04-02 18:17:11 --> URI Class Initialized
INFO - 2022-04-02 18:17:11 --> Router Class Initialized
INFO - 2022-04-02 18:17:11 --> Output Class Initialized
INFO - 2022-04-02 18:17:11 --> Security Class Initialized
DEBUG - 2022-04-02 18:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:17:11 --> Input Class Initialized
INFO - 2022-04-02 18:17:11 --> Language Class Initialized
INFO - 2022-04-02 18:17:11 --> Loader Class Initialized
INFO - 2022-04-02 18:17:11 --> Helper loaded: url_helper
INFO - 2022-04-02 18:17:11 --> Helper loaded: form_helper
INFO - 2022-04-02 18:17:11 --> Helper loaded: common_helper
INFO - 2022-04-02 18:17:11 --> Helper loaded: util_helper
INFO - 2022-04-02 18:17:11 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:17:11 --> Form Validation Class Initialized
INFO - 2022-04-02 18:17:11 --> Controller Class Initialized
INFO - 2022-04-02 18:17:11 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:17:11 --> Final output sent to browser
DEBUG - 2022-04-02 18:17:11 --> Total execution time: 0.0635
INFO - 2022-04-02 18:17:11 --> Config Class Initialized
INFO - 2022-04-02 18:17:11 --> Config Class Initialized
INFO - 2022-04-02 18:17:11 --> Hooks Class Initialized
INFO - 2022-04-02 18:17:11 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-02 18:17:11 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:17:11 --> Utf8 Class Initialized
INFO - 2022-04-02 18:17:11 --> Utf8 Class Initialized
INFO - 2022-04-02 18:17:11 --> URI Class Initialized
INFO - 2022-04-02 18:17:11 --> URI Class Initialized
INFO - 2022-04-02 18:17:11 --> Router Class Initialized
INFO - 2022-04-02 18:17:11 --> Router Class Initialized
INFO - 2022-04-02 18:17:11 --> Output Class Initialized
INFO - 2022-04-02 18:17:11 --> Output Class Initialized
INFO - 2022-04-02 18:17:11 --> Security Class Initialized
INFO - 2022-04-02 18:17:12 --> Security Class Initialized
DEBUG - 2022-04-02 18:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:17:12 --> Input Class Initialized
DEBUG - 2022-04-02 18:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:17:12 --> Input Class Initialized
INFO - 2022-04-02 18:17:12 --> Language Class Initialized
INFO - 2022-04-02 18:17:12 --> Language Class Initialized
ERROR - 2022-04-02 18:17:12 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-02 18:17:12 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:17:51 --> Config Class Initialized
INFO - 2022-04-02 18:17:51 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:17:51 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:17:51 --> Utf8 Class Initialized
INFO - 2022-04-02 18:17:51 --> URI Class Initialized
INFO - 2022-04-02 18:17:51 --> Router Class Initialized
INFO - 2022-04-02 18:17:51 --> Output Class Initialized
INFO - 2022-04-02 18:17:51 --> Security Class Initialized
DEBUG - 2022-04-02 18:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:17:51 --> Input Class Initialized
INFO - 2022-04-02 18:17:51 --> Language Class Initialized
INFO - 2022-04-02 18:17:51 --> Loader Class Initialized
INFO - 2022-04-02 18:17:51 --> Helper loaded: url_helper
INFO - 2022-04-02 18:17:51 --> Helper loaded: form_helper
INFO - 2022-04-02 18:17:51 --> Helper loaded: common_helper
INFO - 2022-04-02 18:17:51 --> Helper loaded: util_helper
INFO - 2022-04-02 18:17:51 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:17:51 --> Form Validation Class Initialized
INFO - 2022-04-02 18:17:51 --> Controller Class Initialized
INFO - 2022-04-02 18:17:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:17:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:17:51 --> Final output sent to browser
DEBUG - 2022-04-02 18:17:51 --> Total execution time: 0.0734
INFO - 2022-04-02 18:17:57 --> Config Class Initialized
INFO - 2022-04-02 18:17:57 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:17:57 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:17:57 --> Utf8 Class Initialized
INFO - 2022-04-02 18:17:57 --> URI Class Initialized
INFO - 2022-04-02 18:17:57 --> Router Class Initialized
INFO - 2022-04-02 18:17:57 --> Output Class Initialized
INFO - 2022-04-02 18:17:57 --> Security Class Initialized
DEBUG - 2022-04-02 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:17:57 --> Input Class Initialized
INFO - 2022-04-02 18:17:57 --> Language Class Initialized
INFO - 2022-04-02 18:17:57 --> Loader Class Initialized
INFO - 2022-04-02 18:17:57 --> Helper loaded: url_helper
INFO - 2022-04-02 18:17:57 --> Helper loaded: form_helper
INFO - 2022-04-02 18:17:57 --> Helper loaded: common_helper
INFO - 2022-04-02 18:17:57 --> Helper loaded: util_helper
INFO - 2022-04-02 18:17:57 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:17:57 --> Form Validation Class Initialized
INFO - 2022-04-02 18:17:57 --> Controller Class Initialized
INFO - 2022-04-02 18:17:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:17:57 --> Final output sent to browser
DEBUG - 2022-04-02 18:17:57 --> Total execution time: 0.0629
INFO - 2022-04-02 18:18:01 --> Config Class Initialized
INFO - 2022-04-02 18:18:01 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:18:01 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:18:01 --> Utf8 Class Initialized
INFO - 2022-04-02 18:18:01 --> URI Class Initialized
INFO - 2022-04-02 18:18:01 --> Router Class Initialized
INFO - 2022-04-02 18:18:01 --> Output Class Initialized
INFO - 2022-04-02 18:18:01 --> Security Class Initialized
DEBUG - 2022-04-02 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:18:01 --> Input Class Initialized
INFO - 2022-04-02 18:18:01 --> Language Class Initialized
INFO - 2022-04-02 18:18:01 --> Loader Class Initialized
INFO - 2022-04-02 18:18:01 --> Helper loaded: url_helper
INFO - 2022-04-02 18:18:01 --> Helper loaded: form_helper
INFO - 2022-04-02 18:18:01 --> Helper loaded: common_helper
INFO - 2022-04-02 18:18:01 --> Helper loaded: util_helper
INFO - 2022-04-02 18:18:01 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:18:01 --> Form Validation Class Initialized
INFO - 2022-04-02 18:18:01 --> Controller Class Initialized
INFO - 2022-04-02 18:18:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:18:01 --> Final output sent to browser
DEBUG - 2022-04-02 18:18:01 --> Total execution time: 0.0733
INFO - 2022-04-02 18:18:34 --> Config Class Initialized
INFO - 2022-04-02 18:18:34 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:18:34 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:18:34 --> Utf8 Class Initialized
INFO - 2022-04-02 18:18:34 --> URI Class Initialized
INFO - 2022-04-02 18:18:34 --> Router Class Initialized
INFO - 2022-04-02 18:18:34 --> Output Class Initialized
INFO - 2022-04-02 18:18:34 --> Security Class Initialized
DEBUG - 2022-04-02 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:18:34 --> Input Class Initialized
INFO - 2022-04-02 18:18:34 --> Language Class Initialized
INFO - 2022-04-02 18:18:34 --> Loader Class Initialized
INFO - 2022-04-02 18:18:34 --> Helper loaded: url_helper
INFO - 2022-04-02 18:18:34 --> Helper loaded: form_helper
INFO - 2022-04-02 18:18:34 --> Helper loaded: common_helper
INFO - 2022-04-02 18:18:34 --> Helper loaded: util_helper
INFO - 2022-04-02 18:18:34 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:18:34 --> Form Validation Class Initialized
INFO - 2022-04-02 18:18:34 --> Controller Class Initialized
INFO - 2022-04-02 18:18:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:18:34 --> Config Class Initialized
INFO - 2022-04-02 18:18:34 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:18:34 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:18:34 --> Utf8 Class Initialized
INFO - 2022-04-02 18:18:34 --> URI Class Initialized
INFO - 2022-04-02 18:18:34 --> Router Class Initialized
INFO - 2022-04-02 18:18:34 --> Output Class Initialized
INFO - 2022-04-02 18:18:34 --> Security Class Initialized
DEBUG - 2022-04-02 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:18:34 --> Input Class Initialized
INFO - 2022-04-02 18:18:34 --> Language Class Initialized
INFO - 2022-04-02 18:18:34 --> Loader Class Initialized
INFO - 2022-04-02 18:18:34 --> Helper loaded: url_helper
INFO - 2022-04-02 18:18:34 --> Helper loaded: form_helper
INFO - 2022-04-02 18:18:34 --> Helper loaded: common_helper
INFO - 2022-04-02 18:18:34 --> Helper loaded: util_helper
INFO - 2022-04-02 18:18:34 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:18:34 --> Form Validation Class Initialized
INFO - 2022-04-02 18:18:34 --> Controller Class Initialized
INFO - 2022-04-02 18:18:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:18:34 --> Final output sent to browser
DEBUG - 2022-04-02 18:18:34 --> Total execution time: 0.0673
INFO - 2022-04-02 18:18:34 --> Config Class Initialized
INFO - 2022-04-02 18:18:34 --> Hooks Class Initialized
INFO - 2022-04-02 18:18:34 --> Config Class Initialized
INFO - 2022-04-02 18:18:34 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:18:34 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:18:34 --> Utf8 Class Initialized
DEBUG - 2022-04-02 18:18:34 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:18:34 --> Utf8 Class Initialized
INFO - 2022-04-02 18:18:34 --> URI Class Initialized
INFO - 2022-04-02 18:18:34 --> URI Class Initialized
INFO - 2022-04-02 18:18:34 --> Router Class Initialized
INFO - 2022-04-02 18:18:34 --> Router Class Initialized
INFO - 2022-04-02 18:18:34 --> Output Class Initialized
INFO - 2022-04-02 18:18:34 --> Security Class Initialized
DEBUG - 2022-04-02 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:18:34 --> Input Class Initialized
INFO - 2022-04-02 18:18:34 --> Output Class Initialized
INFO - 2022-04-02 18:18:34 --> Language Class Initialized
INFO - 2022-04-02 18:18:34 --> Security Class Initialized
ERROR - 2022-04-02 18:18:34 --> 404 Page Not Found: Fasset/img
DEBUG - 2022-04-02 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:18:34 --> Input Class Initialized
INFO - 2022-04-02 18:18:34 --> Language Class Initialized
ERROR - 2022-04-02 18:18:34 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:18:58 --> Config Class Initialized
INFO - 2022-04-02 18:18:58 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:18:58 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:18:58 --> Utf8 Class Initialized
INFO - 2022-04-02 18:18:58 --> URI Class Initialized
INFO - 2022-04-02 18:18:58 --> Router Class Initialized
INFO - 2022-04-02 18:18:58 --> Output Class Initialized
INFO - 2022-04-02 18:18:58 --> Security Class Initialized
DEBUG - 2022-04-02 18:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:18:58 --> Input Class Initialized
INFO - 2022-04-02 18:18:58 --> Language Class Initialized
INFO - 2022-04-02 18:18:58 --> Loader Class Initialized
INFO - 2022-04-02 18:18:58 --> Helper loaded: url_helper
INFO - 2022-04-02 18:18:58 --> Helper loaded: form_helper
INFO - 2022-04-02 18:18:58 --> Helper loaded: common_helper
INFO - 2022-04-02 18:18:58 --> Helper loaded: util_helper
INFO - 2022-04-02 18:18:58 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:18:58 --> Form Validation Class Initialized
INFO - 2022-04-02 18:18:58 --> Controller Class Initialized
INFO - 2022-04-02 18:18:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:18:58 --> Final output sent to browser
DEBUG - 2022-04-02 18:18:58 --> Total execution time: 0.0749
INFO - 2022-04-02 18:19:00 --> Config Class Initialized
INFO - 2022-04-02 18:19:00 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:19:01 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:19:01 --> Utf8 Class Initialized
INFO - 2022-04-02 18:19:01 --> URI Class Initialized
DEBUG - 2022-04-02 18:19:01 --> No URI present. Default controller set.
INFO - 2022-04-02 18:19:01 --> Router Class Initialized
INFO - 2022-04-02 18:19:01 --> Output Class Initialized
INFO - 2022-04-02 18:19:01 --> Security Class Initialized
DEBUG - 2022-04-02 18:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:19:01 --> Input Class Initialized
INFO - 2022-04-02 18:19:01 --> Language Class Initialized
INFO - 2022-04-02 18:19:01 --> Loader Class Initialized
INFO - 2022-04-02 18:19:01 --> Helper loaded: url_helper
INFO - 2022-04-02 18:19:01 --> Helper loaded: form_helper
INFO - 2022-04-02 18:19:01 --> Helper loaded: common_helper
INFO - 2022-04-02 18:19:01 --> Helper loaded: util_helper
INFO - 2022-04-02 18:19:01 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:19:01 --> Form Validation Class Initialized
INFO - 2022-04-02 18:19:01 --> Controller Class Initialized
INFO - 2022-04-02 18:19:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:19:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:19:01 --> Final output sent to browser
DEBUG - 2022-04-02 18:19:01 --> Total execution time: 0.0746
INFO - 2022-04-02 18:19:15 --> Config Class Initialized
INFO - 2022-04-02 18:19:15 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:19:15 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:19:15 --> Utf8 Class Initialized
INFO - 2022-04-02 18:19:15 --> URI Class Initialized
DEBUG - 2022-04-02 18:19:15 --> No URI present. Default controller set.
INFO - 2022-04-02 18:19:15 --> Router Class Initialized
INFO - 2022-04-02 18:19:15 --> Output Class Initialized
INFO - 2022-04-02 18:19:15 --> Security Class Initialized
DEBUG - 2022-04-02 18:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:19:15 --> Input Class Initialized
INFO - 2022-04-02 18:19:15 --> Language Class Initialized
INFO - 2022-04-02 18:19:15 --> Loader Class Initialized
INFO - 2022-04-02 18:19:15 --> Helper loaded: url_helper
INFO - 2022-04-02 18:19:15 --> Helper loaded: form_helper
INFO - 2022-04-02 18:19:15 --> Helper loaded: common_helper
INFO - 2022-04-02 18:19:15 --> Helper loaded: util_helper
INFO - 2022-04-02 18:19:15 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:19:15 --> Form Validation Class Initialized
INFO - 2022-04-02 18:19:15 --> Controller Class Initialized
INFO - 2022-04-02 18:19:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:19:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:19:15 --> Final output sent to browser
DEBUG - 2022-04-02 18:19:15 --> Total execution time: 0.0648
INFO - 2022-04-02 18:28:16 --> Config Class Initialized
INFO - 2022-04-02 18:28:16 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:28:16 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:28:16 --> Utf8 Class Initialized
INFO - 2022-04-02 18:28:16 --> URI Class Initialized
INFO - 2022-04-02 18:28:16 --> Router Class Initialized
INFO - 2022-04-02 18:28:16 --> Output Class Initialized
INFO - 2022-04-02 18:28:16 --> Security Class Initialized
DEBUG - 2022-04-02 18:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:28:16 --> Input Class Initialized
INFO - 2022-04-02 18:28:16 --> Language Class Initialized
INFO - 2022-04-02 18:28:16 --> Loader Class Initialized
INFO - 2022-04-02 18:28:16 --> Helper loaded: url_helper
INFO - 2022-04-02 18:28:16 --> Helper loaded: form_helper
INFO - 2022-04-02 18:28:16 --> Helper loaded: common_helper
INFO - 2022-04-02 18:28:16 --> Helper loaded: util_helper
INFO - 2022-04-02 18:28:16 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:28:16 --> Form Validation Class Initialized
INFO - 2022-04-02 18:28:16 --> Controller Class Initialized
INFO - 2022-04-02 18:28:16 --> Model Class Initialized
INFO - 2022-04-02 18:28:16 --> Final output sent to browser
DEBUG - 2022-04-02 18:28:16 --> Total execution time: 0.0640
INFO - 2022-04-02 18:28:36 --> Config Class Initialized
INFO - 2022-04-02 18:28:36 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:28:36 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:28:36 --> Utf8 Class Initialized
INFO - 2022-04-02 18:28:36 --> URI Class Initialized
INFO - 2022-04-02 18:28:36 --> Router Class Initialized
INFO - 2022-04-02 18:28:36 --> Output Class Initialized
INFO - 2022-04-02 18:28:36 --> Security Class Initialized
DEBUG - 2022-04-02 18:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:28:36 --> Input Class Initialized
INFO - 2022-04-02 18:28:36 --> Language Class Initialized
INFO - 2022-04-02 18:28:36 --> Loader Class Initialized
INFO - 2022-04-02 18:28:36 --> Helper loaded: url_helper
INFO - 2022-04-02 18:28:36 --> Helper loaded: form_helper
INFO - 2022-04-02 18:28:36 --> Helper loaded: common_helper
INFO - 2022-04-02 18:28:36 --> Helper loaded: util_helper
INFO - 2022-04-02 18:28:36 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:28:36 --> Form Validation Class Initialized
INFO - 2022-04-02 18:28:36 --> Controller Class Initialized
INFO - 2022-04-02 18:28:36 --> Model Class Initialized
INFO - 2022-04-02 18:28:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:28:36 --> Final output sent to browser
DEBUG - 2022-04-02 18:28:36 --> Total execution time: 0.0645
INFO - 2022-04-02 18:29:10 --> Config Class Initialized
INFO - 2022-04-02 18:29:10 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:29:10 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:29:10 --> Utf8 Class Initialized
INFO - 2022-04-02 18:29:10 --> URI Class Initialized
INFO - 2022-04-02 18:29:10 --> Router Class Initialized
INFO - 2022-04-02 18:29:10 --> Output Class Initialized
INFO - 2022-04-02 18:29:10 --> Security Class Initialized
DEBUG - 2022-04-02 18:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:29:10 --> Input Class Initialized
INFO - 2022-04-02 18:29:10 --> Language Class Initialized
INFO - 2022-04-02 18:29:10 --> Loader Class Initialized
INFO - 2022-04-02 18:29:10 --> Helper loaded: url_helper
INFO - 2022-04-02 18:29:10 --> Helper loaded: form_helper
INFO - 2022-04-02 18:29:10 --> Helper loaded: common_helper
INFO - 2022-04-02 18:29:10 --> Helper loaded: util_helper
INFO - 2022-04-02 18:29:10 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:29:10 --> Form Validation Class Initialized
INFO - 2022-04-02 18:29:10 --> Controller Class Initialized
INFO - 2022-04-02 18:29:10 --> Model Class Initialized
INFO - 2022-04-02 18:29:10 --> Config Class Initialized
INFO - 2022-04-02 18:29:10 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:29:10 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:29:10 --> Utf8 Class Initialized
INFO - 2022-04-02 18:29:10 --> URI Class Initialized
INFO - 2022-04-02 18:29:10 --> Router Class Initialized
INFO - 2022-04-02 18:29:10 --> Output Class Initialized
INFO - 2022-04-02 18:29:10 --> Security Class Initialized
DEBUG - 2022-04-02 18:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:29:10 --> Input Class Initialized
INFO - 2022-04-02 18:29:10 --> Language Class Initialized
INFO - 2022-04-02 18:29:10 --> Loader Class Initialized
INFO - 2022-04-02 18:29:10 --> Helper loaded: url_helper
INFO - 2022-04-02 18:29:10 --> Helper loaded: form_helper
INFO - 2022-04-02 18:29:10 --> Helper loaded: common_helper
INFO - 2022-04-02 18:29:10 --> Helper loaded: util_helper
INFO - 2022-04-02 18:29:10 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:29:10 --> Form Validation Class Initialized
INFO - 2022-04-02 18:29:10 --> Controller Class Initialized
INFO - 2022-04-02 18:29:10 --> Model Class Initialized
INFO - 2022-04-02 18:29:10 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:29:10 --> Final output sent to browser
DEBUG - 2022-04-02 18:29:10 --> Total execution time: 0.0663
INFO - 2022-04-02 18:29:24 --> Config Class Initialized
INFO - 2022-04-02 18:29:24 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:29:24 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:29:24 --> Utf8 Class Initialized
INFO - 2022-04-02 18:29:24 --> URI Class Initialized
INFO - 2022-04-02 18:29:24 --> Router Class Initialized
INFO - 2022-04-02 18:29:24 --> Output Class Initialized
INFO - 2022-04-02 18:29:24 --> Security Class Initialized
DEBUG - 2022-04-02 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:29:24 --> Input Class Initialized
INFO - 2022-04-02 18:29:24 --> Language Class Initialized
INFO - 2022-04-02 18:29:24 --> Loader Class Initialized
INFO - 2022-04-02 18:29:24 --> Helper loaded: url_helper
INFO - 2022-04-02 18:29:24 --> Helper loaded: form_helper
INFO - 2022-04-02 18:29:24 --> Helper loaded: common_helper
INFO - 2022-04-02 18:29:24 --> Helper loaded: util_helper
INFO - 2022-04-02 18:29:24 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:29:24 --> Form Validation Class Initialized
INFO - 2022-04-02 18:29:24 --> Controller Class Initialized
INFO - 2022-04-02 18:29:24 --> Model Class Initialized
INFO - 2022-04-02 18:29:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:29:24 --> Final output sent to browser
DEBUG - 2022-04-02 18:29:24 --> Total execution time: 0.0650
INFO - 2022-04-02 18:29:33 --> Config Class Initialized
INFO - 2022-04-02 18:29:33 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:29:33 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:29:33 --> Utf8 Class Initialized
INFO - 2022-04-02 18:29:33 --> URI Class Initialized
INFO - 2022-04-02 18:29:33 --> Router Class Initialized
INFO - 2022-04-02 18:29:33 --> Output Class Initialized
INFO - 2022-04-02 18:29:33 --> Security Class Initialized
DEBUG - 2022-04-02 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:29:33 --> Input Class Initialized
INFO - 2022-04-02 18:29:33 --> Language Class Initialized
INFO - 2022-04-02 18:29:33 --> Loader Class Initialized
INFO - 2022-04-02 18:29:33 --> Helper loaded: url_helper
INFO - 2022-04-02 18:29:33 --> Helper loaded: form_helper
INFO - 2022-04-02 18:29:33 --> Helper loaded: common_helper
INFO - 2022-04-02 18:29:33 --> Helper loaded: util_helper
INFO - 2022-04-02 18:29:33 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:29:33 --> Form Validation Class Initialized
INFO - 2022-04-02 18:29:33 --> Controller Class Initialized
INFO - 2022-04-02 18:29:33 --> Model Class Initialized
INFO - 2022-04-02 18:29:33 --> Config Class Initialized
INFO - 2022-04-02 18:29:33 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:29:33 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:29:33 --> Utf8 Class Initialized
INFO - 2022-04-02 18:29:33 --> URI Class Initialized
INFO - 2022-04-02 18:29:33 --> Router Class Initialized
INFO - 2022-04-02 18:29:33 --> Output Class Initialized
INFO - 2022-04-02 18:29:33 --> Security Class Initialized
DEBUG - 2022-04-02 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:29:33 --> Input Class Initialized
INFO - 2022-04-02 18:29:33 --> Language Class Initialized
INFO - 2022-04-02 18:29:33 --> Loader Class Initialized
INFO - 2022-04-02 18:29:33 --> Helper loaded: url_helper
INFO - 2022-04-02 18:29:33 --> Helper loaded: form_helper
INFO - 2022-04-02 18:29:33 --> Helper loaded: common_helper
INFO - 2022-04-02 18:29:33 --> Helper loaded: util_helper
INFO - 2022-04-02 18:29:33 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:29:33 --> Form Validation Class Initialized
INFO - 2022-04-02 18:29:33 --> Controller Class Initialized
INFO - 2022-04-02 18:29:33 --> Model Class Initialized
INFO - 2022-04-02 18:29:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:29:33 --> Final output sent to browser
DEBUG - 2022-04-02 18:29:33 --> Total execution time: 0.0662
INFO - 2022-04-02 18:29:37 --> Config Class Initialized
INFO - 2022-04-02 18:29:37 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:29:37 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:29:37 --> Utf8 Class Initialized
INFO - 2022-04-02 18:29:37 --> URI Class Initialized
INFO - 2022-04-02 18:29:37 --> Router Class Initialized
INFO - 2022-04-02 18:29:37 --> Output Class Initialized
INFO - 2022-04-02 18:29:37 --> Security Class Initialized
DEBUG - 2022-04-02 18:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:29:37 --> Input Class Initialized
INFO - 2022-04-02 18:29:37 --> Language Class Initialized
INFO - 2022-04-02 18:29:37 --> Loader Class Initialized
INFO - 2022-04-02 18:29:37 --> Helper loaded: url_helper
INFO - 2022-04-02 18:29:37 --> Helper loaded: form_helper
INFO - 2022-04-02 18:29:37 --> Helper loaded: common_helper
INFO - 2022-04-02 18:29:37 --> Helper loaded: util_helper
INFO - 2022-04-02 18:29:37 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:29:37 --> Form Validation Class Initialized
INFO - 2022-04-02 18:29:37 --> Controller Class Initialized
INFO - 2022-04-02 18:29:37 --> Model Class Initialized
INFO - 2022-04-02 18:29:37 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:29:37 --> Final output sent to browser
DEBUG - 2022-04-02 18:29:37 --> Total execution time: 0.0590
INFO - 2022-04-02 18:30:09 --> Config Class Initialized
INFO - 2022-04-02 18:30:09 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:09 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:09 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:09 --> URI Class Initialized
INFO - 2022-04-02 18:30:09 --> Router Class Initialized
INFO - 2022-04-02 18:30:09 --> Output Class Initialized
INFO - 2022-04-02 18:30:09 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:09 --> Input Class Initialized
INFO - 2022-04-02 18:30:09 --> Language Class Initialized
INFO - 2022-04-02 18:30:09 --> Loader Class Initialized
INFO - 2022-04-02 18:30:09 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:09 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:09 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:09 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:09 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:09 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:09 --> Controller Class Initialized
INFO - 2022-04-02 18:30:09 --> Model Class Initialized
INFO - 2022-04-02 18:30:09 --> Config Class Initialized
INFO - 2022-04-02 18:30:09 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:09 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:09 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:09 --> URI Class Initialized
INFO - 2022-04-02 18:30:09 --> Router Class Initialized
INFO - 2022-04-02 18:30:09 --> Output Class Initialized
INFO - 2022-04-02 18:30:09 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:09 --> Input Class Initialized
INFO - 2022-04-02 18:30:09 --> Language Class Initialized
INFO - 2022-04-02 18:30:09 --> Loader Class Initialized
INFO - 2022-04-02 18:30:09 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:09 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:09 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:09 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:09 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:09 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:09 --> Controller Class Initialized
INFO - 2022-04-02 18:30:09 --> Model Class Initialized
INFO - 2022-04-02 18:30:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:30:09 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:09 --> Total execution time: 0.0685
INFO - 2022-04-02 18:30:13 --> Config Class Initialized
INFO - 2022-04-02 18:30:13 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:13 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:13 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:13 --> URI Class Initialized
INFO - 2022-04-02 18:30:13 --> Router Class Initialized
INFO - 2022-04-02 18:30:13 --> Output Class Initialized
INFO - 2022-04-02 18:30:13 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:13 --> Input Class Initialized
INFO - 2022-04-02 18:30:13 --> Language Class Initialized
INFO - 2022-04-02 18:30:13 --> Loader Class Initialized
INFO - 2022-04-02 18:30:13 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:13 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:13 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:13 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:13 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:13 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:13 --> Controller Class Initialized
INFO - 2022-04-02 18:30:13 --> Model Class Initialized
INFO - 2022-04-02 18:30:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:30:13 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:13 --> Total execution time: 0.0753
INFO - 2022-04-02 18:30:44 --> Config Class Initialized
INFO - 2022-04-02 18:30:44 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:44 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:44 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:44 --> URI Class Initialized
INFO - 2022-04-02 18:30:44 --> Router Class Initialized
INFO - 2022-04-02 18:30:44 --> Output Class Initialized
INFO - 2022-04-02 18:30:44 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:44 --> Input Class Initialized
INFO - 2022-04-02 18:30:44 --> Language Class Initialized
INFO - 2022-04-02 18:30:44 --> Loader Class Initialized
INFO - 2022-04-02 18:30:44 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:44 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:44 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:44 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:44 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:44 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:44 --> Controller Class Initialized
INFO - 2022-04-02 18:30:44 --> Model Class Initialized
INFO - 2022-04-02 18:30:44 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:44 --> Total execution time: 0.0569
INFO - 2022-04-02 18:30:44 --> Config Class Initialized
INFO - 2022-04-02 18:30:44 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:44 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:44 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:44 --> URI Class Initialized
DEBUG - 2022-04-02 18:30:44 --> No URI present. Default controller set.
INFO - 2022-04-02 18:30:44 --> Router Class Initialized
INFO - 2022-04-02 18:30:44 --> Output Class Initialized
INFO - 2022-04-02 18:30:44 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:44 --> Input Class Initialized
INFO - 2022-04-02 18:30:44 --> Language Class Initialized
INFO - 2022-04-02 18:30:44 --> Loader Class Initialized
INFO - 2022-04-02 18:30:44 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:44 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:44 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:44 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:44 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:44 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:44 --> Controller Class Initialized
INFO - 2022-04-02 18:30:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:30:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:30:44 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:44 --> Total execution time: 0.0686
INFO - 2022-04-02 18:30:50 --> Config Class Initialized
INFO - 2022-04-02 18:30:50 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:50 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:50 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:50 --> URI Class Initialized
INFO - 2022-04-02 18:30:50 --> Router Class Initialized
INFO - 2022-04-02 18:30:50 --> Output Class Initialized
INFO - 2022-04-02 18:30:50 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:50 --> Input Class Initialized
INFO - 2022-04-02 18:30:50 --> Language Class Initialized
INFO - 2022-04-02 18:30:50 --> Loader Class Initialized
INFO - 2022-04-02 18:30:50 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:50 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:50 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:50 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:50 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:50 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:50 --> Controller Class Initialized
INFO - 2022-04-02 18:30:50 --> Model Class Initialized
INFO - 2022-04-02 18:30:50 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:50 --> Total execution time: 0.0594
INFO - 2022-04-02 18:30:50 --> Config Class Initialized
INFO - 2022-04-02 18:30:50 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:50 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:50 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:50 --> URI Class Initialized
INFO - 2022-04-02 18:30:50 --> Router Class Initialized
INFO - 2022-04-02 18:30:50 --> Output Class Initialized
INFO - 2022-04-02 18:30:50 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:50 --> Input Class Initialized
INFO - 2022-04-02 18:30:50 --> Language Class Initialized
INFO - 2022-04-02 18:30:50 --> Loader Class Initialized
INFO - 2022-04-02 18:30:50 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:50 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:50 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:50 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:50 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:50 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:50 --> Controller Class Initialized
INFO - 2022-04-02 18:30:50 --> Model Class Initialized
INFO - 2022-04-02 18:30:50 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:30:50 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:50 --> Total execution time: 0.0701
INFO - 2022-04-02 18:30:51 --> Config Class Initialized
INFO - 2022-04-02 18:30:51 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:51 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:51 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:51 --> URI Class Initialized
INFO - 2022-04-02 18:30:51 --> Router Class Initialized
INFO - 2022-04-02 18:30:51 --> Output Class Initialized
INFO - 2022-04-02 18:30:51 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:51 --> Input Class Initialized
INFO - 2022-04-02 18:30:51 --> Language Class Initialized
INFO - 2022-04-02 18:30:51 --> Loader Class Initialized
INFO - 2022-04-02 18:30:51 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:51 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:51 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:51 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:51 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:51 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:51 --> Controller Class Initialized
INFO - 2022-04-02 18:30:51 --> Model Class Initialized
INFO - 2022-04-02 18:30:51 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:30:51 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:51 --> Total execution time: 0.0677
INFO - 2022-04-02 18:30:56 --> Config Class Initialized
INFO - 2022-04-02 18:30:56 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:56 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:56 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:56 --> URI Class Initialized
DEBUG - 2022-04-02 18:30:56 --> No URI present. Default controller set.
INFO - 2022-04-02 18:30:56 --> Router Class Initialized
INFO - 2022-04-02 18:30:56 --> Output Class Initialized
INFO - 2022-04-02 18:30:56 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:56 --> Input Class Initialized
INFO - 2022-04-02 18:30:56 --> Language Class Initialized
INFO - 2022-04-02 18:30:56 --> Loader Class Initialized
INFO - 2022-04-02 18:30:56 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:56 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:56 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:56 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:56 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:56 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:56 --> Controller Class Initialized
INFO - 2022-04-02 18:30:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:30:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:30:56 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:56 --> Total execution time: 0.0726
INFO - 2022-04-02 18:30:59 --> Config Class Initialized
INFO - 2022-04-02 18:30:59 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:59 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:59 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:59 --> URI Class Initialized
INFO - 2022-04-02 18:30:59 --> Router Class Initialized
INFO - 2022-04-02 18:30:59 --> Output Class Initialized
INFO - 2022-04-02 18:30:59 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:59 --> Input Class Initialized
INFO - 2022-04-02 18:30:59 --> Language Class Initialized
INFO - 2022-04-02 18:30:59 --> Loader Class Initialized
INFO - 2022-04-02 18:30:59 --> Helper loaded: url_helper
INFO - 2022-04-02 18:30:59 --> Helper loaded: form_helper
INFO - 2022-04-02 18:30:59 --> Helper loaded: common_helper
INFO - 2022-04-02 18:30:59 --> Helper loaded: util_helper
INFO - 2022-04-02 18:30:59 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:30:59 --> Form Validation Class Initialized
INFO - 2022-04-02 18:30:59 --> Controller Class Initialized
INFO - 2022-04-02 18:30:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:30:59 --> Final output sent to browser
DEBUG - 2022-04-02 18:30:59 --> Total execution time: 0.0594
INFO - 2022-04-02 18:30:59 --> Config Class Initialized
INFO - 2022-04-02 18:30:59 --> Hooks Class Initialized
INFO - 2022-04-02 18:30:59 --> Config Class Initialized
INFO - 2022-04-02 18:30:59 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:30:59 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:59 --> Utf8 Class Initialized
DEBUG - 2022-04-02 18:30:59 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:30:59 --> Utf8 Class Initialized
INFO - 2022-04-02 18:30:59 --> URI Class Initialized
INFO - 2022-04-02 18:30:59 --> URI Class Initialized
INFO - 2022-04-02 18:30:59 --> Router Class Initialized
INFO - 2022-04-02 18:30:59 --> Router Class Initialized
INFO - 2022-04-02 18:30:59 --> Output Class Initialized
INFO - 2022-04-02 18:30:59 --> Output Class Initialized
INFO - 2022-04-02 18:30:59 --> Security Class Initialized
INFO - 2022-04-02 18:30:59 --> Security Class Initialized
DEBUG - 2022-04-02 18:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-02 18:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:30:59 --> Input Class Initialized
INFO - 2022-04-02 18:30:59 --> Input Class Initialized
INFO - 2022-04-02 18:30:59 --> Language Class Initialized
INFO - 2022-04-02 18:30:59 --> Language Class Initialized
ERROR - 2022-04-02 18:30:59 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-02 18:30:59 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:31:48 --> Config Class Initialized
INFO - 2022-04-02 18:31:48 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:31:48 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:31:48 --> Utf8 Class Initialized
INFO - 2022-04-02 18:31:48 --> URI Class Initialized
INFO - 2022-04-02 18:31:48 --> Router Class Initialized
INFO - 2022-04-02 18:31:48 --> Output Class Initialized
INFO - 2022-04-02 18:31:48 --> Security Class Initialized
DEBUG - 2022-04-02 18:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:31:48 --> Input Class Initialized
INFO - 2022-04-02 18:31:48 --> Language Class Initialized
INFO - 2022-04-02 18:31:48 --> Loader Class Initialized
INFO - 2022-04-02 18:31:48 --> Helper loaded: url_helper
INFO - 2022-04-02 18:31:48 --> Helper loaded: form_helper
INFO - 2022-04-02 18:31:48 --> Helper loaded: common_helper
INFO - 2022-04-02 18:31:48 --> Helper loaded: util_helper
INFO - 2022-04-02 18:31:48 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:31:48 --> Form Validation Class Initialized
INFO - 2022-04-02 18:31:48 --> Controller Class Initialized
INFO - 2022-04-02 18:31:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:31:48 --> Config Class Initialized
INFO - 2022-04-02 18:31:48 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:31:48 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:31:48 --> Utf8 Class Initialized
INFO - 2022-04-02 18:31:48 --> URI Class Initialized
INFO - 2022-04-02 18:31:48 --> Router Class Initialized
INFO - 2022-04-02 18:31:48 --> Output Class Initialized
INFO - 2022-04-02 18:31:48 --> Security Class Initialized
DEBUG - 2022-04-02 18:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:31:48 --> Input Class Initialized
INFO - 2022-04-02 18:31:48 --> Language Class Initialized
INFO - 2022-04-02 18:31:48 --> Loader Class Initialized
INFO - 2022-04-02 18:31:48 --> Helper loaded: url_helper
INFO - 2022-04-02 18:31:48 --> Helper loaded: form_helper
INFO - 2022-04-02 18:31:48 --> Helper loaded: common_helper
INFO - 2022-04-02 18:31:48 --> Helper loaded: util_helper
INFO - 2022-04-02 18:31:48 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:31:48 --> Form Validation Class Initialized
INFO - 2022-04-02 18:31:48 --> Controller Class Initialized
INFO - 2022-04-02 18:31:48 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 18:31:48 --> Final output sent to browser
DEBUG - 2022-04-02 18:31:48 --> Total execution time: 0.0698
INFO - 2022-04-02 18:31:53 --> Config Class Initialized
INFO - 2022-04-02 18:31:53 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:31:53 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:31:53 --> Utf8 Class Initialized
INFO - 2022-04-02 18:31:53 --> URI Class Initialized
INFO - 2022-04-02 18:31:53 --> Router Class Initialized
INFO - 2022-04-02 18:31:53 --> Output Class Initialized
INFO - 2022-04-02 18:31:53 --> Security Class Initialized
DEBUG - 2022-04-02 18:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:31:53 --> Input Class Initialized
INFO - 2022-04-02 18:31:53 --> Language Class Initialized
INFO - 2022-04-02 18:31:53 --> Loader Class Initialized
INFO - 2022-04-02 18:31:53 --> Helper loaded: url_helper
INFO - 2022-04-02 18:31:53 --> Helper loaded: form_helper
INFO - 2022-04-02 18:31:53 --> Helper loaded: common_helper
INFO - 2022-04-02 18:31:53 --> Helper loaded: util_helper
INFO - 2022-04-02 18:31:53 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:31:53 --> Form Validation Class Initialized
INFO - 2022-04-02 18:31:53 --> Controller Class Initialized
INFO - 2022-04-02 18:31:53 --> Model Class Initialized
INFO - 2022-04-02 18:31:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:31:53 --> Final output sent to browser
DEBUG - 2022-04-02 18:31:53 --> Total execution time: 0.0561
INFO - 2022-04-02 18:31:56 --> Config Class Initialized
INFO - 2022-04-02 18:31:56 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:31:56 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:31:56 --> Utf8 Class Initialized
INFO - 2022-04-02 18:31:56 --> URI Class Initialized
INFO - 2022-04-02 18:31:56 --> Router Class Initialized
INFO - 2022-04-02 18:31:56 --> Output Class Initialized
INFO - 2022-04-02 18:31:56 --> Security Class Initialized
DEBUG - 2022-04-02 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:31:56 --> Input Class Initialized
INFO - 2022-04-02 18:31:56 --> Language Class Initialized
INFO - 2022-04-02 18:31:56 --> Loader Class Initialized
INFO - 2022-04-02 18:31:56 --> Helper loaded: url_helper
INFO - 2022-04-02 18:31:56 --> Helper loaded: form_helper
INFO - 2022-04-02 18:31:56 --> Helper loaded: common_helper
INFO - 2022-04-02 18:31:56 --> Helper loaded: util_helper
INFO - 2022-04-02 18:31:56 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:31:56 --> Form Validation Class Initialized
INFO - 2022-04-02 18:31:56 --> Controller Class Initialized
INFO - 2022-04-02 18:31:56 --> Model Class Initialized
INFO - 2022-04-02 18:31:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:31:56 --> Final output sent to browser
DEBUG - 2022-04-02 18:31:56 --> Total execution time: 0.0719
INFO - 2022-04-02 18:31:59 --> Config Class Initialized
INFO - 2022-04-02 18:31:59 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:31:59 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:31:59 --> Utf8 Class Initialized
INFO - 2022-04-02 18:31:59 --> URI Class Initialized
INFO - 2022-04-02 18:31:59 --> Router Class Initialized
INFO - 2022-04-02 18:31:59 --> Output Class Initialized
INFO - 2022-04-02 18:31:59 --> Security Class Initialized
DEBUG - 2022-04-02 18:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:31:59 --> Input Class Initialized
INFO - 2022-04-02 18:31:59 --> Language Class Initialized
INFO - 2022-04-02 18:31:59 --> Loader Class Initialized
INFO - 2022-04-02 18:31:59 --> Helper loaded: url_helper
INFO - 2022-04-02 18:31:59 --> Helper loaded: form_helper
INFO - 2022-04-02 18:31:59 --> Helper loaded: common_helper
INFO - 2022-04-02 18:31:59 --> Helper loaded: util_helper
INFO - 2022-04-02 18:31:59 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:31:59 --> Form Validation Class Initialized
INFO - 2022-04-02 18:31:59 --> Controller Class Initialized
INFO - 2022-04-02 18:31:59 --> Model Class Initialized
INFO - 2022-04-02 18:31:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:31:59 --> Final output sent to browser
DEBUG - 2022-04-02 18:31:59 --> Total execution time: 0.0638
INFO - 2022-04-02 18:32:25 --> Config Class Initialized
INFO - 2022-04-02 18:32:25 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:32:25 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:32:25 --> Utf8 Class Initialized
INFO - 2022-04-02 18:32:25 --> URI Class Initialized
INFO - 2022-04-02 18:32:25 --> Router Class Initialized
INFO - 2022-04-02 18:32:25 --> Output Class Initialized
INFO - 2022-04-02 18:32:25 --> Security Class Initialized
DEBUG - 2022-04-02 18:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:32:25 --> Input Class Initialized
INFO - 2022-04-02 18:32:25 --> Language Class Initialized
INFO - 2022-04-02 18:32:25 --> Loader Class Initialized
INFO - 2022-04-02 18:32:25 --> Helper loaded: url_helper
INFO - 2022-04-02 18:32:25 --> Helper loaded: form_helper
INFO - 2022-04-02 18:32:25 --> Helper loaded: common_helper
INFO - 2022-04-02 18:32:25 --> Helper loaded: util_helper
INFO - 2022-04-02 18:32:25 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:32:25 --> Form Validation Class Initialized
INFO - 2022-04-02 18:32:25 --> Controller Class Initialized
INFO - 2022-04-02 18:32:25 --> Model Class Initialized
INFO - 2022-04-02 18:32:25 --> Config Class Initialized
INFO - 2022-04-02 18:32:25 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:32:25 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:32:25 --> Utf8 Class Initialized
INFO - 2022-04-02 18:32:25 --> URI Class Initialized
INFO - 2022-04-02 18:32:25 --> Router Class Initialized
INFO - 2022-04-02 18:32:25 --> Output Class Initialized
INFO - 2022-04-02 18:32:25 --> Security Class Initialized
DEBUG - 2022-04-02 18:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:32:25 --> Input Class Initialized
INFO - 2022-04-02 18:32:25 --> Language Class Initialized
INFO - 2022-04-02 18:32:25 --> Loader Class Initialized
INFO - 2022-04-02 18:32:25 --> Helper loaded: url_helper
INFO - 2022-04-02 18:32:25 --> Helper loaded: form_helper
INFO - 2022-04-02 18:32:25 --> Helper loaded: common_helper
INFO - 2022-04-02 18:32:25 --> Helper loaded: util_helper
INFO - 2022-04-02 18:32:25 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:32:25 --> Form Validation Class Initialized
INFO - 2022-04-02 18:32:25 --> Controller Class Initialized
INFO - 2022-04-02 18:32:25 --> Model Class Initialized
INFO - 2022-04-02 18:32:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:32:25 --> Final output sent to browser
DEBUG - 2022-04-02 18:32:25 --> Total execution time: 0.0597
INFO - 2022-04-02 18:44:16 --> Config Class Initialized
INFO - 2022-04-02 18:44:16 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:16 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:16 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:16 --> URI Class Initialized
INFO - 2022-04-02 18:44:16 --> Router Class Initialized
INFO - 2022-04-02 18:44:16 --> Output Class Initialized
INFO - 2022-04-02 18:44:16 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:16 --> Input Class Initialized
INFO - 2022-04-02 18:44:16 --> Language Class Initialized
INFO - 2022-04-02 18:44:16 --> Loader Class Initialized
INFO - 2022-04-02 18:44:16 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:16 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:16 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:17 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:17 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:17 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:17 --> Controller Class Initialized
INFO - 2022-04-02 18:44:17 --> Model Class Initialized
INFO - 2022-04-02 18:44:17 --> Model Class Initialized
ERROR - 2022-04-02 18:44:17 --> 404 Page Not Found: 
INFO - 2022-04-02 18:44:18 --> Config Class Initialized
INFO - 2022-04-02 18:44:18 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:18 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:18 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:18 --> URI Class Initialized
INFO - 2022-04-02 18:44:18 --> Router Class Initialized
INFO - 2022-04-02 18:44:18 --> Output Class Initialized
INFO - 2022-04-02 18:44:18 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:18 --> Input Class Initialized
INFO - 2022-04-02 18:44:18 --> Language Class Initialized
INFO - 2022-04-02 18:44:18 --> Loader Class Initialized
INFO - 2022-04-02 18:44:18 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:18 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:18 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:18 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:18 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:18 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:18 --> Controller Class Initialized
INFO - 2022-04-02 18:44:18 --> Model Class Initialized
INFO - 2022-04-02 18:44:18 --> Model Class Initialized
ERROR - 2022-04-02 18:44:18 --> 404 Page Not Found: 
INFO - 2022-04-02 18:44:20 --> Config Class Initialized
INFO - 2022-04-02 18:44:20 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:20 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:20 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:20 --> URI Class Initialized
INFO - 2022-04-02 18:44:20 --> Router Class Initialized
INFO - 2022-04-02 18:44:20 --> Output Class Initialized
INFO - 2022-04-02 18:44:20 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:20 --> Input Class Initialized
INFO - 2022-04-02 18:44:20 --> Language Class Initialized
INFO - 2022-04-02 18:44:20 --> Loader Class Initialized
INFO - 2022-04-02 18:44:20 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:20 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:20 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:20 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:20 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:20 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:20 --> Controller Class Initialized
INFO - 2022-04-02 18:44:20 --> Model Class Initialized
INFO - 2022-04-02 18:44:20 --> Model Class Initialized
ERROR - 2022-04-02 18:44:20 --> 404 Page Not Found: 
INFO - 2022-04-02 18:44:22 --> Config Class Initialized
INFO - 2022-04-02 18:44:22 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:22 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:22 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:22 --> URI Class Initialized
DEBUG - 2022-04-02 18:44:22 --> No URI present. Default controller set.
INFO - 2022-04-02 18:44:22 --> Router Class Initialized
INFO - 2022-04-02 18:44:22 --> Output Class Initialized
INFO - 2022-04-02 18:44:22 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:22 --> Input Class Initialized
INFO - 2022-04-02 18:44:22 --> Language Class Initialized
INFO - 2022-04-02 18:44:22 --> Loader Class Initialized
INFO - 2022-04-02 18:44:22 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:22 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:22 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:22 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:22 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:22 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:22 --> Controller Class Initialized
INFO - 2022-04-02 18:44:22 --> Model Class Initialized
INFO - 2022-04-02 18:44:22 --> Model Class Initialized
INFO - 2022-04-02 18:44:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:44:22 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:44:22 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:22 --> Total execution time: 0.0766
INFO - 2022-04-02 18:44:24 --> Config Class Initialized
INFO - 2022-04-02 18:44:24 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:24 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:24 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:24 --> URI Class Initialized
DEBUG - 2022-04-02 18:44:24 --> No URI present. Default controller set.
INFO - 2022-04-02 18:44:24 --> Router Class Initialized
INFO - 2022-04-02 18:44:24 --> Output Class Initialized
INFO - 2022-04-02 18:44:24 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:24 --> Input Class Initialized
INFO - 2022-04-02 18:44:24 --> Language Class Initialized
INFO - 2022-04-02 18:44:24 --> Loader Class Initialized
INFO - 2022-04-02 18:44:24 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:24 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:24 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:24 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:24 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:24 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:24 --> Controller Class Initialized
INFO - 2022-04-02 18:44:24 --> Model Class Initialized
INFO - 2022-04-02 18:44:24 --> Model Class Initialized
INFO - 2022-04-02 18:44:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:44:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:44:24 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:24 --> Total execution time: 0.0744
INFO - 2022-04-02 18:44:25 --> Config Class Initialized
INFO - 2022-04-02 18:44:25 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:25 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:25 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:25 --> URI Class Initialized
DEBUG - 2022-04-02 18:44:25 --> No URI present. Default controller set.
INFO - 2022-04-02 18:44:25 --> Router Class Initialized
INFO - 2022-04-02 18:44:25 --> Output Class Initialized
INFO - 2022-04-02 18:44:25 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:25 --> Input Class Initialized
INFO - 2022-04-02 18:44:25 --> Language Class Initialized
INFO - 2022-04-02 18:44:25 --> Loader Class Initialized
INFO - 2022-04-02 18:44:25 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:25 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:25 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:25 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:25 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:25 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:25 --> Controller Class Initialized
INFO - 2022-04-02 18:44:25 --> Model Class Initialized
INFO - 2022-04-02 18:44:25 --> Model Class Initialized
INFO - 2022-04-02 18:44:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:44:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:44:25 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:25 --> Total execution time: 0.0683
INFO - 2022-04-02 18:44:26 --> Config Class Initialized
INFO - 2022-04-02 18:44:26 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:26 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:26 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:26 --> URI Class Initialized
DEBUG - 2022-04-02 18:44:26 --> No URI present. Default controller set.
INFO - 2022-04-02 18:44:26 --> Router Class Initialized
INFO - 2022-04-02 18:44:26 --> Output Class Initialized
INFO - 2022-04-02 18:44:26 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:26 --> Input Class Initialized
INFO - 2022-04-02 18:44:26 --> Language Class Initialized
INFO - 2022-04-02 18:44:26 --> Loader Class Initialized
INFO - 2022-04-02 18:44:26 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:26 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:26 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:26 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:26 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:26 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:26 --> Controller Class Initialized
INFO - 2022-04-02 18:44:26 --> Model Class Initialized
INFO - 2022-04-02 18:44:26 --> Model Class Initialized
INFO - 2022-04-02 18:44:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:44:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:44:26 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:26 --> Total execution time: 0.0622
INFO - 2022-04-02 18:44:26 --> Config Class Initialized
INFO - 2022-04-02 18:44:26 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:26 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:26 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:26 --> URI Class Initialized
DEBUG - 2022-04-02 18:44:26 --> No URI present. Default controller set.
INFO - 2022-04-02 18:44:26 --> Router Class Initialized
INFO - 2022-04-02 18:44:26 --> Output Class Initialized
INFO - 2022-04-02 18:44:26 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:26 --> Input Class Initialized
INFO - 2022-04-02 18:44:26 --> Language Class Initialized
INFO - 2022-04-02 18:44:26 --> Loader Class Initialized
INFO - 2022-04-02 18:44:26 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:26 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:26 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:26 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:26 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:26 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:26 --> Controller Class Initialized
INFO - 2022-04-02 18:44:26 --> Model Class Initialized
INFO - 2022-04-02 18:44:26 --> Model Class Initialized
INFO - 2022-04-02 18:44:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:44:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:44:26 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:26 --> Total execution time: 0.0615
INFO - 2022-04-02 18:44:27 --> Config Class Initialized
INFO - 2022-04-02 18:44:27 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:27 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:27 --> URI Class Initialized
INFO - 2022-04-02 18:44:27 --> Router Class Initialized
INFO - 2022-04-02 18:44:27 --> Output Class Initialized
INFO - 2022-04-02 18:44:27 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:27 --> Input Class Initialized
INFO - 2022-04-02 18:44:27 --> Language Class Initialized
INFO - 2022-04-02 18:44:27 --> Loader Class Initialized
INFO - 2022-04-02 18:44:27 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:27 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:27 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:27 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:27 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:27 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:27 --> Controller Class Initialized
INFO - 2022-04-02 18:44:27 --> Model Class Initialized
INFO - 2022-04-02 18:44:27 --> Model Class Initialized
INFO - 2022-04-02 18:44:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:44:27 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:27 --> Total execution time: 0.0720
INFO - 2022-04-02 18:44:28 --> Config Class Initialized
INFO - 2022-04-02 18:44:28 --> Hooks Class Initialized
INFO - 2022-04-02 18:44:28 --> Config Class Initialized
INFO - 2022-04-02 18:44:28 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:28 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:28 --> Utf8 Class Initialized
DEBUG - 2022-04-02 18:44:28 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:28 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:28 --> URI Class Initialized
INFO - 2022-04-02 18:44:28 --> URI Class Initialized
INFO - 2022-04-02 18:44:28 --> Router Class Initialized
INFO - 2022-04-02 18:44:28 --> Router Class Initialized
INFO - 2022-04-02 18:44:28 --> Output Class Initialized
INFO - 2022-04-02 18:44:28 --> Output Class Initialized
INFO - 2022-04-02 18:44:28 --> Security Class Initialized
INFO - 2022-04-02 18:44:28 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:28 --> Input Class Initialized
INFO - 2022-04-02 18:44:28 --> Language Class Initialized
DEBUG - 2022-04-02 18:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:28 --> Input Class Initialized
INFO - 2022-04-02 18:44:28 --> Language Class Initialized
ERROR - 2022-04-02 18:44:28 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-02 18:44:28 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 18:44:53 --> Config Class Initialized
INFO - 2022-04-02 18:44:53 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:44:53 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:44:53 --> Utf8 Class Initialized
INFO - 2022-04-02 18:44:53 --> URI Class Initialized
INFO - 2022-04-02 18:44:53 --> Router Class Initialized
INFO - 2022-04-02 18:44:53 --> Output Class Initialized
INFO - 2022-04-02 18:44:53 --> Security Class Initialized
DEBUG - 2022-04-02 18:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:44:53 --> Input Class Initialized
INFO - 2022-04-02 18:44:53 --> Language Class Initialized
INFO - 2022-04-02 18:44:53 --> Loader Class Initialized
INFO - 2022-04-02 18:44:53 --> Helper loaded: url_helper
INFO - 2022-04-02 18:44:53 --> Helper loaded: form_helper
INFO - 2022-04-02 18:44:53 --> Helper loaded: common_helper
INFO - 2022-04-02 18:44:53 --> Helper loaded: util_helper
INFO - 2022-04-02 18:44:53 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:44:53 --> Form Validation Class Initialized
INFO - 2022-04-02 18:44:53 --> Controller Class Initialized
INFO - 2022-04-02 18:44:53 --> Model Class Initialized
INFO - 2022-04-02 18:44:53 --> Model Class Initialized
INFO - 2022-04-02 18:44:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:44:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:44:53 --> Final output sent to browser
DEBUG - 2022-04-02 18:44:53 --> Total execution time: 0.1626
INFO - 2022-04-02 18:45:03 --> Config Class Initialized
INFO - 2022-04-02 18:45:03 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:45:03 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:45:03 --> Utf8 Class Initialized
INFO - 2022-04-02 18:45:03 --> URI Class Initialized
INFO - 2022-04-02 18:45:03 --> Router Class Initialized
INFO - 2022-04-02 18:45:03 --> Output Class Initialized
INFO - 2022-04-02 18:45:03 --> Security Class Initialized
DEBUG - 2022-04-02 18:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:45:03 --> Input Class Initialized
INFO - 2022-04-02 18:45:03 --> Language Class Initialized
INFO - 2022-04-02 18:45:03 --> Loader Class Initialized
INFO - 2022-04-02 18:45:03 --> Helper loaded: url_helper
INFO - 2022-04-02 18:45:03 --> Helper loaded: form_helper
INFO - 2022-04-02 18:45:03 --> Helper loaded: common_helper
INFO - 2022-04-02 18:45:03 --> Helper loaded: util_helper
INFO - 2022-04-02 18:45:03 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:45:03 --> Form Validation Class Initialized
INFO - 2022-04-02 18:45:03 --> Controller Class Initialized
INFO - 2022-04-02 18:45:03 --> Model Class Initialized
INFO - 2022-04-02 18:45:03 --> Model Class Initialized
INFO - 2022-04-02 18:45:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:45:03 --> Final output sent to browser
DEBUG - 2022-04-02 18:45:03 --> Total execution time: 0.0738
INFO - 2022-04-02 18:45:10 --> Config Class Initialized
INFO - 2022-04-02 18:45:10 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:45:10 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:45:10 --> Utf8 Class Initialized
INFO - 2022-04-02 18:45:10 --> URI Class Initialized
INFO - 2022-04-02 18:45:10 --> Router Class Initialized
INFO - 2022-04-02 18:45:10 --> Output Class Initialized
INFO - 2022-04-02 18:45:10 --> Security Class Initialized
DEBUG - 2022-04-02 18:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:45:10 --> Input Class Initialized
INFO - 2022-04-02 18:45:10 --> Language Class Initialized
INFO - 2022-04-02 18:45:10 --> Loader Class Initialized
INFO - 2022-04-02 18:45:10 --> Helper loaded: url_helper
INFO - 2022-04-02 18:45:10 --> Helper loaded: form_helper
INFO - 2022-04-02 18:45:10 --> Helper loaded: common_helper
INFO - 2022-04-02 18:45:10 --> Helper loaded: util_helper
INFO - 2022-04-02 18:45:10 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:45:10 --> Form Validation Class Initialized
INFO - 2022-04-02 18:45:10 --> Controller Class Initialized
INFO - 2022-04-02 18:45:10 --> Model Class Initialized
INFO - 2022-04-02 18:45:10 --> Model Class Initialized
INFO - 2022-04-02 18:45:10 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:45:10 --> Final output sent to browser
DEBUG - 2022-04-02 18:45:10 --> Total execution time: 0.0723
INFO - 2022-04-02 18:45:12 --> Config Class Initialized
INFO - 2022-04-02 18:45:12 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:45:12 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:45:12 --> Utf8 Class Initialized
INFO - 2022-04-02 18:45:12 --> URI Class Initialized
INFO - 2022-04-02 18:45:12 --> Router Class Initialized
INFO - 2022-04-02 18:45:12 --> Output Class Initialized
INFO - 2022-04-02 18:45:12 --> Security Class Initialized
DEBUG - 2022-04-02 18:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:45:12 --> Input Class Initialized
INFO - 2022-04-02 18:45:12 --> Language Class Initialized
INFO - 2022-04-02 18:45:12 --> Loader Class Initialized
INFO - 2022-04-02 18:45:12 --> Helper loaded: url_helper
INFO - 2022-04-02 18:45:12 --> Helper loaded: form_helper
INFO - 2022-04-02 18:45:12 --> Helper loaded: common_helper
INFO - 2022-04-02 18:45:12 --> Helper loaded: util_helper
INFO - 2022-04-02 18:45:12 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:45:12 --> Form Validation Class Initialized
INFO - 2022-04-02 18:45:12 --> Controller Class Initialized
INFO - 2022-04-02 18:45:12 --> Model Class Initialized
INFO - 2022-04-02 18:45:12 --> Model Class Initialized
INFO - 2022-04-02 18:45:12 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:45:12 --> Final output sent to browser
DEBUG - 2022-04-02 18:45:12 --> Total execution time: 0.0664
INFO - 2022-04-02 18:45:13 --> Config Class Initialized
INFO - 2022-04-02 18:45:13 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:45:13 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:45:13 --> Utf8 Class Initialized
INFO - 2022-04-02 18:45:13 --> URI Class Initialized
DEBUG - 2022-04-02 18:45:13 --> No URI present. Default controller set.
INFO - 2022-04-02 18:45:13 --> Router Class Initialized
INFO - 2022-04-02 18:45:13 --> Output Class Initialized
INFO - 2022-04-02 18:45:13 --> Security Class Initialized
DEBUG - 2022-04-02 18:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:45:13 --> Input Class Initialized
INFO - 2022-04-02 18:45:13 --> Language Class Initialized
INFO - 2022-04-02 18:45:13 --> Loader Class Initialized
INFO - 2022-04-02 18:45:13 --> Helper loaded: url_helper
INFO - 2022-04-02 18:45:13 --> Helper loaded: form_helper
INFO - 2022-04-02 18:45:13 --> Helper loaded: common_helper
INFO - 2022-04-02 18:45:13 --> Helper loaded: util_helper
INFO - 2022-04-02 18:45:13 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:45:13 --> Form Validation Class Initialized
INFO - 2022-04-02 18:45:13 --> Controller Class Initialized
INFO - 2022-04-02 18:45:13 --> Model Class Initialized
INFO - 2022-04-02 18:45:13 --> Model Class Initialized
INFO - 2022-04-02 18:45:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:45:13 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:45:13 --> Final output sent to browser
DEBUG - 2022-04-02 18:45:13 --> Total execution time: 0.0762
INFO - 2022-04-02 18:45:14 --> Config Class Initialized
INFO - 2022-04-02 18:45:14 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:45:14 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:45:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:45:14 --> URI Class Initialized
DEBUG - 2022-04-02 18:45:14 --> No URI present. Default controller set.
INFO - 2022-04-02 18:45:14 --> Router Class Initialized
INFO - 2022-04-02 18:45:14 --> Output Class Initialized
INFO - 2022-04-02 18:45:14 --> Security Class Initialized
DEBUG - 2022-04-02 18:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:45:14 --> Input Class Initialized
INFO - 2022-04-02 18:45:14 --> Language Class Initialized
INFO - 2022-04-02 18:45:14 --> Loader Class Initialized
INFO - 2022-04-02 18:45:14 --> Helper loaded: url_helper
INFO - 2022-04-02 18:45:14 --> Helper loaded: form_helper
INFO - 2022-04-02 18:45:14 --> Helper loaded: common_helper
INFO - 2022-04-02 18:45:14 --> Helper loaded: util_helper
INFO - 2022-04-02 18:45:14 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:45:14 --> Form Validation Class Initialized
INFO - 2022-04-02 18:45:14 --> Controller Class Initialized
INFO - 2022-04-02 18:45:14 --> Model Class Initialized
INFO - 2022-04-02 18:45:14 --> Model Class Initialized
INFO - 2022-04-02 18:45:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:45:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:45:14 --> Final output sent to browser
DEBUG - 2022-04-02 18:45:14 --> Total execution time: 0.0887
INFO - 2022-04-02 18:45:17 --> Config Class Initialized
INFO - 2022-04-02 18:45:17 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:45:17 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:45:17 --> Utf8 Class Initialized
INFO - 2022-04-02 18:45:17 --> URI Class Initialized
INFO - 2022-04-02 18:45:17 --> Router Class Initialized
INFO - 2022-04-02 18:45:17 --> Output Class Initialized
INFO - 2022-04-02 18:45:17 --> Security Class Initialized
DEBUG - 2022-04-02 18:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:45:17 --> Input Class Initialized
INFO - 2022-04-02 18:45:17 --> Language Class Initialized
INFO - 2022-04-02 18:45:17 --> Loader Class Initialized
INFO - 2022-04-02 18:45:17 --> Helper loaded: url_helper
INFO - 2022-04-02 18:45:17 --> Helper loaded: form_helper
INFO - 2022-04-02 18:45:17 --> Helper loaded: common_helper
INFO - 2022-04-02 18:45:17 --> Helper loaded: util_helper
INFO - 2022-04-02 18:45:17 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:45:17 --> Form Validation Class Initialized
INFO - 2022-04-02 18:45:17 --> Controller Class Initialized
INFO - 2022-04-02 18:45:17 --> Model Class Initialized
INFO - 2022-04-02 18:45:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:45:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:45:17 --> Final output sent to browser
DEBUG - 2022-04-02 18:45:17 --> Total execution time: 0.0766
INFO - 2022-04-02 18:47:53 --> Config Class Initialized
INFO - 2022-04-02 18:47:53 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:47:53 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:47:53 --> Utf8 Class Initialized
INFO - 2022-04-02 18:47:53 --> URI Class Initialized
INFO - 2022-04-02 18:47:53 --> Router Class Initialized
INFO - 2022-04-02 18:47:53 --> Output Class Initialized
INFO - 2022-04-02 18:47:53 --> Security Class Initialized
DEBUG - 2022-04-02 18:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:47:53 --> Input Class Initialized
INFO - 2022-04-02 18:47:53 --> Language Class Initialized
INFO - 2022-04-02 18:47:53 --> Loader Class Initialized
INFO - 2022-04-02 18:47:53 --> Helper loaded: url_helper
INFO - 2022-04-02 18:47:53 --> Helper loaded: form_helper
INFO - 2022-04-02 18:47:53 --> Helper loaded: common_helper
INFO - 2022-04-02 18:47:53 --> Helper loaded: util_helper
INFO - 2022-04-02 18:47:53 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:47:53 --> Form Validation Class Initialized
INFO - 2022-04-02 18:47:53 --> Controller Class Initialized
INFO - 2022-04-02 18:47:53 --> Model Class Initialized
INFO - 2022-04-02 18:47:53 --> Final output sent to browser
DEBUG - 2022-04-02 18:47:53 --> Total execution time: 0.0673
INFO - 2022-04-02 18:47:56 --> Config Class Initialized
INFO - 2022-04-02 18:47:56 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:47:56 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:47:56 --> Utf8 Class Initialized
INFO - 2022-04-02 18:47:56 --> URI Class Initialized
INFO - 2022-04-02 18:47:56 --> Router Class Initialized
INFO - 2022-04-02 18:47:56 --> Output Class Initialized
INFO - 2022-04-02 18:47:56 --> Security Class Initialized
DEBUG - 2022-04-02 18:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:47:56 --> Input Class Initialized
INFO - 2022-04-02 18:47:56 --> Language Class Initialized
INFO - 2022-04-02 18:47:56 --> Loader Class Initialized
INFO - 2022-04-02 18:47:56 --> Helper loaded: url_helper
INFO - 2022-04-02 18:47:56 --> Helper loaded: form_helper
INFO - 2022-04-02 18:47:56 --> Helper loaded: common_helper
INFO - 2022-04-02 18:47:56 --> Helper loaded: util_helper
INFO - 2022-04-02 18:47:56 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:47:56 --> Form Validation Class Initialized
INFO - 2022-04-02 18:47:56 --> Controller Class Initialized
INFO - 2022-04-02 18:47:56 --> Model Class Initialized
INFO - 2022-04-02 18:47:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:47:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:47:56 --> Final output sent to browser
DEBUG - 2022-04-02 18:47:56 --> Total execution time: 0.0821
INFO - 2022-04-02 18:47:59 --> Config Class Initialized
INFO - 2022-04-02 18:47:59 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:47:59 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:47:59 --> Utf8 Class Initialized
INFO - 2022-04-02 18:47:59 --> URI Class Initialized
DEBUG - 2022-04-02 18:47:59 --> No URI present. Default controller set.
INFO - 2022-04-02 18:47:59 --> Router Class Initialized
INFO - 2022-04-02 18:47:59 --> Output Class Initialized
INFO - 2022-04-02 18:47:59 --> Security Class Initialized
DEBUG - 2022-04-02 18:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:47:59 --> Input Class Initialized
INFO - 2022-04-02 18:47:59 --> Language Class Initialized
INFO - 2022-04-02 18:47:59 --> Loader Class Initialized
INFO - 2022-04-02 18:47:59 --> Helper loaded: url_helper
INFO - 2022-04-02 18:47:59 --> Helper loaded: form_helper
INFO - 2022-04-02 18:47:59 --> Helper loaded: common_helper
INFO - 2022-04-02 18:47:59 --> Helper loaded: util_helper
INFO - 2022-04-02 18:47:59 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:47:59 --> Form Validation Class Initialized
INFO - 2022-04-02 18:47:59 --> Controller Class Initialized
INFO - 2022-04-02 18:47:59 --> Model Class Initialized
INFO - 2022-04-02 18:47:59 --> Model Class Initialized
INFO - 2022-04-02 18:47:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:47:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:47:59 --> Final output sent to browser
DEBUG - 2022-04-02 18:47:59 --> Total execution time: 0.0557
INFO - 2022-04-02 18:48:01 --> Config Class Initialized
INFO - 2022-04-02 18:48:01 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:48:01 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:48:01 --> Utf8 Class Initialized
INFO - 2022-04-02 18:48:01 --> URI Class Initialized
INFO - 2022-04-02 18:48:01 --> Router Class Initialized
INFO - 2022-04-02 18:48:01 --> Output Class Initialized
INFO - 2022-04-02 18:48:01 --> Security Class Initialized
DEBUG - 2022-04-02 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:48:01 --> Input Class Initialized
INFO - 2022-04-02 18:48:01 --> Language Class Initialized
INFO - 2022-04-02 18:48:01 --> Loader Class Initialized
INFO - 2022-04-02 18:48:01 --> Helper loaded: url_helper
INFO - 2022-04-02 18:48:01 --> Helper loaded: form_helper
INFO - 2022-04-02 18:48:01 --> Helper loaded: common_helper
INFO - 2022-04-02 18:48:01 --> Helper loaded: util_helper
INFO - 2022-04-02 18:48:01 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:48:01 --> Form Validation Class Initialized
INFO - 2022-04-02 18:48:01 --> Controller Class Initialized
INFO - 2022-04-02 18:48:01 --> Model Class Initialized
INFO - 2022-04-02 18:48:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:48:01 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:48:01 --> Final output sent to browser
DEBUG - 2022-04-02 18:48:01 --> Total execution time: 0.0733
INFO - 2022-04-02 18:49:38 --> Config Class Initialized
INFO - 2022-04-02 18:49:38 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:49:38 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:49:38 --> Utf8 Class Initialized
INFO - 2022-04-02 18:49:38 --> URI Class Initialized
INFO - 2022-04-02 18:49:38 --> Router Class Initialized
INFO - 2022-04-02 18:49:38 --> Output Class Initialized
INFO - 2022-04-02 18:49:38 --> Security Class Initialized
DEBUG - 2022-04-02 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:49:38 --> Input Class Initialized
INFO - 2022-04-02 18:49:38 --> Language Class Initialized
INFO - 2022-04-02 18:49:38 --> Loader Class Initialized
INFO - 2022-04-02 18:49:38 --> Helper loaded: url_helper
INFO - 2022-04-02 18:49:38 --> Helper loaded: form_helper
INFO - 2022-04-02 18:49:38 --> Helper loaded: common_helper
INFO - 2022-04-02 18:49:38 --> Helper loaded: util_helper
INFO - 2022-04-02 18:49:38 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:49:38 --> Form Validation Class Initialized
INFO - 2022-04-02 18:49:38 --> Controller Class Initialized
INFO - 2022-04-02 18:49:38 --> Model Class Initialized
INFO - 2022-04-02 18:49:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:49:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:49:38 --> Final output sent to browser
DEBUG - 2022-04-02 18:49:38 --> Total execution time: 0.0704
INFO - 2022-04-02 18:49:38 --> Config Class Initialized
INFO - 2022-04-02 18:49:38 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:49:38 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:49:38 --> Utf8 Class Initialized
INFO - 2022-04-02 18:49:38 --> URI Class Initialized
INFO - 2022-04-02 18:49:38 --> Router Class Initialized
INFO - 2022-04-02 18:49:38 --> Output Class Initialized
INFO - 2022-04-02 18:49:38 --> Config Class Initialized
INFO - 2022-04-02 18:49:38 --> Hooks Class Initialized
INFO - 2022-04-02 18:49:38 --> Config Class Initialized
INFO - 2022-04-02 18:49:38 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:49:38 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:49:38 --> Utf8 Class Initialized
DEBUG - 2022-04-02 18:49:38 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:49:38 --> Utf8 Class Initialized
INFO - 2022-04-02 18:49:38 --> URI Class Initialized
INFO - 2022-04-02 18:49:38 --> URI Class Initialized
INFO - 2022-04-02 18:49:38 --> Router Class Initialized
INFO - 2022-04-02 18:49:38 --> Security Class Initialized
INFO - 2022-04-02 18:49:38 --> Output Class Initialized
DEBUG - 2022-04-02 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:49:38 --> Input Class Initialized
INFO - 2022-04-02 18:49:38 --> Security Class Initialized
INFO - 2022-04-02 18:49:38 --> Language Class Initialized
INFO - 2022-04-02 18:49:38 --> Router Class Initialized
INFO - 2022-04-02 18:49:38 --> Config Class Initialized
INFO - 2022-04-02 18:49:38 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-02 18:49:38 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:49:38 --> Output Class Initialized
INFO - 2022-04-02 18:49:38 --> Input Class Initialized
DEBUG - 2022-04-02 18:49:38 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:49:38 --> Language Class Initialized
INFO - 2022-04-02 18:49:38 --> Utf8 Class Initialized
INFO - 2022-04-02 18:49:38 --> Security Class Initialized
INFO - 2022-04-02 18:49:38 --> URI Class Initialized
ERROR - 2022-04-02 18:49:38 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-02 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:49:38 --> Input Class Initialized
INFO - 2022-04-02 18:49:38 --> Router Class Initialized
INFO - 2022-04-02 18:49:38 --> Output Class Initialized
INFO - 2022-04-02 18:49:38 --> Language Class Initialized
ERROR - 2022-04-02 18:49:38 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:49:38 --> Security Class Initialized
DEBUG - 2022-04-02 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:49:38 --> Input Class Initialized
INFO - 2022-04-02 18:49:38 --> Language Class Initialized
ERROR - 2022-04-02 18:49:38 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:14 --> Config Class Initialized
INFO - 2022-04-02 18:50:14 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:14 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:14 --> URI Class Initialized
INFO - 2022-04-02 18:50:14 --> Router Class Initialized
INFO - 2022-04-02 18:50:14 --> Output Class Initialized
INFO - 2022-04-02 18:50:14 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:14 --> Input Class Initialized
INFO - 2022-04-02 18:50:14 --> Language Class Initialized
INFO - 2022-04-02 18:50:14 --> Loader Class Initialized
INFO - 2022-04-02 18:50:14 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:14 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:14 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:14 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:14 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:14 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:14 --> Controller Class Initialized
INFO - 2022-04-02 18:50:14 --> Model Class Initialized
INFO - 2022-04-02 18:50:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:50:14 --> Config Class Initialized
INFO - 2022-04-02 18:50:14 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:14 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:14 --> URI Class Initialized
INFO - 2022-04-02 18:50:14 --> Router Class Initialized
INFO - 2022-04-02 18:50:14 --> Output Class Initialized
INFO - 2022-04-02 18:50:14 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:14 --> Input Class Initialized
INFO - 2022-04-02 18:50:14 --> Language Class Initialized
INFO - 2022-04-02 18:50:14 --> Loader Class Initialized
INFO - 2022-04-02 18:50:14 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:14 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:14 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:14 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:14 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:14 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:14 --> Controller Class Initialized
INFO - 2022-04-02 18:50:14 --> Model Class Initialized
INFO - 2022-04-02 18:50:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:50:14 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:50:14 --> Final output sent to browser
DEBUG - 2022-04-02 18:50:14 --> Total execution time: 0.0624
INFO - 2022-04-02 18:50:14 --> Config Class Initialized
INFO - 2022-04-02 18:50:14 --> Config Class Initialized
INFO - 2022-04-02 18:50:14 --> Hooks Class Initialized
INFO - 2022-04-02 18:50:14 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-02 18:50:14 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:14 --> URI Class Initialized
INFO - 2022-04-02 18:50:14 --> URI Class Initialized
INFO - 2022-04-02 18:50:14 --> Router Class Initialized
INFO - 2022-04-02 18:50:14 --> Router Class Initialized
INFO - 2022-04-02 18:50:14 --> Output Class Initialized
INFO - 2022-04-02 18:50:14 --> Output Class Initialized
INFO - 2022-04-02 18:50:14 --> Security Class Initialized
INFO - 2022-04-02 18:50:14 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-02 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:14 --> Input Class Initialized
INFO - 2022-04-02 18:50:14 --> Input Class Initialized
INFO - 2022-04-02 18:50:14 --> Language Class Initialized
INFO - 2022-04-02 18:50:14 --> Language Class Initialized
ERROR - 2022-04-02 18:50:14 --> 404 Page Not Found: Fassets/img
ERROR - 2022-04-02 18:50:14 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:14 --> Config Class Initialized
INFO - 2022-04-02 18:50:14 --> Hooks Class Initialized
INFO - 2022-04-02 18:50:14 --> Config Class Initialized
INFO - 2022-04-02 18:50:14 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:14 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:14 --> URI Class Initialized
DEBUG - 2022-04-02 18:50:14 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:14 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:14 --> URI Class Initialized
INFO - 2022-04-02 18:50:14 --> Router Class Initialized
INFO - 2022-04-02 18:50:14 --> Output Class Initialized
INFO - 2022-04-02 18:50:14 --> Router Class Initialized
INFO - 2022-04-02 18:50:14 --> Security Class Initialized
INFO - 2022-04-02 18:50:14 --> Output Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:14 --> Input Class Initialized
INFO - 2022-04-02 18:50:14 --> Security Class Initialized
INFO - 2022-04-02 18:50:14 --> Language Class Initialized
DEBUG - 2022-04-02 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:14 --> Input Class Initialized
ERROR - 2022-04-02 18:50:14 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:14 --> Language Class Initialized
ERROR - 2022-04-02 18:50:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:21 --> Config Class Initialized
INFO - 2022-04-02 18:50:21 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:21 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:21 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:21 --> URI Class Initialized
INFO - 2022-04-02 18:50:21 --> Router Class Initialized
INFO - 2022-04-02 18:50:21 --> Output Class Initialized
INFO - 2022-04-02 18:50:21 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:21 --> Input Class Initialized
INFO - 2022-04-02 18:50:21 --> Language Class Initialized
INFO - 2022-04-02 18:50:21 --> Loader Class Initialized
INFO - 2022-04-02 18:50:21 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:21 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:21 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:21 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:21 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:21 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:21 --> Controller Class Initialized
INFO - 2022-04-02 18:50:21 --> Model Class Initialized
INFO - 2022-04-02 18:50:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:50:21 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:50:21 --> Final output sent to browser
DEBUG - 2022-04-02 18:50:21 --> Total execution time: 0.0631
INFO - 2022-04-02 18:50:21 --> Config Class Initialized
INFO - 2022-04-02 18:50:21 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:21 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:21 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:21 --> URI Class Initialized
INFO - 2022-04-02 18:50:21 --> Router Class Initialized
INFO - 2022-04-02 18:50:21 --> Output Class Initialized
INFO - 2022-04-02 18:50:21 --> Security Class Initialized
INFO - 2022-04-02 18:50:21 --> Config Class Initialized
INFO - 2022-04-02 18:50:21 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:21 --> Input Class Initialized
INFO - 2022-04-02 18:50:21 --> Language Class Initialized
DEBUG - 2022-04-02 18:50:21 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:21 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:21 --> URI Class Initialized
ERROR - 2022-04-02 18:50:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:21 --> Router Class Initialized
INFO - 2022-04-02 18:50:21 --> Output Class Initialized
INFO - 2022-04-02 18:50:21 --> Security Class Initialized
INFO - 2022-04-02 18:50:21 --> Config Class Initialized
INFO - 2022-04-02 18:50:21 --> Config Class Initialized
INFO - 2022-04-02 18:50:21 --> Hooks Class Initialized
INFO - 2022-04-02 18:50:21 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:21 --> Input Class Initialized
INFO - 2022-04-02 18:50:21 --> Language Class Initialized
DEBUG - 2022-04-02 18:50:21 --> UTF-8 Support Enabled
ERROR - 2022-04-02 18:50:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:21 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:21 --> URI Class Initialized
DEBUG - 2022-04-02 18:50:21 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:21 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:21 --> Router Class Initialized
INFO - 2022-04-02 18:50:21 --> URI Class Initialized
INFO - 2022-04-02 18:50:21 --> Output Class Initialized
INFO - 2022-04-02 18:50:21 --> Security Class Initialized
INFO - 2022-04-02 18:50:21 --> Router Class Initialized
DEBUG - 2022-04-02 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:21 --> Input Class Initialized
INFO - 2022-04-02 18:50:21 --> Output Class Initialized
INFO - 2022-04-02 18:50:21 --> Language Class Initialized
INFO - 2022-04-02 18:50:21 --> Security Class Initialized
ERROR - 2022-04-02 18:50:21 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-02 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:21 --> Input Class Initialized
INFO - 2022-04-02 18:50:21 --> Language Class Initialized
ERROR - 2022-04-02 18:50:21 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:50:25 --> Config Class Initialized
INFO - 2022-04-02 18:50:25 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:25 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:25 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:25 --> URI Class Initialized
INFO - 2022-04-02 18:50:25 --> Router Class Initialized
INFO - 2022-04-02 18:50:25 --> Output Class Initialized
INFO - 2022-04-02 18:50:25 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:25 --> Input Class Initialized
INFO - 2022-04-02 18:50:25 --> Language Class Initialized
INFO - 2022-04-02 18:50:25 --> Loader Class Initialized
INFO - 2022-04-02 18:50:25 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:25 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:25 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:25 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:25 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:25 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:25 --> Controller Class Initialized
INFO - 2022-04-02 18:50:25 --> Model Class Initialized
INFO - 2022-04-02 18:50:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:50:25 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:50:25 --> Final output sent to browser
DEBUG - 2022-04-02 18:50:25 --> Total execution time: 0.0608
INFO - 2022-04-02 18:50:27 --> Config Class Initialized
INFO - 2022-04-02 18:50:27 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:27 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:27 --> URI Class Initialized
INFO - 2022-04-02 18:50:27 --> Router Class Initialized
INFO - 2022-04-02 18:50:27 --> Output Class Initialized
INFO - 2022-04-02 18:50:27 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:27 --> Input Class Initialized
INFO - 2022-04-02 18:50:27 --> Language Class Initialized
INFO - 2022-04-02 18:50:27 --> Loader Class Initialized
INFO - 2022-04-02 18:50:27 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:27 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:27 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:27 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:27 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:27 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:27 --> Controller Class Initialized
INFO - 2022-04-02 18:50:27 --> Model Class Initialized
INFO - 2022-04-02 18:50:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:50:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:50:27 --> Final output sent to browser
DEBUG - 2022-04-02 18:50:27 --> Total execution time: 0.0778
INFO - 2022-04-02 18:50:30 --> Config Class Initialized
INFO - 2022-04-02 18:50:30 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:30 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:30 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:30 --> URI Class Initialized
INFO - 2022-04-02 18:50:30 --> Router Class Initialized
INFO - 2022-04-02 18:50:30 --> Output Class Initialized
INFO - 2022-04-02 18:50:30 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:30 --> Input Class Initialized
INFO - 2022-04-02 18:50:30 --> Language Class Initialized
INFO - 2022-04-02 18:50:30 --> Loader Class Initialized
INFO - 2022-04-02 18:50:30 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:30 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:30 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:30 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:30 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:30 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:30 --> Controller Class Initialized
INFO - 2022-04-02 18:50:30 --> Model Class Initialized
INFO - 2022-04-02 18:50:30 --> Model Class Initialized
INFO - 2022-04-02 18:50:31 --> Config Class Initialized
INFO - 2022-04-02 18:50:31 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:31 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:31 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:31 --> URI Class Initialized
INFO - 2022-04-02 18:50:31 --> Router Class Initialized
INFO - 2022-04-02 18:50:31 --> Output Class Initialized
INFO - 2022-04-02 18:50:31 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:31 --> Input Class Initialized
INFO - 2022-04-02 18:50:31 --> Language Class Initialized
INFO - 2022-04-02 18:50:31 --> Loader Class Initialized
INFO - 2022-04-02 18:50:31 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:31 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:31 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:31 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:31 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:31 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:31 --> Controller Class Initialized
INFO - 2022-04-02 18:50:31 --> Model Class Initialized
INFO - 2022-04-02 18:50:31 --> Model Class Initialized
INFO - 2022-04-02 18:50:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:50:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:50:31 --> Final output sent to browser
DEBUG - 2022-04-02 18:50:31 --> Total execution time: 0.0703
INFO - 2022-04-02 18:50:33 --> Config Class Initialized
INFO - 2022-04-02 18:50:33 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:50:33 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:50:33 --> Utf8 Class Initialized
INFO - 2022-04-02 18:50:33 --> URI Class Initialized
INFO - 2022-04-02 18:50:33 --> Router Class Initialized
INFO - 2022-04-02 18:50:33 --> Output Class Initialized
INFO - 2022-04-02 18:50:33 --> Security Class Initialized
DEBUG - 2022-04-02 18:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:50:33 --> Input Class Initialized
INFO - 2022-04-02 18:50:33 --> Language Class Initialized
INFO - 2022-04-02 18:50:33 --> Loader Class Initialized
INFO - 2022-04-02 18:50:33 --> Helper loaded: url_helper
INFO - 2022-04-02 18:50:33 --> Helper loaded: form_helper
INFO - 2022-04-02 18:50:33 --> Helper loaded: common_helper
INFO - 2022-04-02 18:50:33 --> Helper loaded: util_helper
INFO - 2022-04-02 18:50:33 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:50:33 --> Form Validation Class Initialized
INFO - 2022-04-02 18:50:33 --> Controller Class Initialized
INFO - 2022-04-02 18:50:33 --> Model Class Initialized
INFO - 2022-04-02 18:50:33 --> Model Class Initialized
INFO - 2022-04-02 18:50:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:50:33 --> Final output sent to browser
DEBUG - 2022-04-02 18:50:33 --> Total execution time: 0.0686
INFO - 2022-04-02 18:51:07 --> Config Class Initialized
INFO - 2022-04-02 18:51:07 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:51:07 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:51:07 --> Utf8 Class Initialized
INFO - 2022-04-02 18:51:07 --> URI Class Initialized
INFO - 2022-04-02 18:51:07 --> Router Class Initialized
INFO - 2022-04-02 18:51:07 --> Output Class Initialized
INFO - 2022-04-02 18:51:07 --> Security Class Initialized
DEBUG - 2022-04-02 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:51:07 --> Input Class Initialized
INFO - 2022-04-02 18:51:07 --> Language Class Initialized
INFO - 2022-04-02 18:51:07 --> Loader Class Initialized
INFO - 2022-04-02 18:51:07 --> Helper loaded: url_helper
INFO - 2022-04-02 18:51:07 --> Helper loaded: form_helper
INFO - 2022-04-02 18:51:07 --> Helper loaded: common_helper
INFO - 2022-04-02 18:51:07 --> Helper loaded: util_helper
INFO - 2022-04-02 18:51:07 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:51:07 --> Form Validation Class Initialized
INFO - 2022-04-02 18:51:07 --> Controller Class Initialized
INFO - 2022-04-02 18:51:07 --> Model Class Initialized
INFO - 2022-04-02 18:51:07 --> Model Class Initialized
INFO - 2022-04-02 18:51:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:51:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:51:07 --> Final output sent to browser
DEBUG - 2022-04-02 18:51:07 --> Total execution time: 0.1485
INFO - 2022-04-02 18:51:10 --> Config Class Initialized
INFO - 2022-04-02 18:51:10 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:51:10 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:51:10 --> Utf8 Class Initialized
INFO - 2022-04-02 18:51:10 --> URI Class Initialized
INFO - 2022-04-02 18:51:10 --> Router Class Initialized
INFO - 2022-04-02 18:51:10 --> Output Class Initialized
INFO - 2022-04-02 18:51:10 --> Security Class Initialized
DEBUG - 2022-04-02 18:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:51:10 --> Input Class Initialized
INFO - 2022-04-02 18:51:10 --> Language Class Initialized
INFO - 2022-04-02 18:51:10 --> Loader Class Initialized
INFO - 2022-04-02 18:51:10 --> Helper loaded: url_helper
INFO - 2022-04-02 18:51:10 --> Helper loaded: form_helper
INFO - 2022-04-02 18:51:10 --> Helper loaded: common_helper
INFO - 2022-04-02 18:51:10 --> Helper loaded: util_helper
INFO - 2022-04-02 18:51:10 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:51:10 --> Form Validation Class Initialized
INFO - 2022-04-02 18:51:10 --> Controller Class Initialized
INFO - 2022-04-02 18:51:10 --> Model Class Initialized
INFO - 2022-04-02 18:51:10 --> Model Class Initialized
INFO - 2022-04-02 18:51:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:51:10 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:51:10 --> Final output sent to browser
DEBUG - 2022-04-02 18:51:10 --> Total execution time: 0.0633
INFO - 2022-04-02 18:51:22 --> Config Class Initialized
INFO - 2022-04-02 18:51:22 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:51:22 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:51:22 --> Utf8 Class Initialized
INFO - 2022-04-02 18:51:22 --> URI Class Initialized
INFO - 2022-04-02 18:51:22 --> Router Class Initialized
INFO - 2022-04-02 18:51:22 --> Output Class Initialized
INFO - 2022-04-02 18:51:22 --> Security Class Initialized
DEBUG - 2022-04-02 18:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:51:22 --> Input Class Initialized
INFO - 2022-04-02 18:51:22 --> Language Class Initialized
INFO - 2022-04-02 18:51:22 --> Loader Class Initialized
INFO - 2022-04-02 18:51:22 --> Helper loaded: url_helper
INFO - 2022-04-02 18:51:22 --> Helper loaded: form_helper
INFO - 2022-04-02 18:51:22 --> Helper loaded: common_helper
INFO - 2022-04-02 18:51:22 --> Helper loaded: util_helper
INFO - 2022-04-02 18:51:22 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:51:22 --> Form Validation Class Initialized
INFO - 2022-04-02 18:51:22 --> Controller Class Initialized
INFO - 2022-04-02 18:51:23 --> Model Class Initialized
INFO - 2022-04-02 18:51:23 --> Model Class Initialized
INFO - 2022-04-02 18:51:23 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:51:23 --> Final output sent to browser
DEBUG - 2022-04-02 18:51:23 --> Total execution time: 0.0694
INFO - 2022-04-02 18:51:33 --> Config Class Initialized
INFO - 2022-04-02 18:51:33 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:51:33 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:51:33 --> Utf8 Class Initialized
INFO - 2022-04-02 18:51:33 --> URI Class Initialized
INFO - 2022-04-02 18:51:33 --> Router Class Initialized
INFO - 2022-04-02 18:51:33 --> Output Class Initialized
INFO - 2022-04-02 18:51:33 --> Security Class Initialized
DEBUG - 2022-04-02 18:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:51:33 --> Input Class Initialized
INFO - 2022-04-02 18:51:33 --> Language Class Initialized
INFO - 2022-04-02 18:51:33 --> Loader Class Initialized
INFO - 2022-04-02 18:51:33 --> Helper loaded: url_helper
INFO - 2022-04-02 18:51:33 --> Helper loaded: form_helper
INFO - 2022-04-02 18:51:33 --> Helper loaded: common_helper
INFO - 2022-04-02 18:51:33 --> Helper loaded: util_helper
INFO - 2022-04-02 18:51:33 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:51:34 --> Form Validation Class Initialized
INFO - 2022-04-02 18:51:34 --> Controller Class Initialized
INFO - 2022-04-02 18:51:34 --> Model Class Initialized
INFO - 2022-04-02 18:51:34 --> Model Class Initialized
INFO - 2022-04-02 18:51:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:51:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:51:34 --> Final output sent to browser
DEBUG - 2022-04-02 18:51:34 --> Total execution time: 0.0664
INFO - 2022-04-02 18:51:36 --> Config Class Initialized
INFO - 2022-04-02 18:51:36 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:51:36 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:51:36 --> Utf8 Class Initialized
INFO - 2022-04-02 18:51:36 --> URI Class Initialized
INFO - 2022-04-02 18:51:36 --> Router Class Initialized
INFO - 2022-04-02 18:51:36 --> Output Class Initialized
INFO - 2022-04-02 18:51:36 --> Security Class Initialized
DEBUG - 2022-04-02 18:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:51:36 --> Input Class Initialized
INFO - 2022-04-02 18:51:36 --> Language Class Initialized
INFO - 2022-04-02 18:51:36 --> Loader Class Initialized
INFO - 2022-04-02 18:51:36 --> Helper loaded: url_helper
INFO - 2022-04-02 18:51:36 --> Helper loaded: form_helper
INFO - 2022-04-02 18:51:36 --> Helper loaded: common_helper
INFO - 2022-04-02 18:51:36 --> Helper loaded: util_helper
INFO - 2022-04-02 18:51:36 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:51:36 --> Form Validation Class Initialized
INFO - 2022-04-02 18:51:36 --> Controller Class Initialized
INFO - 2022-04-02 18:51:36 --> Model Class Initialized
INFO - 2022-04-02 18:51:36 --> Model Class Initialized
INFO - 2022-04-02 18:51:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:51:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:51:36 --> Final output sent to browser
DEBUG - 2022-04-02 18:51:36 --> Total execution time: 0.0734
INFO - 2022-04-02 18:58:28 --> Config Class Initialized
INFO - 2022-04-02 18:58:28 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:28 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:28 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:28 --> URI Class Initialized
INFO - 2022-04-02 18:58:28 --> Router Class Initialized
INFO - 2022-04-02 18:58:28 --> Output Class Initialized
INFO - 2022-04-02 18:58:28 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:28 --> Input Class Initialized
INFO - 2022-04-02 18:58:28 --> Language Class Initialized
INFO - 2022-04-02 18:58:28 --> Loader Class Initialized
INFO - 2022-04-02 18:58:28 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:28 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:28 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:28 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:28 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:28 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:28 --> Controller Class Initialized
INFO - 2022-04-02 18:58:28 --> Model Class Initialized
INFO - 2022-04-02 18:58:28 --> Model Class Initialized
INFO - 2022-04-02 18:58:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:58:28 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:28 --> Total execution time: 0.0693
INFO - 2022-04-02 18:58:30 --> Config Class Initialized
INFO - 2022-04-02 18:58:30 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:30 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:30 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:30 --> URI Class Initialized
INFO - 2022-04-02 18:58:30 --> Router Class Initialized
INFO - 2022-04-02 18:58:30 --> Output Class Initialized
INFO - 2022-04-02 18:58:30 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:30 --> Input Class Initialized
INFO - 2022-04-02 18:58:30 --> Language Class Initialized
INFO - 2022-04-02 18:58:30 --> Loader Class Initialized
INFO - 2022-04-02 18:58:30 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:30 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:30 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:30 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:30 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:30 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:30 --> Controller Class Initialized
INFO - 2022-04-02 18:58:30 --> Model Class Initialized
INFO - 2022-04-02 18:58:30 --> Model Class Initialized
INFO - 2022-04-02 18:58:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:58:30 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:30 --> Total execution time: 0.0723
INFO - 2022-04-02 18:58:32 --> Config Class Initialized
INFO - 2022-04-02 18:58:32 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:32 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:32 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:32 --> URI Class Initialized
INFO - 2022-04-02 18:58:32 --> Router Class Initialized
INFO - 2022-04-02 18:58:32 --> Output Class Initialized
INFO - 2022-04-02 18:58:32 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:32 --> Input Class Initialized
INFO - 2022-04-02 18:58:32 --> Language Class Initialized
INFO - 2022-04-02 18:58:32 --> Loader Class Initialized
INFO - 2022-04-02 18:58:32 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:32 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:32 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:32 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:32 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:32 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:32 --> Controller Class Initialized
INFO - 2022-04-02 18:58:32 --> Model Class Initialized
INFO - 2022-04-02 18:58:32 --> Model Class Initialized
INFO - 2022-04-02 18:58:32 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:58:32 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:32 --> Total execution time: 0.0720
INFO - 2022-04-02 18:58:41 --> Config Class Initialized
INFO - 2022-04-02 18:58:41 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:41 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:41 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:41 --> URI Class Initialized
INFO - 2022-04-02 18:58:41 --> Router Class Initialized
INFO - 2022-04-02 18:58:41 --> Output Class Initialized
INFO - 2022-04-02 18:58:41 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:41 --> Input Class Initialized
INFO - 2022-04-02 18:58:41 --> Language Class Initialized
INFO - 2022-04-02 18:58:41 --> Loader Class Initialized
INFO - 2022-04-02 18:58:41 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:41 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:41 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:41 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:41 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:41 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:41 --> Controller Class Initialized
INFO - 2022-04-02 18:58:41 --> Model Class Initialized
INFO - 2022-04-02 18:58:41 --> Model Class Initialized
INFO - 2022-04-02 18:58:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:58:41 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:58:41 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:41 --> Total execution time: 0.0673
INFO - 2022-04-02 18:58:44 --> Config Class Initialized
INFO - 2022-04-02 18:58:44 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:44 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:44 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:44 --> URI Class Initialized
INFO - 2022-04-02 18:58:44 --> Router Class Initialized
INFO - 2022-04-02 18:58:44 --> Output Class Initialized
INFO - 2022-04-02 18:58:44 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:44 --> Input Class Initialized
INFO - 2022-04-02 18:58:44 --> Language Class Initialized
INFO - 2022-04-02 18:58:44 --> Loader Class Initialized
INFO - 2022-04-02 18:58:44 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:44 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:44 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:44 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:44 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:44 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:44 --> Controller Class Initialized
INFO - 2022-04-02 18:58:44 --> Model Class Initialized
INFO - 2022-04-02 18:58:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:58:44 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:58:44 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:44 --> Total execution time: 0.0685
INFO - 2022-04-02 18:58:56 --> Config Class Initialized
INFO - 2022-04-02 18:58:56 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:56 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:56 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:56 --> URI Class Initialized
INFO - 2022-04-02 18:58:56 --> Router Class Initialized
INFO - 2022-04-02 18:58:56 --> Output Class Initialized
INFO - 2022-04-02 18:58:56 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:56 --> Input Class Initialized
INFO - 2022-04-02 18:58:56 --> Language Class Initialized
INFO - 2022-04-02 18:58:56 --> Loader Class Initialized
INFO - 2022-04-02 18:58:56 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:56 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:56 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:56 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:56 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:56 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:56 --> Controller Class Initialized
INFO - 2022-04-02 18:58:56 --> Model Class Initialized
INFO - 2022-04-02 18:58:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 18:58:56 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:56 --> Total execution time: 0.0676
INFO - 2022-04-02 18:58:58 --> Config Class Initialized
INFO - 2022-04-02 18:58:58 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:58:58 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:58:58 --> Utf8 Class Initialized
INFO - 2022-04-02 18:58:58 --> URI Class Initialized
INFO - 2022-04-02 18:58:58 --> Router Class Initialized
INFO - 2022-04-02 18:58:58 --> Output Class Initialized
INFO - 2022-04-02 18:58:58 --> Security Class Initialized
DEBUG - 2022-04-02 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:58:58 --> Input Class Initialized
INFO - 2022-04-02 18:58:58 --> Language Class Initialized
INFO - 2022-04-02 18:58:58 --> Loader Class Initialized
INFO - 2022-04-02 18:58:58 --> Helper loaded: url_helper
INFO - 2022-04-02 18:58:58 --> Helper loaded: form_helper
INFO - 2022-04-02 18:58:58 --> Helper loaded: common_helper
INFO - 2022-04-02 18:58:58 --> Helper loaded: util_helper
INFO - 2022-04-02 18:58:58 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:58:58 --> Form Validation Class Initialized
INFO - 2022-04-02 18:58:58 --> Controller Class Initialized
INFO - 2022-04-02 18:58:58 --> Model Class Initialized
INFO - 2022-04-02 18:58:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:58:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:58:58 --> Final output sent to browser
DEBUG - 2022-04-02 18:58:58 --> Total execution time: 0.0765
INFO - 2022-04-02 18:59:16 --> Config Class Initialized
INFO - 2022-04-02 18:59:16 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:16 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:16 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:16 --> URI Class Initialized
INFO - 2022-04-02 18:59:16 --> Router Class Initialized
INFO - 2022-04-02 18:59:16 --> Output Class Initialized
INFO - 2022-04-02 18:59:16 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:16 --> Input Class Initialized
INFO - 2022-04-02 18:59:16 --> Language Class Initialized
INFO - 2022-04-02 18:59:16 --> Loader Class Initialized
INFO - 2022-04-02 18:59:16 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:16 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:16 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:16 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:16 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:16 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:16 --> Controller Class Initialized
INFO - 2022-04-02 18:59:16 --> Model Class Initialized
INFO - 2022-04-02 18:59:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:59:16 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:59:16 --> Final output sent to browser
DEBUG - 2022-04-02 18:59:16 --> Total execution time: 0.0654
INFO - 2022-04-02 18:59:17 --> Config Class Initialized
INFO - 2022-04-02 18:59:17 --> Hooks Class Initialized
INFO - 2022-04-02 18:59:17 --> Config Class Initialized
INFO - 2022-04-02 18:59:17 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:17 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:17 --> Utf8 Class Initialized
DEBUG - 2022-04-02 18:59:17 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:17 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:17 --> URI Class Initialized
INFO - 2022-04-02 18:59:17 --> URI Class Initialized
INFO - 2022-04-02 18:59:17 --> Router Class Initialized
INFO - 2022-04-02 18:59:17 --> Router Class Initialized
INFO - 2022-04-02 18:59:17 --> Output Class Initialized
INFO - 2022-04-02 18:59:17 --> Output Class Initialized
INFO - 2022-04-02 18:59:17 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:17 --> Input Class Initialized
INFO - 2022-04-02 18:59:17 --> Language Class Initialized
INFO - 2022-04-02 18:59:17 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:17 --> Input Class Initialized
ERROR - 2022-04-02 18:59:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:59:17 --> Config Class Initialized
INFO - 2022-04-02 18:59:17 --> Language Class Initialized
INFO - 2022-04-02 18:59:17 --> Hooks Class Initialized
ERROR - 2022-04-02 18:59:17 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-02 18:59:17 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:17 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:17 --> URI Class Initialized
INFO - 2022-04-02 18:59:17 --> Config Class Initialized
INFO - 2022-04-02 18:59:17 --> Hooks Class Initialized
INFO - 2022-04-02 18:59:17 --> Router Class Initialized
DEBUG - 2022-04-02 18:59:17 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:17 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:17 --> Output Class Initialized
INFO - 2022-04-02 18:59:17 --> URI Class Initialized
INFO - 2022-04-02 18:59:17 --> Security Class Initialized
INFO - 2022-04-02 18:59:17 --> Router Class Initialized
DEBUG - 2022-04-02 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:17 --> Input Class Initialized
INFO - 2022-04-02 18:59:17 --> Language Class Initialized
INFO - 2022-04-02 18:59:17 --> Output Class Initialized
ERROR - 2022-04-02 18:59:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:59:17 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:17 --> Input Class Initialized
INFO - 2022-04-02 18:59:17 --> Language Class Initialized
ERROR - 2022-04-02 18:59:17 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:59:35 --> Config Class Initialized
INFO - 2022-04-02 18:59:35 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:35 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:35 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:35 --> URI Class Initialized
INFO - 2022-04-02 18:59:35 --> Router Class Initialized
INFO - 2022-04-02 18:59:35 --> Output Class Initialized
INFO - 2022-04-02 18:59:35 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:35 --> Input Class Initialized
INFO - 2022-04-02 18:59:35 --> Language Class Initialized
INFO - 2022-04-02 18:59:35 --> Loader Class Initialized
INFO - 2022-04-02 18:59:35 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:35 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:35 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:35 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:35 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:35 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:35 --> Controller Class Initialized
INFO - 2022-04-02 18:59:35 --> Model Class Initialized
INFO - 2022-04-02 18:59:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 18:59:35 --> Config Class Initialized
INFO - 2022-04-02 18:59:35 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:35 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:35 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:35 --> URI Class Initialized
INFO - 2022-04-02 18:59:35 --> Router Class Initialized
INFO - 2022-04-02 18:59:35 --> Output Class Initialized
INFO - 2022-04-02 18:59:35 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:35 --> Input Class Initialized
INFO - 2022-04-02 18:59:35 --> Language Class Initialized
INFO - 2022-04-02 18:59:35 --> Loader Class Initialized
INFO - 2022-04-02 18:59:35 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:35 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:35 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:35 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:35 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:35 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:35 --> Controller Class Initialized
INFO - 2022-04-02 18:59:35 --> Model Class Initialized
INFO - 2022-04-02 18:59:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:59:35 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:59:35 --> Final output sent to browser
DEBUG - 2022-04-02 18:59:35 --> Total execution time: 0.0534
INFO - 2022-04-02 18:59:35 --> Config Class Initialized
INFO - 2022-04-02 18:59:35 --> Hooks Class Initialized
INFO - 2022-04-02 18:59:35 --> Config Class Initialized
INFO - 2022-04-02 18:59:35 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:35 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:35 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:35 --> URI Class Initialized
INFO - 2022-04-02 18:59:35 --> Router Class Initialized
INFO - 2022-04-02 18:59:35 --> Config Class Initialized
INFO - 2022-04-02 18:59:35 --> Hooks Class Initialized
INFO - 2022-04-02 18:59:35 --> Output Class Initialized
DEBUG - 2022-04-02 18:59:35 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:35 --> Security Class Initialized
INFO - 2022-04-02 18:59:35 --> Utf8 Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:35 --> URI Class Initialized
INFO - 2022-04-02 18:59:35 --> Input Class Initialized
INFO - 2022-04-02 18:59:35 --> Language Class Initialized
INFO - 2022-04-02 18:59:35 --> Router Class Initialized
INFO - 2022-04-02 18:59:35 --> Output Class Initialized
ERROR - 2022-04-02 18:59:35 --> 404 Page Not Found: Fassets/img
DEBUG - 2022-04-02 18:59:35 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:35 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:35 --> Security Class Initialized
INFO - 2022-04-02 18:59:35 --> URI Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:35 --> Input Class Initialized
INFO - 2022-04-02 18:59:35 --> Config Class Initialized
INFO - 2022-04-02 18:59:35 --> Hooks Class Initialized
INFO - 2022-04-02 18:59:35 --> Language Class Initialized
INFO - 2022-04-02 18:59:35 --> Router Class Initialized
ERROR - 2022-04-02 18:59:35 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:59:35 --> Output Class Initialized
DEBUG - 2022-04-02 18:59:35 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:35 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:35 --> Security Class Initialized
INFO - 2022-04-02 18:59:35 --> URI Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:35 --> Input Class Initialized
INFO - 2022-04-02 18:59:35 --> Language Class Initialized
INFO - 2022-04-02 18:59:35 --> Router Class Initialized
INFO - 2022-04-02 18:59:35 --> Output Class Initialized
ERROR - 2022-04-02 18:59:35 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:59:35 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:35 --> Input Class Initialized
INFO - 2022-04-02 18:59:35 --> Language Class Initialized
ERROR - 2022-04-02 18:59:35 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 18:59:53 --> Config Class Initialized
INFO - 2022-04-02 18:59:53 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:53 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:53 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:53 --> URI Class Initialized
INFO - 2022-04-02 18:59:53 --> Router Class Initialized
INFO - 2022-04-02 18:59:53 --> Output Class Initialized
INFO - 2022-04-02 18:59:53 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:53 --> Input Class Initialized
INFO - 2022-04-02 18:59:53 --> Language Class Initialized
INFO - 2022-04-02 18:59:53 --> Loader Class Initialized
INFO - 2022-04-02 18:59:53 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:53 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:53 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:53 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:53 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:53 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:53 --> Controller Class Initialized
INFO - 2022-04-02 18:59:53 --> Model Class Initialized
INFO - 2022-04-02 18:59:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 18:59:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 18:59:53 --> Final output sent to browser
DEBUG - 2022-04-02 18:59:53 --> Total execution time: 0.0676
INFO - 2022-04-02 18:59:53 --> Config Class Initialized
INFO - 2022-04-02 18:59:53 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:53 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:53 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:53 --> URI Class Initialized
INFO - 2022-04-02 18:59:53 --> Router Class Initialized
INFO - 2022-04-02 18:59:53 --> Output Class Initialized
INFO - 2022-04-02 18:59:53 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:53 --> Input Class Initialized
INFO - 2022-04-02 18:59:53 --> Language Class Initialized
INFO - 2022-04-02 18:59:53 --> Loader Class Initialized
INFO - 2022-04-02 18:59:53 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:53 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:53 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:53 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:53 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:53 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:53 --> Controller Class Initialized
INFO - 2022-04-02 18:59:53 --> Model Class Initialized
INFO - 2022-04-02 18:59:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 18:59:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 18:59:53 --> Final output sent to browser
DEBUG - 2022-04-02 18:59:53 --> Total execution time: 0.0610
INFO - 2022-04-02 18:59:55 --> Config Class Initialized
INFO - 2022-04-02 18:59:55 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:55 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:55 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:55 --> URI Class Initialized
INFO - 2022-04-02 18:59:55 --> Router Class Initialized
INFO - 2022-04-02 18:59:55 --> Output Class Initialized
INFO - 2022-04-02 18:59:55 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:55 --> Input Class Initialized
INFO - 2022-04-02 18:59:55 --> Language Class Initialized
INFO - 2022-04-02 18:59:55 --> Loader Class Initialized
INFO - 2022-04-02 18:59:55 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:55 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:55 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:55 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:55 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:55 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:55 --> Controller Class Initialized
INFO - 2022-04-02 18:59:55 --> Model Class Initialized
INFO - 2022-04-02 18:59:55 --> Model Class Initialized
INFO - 2022-04-02 18:59:55 --> Config Class Initialized
INFO - 2022-04-02 18:59:55 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:55 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:55 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:55 --> URI Class Initialized
INFO - 2022-04-02 18:59:55 --> Router Class Initialized
INFO - 2022-04-02 18:59:56 --> Output Class Initialized
INFO - 2022-04-02 18:59:56 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:56 --> Input Class Initialized
INFO - 2022-04-02 18:59:56 --> Language Class Initialized
INFO - 2022-04-02 18:59:56 --> Loader Class Initialized
INFO - 2022-04-02 18:59:56 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:56 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:56 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:56 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:56 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:56 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:56 --> Controller Class Initialized
INFO - 2022-04-02 18:59:56 --> Model Class Initialized
INFO - 2022-04-02 18:59:56 --> Model Class Initialized
INFO - 2022-04-02 18:59:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 18:59:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 18:59:56 --> Final output sent to browser
DEBUG - 2022-04-02 18:59:56 --> Total execution time: 0.0728
INFO - 2022-04-02 18:59:57 --> Config Class Initialized
INFO - 2022-04-02 18:59:57 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:57 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:57 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:57 --> URI Class Initialized
INFO - 2022-04-02 18:59:57 --> Router Class Initialized
INFO - 2022-04-02 18:59:57 --> Output Class Initialized
INFO - 2022-04-02 18:59:57 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:57 --> Input Class Initialized
INFO - 2022-04-02 18:59:57 --> Language Class Initialized
INFO - 2022-04-02 18:59:57 --> Loader Class Initialized
INFO - 2022-04-02 18:59:57 --> Helper loaded: url_helper
INFO - 2022-04-02 18:59:57 --> Helper loaded: form_helper
INFO - 2022-04-02 18:59:57 --> Helper loaded: common_helper
INFO - 2022-04-02 18:59:57 --> Helper loaded: util_helper
INFO - 2022-04-02 18:59:57 --> Database Driver Class Initialized
DEBUG - 2022-04-02 18:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 18:59:57 --> Form Validation Class Initialized
INFO - 2022-04-02 18:59:57 --> Controller Class Initialized
INFO - 2022-04-02 18:59:57 --> Model Class Initialized
INFO - 2022-04-02 18:59:57 --> Model Class Initialized
INFO - 2022-04-02 18:59:57 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 18:59:57 --> Final output sent to browser
DEBUG - 2022-04-02 18:59:57 --> Total execution time: 0.0660
INFO - 2022-04-02 18:59:57 --> Config Class Initialized
INFO - 2022-04-02 18:59:57 --> Hooks Class Initialized
INFO - 2022-04-02 18:59:57 --> Config Class Initialized
INFO - 2022-04-02 18:59:57 --> Hooks Class Initialized
DEBUG - 2022-04-02 18:59:57 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:57 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:57 --> URI Class Initialized
DEBUG - 2022-04-02 18:59:57 --> UTF-8 Support Enabled
INFO - 2022-04-02 18:59:57 --> Utf8 Class Initialized
INFO - 2022-04-02 18:59:57 --> Router Class Initialized
INFO - 2022-04-02 18:59:57 --> URI Class Initialized
INFO - 2022-04-02 18:59:57 --> Router Class Initialized
INFO - 2022-04-02 18:59:57 --> Output Class Initialized
INFO - 2022-04-02 18:59:57 --> Output Class Initialized
INFO - 2022-04-02 18:59:57 --> Security Class Initialized
INFO - 2022-04-02 18:59:57 --> Security Class Initialized
DEBUG - 2022-04-02 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:57 --> Input Class Initialized
DEBUG - 2022-04-02 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 18:59:57 --> Input Class Initialized
INFO - 2022-04-02 18:59:57 --> Language Class Initialized
INFO - 2022-04-02 18:59:57 --> Language Class Initialized
ERROR - 2022-04-02 18:59:57 --> 404 Page Not Found: Fasset/img
ERROR - 2022-04-02 18:59:57 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 19:00:24 --> Config Class Initialized
INFO - 2022-04-02 19:00:24 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:00:24 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:00:24 --> Utf8 Class Initialized
INFO - 2022-04-02 19:00:24 --> URI Class Initialized
INFO - 2022-04-02 19:00:24 --> Router Class Initialized
INFO - 2022-04-02 19:00:24 --> Output Class Initialized
INFO - 2022-04-02 19:00:24 --> Security Class Initialized
DEBUG - 2022-04-02 19:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:00:24 --> Input Class Initialized
INFO - 2022-04-02 19:00:24 --> Language Class Initialized
INFO - 2022-04-02 19:00:24 --> Loader Class Initialized
INFO - 2022-04-02 19:00:24 --> Helper loaded: url_helper
INFO - 2022-04-02 19:00:24 --> Helper loaded: form_helper
INFO - 2022-04-02 19:00:24 --> Helper loaded: common_helper
INFO - 2022-04-02 19:00:24 --> Helper loaded: util_helper
INFO - 2022-04-02 19:00:24 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:00:24 --> Form Validation Class Initialized
INFO - 2022-04-02 19:00:24 --> Controller Class Initialized
INFO - 2022-04-02 19:00:24 --> Model Class Initialized
INFO - 2022-04-02 19:00:24 --> Model Class Initialized
INFO - 2022-04-02 19:00:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:00:24 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:00:24 --> Final output sent to browser
DEBUG - 2022-04-02 19:00:24 --> Total execution time: 0.0667
INFO - 2022-04-02 19:00:26 --> Config Class Initialized
INFO - 2022-04-02 19:00:26 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:00:26 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:00:26 --> Utf8 Class Initialized
INFO - 2022-04-02 19:00:26 --> URI Class Initialized
INFO - 2022-04-02 19:00:26 --> Router Class Initialized
INFO - 2022-04-02 19:00:26 --> Output Class Initialized
INFO - 2022-04-02 19:00:26 --> Security Class Initialized
DEBUG - 2022-04-02 19:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:00:26 --> Input Class Initialized
INFO - 2022-04-02 19:00:26 --> Language Class Initialized
INFO - 2022-04-02 19:00:26 --> Loader Class Initialized
INFO - 2022-04-02 19:00:26 --> Helper loaded: url_helper
INFO - 2022-04-02 19:00:26 --> Helper loaded: form_helper
INFO - 2022-04-02 19:00:26 --> Helper loaded: common_helper
INFO - 2022-04-02 19:00:26 --> Helper loaded: util_helper
INFO - 2022-04-02 19:00:27 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:00:27 --> Form Validation Class Initialized
INFO - 2022-04-02 19:00:27 --> Controller Class Initialized
INFO - 2022-04-02 19:00:27 --> Model Class Initialized
INFO - 2022-04-02 19:00:27 --> Model Class Initialized
INFO - 2022-04-02 19:00:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:00:27 --> Final output sent to browser
DEBUG - 2022-04-02 19:00:27 --> Total execution time: 0.0758
INFO - 2022-04-02 19:00:29 --> Config Class Initialized
INFO - 2022-04-02 19:00:29 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:00:29 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:00:29 --> Utf8 Class Initialized
INFO - 2022-04-02 19:00:29 --> URI Class Initialized
INFO - 2022-04-02 19:00:29 --> Router Class Initialized
INFO - 2022-04-02 19:00:29 --> Output Class Initialized
INFO - 2022-04-02 19:00:29 --> Security Class Initialized
DEBUG - 2022-04-02 19:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:00:29 --> Input Class Initialized
INFO - 2022-04-02 19:00:29 --> Language Class Initialized
INFO - 2022-04-02 19:00:29 --> Loader Class Initialized
INFO - 2022-04-02 19:00:29 --> Helper loaded: url_helper
INFO - 2022-04-02 19:00:29 --> Helper loaded: form_helper
INFO - 2022-04-02 19:00:29 --> Helper loaded: common_helper
INFO - 2022-04-02 19:00:29 --> Helper loaded: util_helper
INFO - 2022-04-02 19:00:29 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:00:29 --> Form Validation Class Initialized
INFO - 2022-04-02 19:00:29 --> Controller Class Initialized
INFO - 2022-04-02 19:00:29 --> Model Class Initialized
INFO - 2022-04-02 19:00:29 --> Model Class Initialized
INFO - 2022-04-02 19:00:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:00:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:00:29 --> Final output sent to browser
DEBUG - 2022-04-02 19:00:29 --> Total execution time: 0.0684
INFO - 2022-04-02 19:00:31 --> Config Class Initialized
INFO - 2022-04-02 19:00:31 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:00:31 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:00:31 --> Utf8 Class Initialized
INFO - 2022-04-02 19:00:31 --> URI Class Initialized
INFO - 2022-04-02 19:00:31 --> Router Class Initialized
INFO - 2022-04-02 19:00:31 --> Output Class Initialized
INFO - 2022-04-02 19:00:31 --> Security Class Initialized
DEBUG - 2022-04-02 19:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:00:31 --> Input Class Initialized
INFO - 2022-04-02 19:00:31 --> Language Class Initialized
INFO - 2022-04-02 19:00:31 --> Loader Class Initialized
INFO - 2022-04-02 19:00:31 --> Helper loaded: url_helper
INFO - 2022-04-02 19:00:31 --> Helper loaded: form_helper
INFO - 2022-04-02 19:00:31 --> Helper loaded: common_helper
INFO - 2022-04-02 19:00:31 --> Helper loaded: util_helper
INFO - 2022-04-02 19:00:31 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:00:31 --> Form Validation Class Initialized
INFO - 2022-04-02 19:00:31 --> Controller Class Initialized
INFO - 2022-04-02 19:00:31 --> Model Class Initialized
INFO - 2022-04-02 19:00:31 --> Model Class Initialized
INFO - 2022-04-02 19:00:31 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:00:31 --> Final output sent to browser
DEBUG - 2022-04-02 19:00:31 --> Total execution time: 0.0694
INFO - 2022-04-02 19:00:54 --> Config Class Initialized
INFO - 2022-04-02 19:00:54 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:00:54 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:00:54 --> Utf8 Class Initialized
INFO - 2022-04-02 19:00:54 --> URI Class Initialized
INFO - 2022-04-02 19:00:54 --> Router Class Initialized
INFO - 2022-04-02 19:00:54 --> Output Class Initialized
INFO - 2022-04-02 19:00:54 --> Security Class Initialized
DEBUG - 2022-04-02 19:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:00:54 --> Input Class Initialized
INFO - 2022-04-02 19:00:54 --> Language Class Initialized
INFO - 2022-04-02 19:00:54 --> Loader Class Initialized
INFO - 2022-04-02 19:00:54 --> Helper loaded: url_helper
INFO - 2022-04-02 19:00:54 --> Helper loaded: form_helper
INFO - 2022-04-02 19:00:54 --> Helper loaded: common_helper
INFO - 2022-04-02 19:00:54 --> Helper loaded: util_helper
INFO - 2022-04-02 19:00:54 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:00:54 --> Form Validation Class Initialized
INFO - 2022-04-02 19:00:54 --> Controller Class Initialized
INFO - 2022-04-02 19:00:54 --> Model Class Initialized
INFO - 2022-04-02 19:00:54 --> Model Class Initialized
INFO - 2022-04-02 19:00:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:00:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:00:54 --> Final output sent to browser
DEBUG - 2022-04-02 19:00:54 --> Total execution time: 0.0658
INFO - 2022-04-02 19:00:56 --> Config Class Initialized
INFO - 2022-04-02 19:00:56 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:00:56 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:00:56 --> Utf8 Class Initialized
INFO - 2022-04-02 19:00:56 --> URI Class Initialized
INFO - 2022-04-02 19:00:56 --> Router Class Initialized
INFO - 2022-04-02 19:00:56 --> Output Class Initialized
INFO - 2022-04-02 19:00:56 --> Security Class Initialized
DEBUG - 2022-04-02 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:00:56 --> Input Class Initialized
INFO - 2022-04-02 19:00:56 --> Language Class Initialized
INFO - 2022-04-02 19:00:56 --> Loader Class Initialized
INFO - 2022-04-02 19:00:56 --> Helper loaded: url_helper
INFO - 2022-04-02 19:00:56 --> Helper loaded: form_helper
INFO - 2022-04-02 19:00:56 --> Helper loaded: common_helper
INFO - 2022-04-02 19:00:56 --> Helper loaded: util_helper
INFO - 2022-04-02 19:00:56 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:00:56 --> Form Validation Class Initialized
INFO - 2022-04-02 19:00:56 --> Controller Class Initialized
INFO - 2022-04-02 19:00:56 --> Model Class Initialized
INFO - 2022-04-02 19:00:56 --> Model Class Initialized
INFO - 2022-04-02 19:00:56 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:00:56 --> Final output sent to browser
DEBUG - 2022-04-02 19:00:56 --> Total execution time: 0.0667
INFO - 2022-04-02 19:01:17 --> Config Class Initialized
INFO - 2022-04-02 19:01:17 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:01:17 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:01:17 --> Utf8 Class Initialized
INFO - 2022-04-02 19:01:17 --> URI Class Initialized
INFO - 2022-04-02 19:01:17 --> Router Class Initialized
INFO - 2022-04-02 19:01:17 --> Output Class Initialized
INFO - 2022-04-02 19:01:17 --> Security Class Initialized
DEBUG - 2022-04-02 19:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:01:17 --> Input Class Initialized
INFO - 2022-04-02 19:01:17 --> Language Class Initialized
INFO - 2022-04-02 19:01:17 --> Loader Class Initialized
INFO - 2022-04-02 19:01:17 --> Helper loaded: url_helper
INFO - 2022-04-02 19:01:17 --> Helper loaded: form_helper
INFO - 2022-04-02 19:01:17 --> Helper loaded: common_helper
INFO - 2022-04-02 19:01:17 --> Helper loaded: util_helper
INFO - 2022-04-02 19:01:17 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:01:17 --> Form Validation Class Initialized
INFO - 2022-04-02 19:01:17 --> Controller Class Initialized
INFO - 2022-04-02 19:01:17 --> Model Class Initialized
INFO - 2022-04-02 19:01:17 --> Model Class Initialized
INFO - 2022-04-02 19:01:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:01:17 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:01:17 --> Final output sent to browser
DEBUG - 2022-04-02 19:01:17 --> Total execution time: 0.0647
INFO - 2022-04-02 19:01:19 --> Config Class Initialized
INFO - 2022-04-02 19:01:19 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:01:19 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:01:19 --> Utf8 Class Initialized
INFO - 2022-04-02 19:01:19 --> URI Class Initialized
INFO - 2022-04-02 19:01:19 --> Router Class Initialized
INFO - 2022-04-02 19:01:19 --> Output Class Initialized
INFO - 2022-04-02 19:01:19 --> Security Class Initialized
DEBUG - 2022-04-02 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:01:19 --> Input Class Initialized
INFO - 2022-04-02 19:01:19 --> Language Class Initialized
INFO - 2022-04-02 19:01:19 --> Loader Class Initialized
INFO - 2022-04-02 19:01:19 --> Helper loaded: url_helper
INFO - 2022-04-02 19:01:19 --> Helper loaded: form_helper
INFO - 2022-04-02 19:01:19 --> Helper loaded: common_helper
INFO - 2022-04-02 19:01:19 --> Helper loaded: util_helper
INFO - 2022-04-02 19:01:19 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:01:19 --> Form Validation Class Initialized
INFO - 2022-04-02 19:01:19 --> Controller Class Initialized
INFO - 2022-04-02 19:01:19 --> Model Class Initialized
INFO - 2022-04-02 19:01:19 --> Model Class Initialized
INFO - 2022-04-02 19:01:19 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:01:19 --> Final output sent to browser
DEBUG - 2022-04-02 19:01:19 --> Total execution time: 0.0726
INFO - 2022-04-02 19:03:08 --> Config Class Initialized
INFO - 2022-04-02 19:03:08 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:08 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:08 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:08 --> URI Class Initialized
INFO - 2022-04-02 19:03:08 --> Router Class Initialized
INFO - 2022-04-02 19:03:08 --> Output Class Initialized
INFO - 2022-04-02 19:03:08 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:08 --> Input Class Initialized
INFO - 2022-04-02 19:03:08 --> Language Class Initialized
INFO - 2022-04-02 19:03:08 --> Loader Class Initialized
INFO - 2022-04-02 19:03:08 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:08 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:08 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:08 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:08 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:08 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:08 --> Controller Class Initialized
INFO - 2022-04-02 19:03:08 --> Model Class Initialized
INFO - 2022-04-02 19:03:08 --> Model Class Initialized
INFO - 2022-04-02 19:03:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:03:08 --> Final output sent to browser
DEBUG - 2022-04-02 19:03:08 --> Total execution time: 0.0575
INFO - 2022-04-02 19:03:27 --> Config Class Initialized
INFO - 2022-04-02 19:03:27 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:27 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:27 --> URI Class Initialized
INFO - 2022-04-02 19:03:27 --> Router Class Initialized
INFO - 2022-04-02 19:03:27 --> Output Class Initialized
INFO - 2022-04-02 19:03:27 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:27 --> Input Class Initialized
INFO - 2022-04-02 19:03:27 --> Language Class Initialized
INFO - 2022-04-02 19:03:27 --> Loader Class Initialized
INFO - 2022-04-02 19:03:27 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:27 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:27 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:27 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:27 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:27 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:27 --> Controller Class Initialized
INFO - 2022-04-02 19:03:27 --> Model Class Initialized
INFO - 2022-04-02 19:03:27 --> Model Class Initialized
INFO - 2022-04-02 19:03:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:03:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:03:27 --> Final output sent to browser
DEBUG - 2022-04-02 19:03:27 --> Total execution time: 0.0577
INFO - 2022-04-02 19:03:29 --> Config Class Initialized
INFO - 2022-04-02 19:03:29 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:29 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:29 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:29 --> URI Class Initialized
INFO - 2022-04-02 19:03:29 --> Router Class Initialized
INFO - 2022-04-02 19:03:29 --> Output Class Initialized
INFO - 2022-04-02 19:03:29 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:29 --> Input Class Initialized
INFO - 2022-04-02 19:03:29 --> Language Class Initialized
INFO - 2022-04-02 19:03:29 --> Loader Class Initialized
INFO - 2022-04-02 19:03:29 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:29 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:29 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:29 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:29 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:29 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:29 --> Controller Class Initialized
INFO - 2022-04-02 19:03:29 --> Model Class Initialized
INFO - 2022-04-02 19:03:29 --> Model Class Initialized
INFO - 2022-04-02 19:03:29 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:03:29 --> Final output sent to browser
DEBUG - 2022-04-02 19:03:29 --> Total execution time: 0.0729
INFO - 2022-04-02 19:03:30 --> Config Class Initialized
INFO - 2022-04-02 19:03:30 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:30 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:30 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:30 --> URI Class Initialized
INFO - 2022-04-02 19:03:30 --> Router Class Initialized
INFO - 2022-04-02 19:03:30 --> Output Class Initialized
INFO - 2022-04-02 19:03:30 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:30 --> Input Class Initialized
INFO - 2022-04-02 19:03:30 --> Language Class Initialized
INFO - 2022-04-02 19:03:30 --> Loader Class Initialized
INFO - 2022-04-02 19:03:30 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:30 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:30 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:30 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:30 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:30 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:30 --> Controller Class Initialized
INFO - 2022-04-02 19:03:30 --> Model Class Initialized
INFO - 2022-04-02 19:03:30 --> Model Class Initialized
INFO - 2022-04-02 19:03:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:03:30 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:03:30 --> Final output sent to browser
DEBUG - 2022-04-02 19:03:30 --> Total execution time: 0.0710
INFO - 2022-04-02 19:03:33 --> Config Class Initialized
INFO - 2022-04-02 19:03:33 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:33 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:33 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:33 --> URI Class Initialized
INFO - 2022-04-02 19:03:33 --> Router Class Initialized
INFO - 2022-04-02 19:03:33 --> Output Class Initialized
INFO - 2022-04-02 19:03:33 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:33 --> Input Class Initialized
INFO - 2022-04-02 19:03:33 --> Language Class Initialized
INFO - 2022-04-02 19:03:33 --> Loader Class Initialized
INFO - 2022-04-02 19:03:33 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:33 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:33 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:33 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:33 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:33 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:33 --> Controller Class Initialized
INFO - 2022-04-02 19:03:33 --> Model Class Initialized
INFO - 2022-04-02 19:03:33 --> Model Class Initialized
INFO - 2022-04-02 19:03:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:03:33 --> Final output sent to browser
DEBUG - 2022-04-02 19:03:33 --> Total execution time: 0.0564
INFO - 2022-04-02 19:03:58 --> Config Class Initialized
INFO - 2022-04-02 19:03:58 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:58 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:58 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:58 --> URI Class Initialized
INFO - 2022-04-02 19:03:58 --> Router Class Initialized
INFO - 2022-04-02 19:03:58 --> Output Class Initialized
INFO - 2022-04-02 19:03:58 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:58 --> Input Class Initialized
INFO - 2022-04-02 19:03:58 --> Language Class Initialized
INFO - 2022-04-02 19:03:58 --> Loader Class Initialized
INFO - 2022-04-02 19:03:58 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:58 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:58 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:58 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:58 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:58 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:58 --> Controller Class Initialized
INFO - 2022-04-02 19:03:58 --> Model Class Initialized
INFO - 2022-04-02 19:03:58 --> Model Class Initialized
INFO - 2022-04-02 19:03:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:03:58 --> Config Class Initialized
INFO - 2022-04-02 19:03:58 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:03:58 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:03:58 --> Utf8 Class Initialized
INFO - 2022-04-02 19:03:58 --> URI Class Initialized
INFO - 2022-04-02 19:03:58 --> Router Class Initialized
INFO - 2022-04-02 19:03:58 --> Output Class Initialized
INFO - 2022-04-02 19:03:58 --> Security Class Initialized
DEBUG - 2022-04-02 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:03:58 --> Input Class Initialized
INFO - 2022-04-02 19:03:58 --> Language Class Initialized
INFO - 2022-04-02 19:03:58 --> Loader Class Initialized
INFO - 2022-04-02 19:03:58 --> Helper loaded: url_helper
INFO - 2022-04-02 19:03:58 --> Helper loaded: form_helper
INFO - 2022-04-02 19:03:58 --> Helper loaded: common_helper
INFO - 2022-04-02 19:03:59 --> Helper loaded: util_helper
INFO - 2022-04-02 19:03:59 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:03:59 --> Form Validation Class Initialized
INFO - 2022-04-02 19:03:59 --> Controller Class Initialized
INFO - 2022-04-02 19:03:59 --> Model Class Initialized
INFO - 2022-04-02 19:03:59 --> Model Class Initialized
INFO - 2022-04-02 19:03:59 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:03:59 --> Final output sent to browser
DEBUG - 2022-04-02 19:03:59 --> Total execution time: 0.0722
INFO - 2022-04-02 19:04:06 --> Config Class Initialized
INFO - 2022-04-02 19:04:06 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:04:06 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:04:06 --> Utf8 Class Initialized
INFO - 2022-04-02 19:04:06 --> URI Class Initialized
INFO - 2022-04-02 19:04:06 --> Router Class Initialized
INFO - 2022-04-02 19:04:06 --> Output Class Initialized
INFO - 2022-04-02 19:04:06 --> Security Class Initialized
DEBUG - 2022-04-02 19:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:04:06 --> Input Class Initialized
INFO - 2022-04-02 19:04:06 --> Language Class Initialized
INFO - 2022-04-02 19:04:06 --> Loader Class Initialized
INFO - 2022-04-02 19:04:06 --> Helper loaded: url_helper
INFO - 2022-04-02 19:04:06 --> Helper loaded: form_helper
INFO - 2022-04-02 19:04:06 --> Helper loaded: common_helper
INFO - 2022-04-02 19:04:06 --> Helper loaded: util_helper
INFO - 2022-04-02 19:04:06 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:04:06 --> Form Validation Class Initialized
INFO - 2022-04-02 19:04:06 --> Controller Class Initialized
INFO - 2022-04-02 19:04:06 --> Model Class Initialized
INFO - 2022-04-02 19:04:06 --> Model Class Initialized
INFO - 2022-04-02 19:04:06 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:04:06 --> Final output sent to browser
DEBUG - 2022-04-02 19:04:06 --> Total execution time: 0.0571
INFO - 2022-04-02 19:04:07 --> Config Class Initialized
INFO - 2022-04-02 19:04:07 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:04:07 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:04:07 --> Utf8 Class Initialized
INFO - 2022-04-02 19:04:07 --> URI Class Initialized
INFO - 2022-04-02 19:04:07 --> Router Class Initialized
INFO - 2022-04-02 19:04:07 --> Output Class Initialized
INFO - 2022-04-02 19:04:07 --> Security Class Initialized
DEBUG - 2022-04-02 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:04:07 --> Input Class Initialized
INFO - 2022-04-02 19:04:07 --> Language Class Initialized
INFO - 2022-04-02 19:04:07 --> Loader Class Initialized
INFO - 2022-04-02 19:04:07 --> Helper loaded: url_helper
INFO - 2022-04-02 19:04:07 --> Helper loaded: form_helper
INFO - 2022-04-02 19:04:07 --> Helper loaded: common_helper
INFO - 2022-04-02 19:04:07 --> Helper loaded: util_helper
INFO - 2022-04-02 19:04:07 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:04:07 --> Form Validation Class Initialized
INFO - 2022-04-02 19:04:07 --> Controller Class Initialized
INFO - 2022-04-02 19:04:07 --> Model Class Initialized
INFO - 2022-04-02 19:04:07 --> Model Class Initialized
INFO - 2022-04-02 19:04:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:04:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:04:07 --> Final output sent to browser
DEBUG - 2022-04-02 19:04:07 --> Total execution time: 0.0657
INFO - 2022-04-02 19:04:09 --> Config Class Initialized
INFO - 2022-04-02 19:04:09 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:04:09 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:04:09 --> Utf8 Class Initialized
INFO - 2022-04-02 19:04:09 --> URI Class Initialized
INFO - 2022-04-02 19:04:09 --> Router Class Initialized
INFO - 2022-04-02 19:04:09 --> Output Class Initialized
INFO - 2022-04-02 19:04:09 --> Security Class Initialized
DEBUG - 2022-04-02 19:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:04:09 --> Input Class Initialized
INFO - 2022-04-02 19:04:09 --> Language Class Initialized
INFO - 2022-04-02 19:04:09 --> Loader Class Initialized
INFO - 2022-04-02 19:04:09 --> Helper loaded: url_helper
INFO - 2022-04-02 19:04:09 --> Helper loaded: form_helper
INFO - 2022-04-02 19:04:09 --> Helper loaded: common_helper
INFO - 2022-04-02 19:04:09 --> Helper loaded: util_helper
INFO - 2022-04-02 19:04:09 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:04:09 --> Form Validation Class Initialized
INFO - 2022-04-02 19:04:09 --> Controller Class Initialized
INFO - 2022-04-02 19:04:09 --> Model Class Initialized
INFO - 2022-04-02 19:04:09 --> Model Class Initialized
INFO - 2022-04-02 19:04:09 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:04:09 --> Final output sent to browser
DEBUG - 2022-04-02 19:04:09 --> Total execution time: 0.0658
INFO - 2022-04-02 19:04:26 --> Config Class Initialized
INFO - 2022-04-02 19:04:26 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:04:26 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:04:26 --> Utf8 Class Initialized
INFO - 2022-04-02 19:04:26 --> URI Class Initialized
INFO - 2022-04-02 19:04:26 --> Router Class Initialized
INFO - 2022-04-02 19:04:26 --> Output Class Initialized
INFO - 2022-04-02 19:04:26 --> Security Class Initialized
DEBUG - 2022-04-02 19:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:04:26 --> Input Class Initialized
INFO - 2022-04-02 19:04:26 --> Language Class Initialized
INFO - 2022-04-02 19:04:26 --> Loader Class Initialized
INFO - 2022-04-02 19:04:26 --> Helper loaded: url_helper
INFO - 2022-04-02 19:04:26 --> Helper loaded: form_helper
INFO - 2022-04-02 19:04:26 --> Helper loaded: common_helper
INFO - 2022-04-02 19:04:26 --> Helper loaded: util_helper
INFO - 2022-04-02 19:04:26 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:04:26 --> Form Validation Class Initialized
INFO - 2022-04-02 19:04:26 --> Controller Class Initialized
INFO - 2022-04-02 19:04:26 --> Model Class Initialized
INFO - 2022-04-02 19:04:26 --> Model Class Initialized
INFO - 2022-04-02 19:04:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:04:26 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:04:26 --> Final output sent to browser
DEBUG - 2022-04-02 19:04:26 --> Total execution time: 0.0635
INFO - 2022-04-02 19:04:28 --> Config Class Initialized
INFO - 2022-04-02 19:04:28 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:04:28 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:04:28 --> Utf8 Class Initialized
INFO - 2022-04-02 19:04:28 --> URI Class Initialized
INFO - 2022-04-02 19:04:28 --> Router Class Initialized
INFO - 2022-04-02 19:04:28 --> Output Class Initialized
INFO - 2022-04-02 19:04:28 --> Security Class Initialized
DEBUG - 2022-04-02 19:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:04:28 --> Input Class Initialized
INFO - 2022-04-02 19:04:28 --> Language Class Initialized
INFO - 2022-04-02 19:04:28 --> Loader Class Initialized
INFO - 2022-04-02 19:04:28 --> Helper loaded: url_helper
INFO - 2022-04-02 19:04:28 --> Helper loaded: form_helper
INFO - 2022-04-02 19:04:28 --> Helper loaded: common_helper
INFO - 2022-04-02 19:04:28 --> Helper loaded: util_helper
INFO - 2022-04-02 19:04:28 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:04:28 --> Form Validation Class Initialized
INFO - 2022-04-02 19:04:28 --> Controller Class Initialized
INFO - 2022-04-02 19:04:28 --> Model Class Initialized
INFO - 2022-04-02 19:04:28 --> Model Class Initialized
INFO - 2022-04-02 19:04:28 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:04:28 --> Final output sent to browser
DEBUG - 2022-04-02 19:04:28 --> Total execution time: 0.0734
INFO - 2022-04-02 19:07:38 --> Config Class Initialized
INFO - 2022-04-02 19:07:38 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:38 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:38 --> URI Class Initialized
INFO - 2022-04-02 19:07:38 --> Router Class Initialized
INFO - 2022-04-02 19:07:38 --> Output Class Initialized
INFO - 2022-04-02 19:07:38 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:38 --> Input Class Initialized
INFO - 2022-04-02 19:07:38 --> Language Class Initialized
INFO - 2022-04-02 19:07:38 --> Loader Class Initialized
INFO - 2022-04-02 19:07:38 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:38 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:38 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:38 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:38 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:38 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:38 --> Controller Class Initialized
INFO - 2022-04-02 19:07:38 --> Model Class Initialized
INFO - 2022-04-02 19:07:38 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\admin/login.php
INFO - 2022-04-02 19:07:38 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:38 --> Total execution time: 0.0790
INFO - 2022-04-02 19:07:39 --> Config Class Initialized
INFO - 2022-04-02 19:07:39 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:39 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:39 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:39 --> URI Class Initialized
INFO - 2022-04-02 19:07:39 --> Router Class Initialized
INFO - 2022-04-02 19:07:39 --> Output Class Initialized
INFO - 2022-04-02 19:07:39 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:39 --> Input Class Initialized
INFO - 2022-04-02 19:07:39 --> Language Class Initialized
INFO - 2022-04-02 19:07:39 --> Loader Class Initialized
INFO - 2022-04-02 19:07:39 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:39 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:39 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:39 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:39 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:39 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:39 --> Controller Class Initialized
INFO - 2022-04-02 19:07:39 --> Model Class Initialized
INFO - 2022-04-02 19:07:39 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:39 --> Total execution time: 0.0701
INFO - 2022-04-02 19:07:40 --> Config Class Initialized
INFO - 2022-04-02 19:07:40 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:40 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:40 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:40 --> URI Class Initialized
DEBUG - 2022-04-02 19:07:40 --> No URI present. Default controller set.
INFO - 2022-04-02 19:07:40 --> Router Class Initialized
INFO - 2022-04-02 19:07:40 --> Output Class Initialized
INFO - 2022-04-02 19:07:40 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:40 --> Input Class Initialized
INFO - 2022-04-02 19:07:40 --> Language Class Initialized
INFO - 2022-04-02 19:07:40 --> Loader Class Initialized
INFO - 2022-04-02 19:07:40 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:40 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:40 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:40 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:40 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:40 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:40 --> Controller Class Initialized
INFO - 2022-04-02 19:07:40 --> Model Class Initialized
INFO - 2022-04-02 19:07:40 --> Model Class Initialized
INFO - 2022-04-02 19:07:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:07:40 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:07:40 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:40 --> Total execution time: 0.0828
INFO - 2022-04-02 19:07:42 --> Config Class Initialized
INFO - 2022-04-02 19:07:42 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:42 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:42 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:42 --> URI Class Initialized
INFO - 2022-04-02 19:07:42 --> Router Class Initialized
INFO - 2022-04-02 19:07:42 --> Output Class Initialized
INFO - 2022-04-02 19:07:42 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:42 --> Input Class Initialized
INFO - 2022-04-02 19:07:42 --> Language Class Initialized
INFO - 2022-04-02 19:07:42 --> Loader Class Initialized
INFO - 2022-04-02 19:07:42 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:42 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:42 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:42 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:42 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:42 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:42 --> Controller Class Initialized
INFO - 2022-04-02 19:07:42 --> Model Class Initialized
INFO - 2022-04-02 19:07:42 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:42 --> Total execution time: 0.0701
INFO - 2022-04-02 19:07:45 --> Config Class Initialized
INFO - 2022-04-02 19:07:45 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:45 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:45 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:45 --> URI Class Initialized
DEBUG - 2022-04-02 19:07:45 --> No URI present. Default controller set.
INFO - 2022-04-02 19:07:45 --> Router Class Initialized
INFO - 2022-04-02 19:07:45 --> Output Class Initialized
INFO - 2022-04-02 19:07:45 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:45 --> Input Class Initialized
INFO - 2022-04-02 19:07:45 --> Language Class Initialized
INFO - 2022-04-02 19:07:45 --> Loader Class Initialized
INFO - 2022-04-02 19:07:45 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:45 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:45 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:45 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:45 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:45 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:45 --> Controller Class Initialized
INFO - 2022-04-02 19:07:45 --> Model Class Initialized
INFO - 2022-04-02 19:07:45 --> Model Class Initialized
INFO - 2022-04-02 19:07:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:07:45 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:07:45 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:45 --> Total execution time: 0.0752
INFO - 2022-04-02 19:07:55 --> Config Class Initialized
INFO - 2022-04-02 19:07:55 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:55 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:55 --> URI Class Initialized
INFO - 2022-04-02 19:07:55 --> Router Class Initialized
INFO - 2022-04-02 19:07:55 --> Output Class Initialized
INFO - 2022-04-02 19:07:55 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:55 --> Input Class Initialized
INFO - 2022-04-02 19:07:55 --> Language Class Initialized
INFO - 2022-04-02 19:07:55 --> Loader Class Initialized
INFO - 2022-04-02 19:07:55 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:55 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:55 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:55 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:55 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:55 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:55 --> Controller Class Initialized
INFO - 2022-04-02 19:07:55 --> Model Class Initialized
INFO - 2022-04-02 19:07:55 --> Config Class Initialized
INFO - 2022-04-02 19:07:55 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:55 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:55 --> URI Class Initialized
INFO - 2022-04-02 19:07:55 --> Router Class Initialized
INFO - 2022-04-02 19:07:55 --> Output Class Initialized
INFO - 2022-04-02 19:07:55 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:55 --> Input Class Initialized
INFO - 2022-04-02 19:07:55 --> Language Class Initialized
INFO - 2022-04-02 19:07:55 --> Loader Class Initialized
INFO - 2022-04-02 19:07:55 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:55 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:55 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:55 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:55 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:55 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:55 --> Controller Class Initialized
INFO - 2022-04-02 19:07:55 --> Model Class Initialized
INFO - 2022-04-02 19:07:55 --> Model Class Initialized
INFO - 2022-04-02 19:07:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:07:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:07:55 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:55 --> Total execution time: 0.0561
INFO - 2022-04-02 19:07:58 --> Config Class Initialized
INFO - 2022-04-02 19:07:58 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:07:58 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:07:58 --> Utf8 Class Initialized
INFO - 2022-04-02 19:07:58 --> URI Class Initialized
DEBUG - 2022-04-02 19:07:58 --> No URI present. Default controller set.
INFO - 2022-04-02 19:07:58 --> Router Class Initialized
INFO - 2022-04-02 19:07:58 --> Output Class Initialized
INFO - 2022-04-02 19:07:58 --> Security Class Initialized
DEBUG - 2022-04-02 19:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:07:58 --> Input Class Initialized
INFO - 2022-04-02 19:07:58 --> Language Class Initialized
INFO - 2022-04-02 19:07:58 --> Loader Class Initialized
INFO - 2022-04-02 19:07:58 --> Helper loaded: url_helper
INFO - 2022-04-02 19:07:58 --> Helper loaded: form_helper
INFO - 2022-04-02 19:07:58 --> Helper loaded: common_helper
INFO - 2022-04-02 19:07:58 --> Helper loaded: util_helper
INFO - 2022-04-02 19:07:58 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:07:58 --> Form Validation Class Initialized
INFO - 2022-04-02 19:07:58 --> Controller Class Initialized
INFO - 2022-04-02 19:07:58 --> Model Class Initialized
INFO - 2022-04-02 19:07:58 --> Model Class Initialized
INFO - 2022-04-02 19:07:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:07:58 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:07:58 --> Final output sent to browser
DEBUG - 2022-04-02 19:07:58 --> Total execution time: 0.0666
INFO - 2022-04-02 19:10:07 --> Config Class Initialized
INFO - 2022-04-02 19:10:07 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:10:07 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:10:07 --> Utf8 Class Initialized
INFO - 2022-04-02 19:10:07 --> URI Class Initialized
INFO - 2022-04-02 19:10:07 --> Router Class Initialized
INFO - 2022-04-02 19:10:07 --> Output Class Initialized
INFO - 2022-04-02 19:10:07 --> Security Class Initialized
DEBUG - 2022-04-02 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:10:07 --> Input Class Initialized
INFO - 2022-04-02 19:10:07 --> Language Class Initialized
INFO - 2022-04-02 19:10:07 --> Loader Class Initialized
INFO - 2022-04-02 19:10:07 --> Helper loaded: url_helper
INFO - 2022-04-02 19:10:07 --> Helper loaded: form_helper
INFO - 2022-04-02 19:10:07 --> Helper loaded: common_helper
INFO - 2022-04-02 19:10:07 --> Helper loaded: util_helper
INFO - 2022-04-02 19:10:07 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:10:07 --> Form Validation Class Initialized
INFO - 2022-04-02 19:10:07 --> Controller Class Initialized
INFO - 2022-04-02 19:10:07 --> Model Class Initialized
INFO - 2022-04-02 19:10:07 --> Model Class Initialized
INFO - 2022-04-02 19:10:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:10:07 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:10:07 --> Final output sent to browser
DEBUG - 2022-04-02 19:10:07 --> Total execution time: 0.0681
INFO - 2022-04-02 19:10:08 --> Config Class Initialized
INFO - 2022-04-02 19:10:08 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:10:08 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:10:08 --> Utf8 Class Initialized
INFO - 2022-04-02 19:10:08 --> URI Class Initialized
INFO - 2022-04-02 19:10:08 --> Router Class Initialized
INFO - 2022-04-02 19:10:08 --> Output Class Initialized
INFO - 2022-04-02 19:10:08 --> Security Class Initialized
DEBUG - 2022-04-02 19:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:10:08 --> Input Class Initialized
INFO - 2022-04-02 19:10:08 --> Language Class Initialized
INFO - 2022-04-02 19:10:08 --> Loader Class Initialized
INFO - 2022-04-02 19:10:08 --> Helper loaded: url_helper
INFO - 2022-04-02 19:10:08 --> Helper loaded: form_helper
INFO - 2022-04-02 19:10:08 --> Helper loaded: common_helper
INFO - 2022-04-02 19:10:08 --> Helper loaded: util_helper
INFO - 2022-04-02 19:10:08 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:10:08 --> Form Validation Class Initialized
INFO - 2022-04-02 19:10:08 --> Controller Class Initialized
INFO - 2022-04-02 19:10:08 --> Model Class Initialized
INFO - 2022-04-02 19:10:08 --> Model Class Initialized
INFO - 2022-04-02 19:10:08 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:10:08 --> Final output sent to browser
DEBUG - 2022-04-02 19:10:08 --> Total execution time: 0.0647
INFO - 2022-04-02 19:10:53 --> Config Class Initialized
INFO - 2022-04-02 19:10:53 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:10:53 --> Utf8 Class Initialized
INFO - 2022-04-02 19:10:53 --> URI Class Initialized
INFO - 2022-04-02 19:10:53 --> Router Class Initialized
INFO - 2022-04-02 19:10:53 --> Output Class Initialized
INFO - 2022-04-02 19:10:53 --> Security Class Initialized
DEBUG - 2022-04-02 19:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:10:53 --> Input Class Initialized
INFO - 2022-04-02 19:10:53 --> Language Class Initialized
INFO - 2022-04-02 19:10:53 --> Loader Class Initialized
INFO - 2022-04-02 19:10:53 --> Helper loaded: url_helper
INFO - 2022-04-02 19:10:53 --> Helper loaded: form_helper
INFO - 2022-04-02 19:10:53 --> Helper loaded: common_helper
INFO - 2022-04-02 19:10:53 --> Helper loaded: util_helper
INFO - 2022-04-02 19:10:53 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:10:53 --> Form Validation Class Initialized
INFO - 2022-04-02 19:10:53 --> Controller Class Initialized
INFO - 2022-04-02 19:10:53 --> Model Class Initialized
INFO - 2022-04-02 19:10:53 --> Model Class Initialized
INFO - 2022-04-02 19:10:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:10:53 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:10:53 --> Final output sent to browser
DEBUG - 2022-04-02 19:10:53 --> Total execution time: 0.0564
INFO - 2022-04-02 19:11:00 --> Config Class Initialized
INFO - 2022-04-02 19:11:00 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:00 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:00 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:00 --> URI Class Initialized
INFO - 2022-04-02 19:11:00 --> Router Class Initialized
INFO - 2022-04-02 19:11:00 --> Output Class Initialized
INFO - 2022-04-02 19:11:00 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:00 --> Input Class Initialized
INFO - 2022-04-02 19:11:00 --> Language Class Initialized
INFO - 2022-04-02 19:11:00 --> Loader Class Initialized
INFO - 2022-04-02 19:11:00 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:00 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:00 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:00 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:00 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:00 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:00 --> Controller Class Initialized
INFO - 2022-04-02 19:11:00 --> Model Class Initialized
INFO - 2022-04-02 19:11:00 --> Model Class Initialized
INFO - 2022-04-02 19:11:00 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:11:00 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:00 --> Total execution time: 0.0612
INFO - 2022-04-02 19:11:04 --> Config Class Initialized
INFO - 2022-04-02 19:11:04 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:04 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:04 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:04 --> URI Class Initialized
INFO - 2022-04-02 19:11:04 --> Router Class Initialized
INFO - 2022-04-02 19:11:04 --> Output Class Initialized
INFO - 2022-04-02 19:11:04 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:04 --> Input Class Initialized
INFO - 2022-04-02 19:11:04 --> Language Class Initialized
INFO - 2022-04-02 19:11:04 --> Loader Class Initialized
INFO - 2022-04-02 19:11:04 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:04 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:04 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:04 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:04 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:04 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:04 --> Controller Class Initialized
INFO - 2022-04-02 19:11:04 --> Model Class Initialized
INFO - 2022-04-02 19:11:04 --> Model Class Initialized
INFO - 2022-04-02 19:11:04 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:11:04 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:04 --> Total execution time: 0.0749
INFO - 2022-04-02 19:11:27 --> Config Class Initialized
INFO - 2022-04-02 19:11:27 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:27 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:27 --> URI Class Initialized
INFO - 2022-04-02 19:11:27 --> Router Class Initialized
INFO - 2022-04-02 19:11:27 --> Output Class Initialized
INFO - 2022-04-02 19:11:27 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:27 --> Input Class Initialized
INFO - 2022-04-02 19:11:27 --> Language Class Initialized
INFO - 2022-04-02 19:11:27 --> Loader Class Initialized
INFO - 2022-04-02 19:11:27 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:27 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:27 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:27 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:27 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:27 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:27 --> Controller Class Initialized
INFO - 2022-04-02 19:11:27 --> Model Class Initialized
INFO - 2022-04-02 19:11:27 --> Model Class Initialized
INFO - 2022-04-02 19:11:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:11:27 --> Config Class Initialized
INFO - 2022-04-02 19:11:27 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:27 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:27 --> URI Class Initialized
INFO - 2022-04-02 19:11:27 --> Router Class Initialized
INFO - 2022-04-02 19:11:27 --> Output Class Initialized
INFO - 2022-04-02 19:11:27 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:27 --> Input Class Initialized
INFO - 2022-04-02 19:11:27 --> Language Class Initialized
INFO - 2022-04-02 19:11:27 --> Loader Class Initialized
INFO - 2022-04-02 19:11:27 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:27 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:27 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:27 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:27 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:27 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:27 --> Controller Class Initialized
INFO - 2022-04-02 19:11:27 --> Model Class Initialized
INFO - 2022-04-02 19:11:27 --> Model Class Initialized
INFO - 2022-04-02 19:11:27 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:11:27 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:27 --> Total execution time: 0.0691
INFO - 2022-04-02 19:11:27 --> Config Class Initialized
INFO - 2022-04-02 19:11:27 --> Hooks Class Initialized
INFO - 2022-04-02 19:11:27 --> Config Class Initialized
INFO - 2022-04-02 19:11:27 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:27 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:27 --> URI Class Initialized
DEBUG - 2022-04-02 19:11:27 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:27 --> Router Class Initialized
INFO - 2022-04-02 19:11:27 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:27 --> Output Class Initialized
INFO - 2022-04-02 19:11:27 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:27 --> Input Class Initialized
INFO - 2022-04-02 19:11:27 --> URI Class Initialized
INFO - 2022-04-02 19:11:27 --> Language Class Initialized
INFO - 2022-04-02 19:11:27 --> Router Class Initialized
INFO - 2022-04-02 19:11:27 --> Output Class Initialized
ERROR - 2022-04-02 19:11:27 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 19:11:27 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:27 --> Input Class Initialized
INFO - 2022-04-02 19:11:27 --> Language Class Initialized
ERROR - 2022-04-02 19:11:27 --> 404 Page Not Found: Fasset/img
INFO - 2022-04-02 19:11:33 --> Config Class Initialized
INFO - 2022-04-02 19:11:33 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:33 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:33 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:33 --> URI Class Initialized
INFO - 2022-04-02 19:11:33 --> Router Class Initialized
INFO - 2022-04-02 19:11:33 --> Output Class Initialized
INFO - 2022-04-02 19:11:33 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:33 --> Input Class Initialized
INFO - 2022-04-02 19:11:33 --> Language Class Initialized
INFO - 2022-04-02 19:11:33 --> Loader Class Initialized
INFO - 2022-04-02 19:11:33 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:33 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:33 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:33 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:33 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:33 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:33 --> Controller Class Initialized
INFO - 2022-04-02 19:11:33 --> Model Class Initialized
INFO - 2022-04-02 19:11:33 --> Model Class Initialized
INFO - 2022-04-02 19:11:33 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\register.php
INFO - 2022-04-02 19:11:33 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:33 --> Total execution time: 0.0605
INFO - 2022-04-02 19:11:34 --> Config Class Initialized
INFO - 2022-04-02 19:11:34 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:34 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:34 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:34 --> URI Class Initialized
INFO - 2022-04-02 19:11:34 --> Router Class Initialized
INFO - 2022-04-02 19:11:34 --> Output Class Initialized
INFO - 2022-04-02 19:11:34 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:34 --> Input Class Initialized
INFO - 2022-04-02 19:11:34 --> Language Class Initialized
INFO - 2022-04-02 19:11:34 --> Loader Class Initialized
INFO - 2022-04-02 19:11:34 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:34 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:34 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:34 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:34 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:34 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:34 --> Controller Class Initialized
INFO - 2022-04-02 19:11:34 --> Model Class Initialized
INFO - 2022-04-02 19:11:34 --> Model Class Initialized
INFO - 2022-04-02 19:11:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:11:34 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:11:34 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:34 --> Total execution time: 0.0652
INFO - 2022-04-02 19:11:36 --> Config Class Initialized
INFO - 2022-04-02 19:11:36 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:36 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:36 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:36 --> URI Class Initialized
INFO - 2022-04-02 19:11:36 --> Router Class Initialized
INFO - 2022-04-02 19:11:36 --> Output Class Initialized
INFO - 2022-04-02 19:11:36 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:36 --> Input Class Initialized
INFO - 2022-04-02 19:11:36 --> Language Class Initialized
INFO - 2022-04-02 19:11:36 --> Loader Class Initialized
INFO - 2022-04-02 19:11:36 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:36 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:36 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:36 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:36 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:36 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:36 --> Controller Class Initialized
INFO - 2022-04-02 19:11:36 --> Model Class Initialized
INFO - 2022-04-02 19:11:36 --> Model Class Initialized
INFO - 2022-04-02 19:11:36 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:11:36 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:36 --> Total execution time: 0.0682
INFO - 2022-04-02 19:11:54 --> Config Class Initialized
INFO - 2022-04-02 19:11:54 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:54 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:54 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:54 --> URI Class Initialized
INFO - 2022-04-02 19:11:54 --> Router Class Initialized
INFO - 2022-04-02 19:11:54 --> Output Class Initialized
INFO - 2022-04-02 19:11:54 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:54 --> Input Class Initialized
INFO - 2022-04-02 19:11:54 --> Language Class Initialized
INFO - 2022-04-02 19:11:54 --> Loader Class Initialized
INFO - 2022-04-02 19:11:54 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:54 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:54 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:54 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:54 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:54 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:54 --> Controller Class Initialized
INFO - 2022-04-02 19:11:54 --> Model Class Initialized
INFO - 2022-04-02 19:11:54 --> Model Class Initialized
INFO - 2022-04-02 19:11:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:11:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:11:54 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:54 --> Total execution time: 0.1499
INFO - 2022-04-02 19:11:55 --> Config Class Initialized
INFO - 2022-04-02 19:11:55 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:11:55 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:11:55 --> Utf8 Class Initialized
INFO - 2022-04-02 19:11:55 --> URI Class Initialized
INFO - 2022-04-02 19:11:55 --> Router Class Initialized
INFO - 2022-04-02 19:11:55 --> Output Class Initialized
INFO - 2022-04-02 19:11:55 --> Security Class Initialized
DEBUG - 2022-04-02 19:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:11:55 --> Input Class Initialized
INFO - 2022-04-02 19:11:55 --> Language Class Initialized
INFO - 2022-04-02 19:11:55 --> Loader Class Initialized
INFO - 2022-04-02 19:11:55 --> Helper loaded: url_helper
INFO - 2022-04-02 19:11:55 --> Helper loaded: form_helper
INFO - 2022-04-02 19:11:55 --> Helper loaded: common_helper
INFO - 2022-04-02 19:11:55 --> Helper loaded: util_helper
INFO - 2022-04-02 19:11:55 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:11:55 --> Form Validation Class Initialized
INFO - 2022-04-02 19:11:55 --> Controller Class Initialized
INFO - 2022-04-02 19:11:55 --> Model Class Initialized
INFO - 2022-04-02 19:11:55 --> Model Class Initialized
INFO - 2022-04-02 19:11:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-04-02 19:11:55 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:11:55 --> Final output sent to browser
DEBUG - 2022-04-02 19:11:55 --> Total execution time: 0.0599
INFO - 2022-04-02 19:12:02 --> Config Class Initialized
INFO - 2022-04-02 19:12:02 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:12:02 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:02 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:02 --> URI Class Initialized
INFO - 2022-04-02 19:12:02 --> Router Class Initialized
INFO - 2022-04-02 19:12:02 --> Output Class Initialized
INFO - 2022-04-02 19:12:02 --> Security Class Initialized
DEBUG - 2022-04-02 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:02 --> Input Class Initialized
INFO - 2022-04-02 19:12:02 --> Language Class Initialized
INFO - 2022-04-02 19:12:02 --> Loader Class Initialized
INFO - 2022-04-02 19:12:02 --> Helper loaded: url_helper
INFO - 2022-04-02 19:12:02 --> Helper loaded: form_helper
INFO - 2022-04-02 19:12:02 --> Helper loaded: common_helper
INFO - 2022-04-02 19:12:02 --> Helper loaded: util_helper
INFO - 2022-04-02 19:12:02 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:12:02 --> Form Validation Class Initialized
INFO - 2022-04-02 19:12:02 --> Controller Class Initialized
INFO - 2022-04-02 19:12:02 --> Model Class Initialized
INFO - 2022-04-02 19:12:02 --> Model Class Initialized
INFO - 2022-04-02 19:12:02 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\login.php
INFO - 2022-04-02 19:12:02 --> Final output sent to browser
DEBUG - 2022-04-02 19:12:02 --> Total execution time: 0.0677
INFO - 2022-04-02 19:12:03 --> Config Class Initialized
INFO - 2022-04-02 19:12:03 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:12:03 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:03 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:03 --> URI Class Initialized
INFO - 2022-04-02 19:12:03 --> Router Class Initialized
INFO - 2022-04-02 19:12:03 --> Output Class Initialized
INFO - 2022-04-02 19:12:03 --> Security Class Initialized
DEBUG - 2022-04-02 19:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:03 --> Input Class Initialized
INFO - 2022-04-02 19:12:03 --> Language Class Initialized
INFO - 2022-04-02 19:12:03 --> Loader Class Initialized
INFO - 2022-04-02 19:12:03 --> Helper loaded: url_helper
INFO - 2022-04-02 19:12:03 --> Helper loaded: form_helper
INFO - 2022-04-02 19:12:03 --> Helper loaded: common_helper
INFO - 2022-04-02 19:12:03 --> Helper loaded: util_helper
INFO - 2022-04-02 19:12:03 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:12:03 --> Form Validation Class Initialized
INFO - 2022-04-02 19:12:03 --> Controller Class Initialized
INFO - 2022-04-02 19:12:03 --> Model Class Initialized
INFO - 2022-04-02 19:12:03 --> Model Class Initialized
INFO - 2022-04-02 19:12:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 19:12:03 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 19:12:03 --> Final output sent to browser
DEBUG - 2022-04-02 19:12:03 --> Total execution time: 0.0710
INFO - 2022-04-02 19:12:05 --> Config Class Initialized
INFO - 2022-04-02 19:12:05 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:12:05 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:05 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:05 --> URI Class Initialized
INFO - 2022-04-02 19:12:05 --> Router Class Initialized
INFO - 2022-04-02 19:12:05 --> Output Class Initialized
INFO - 2022-04-02 19:12:05 --> Security Class Initialized
DEBUG - 2022-04-02 19:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:05 --> Input Class Initialized
INFO - 2022-04-02 19:12:05 --> Language Class Initialized
INFO - 2022-04-02 19:12:05 --> Loader Class Initialized
INFO - 2022-04-02 19:12:05 --> Helper loaded: url_helper
INFO - 2022-04-02 19:12:05 --> Helper loaded: form_helper
INFO - 2022-04-02 19:12:05 --> Helper loaded: common_helper
INFO - 2022-04-02 19:12:05 --> Helper loaded: util_helper
INFO - 2022-04-02 19:12:05 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:12:05 --> Form Validation Class Initialized
INFO - 2022-04-02 19:12:05 --> Controller Class Initialized
INFO - 2022-04-02 19:12:05 --> Model Class Initialized
INFO - 2022-04-02 19:12:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2022-04-02 19:12:05 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2022-04-02 19:12:05 --> Final output sent to browser
DEBUG - 2022-04-02 19:12:05 --> Total execution time: 0.0666
INFO - 2022-04-02 19:12:15 --> Config Class Initialized
INFO - 2022-04-02 19:12:15 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:12:15 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:15 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:15 --> URI Class Initialized
INFO - 2022-04-02 19:12:15 --> Router Class Initialized
INFO - 2022-04-02 19:12:15 --> Output Class Initialized
INFO - 2022-04-02 19:12:15 --> Security Class Initialized
DEBUG - 2022-04-02 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:15 --> Input Class Initialized
INFO - 2022-04-02 19:12:15 --> Language Class Initialized
INFO - 2022-04-02 19:12:15 --> Loader Class Initialized
INFO - 2022-04-02 19:12:15 --> Helper loaded: url_helper
INFO - 2022-04-02 19:12:15 --> Helper loaded: form_helper
INFO - 2022-04-02 19:12:15 --> Helper loaded: common_helper
INFO - 2022-04-02 19:12:15 --> Helper loaded: util_helper
INFO - 2022-04-02 19:12:15 --> Database Driver Class Initialized
DEBUG - 2022-04-02 19:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 19:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 19:12:15 --> Form Validation Class Initialized
INFO - 2022-04-02 19:12:15 --> Controller Class Initialized
INFO - 2022-04-02 19:12:15 --> Model Class Initialized
INFO - 2022-04-02 19:12:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/changepassword.php
INFO - 2022-04-02 19:12:15 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\provider/_layout.php
INFO - 2022-04-02 19:12:15 --> Final output sent to browser
DEBUG - 2022-04-02 19:12:15 --> Total execution time: 0.0684
INFO - 2022-04-02 19:12:15 --> Config Class Initialized
INFO - 2022-04-02 19:12:15 --> Hooks Class Initialized
DEBUG - 2022-04-02 19:12:15 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:15 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:15 --> URI Class Initialized
INFO - 2022-04-02 19:12:15 --> Router Class Initialized
INFO - 2022-04-02 19:12:15 --> Output Class Initialized
INFO - 2022-04-02 19:12:15 --> Config Class Initialized
INFO - 2022-04-02 19:12:15 --> Hooks Class Initialized
INFO - 2022-04-02 19:12:15 --> Security Class Initialized
DEBUG - 2022-04-02 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:15 --> Input Class Initialized
DEBUG - 2022-04-02 19:12:15 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:15 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:15 --> Language Class Initialized
INFO - 2022-04-02 19:12:15 --> URI Class Initialized
ERROR - 2022-04-02 19:12:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 19:12:15 --> Router Class Initialized
INFO - 2022-04-02 19:12:15 --> Output Class Initialized
INFO - 2022-04-02 19:12:15 --> Config Class Initialized
INFO - 2022-04-02 19:12:15 --> Hooks Class Initialized
INFO - 2022-04-02 19:12:15 --> Security Class Initialized
DEBUG - 2022-04-02 19:12:15 --> UTF-8 Support Enabled
INFO - 2022-04-02 19:12:15 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:15 --> Config Class Initialized
INFO - 2022-04-02 19:12:15 --> Hooks Class Initialized
INFO - 2022-04-02 19:12:15 --> URI Class Initialized
DEBUG - 2022-04-02 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:15 --> Input Class Initialized
INFO - 2022-04-02 19:12:15 --> Language Class Initialized
INFO - 2022-04-02 19:12:15 --> Router Class Initialized
DEBUG - 2022-04-02 19:12:15 --> UTF-8 Support Enabled
ERROR - 2022-04-02 19:12:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 19:12:15 --> Utf8 Class Initialized
INFO - 2022-04-02 19:12:15 --> URI Class Initialized
INFO - 2022-04-02 19:12:15 --> Router Class Initialized
INFO - 2022-04-02 19:12:15 --> Output Class Initialized
INFO - 2022-04-02 19:12:15 --> Security Class Initialized
INFO - 2022-04-02 19:12:15 --> Output Class Initialized
DEBUG - 2022-04-02 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:15 --> Input Class Initialized
INFO - 2022-04-02 19:12:15 --> Security Class Initialized
INFO - 2022-04-02 19:12:15 --> Language Class Initialized
DEBUG - 2022-04-02 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 19:12:15 --> Input Class Initialized
ERROR - 2022-04-02 19:12:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 19:12:15 --> Language Class Initialized
ERROR - 2022-04-02 19:12:15 --> 404 Page Not Found: Fassets/img
INFO - 2022-04-02 23:07:54 --> Config Class Initialized
INFO - 2022-04-02 23:07:54 --> Hooks Class Initialized
DEBUG - 2022-04-02 23:07:54 --> UTF-8 Support Enabled
INFO - 2022-04-02 23:07:54 --> Utf8 Class Initialized
INFO - 2022-04-02 23:07:54 --> URI Class Initialized
INFO - 2022-04-02 23:07:54 --> Router Class Initialized
INFO - 2022-04-02 23:07:54 --> Output Class Initialized
INFO - 2022-04-02 23:07:54 --> Security Class Initialized
DEBUG - 2022-04-02 23:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 23:07:54 --> Input Class Initialized
INFO - 2022-04-02 23:07:54 --> Language Class Initialized
INFO - 2022-04-02 23:07:54 --> Loader Class Initialized
INFO - 2022-04-02 23:07:54 --> Helper loaded: url_helper
INFO - 2022-04-02 23:07:54 --> Helper loaded: form_helper
INFO - 2022-04-02 23:07:54 --> Helper loaded: common_helper
INFO - 2022-04-02 23:07:54 --> Helper loaded: util_helper
INFO - 2022-04-02 23:07:54 --> Database Driver Class Initialized
DEBUG - 2022-04-02 23:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 23:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 23:07:54 --> Form Validation Class Initialized
INFO - 2022-04-02 23:07:54 --> Controller Class Initialized
INFO - 2022-04-02 23:07:54 --> Model Class Initialized
INFO - 2022-04-02 23:07:54 --> Config Class Initialized
INFO - 2022-04-02 23:07:54 --> Hooks Class Initialized
DEBUG - 2022-04-02 23:07:54 --> UTF-8 Support Enabled
INFO - 2022-04-02 23:07:54 --> Utf8 Class Initialized
INFO - 2022-04-02 23:07:54 --> URI Class Initialized
INFO - 2022-04-02 23:07:54 --> Router Class Initialized
INFO - 2022-04-02 23:07:54 --> Output Class Initialized
INFO - 2022-04-02 23:07:54 --> Security Class Initialized
DEBUG - 2022-04-02 23:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-02 23:07:54 --> Input Class Initialized
INFO - 2022-04-02 23:07:54 --> Language Class Initialized
INFO - 2022-04-02 23:07:54 --> Loader Class Initialized
INFO - 2022-04-02 23:07:54 --> Helper loaded: url_helper
INFO - 2022-04-02 23:07:54 --> Helper loaded: form_helper
INFO - 2022-04-02 23:07:54 --> Helper loaded: common_helper
INFO - 2022-04-02 23:07:54 --> Helper loaded: util_helper
INFO - 2022-04-02 23:07:54 --> Database Driver Class Initialized
DEBUG - 2022-04-02 23:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-02 23:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-02 23:07:54 --> Form Validation Class Initialized
INFO - 2022-04-02 23:07:54 --> Controller Class Initialized
INFO - 2022-04-02 23:07:54 --> Model Class Initialized
INFO - 2022-04-02 23:07:54 --> Model Class Initialized
INFO - 2022-04-02 23:07:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\index.php
INFO - 2022-04-02 23:07:54 --> File loaded: C:\xampp\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2022-04-02 23:07:54 --> Final output sent to browser
DEBUG - 2022-04-02 23:07:54 --> Total execution time: 0.0636
