<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends MY_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('mcommon');
	    /*if($this->is_logged_in_user()){
	    	redirect(base_url('profile'));
	    }*/	    
 
	}
	public function index(){ 

		echo "hello";	
	}
/////state and city list added by Somnath on 22-02-2021/////////////
	public function getState()
	{
		$html="";

		if($this->input->post()){

			$whereArray = array('cm.id' => $this->input->post('cid'),'sm.country_id'=>$this->input->post('cid') );
			$join[] = ['table' => 'countries_master cm', 'on' => 'cm.id = sm.country_id', 'type' => 'INNER'];
			$stateList = $this->mcommon->selectAll('states_master sm',$whereArray, 'sm.*','','', $join);
			$html ="<option value=''>-Select State-</option>";
			foreach ($stateList as $key => $value) {
				$html.='<option value="'.$value['id'].'">'.$value['name'].'</option>';
			}
			echo $html;
		}
	}
	public function getCity()
	{
		$html="";

		if($this->input->post()){

			$whereArray = array('sm.id' => $this->input->post('sid'),'cm.state_id'=>$this->input->post('sid') );
			$join[] = ['table' => 'states_master sm', 'on' => 'sm.id = cm.state_id', 'type' => 'INNER'];
			$stateList = $this->mcommon->selectAll('cities_master cm',$whereArray, 'cm.*','','', $join);
			$html ="<option value=''>-Select City-</option>";
			foreach ($stateList as $key => $value) {
				$html.='<option value="'.$value['id'].'">'.$value['name'].'</option>';
			}
			echo $html;
		}
	}
	public function changeTicketStatus()
	{
		if($this->input->post()){
			$postData=$this->input->post();
			$updateData = array(
								'status' => $postData['status']
							);

			$this->mcommon->update($postData['table'],array('id' => $postData['id']),$updateData);
			$this->session->set_flashdata('success_msg', 'Ticket Closed Successfully');

		}
	}
	public function changeStatus()
	{
		if($this->input->post()){
			$postData=$this->input->post();
			$updateData = array(
								'status' => $postData['status']
							);

			$this->mcommon->update($postData['table'],array('id' => $postData['id']),$updateData);

			if($postData['status']== 0){

				$this->session->set_flashdata('success_msg', 'Data Inactivated Successfully');

			}elseif($postData['status'] == 1){

				$this->session->set_flashdata('success_msg', 'Data Activated Successfully');

			}elseif($postData['status'] == 3){
				$this->session->set_flashdata('success_msg', 'Data Deleted Successfully');

			}

		}
	}

	public function changeStatusV2()
	{
		if($this->input->post()){
			$postData=$this->input->post();
			$updateData = array(
								'status' => $postData['status']
							);

			$this->mcommon->update($postData['table'],array($postData['field'] => $postData['val']),$updateData);
			//echo $this->db->last_query();exit;

			if($postData['status']== 0){

				$this->session->set_flashdata('success_msg', 'Data Inactivated Successfully');

			}elseif($postData['status'] == 1){

				$this->session->set_flashdata('success_msg', 'Data Activated Successfully');

			}elseif($postData['status'] == 3){
				$this->session->set_flashdata('success_msg', 'Data Deleted Successfully');

			}

		}
	}


	public function changeStatusV4()
	{
		if($this->input->post()){
			$postData=$this->input->post();
			$updateData = array(
								$postData['update_field'] => $postData['update_val']
							);

			$this->mcommon->update($postData['table'],array($postData['search_field'] => $postData['search_val']),$updateData);
			//echo $this->db->last_query();exit;

			if($postData['update_val'] == 0){
				$this->session->set_flashdata('success_msg', 'Reviewer status has been changed to 1st level.');

			}elseif($postData['update_val'] == 1){
				$this->session->set_flashdata('success_msg', 'Reviewer status has been upgraded to lead.');

			}

		}
	}

	
	
	
	

}
