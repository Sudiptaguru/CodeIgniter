<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('Account_m');

	}

	
	public function index(){
        
		$this -> data['main']='ads/dashboard';
	    $this -> data['title']='Dashboard';
	
	    $this -> load -> view('provider/_layout', $this -> data);
				
	}

    function account(){
		
	}

}