<?php
class adsController extends CI_Controller
{
  function __construct()
    {
      parent::__construct();
      // $this->load->model('Account_m');
      // $this->load->model('HomeModel');
      $this->load->model('Common_model');
    }
  private function _loadView($data)
  {
    $this->load->view('adsRegister', $data);
  }

  public function index()
  { 
      $this -> data['content']='adsRegister';
      $this -> data['title']='User List';
      $this -> data['cms']=  $this->Common_model->getRows('user',array('status'=>1 ,'is_deleted'=>0,'group_id' => 3));
      $this->_loadView($this -> data);
      
  }

  public function add()
  {

      $this -> data['content']='adsRegister';
      $this -> data['title']='Add User';
      $this->_loadView($this -> data);  
  }

  public function save()
  {
    $this->form_validation->set_rules('first_name', 'First Name', 'required|min_length[2]');
    $this->form_validation->set_rules('last_name', 'Last Name', 'required|min_length[2]');
    $this->form_validation->set_rules('mobile', 'Mobile', 'required|min_length[10]|max_length[10]');
    $this->form_validation->set_message('is_unique', 'Email already exists.');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user.email]');
    $this->form_validation->set_rules('password', 'Password', 'required|min_length[4]');
    if ($this->form_validation->run() == FALSE){
      $this->session->set_flashdata('error', validation_errors());
            redirect(base_url() . 'ads/adsController/add');
    }
    else{
      $data =  $this->input->post();
 
    $userdetails   =  $this->Common_model->getRow('user',array('email'=>$data['email']));
    if(!empty($userdetails)){
       $this -> session ->set_flashdata('error','Email Alreday register.');
        redirect('ads/adsController/add');
    }

    else
      
    $data1 =  array(
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'mobile' => $data['mobile'],
                    'email' => $data['email'],
                    'password' => password_hash($data['password'],PASSWORD_BCRYPT),
                    'group_id' =>2,
                    'status' =>1,
                    'created_on' =>date('Y-m-d H:i:m') ,
                    'created_by' => $_SESSION['admin_details']['cms_id']
                  );
    $id =  $this->Common_model->add('user',$data1); 
    
    if($id > 0 )
    {
      $this -> session ->set_flashdata('success','Added successfully!');
    }
    // else{
    //  $this -> session ->set_flashdata('error','Problem saving CMS page! Try again.'); 
    // }

    redirect('ads/adsController/add');
    }
  }

}
?>