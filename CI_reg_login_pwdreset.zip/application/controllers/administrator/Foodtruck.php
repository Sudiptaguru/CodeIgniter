<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Foodtruck extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();

		/*if($this->is_logged_in_admin()):
	    	redirect('admin/role/add');
	    endif; */
        $this -> load -> model('admin/Foodtruck_m');
	   
	}

	private function _loadView($data)
	{
		$this->load->view('admin/layouts/index', $data);
	}

	public function index(){
		$this -> data['content']='admin/foodtruck/list';
	    $this -> data['title']='Food Truck List';
	    $this -> data['truck_list'] = $this -> Foodtruck_m ->  get_all();
			
	    $this->_loadView($this -> data);
				
	}

	public function add(){
		$upload_error = "";

		$this->form_validation->set_rules(
        'truck_name', 'Truck name',
        'required|trim|is_unique[truck_details.truck_name]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )
		);

		$this->form_validation->set_rules('facebook','First Facebook','trim');
		$this->form_validation->set_rules('twitter','Twitter','trim');
        $this->form_validation->set_rules('linkedin','Linkedin','trim');
		$this->form_validation->set_rules('website','Website','trim');
		
		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$d = array(
							'truck_name' => $postData['truck_name'],
							'facebook' => $postData['facebook'],
							'linkedin' =>  $postData['linkedin'],
							'twitter' => $postData['twitter'],						
							'created_at' => date('Y-m-d H:i:s'),
							'updated_at' => date('Y-m-d H:i:s'),
							'user_id' => $postData['owner_id'],
                            'website' => $postData['website']
							
					);
				
       // ---- image upload -- //
     
 
        $data = array();
  
        // Count total files
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/truck_images'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '5000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
             
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('administrator/Foodtruck/add');
			}
          }
   
        }
	}
		
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();
    
	   // if truck detail exists, update 

	   

        $query = $this -> db -> get_where('truck_details', array('user_id' => $postData['owner_id']));

		if ($query -> num_rows() > 0){
			$truck_det_id = $query -> row('id');
			$this -> db ->update('truck_details',$d,  array('user_id' => $postData['owner_id']));

		}
		else {
			$this -> db ->insert('truck_details',$d);
			$truck_det_id = $this -> db -> insert_id();

		}
	   
	 
	  
	   // if images uploaded
	   
	   $images = array();
	   if (count($data['filenames'])){
		   foreach ($data['filenames'] as $f) {
			   $images[] = array('user_id' =>  $postData['owner_id'], 'image' => $f, 'truck_details_id' => $truck_det_id);
		   }

	   }
	   
	   
		if (count($images)) {
				$this -> db ->insert_batch('truck_images',$images);
		}
	   
	   $this->db->trans_complete();
	   
	
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem saving user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Added successfully!');
		 
	   }

	   //-- END transaction-- //
	   	redirect('administrator/Foodtruck/add');
	
		}

        $this -> data['details']= $this -> Foodtruck_m -> get(User_H::$_PROVIDER); 
		
		
	    $this -> data['content']='admin/foodtruck/add';
	    $this -> data['title']='Add Truck Details';
	    $this->_loadView($this -> data);	 	
		
	}

    function view($id){
        		
		$this -> data['content']='admin/foodtruck/view';
	    $this -> data['title']='Food Truck Detail';
		$this -> data['u'] = $this -> Foodtruck_m -> get_detail($id);  
		
	    $this->_loadView($this -> data);
        
    }

	function get_all_truck_image_ajax(){
		$uid = $this -> input -> post('uid');
		$this -> db -> where('user_id' , $uid);
		$result = $this -> db ->  get('truck_images') -> result();
		echo json_encode($result);

	}

	function get_user_detail_by_id_ajax(){
		$user_id = $this -> input -> post('user_id');
		$res = $this -> db -> get_where('user',['user_id' => $user_id]) -> row_array();
		echo json_encode($res);
	
	}
	
	function manage($id){
		$this -> data['content']='admin/foodtruck/manage';
	    $this -> data['title']='Manage Food Truck';
		$this -> data['u'] = $this -> Foodtruck_m -> get_detail($id);  
	    $this->_loadView($this -> data);
	}
	
	function schedule(){
		if (empty($_GET['truck_owner'])){
			show_404();		
		}
		
		$truck_owner_id = $_GET['truck_owner'];
		//echo $truck_owner_id;die;
		$this -> data['content']='admin/foodtruck/schedule/add';
	    $this -> data['title']='Add Schedule | Manage Food Truck';
		$this -> data['u'] = $this -> Foodtruck_m -> get_detail($truck_owner_id);  
	    $this->_loadView($this -> data);
	}
	
	function save_schedule_ajax(){
		$postData = $this -> input -> post();
		
		$schedule_data = $postData['schedule_data'];
		$truck_owner_id = $postData['truck_owner_id'];
		
		if (empty($schedule_data)){
			exit(-1);
		}

	   //-- transacrion --//
	     $d =  array();
	    foreach ($schedule_data as $f) {
		   $d[] = array(
							'day' => $f['day'],
							'start_time' => $f['start_time'],
							'end_time' => $f['end_time'],
							'location' => $f['location'],
							'truck_owner_id' => $truck_owner_id
						);
						
	   }

	   $this->db->trans_begin();
	   $this -> db -> where('truck_owner_id', $truck_owner_id);
	   $this -> db -> delete('foodtruck_schedule');
  
		$this -> db ->insert_batch('foodtruck_schedule',$d);
		
	   
	   $this->db->trans_complete();
	   
	
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   echo '0';
		
	   } else {
		
		   $this->db->trans_commit();
		  echo '1';
		 
	   }
		
	}
	
	function menu(){
		if (empty($_GET['truck_owner'])){
			show_404();		
		}
		
		$truck_owner_id = $_GET['truck_owner'];
		// menu image upload
		 $data = array();
  
        // Count total files
		
		if (!empty($_FILES['files']['name'])) {
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/menu_images'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '5000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
             
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('administrator/Foodtruck/menu?truck_owner='.$truck_owner_id);
			}
          }
   
        }
	
		
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();
  
	   
	   $images = array();
	   if (count($data['filenames'])){
		   foreach ($data['filenames'] as $f) {
			   $images[] = array('user_id' => $truck_owner_id, 'images' => $f);
		   }

	   }
	   
	   
		if (count($images)) {
				$this -> db ->insert_batch('food_menu',$images);
		}
	   
	   $this->db->trans_complete();
	   
	
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem saving user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Added successfully!');
		 
	   }
	   
	   redirect('administrator/Foodtruck/menu?truck_owner='.$truck_owner_id);
	   
	  }
		}
		// END menu image upload
		
		//echo $truck_owner_id;die;
		$this -> data['content']='admin/foodtruck/menu/add';
	    $this -> data['title']='Add Food Menu | Manage Food Truck';
		$this -> data['u'] = $this -> Foodtruck_m -> get_detail($truck_owner_id);
		$this -> data['menu_images'] = $this -> Foodtruck_m -> get_menu_images($truck_owner_id);  		
		//echo '<pre>';print_r($this -> data);die;
	    $this->_loadView($this -> data);
		
	}



	public function chef(){

		if (empty($_GET['truck_owner'])){
			show_404();		
		}
		
		$truck_owner_id = $_GET['truck_owner'];
		// menu image upload
		 $data = array();

		$upload_error = "";

		
		$this->form_validation->set_rules('chef_name','Chef Name','trim|required');
		$this->form_validation->set_rules('chef_detail','Description','trim|required');
       
		
		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$d = array(
							'chef_name' => $postData['chef_name'],
							'chef_detail' => $postData['chef_detail'],
							'created_on' => date('Y-m-d H:i:s'),
							'updated_on' => date('Y-m-d H:i:s'),
							'uid' => $truck_owner_id
                          						
					);
				
       // ---- image upload -- //
     
 
        $data = array();
  
        // Count total files
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/chef'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '5000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
			  $d['chef_image'] = $data['filenames'][0];
             
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('administrator/Foodtruck/chef?truck_owner='.$truck_owner_id);
			}
          }
   
        }
	}

	
		
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();  
	   // if images uploaded
	   // $data['filenames']
	  
	
	    $this -> db -> insert('chef', $d);
		
	   $this->db->trans_complete();
	   
	 
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem saving user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Added successfully!');
		 
	   }

	   //-- END transaction-- //
	   redirect('administrator/Foodtruck/chef?truck_owner='.$truck_owner_id);
	
		}

     
		
	    $this -> data['content']='admin/foodtruck/chef/add';
	    $this -> data['title']='Add Chef';
	    $this->_loadView($this -> data);	 	
		
	}

	
}

