<?php
class Cms extends Public_Controller
{
  function __construct()
    {
      parent::__construct();
      // $this->load->model('Account_m');
      $this->load->model('HomeModel');
      $this->load->model('Common_model');
    }
  private function _loadView($data)
  {
    $this->load->view('admin/layouts/index', $data);
  }

  public function index()
  { 
      

      $this -> data['main']='admin/cms/list';
      $this -> data['title']='CMS List';
      $this -> data['cms']=  $this->Common_model->getRows('cms_master',array('status'=>1 ,'delete_status'=>0));
  
      $this -> load -> view('provider/_layout', $this -> data);
      
  }


  public function add()
  {

      $this -> data['main']='admin/cms/add';
      $this -> data['title']='Add CMS';
      $this -> load -> view('provider/_layout', $this -> data);  
  }

  public function save()
  {
    $data =  $this->input->post();
    $data1 =  array(
                    'title' => $data['title'],
                    'page_slug' => $data['page_slug'],
                    'content' => $data['slug']
                    // 'status' =>1,
                    // 'created_datetime' =>date('Y-m-d H:i:m') ,
                    // 'created_by' => $_SESSION['admin_details']['cms_id']
                  );
    $id =  $this->Common_model->add('cms_master',$data1); 
    
    if($id > 0 ){
      $this -> session ->set_flashdata('success','Added successfully!');
    }else{
     $this -> session ->set_flashdata('error','Problem saving CMS page! Try again.'); 
    }

    redirect('administrator/cms/add');


  }

  public function update($id)
  {
    $this -> data['main']='admin/cms/edit';
    $this -> data['title']='Edit CMS';
    $this -> data['cms']=  $this->Common_model->getRow('cms_master',array('cms_id'=>$id));
    // echo $this->db->last_query();die;
   $this -> load -> view('provider/_layout', $this -> data);

    // redirect('administrator/Cms');
  }

  public function updateData()
  {
    $cms_id = $this->input->post('cms_id');
        $title = $this->input->post('title');
        $content = $this->input->post('slug');
        $page_slug = $this->input->post('page_slug');
        $data  = array(
                'cms_id' => $cms_id,
                'title' => $title,
                'content' => $content,
                'page_slug' => $page_slug
            );
        $this->Common_model->upddata($data);
        // if($status!=true){
            $this->session->set_flashdata('success', "Updated successfully");
            redirect('administrator/Cms');
  }

  public function delete_row($cms_id)
  {
    if (!$cms_id){
      show_404();
    }
    $this -> db -> update('cms_master', array('delete_status' => '1'), ['cms_id' => $cms_id]);
    // $this -> session ->set_flashdata('success', 'Cms deleted...'); 
    redirect('administrator/Cms'); 
  }

}
?>