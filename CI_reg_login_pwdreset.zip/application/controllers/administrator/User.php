<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();

		/*if($this->is_logged_in_admin()):
	    	redirect('admin/role/add');
	    endif; */
	    $this -> load -> model('admin/Role_m');
	    $this -> load -> model('admin/User_m');
	}

	private function _loadView($data)
	{
		$this->load->view('admin/layouts/index', $data);
	}

	public function index(){
		$this -> data['content']='admin/user/list';
	    $this -> data['title']='User List';
	    $this -> data['user'] = $this -> User_m -> get();
	    $this->_loadView($this -> data);
				
	}

	public function add(){

		$this->form_validation->set_rules(
        'email', 'Email',
        'required|trim|valid_email|is_unique[user.email]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )
		);

		$this->form_validation->set_rules('first_name','First name','trim|required');
		$this->form_validation->set_rules('last_name','Last name','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[4]|matches[confirm_password]');
		$this->form_validation->set_rules('confirm_password','Confirm password','trim|required|matches[password]');
		$this->form_validation->set_rules('role','Role','required');
		


		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$d = array(
							'first_name' => $postData['first_name'],
							'last_name' => $postData['last_name'],
							'email' =>  $postData['email'],
							'password' => password_hash($postData['password'],PASSWORD_BCRYPT),
							'group_id' =>  $postData['role'],
							'created_on' => date('Y-m-d H:i:s'),
							'updated_on' => date('Y-m-d H:i:s'),
							'created_by' => $_SESSION['admin_details']['user_id'],
							'status' => $postData['status']

					);
				

				$this -> db ->insert('user',$d);
				if ($this -> db -> insert_id()){
					$this -> session ->set_flashdata('success','Added successfully!');
				}
				else {
					$this -> session ->set_flashdata('error','Problem saving user! Try again.');
				}
				redirect('administrator/User/add');

		}
        $this -> data['group']= $this -> Role_m -> get();
      //  echo '<pre>';print_r($this -> data['group']);die;
	    $this -> data['content']='admin/user/add';
	    $this -> data['title']='Add User';
	    $this->_loadView($this -> data);	 	
		
	}

	public function edit($id){

		if(!$id){
			show_404();
		}

		$this -> data['group']= $this -> Role_m -> get();
		$this -> data['user']= $this -> User_m -> get($id);
		
	    $this -> data['content']='admin/user/edit';
	    $this -> data['title']='Edit User';

	    $this->_loadView($this -> data);	 	
		
	}

	function update($id){
		
	
		$this->form_validation->set_rules('first_name','First name','trim|required');
		$this->form_validation->set_rules('last_name','Last name','trim|required');
		$this->form_validation->set_rules('role','Role','required');
		$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('password','Password','trim');
	//	echo 'hi';
	//	echo '<pre>';print_r($_POST);die;


		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();

				$d = array(
							'first_name' => $postData['first_name'],
							'last_name' => $postData['last_name'],
							'group_id' =>  $postData['role'],
							'updated_on' => date('Y-m-d H:i:s'),
							'status' => $postData['status']

					);

				if (isset($postData ['password'])){
					$d['password'] = md5($postData['password']);
				}

	
				$uid = $postData['user_id'];
				$status = $this -> db ->update('user', $d, array('user_id' => $uid));
				

				if ($status){
					$this -> session ->set_flashdata('success','Updated successfully!');
				}
				else {
					$this -> session ->set_flashdata('error','Problem updating role! Try again.');
				}
				 redirect('administrator/User/edit/'.$id);	

		}
		else {

				$this -> session ->set_flashdata('fail',validation_errors());			
					 redirect('administrator/User/edit/'.$id);	
				
		}

  	

	 
	}


	public function destroy($id){
		if (!$id){
		  show_404();
		}

		$this -> db -> update('user', array('is_deleted' => '1'), ['user_id' => $id]);
		$this -> session ->set_flashdata('success', 'User deleted...');	
		redirect('administrator/User');	
	}

	function changeUserStatusAjax(){
		$user_id = $this -> input ->post('uid');
		$status = $this -> input ->post('status');

		$this -> db -> where('user_id' , $user_id);

		$s =$this -> db -> update('user',['status' => $status]);
		if ($s){
			echo "1";
		}
		else {
			echo "0";
		}


	}

	function back(){
		redirect(base_url('admin'));
	}
}

