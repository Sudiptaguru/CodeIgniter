<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('Account_m');

	}

	
	public function index(){
		
				
	}

    function add(){

		 $data = array();

		$upload_error = "";

		
		$this->form_validation->set_rules('first_name','First Name','trim|required');
		$this->form_validation->set_rules('last_name','Last Name','trim|required');
		$this->form_validation->set_rules('contact','Contact no.','trim|required');
       
		
		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
								
				$d = array(
							'first_name' => $postData['first_name'],
							'last_name' => $postData['last_name'],
							'mobile' => $postData['contact'],
							'updated_on' => date('Y-m-d H:i:s')                         						
					);
				
       // ---- image upload -- //
     
 
        $data = array();
  
        // Count total files
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/profile'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '2000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
              $d['profile_pic'] = $data['filenames'][0];
			  $old_image = $postData['old_image'];
			  if ($old_image <> ''){
				  unlink('uploads/profile/'.$old_image);
			  }
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('provider/Profile/add');
			}
          }
   
        }
	}
	
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();  
  
	   $this -> db -> update('user', $d, ['user_id' => $this -> userID()]);
	
	   $this->db->trans_complete();
	   
	  
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem updating user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Updated successfully!');
		 
	   }

	   //-- END transaction-- //
	  redirect('provider/Profile/add');
	
		}


		
		$this -> data['detail'] = $this -> Account_m -> get_row();

	    $this -> data['main']='provider/profile';
	    $this -> data['title']='Profile Add';	
	    $this -> load -> view('provider/_layout', $this -> data);	
		
	}
	
	function changepassword(){
		
		$this->form_validation->set_rules('oldpass', 'old password', 'trim|required|callback_password_check');
        $this->form_validation->set_rules('newpass', 'new password', 'trim|required|matches[passconf]');
        $this->form_validation->set_rules('passconf', 'confirm password', 'trim|matches[newpass]');
		
		 if($this -> form_validation -> run() == TRUE) {
			$newpassword = $this -> input -> post('newpass');
			$d['password'] = password_hash($newpassword,PASSWORD_BCRYPT);
			// $d['password'] = md5($newpassword);
			$status = $this -> db -> update('user', $d, array('user_id' => $this -> userID()));
	
			if ($status){
				$this -> session -> set_flashdata('success','Password updated successfully!');				
			}
			else {
				$this -> session -> set_flashdata('error','Problem occured. Try again!');	
				
			}
			redirect('provider/Profile/changepassword');
			
        }
			
		$this -> data['main']='provider/changepassword';
		// $this -> data['main']='provider/main';
	    $this -> data['title']='Profile Add';	
	    $this -> load -> view('provider/_layout', $this -> data);
		
	}
	
	 public function password_check($oldpass) {
       
        $user = $this -> Account_m -> get_row();
		//$old = $this -> input -> post('oldpass');
        if(password_verify($oldpass,$user['password'])) {
			return true;
            
        }
		else {
			$this->form_validation->set_message('password_check', 'The {field} does not match');
            return false;
		}
        
    }

}