<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Foodmenu extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('Foodmenu_m');

	}

	
	public function index(){
		
		
				
	}

    function add(){
		
		
		$truck_owner_id = $this -> userID();
		$data = array();
  
        // Count total files
		
		if (!empty($_FILES['files']['name'])) {
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/menu_images'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '5000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
             
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('provider/Foodmenu/add');
			}
          }
   
        }
	
		
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();
  
	   
	   $images = array();
	   if (count($data['filenames'])){
		   foreach ($data['filenames'] as $f) {
			   $images[] = array('user_id' => $truck_owner_id, 'images' => $f);
		   }

	   }
	   
	   
		if (count($images)) {
				$this -> db ->insert_batch('food_menu',$images);
		}
	   
	   $this->db->trans_complete();
	   
	
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem saving user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Added successfully!');
		 
	   }
	   
	   redirect('provider/Foodmenu/add');
	   
	  }
		}
		// END menu image upload
		

		$this -> data['main']='provider/menu/add';
	    $this -> data['title']='Add Food Menu';
		$this -> data['menu_images'] = $this -> Foodmenu_m -> get_menu_detail($this -> UserID());
		
	    $this -> load -> view('provider/_layout', $this -> data);
		
	}
	
	

}