<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Schedule extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		
		if (!$this -> isProvider()){
			redirect(base_url('Home'));
		}
		
		$this -> load -> model('Schedule_m');	
		
	}

	
	public function index(){
        
						
	}

    function add(){
	
	    $this -> data['schedule'] = $this -> Schedule_m -> get_detail($this -> userID());
		$this -> data['main']='provider/schedule/add';
	    $this -> data['title']='Truck Add';	
	    $this -> load -> view('provider/_layout', $this -> data);
	}
	
	
	function save_schedule_ajax(){
		
		$postData = $this -> input -> post();
		
		$schedule_data = $postData['schedule_data'];
		$truck_owner_id = $this -> userID();
		
		if (empty($schedule_data)){
			exit(-1);
		}

	   //-- transacrion --//
	     $d =  array();
	    foreach ($schedule_data as $f) {
		   $d[] = array(
							'day' => $f['day'],
							'start_time' => $f['start_time'],
							'end_time' => $f['end_time'],
							'location' => $f['location'],
							'truck_owner_id' => $truck_owner_id
						);
						
	   }

	   $this->db->trans_begin();
	   $this -> db -> where('truck_owner_id', $truck_owner_id);
	   $this -> db -> delete('foodtruck_schedule');
  
		$this -> db ->insert_batch('foodtruck_schedule',$d);
		
	   
	   $this->db->trans_complete();
	   
	
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   echo '0';
		
	   } else {
		
		   $this->db->trans_commit();
		  echo '1';
		 
	   }
		
	}

}