<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Truck extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		
		if (!$this -> isProvider()){
			redirect(base_url('Home'));
		}
		
		$this -> load -> model('Account_m');
		$this -> load -> model('Truck_m');
	}

	
	public function index(){
        
						
	}

    function add(){
	
		$upload_error = "";

		$this->form_validation->set_rules(
        'truck_name', 'Truck name',
        'required|trim|is_unique[truck_details.truck_name]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )
		);

		$this->form_validation->set_rules('facebook','First Facebook','trim');
		$this->form_validation->set_rules('twitter','Twitter','trim');
        $this->form_validation->set_rules('linkedin','Linkedin','trim');
		$this->form_validation->set_rules('website','Website','trim');
		
		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$postData['owner_id'] = $this -> userID();
				$d = array(
							'truck_name' => $postData['truck_name'],
							'facebook' => $postData['facebook'],
							'linkedin' =>  $postData['linkedin'],
							'twitter' => $postData['twitter'],						
							'created_at' => date('Y-m-d H:i:s'),
							'updated_at' => date('Y-m-d H:i:s'),
							'user_id' => $postData['owner_id'],
                            'website' => $postData['website']
							
					);
				
       // ---- image upload -- //
     
 
        $data = array();
  
        // Count total files
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/truck_images'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '5000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
             
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('provider/Truck/add');
			}
          }
   
        }
	}
		
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();
    
	   // if truck detail exists, update 

	   

        $query = $this -> db -> get_where('truck_details', array('user_id' => $postData['owner_id']));

		if ($query -> num_rows() > 0){
			$truck_det_id = $query -> row('id');
			$this -> db ->update('truck_details',$d,  array('user_id' => $postData['owner_id']));

		}
		else {
			$this -> db ->insert('truck_details',$d);
			$truck_det_id = $this -> db -> insert_id();

		}
	   
	 
	  
	   // if images uploaded
	   
	   $images = array();
	   if (count($data['filenames'])){
		   foreach ($data['filenames'] as $f) {
			   $images[] = array('user_id' =>  $postData['owner_id'], 'image' => $f, 'truck_details_id' => $truck_det_id);
		   }

	   }
	   
	   
		if (count($images)) {
				$this -> db ->insert_batch('truck_images',$images);
		}
	   
	   $this->db->trans_complete();
	   
	
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem saving user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Added successfully!');
		 
	   }

	   //-- END transaction-- //
	   	redirect('provider/Truck/add');
	
		}

 
		$this -> data['user']= $this -> Truck_m -> get_truck_detail();
		
//	echo '<pre>';print_r($this -> data['user']);die;	
		$this -> data['main']='provider/truck/add';
	    $this -> data['title']='Food Truck ADD';	
	    $this -> load -> view('provider/_layout', $this -> data);
	}

}