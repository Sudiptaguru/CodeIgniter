<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chef extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('Chef_m');

	}

	
	public function index(){
		
		$this -> data['list'] = $this -> Chef_m -> get_chef_detail();
		
        $this -> data['main']='provider/chef/list';
	    $this -> data['title']='Chef List';	
	    $this -> load -> view('provider/_layout', $this -> data);	
		
				
	}

    function add(){
		
		// menu image upload
		 $data = array();

		$upload_error = "";

		
		$this->form_validation->set_rules('chef_name','Chef Name','trim|required');
		$this->form_validation->set_rules('chef_detail','Description','trim|required');
       
		
		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$truck_owner_id = $this -> userID();
				
				$d = array(
							'chef_name' => $postData['chef_name'],
							'chef_detail' => $postData['chef_detail'],
							'created_on' => date('Y-m-d H:i:s'),
							'updated_on' => date('Y-m-d H:i:s'),
							'uid' => $truck_owner_id
                          						
					);
				
       // ---- image upload -- //
     
 
        $data = array();
  
        // Count total files
        $countfiles = count($_FILES['files']['name']);
	   if ($countfiles  > 0) {
   
        // Looping all files
        for($i=0; $i<$countfiles; $i++){
   
          if(!empty($_FILES['files']['name'][$i])){
   
            // Define new $_FILES array - $_FILES['file']
            $_FILES['file']['name'] = $_FILES['files']['name'][$i];
            $_FILES['file']['type'] = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error'] = $_FILES['files']['error'][$i];
            $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
            // Set preference
            $config['upload_path'] = 'uploads/chef'; 
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '5000'; // max_size in kb
            $config['file_name'] = $_FILES['files']['name'][$i];
   
            //Load upload library
            $this->load->library('upload',$config); 
   
            // File upload
            if($this->upload->do_upload('file')){
              // Get data about the file
              $uploadData = $this->upload->data();
              $filename = $uploadData['file_name'];
  
              // Initialize array
              $data['filenames'][] = $filename;
              $d['chef_image'] = $data['filenames'][0];
            }
			else {
				$upload_error = $this->upload->display_errors();
				$this -> session -> set_flashdata('uploaderror', $upload_error);
				redirect('administrator/Chef/add');
			}
          }
   
        }
	}

	
		
       // END image upload -- //
	  

	   //-- transacrion --//

	   $this->db->trans_begin();  
  
	   $this -> db -> insert('chef', $d);
	
	   $this->db->trans_complete();
	   
	  
	   if ($this->db->trans_status() === FALSE) {
		  
		   $this->db->trans_rollback();
		   $this -> session ->set_flashdata('error','Problem saving user! Try again.');
		
	   } else {
		
		   $this->db->trans_commit();
		   $this -> session ->set_flashdata('success','Added successfully!');
		 
	   }

	   //-- END transaction-- //
	   redirect('provider/Chef/add');
	
		}

     
		
	    $this -> data['main']='provider/chef/add';
	    $this -> data['title']='Chef Add';	
	    $this -> load -> view('provider/_layout', $this -> data);	
		
	}
	
	

}