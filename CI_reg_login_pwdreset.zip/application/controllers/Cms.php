<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   class Cms extends CI_Controller 
   {
    function __construct()
    {
      parent::__construct();
      // $this->load->database();
      $this->load->model('Account_m');
    }
   
    public function index()
    { 
      $this->load->model('Account_m');
      // $data['test']=$this->Account_m->get_data();
      $data['test'] = $this->Account_m->getUserdata();
      print_r($data['test']);
      $this->load->view('viewCms', $data);
      // $this->load->view('ckeditor/samples/index', $data);
      
    }

    public function edit()
    {
       $id=$this->uri->segment(3); 
       $data['user']= $this->Account_m->get_data($id);
       
       // echo "<pre>";
       // print_r($data);die();

      // $this->load->view('ckeditor/samples/updateData',$data);
      $this->load->view('ckeditor/samples/updateCms',$data);
   
    }
   
    public function update_user() 
    {   
   
     $id=$this->input->post('id');
   
   
    
      $data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           // 'name' => strip_tags($this->input->post('name')), 
           'slug' => strip_tags($this->input->post('slug'))
           );
   
       
   
       // echo "<pre>";
       // print_r($data);die();
   
       $this->load->model('Account_m');
   
       if($this->Account_m->upddata($data,$id)) 
       {  
           // echo("update successful");
           redirect('Cms');
   
       }
       else
       {
           echo("update not successful");
       }
   
   }
   
    public function delete_row($id='')
    {  
      $id=$this->uri->segment(3);
        $this->Account_m->delete_data($id);
        redirect('Cms');
    }


  // public function edit_status()
  // {
  //   // print_r($_POST);die();

  //   $id= $this->input->post('id'); 
  //   $status = $this->input->post('status');
    
  //    $this->load->model('User');
   
  //      if($this->User->update_status($status,$id)) 
  //      {  
  //          echo '1';
  //      }
  //      else
  //      {
  //          echo '0';
  //      }
    
  // }


   
   }
   
   ?>