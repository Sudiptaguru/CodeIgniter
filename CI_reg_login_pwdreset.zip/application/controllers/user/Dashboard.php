<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('Account_m');

	}
	
	public function index(){
		
		$this -> data['account_detail']  = $this -> Account_m -> get_row();
		//echo '<pre>';print_r($this -> data['account_detail']);die;
		$this -> data['main']='user/account';
		$this -> data['title']='My Account';
		$this -> load -> view('user/_layout', $this -> data);
	}

	public function update(){
        $user_id = $this->input->post('user_id');
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $mobile = $this->input->post('mobile');
        $data  = array(
                'user_id' => $user_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'mobile' => $mobile
            );
        $this->Account_m->update($data,$user_id);

        // if($status == true){
        //         $data['message'] = "
        //          <font color='green'>
        //          Successfully Data Updated </font>";
        //     }else{
        //         $data['message'] = "
        //         <font color='red'>
        //         Please Try Again,Data is not updated </font>";
        //     }
        redirect('Home','refresh');
    }
	
	public function updateProfileImage()
	{
		
		$pic = '';
        $files =$_FILES;
        if (!empty($files) && $files['profile_image']['name'] != '') {
        	echo "<pre>";
   //      	print_r($files['profile_image']['name']);die;
			// print_r($this->input->post());
            $pic = $this->commonFileUpload('uploads/profile/', $files['profile_image']['name'], 'profile_image');
            die;
            // print_r($pic);
            // if ($pic['status'] != 1) {
            //      $this->response_to_json(FALSE, $pic['image']);
            // }else{
            //     // $updateData = array('profile_image'=>$pic['image']);
            //     // $updateData['updated_on'] = date('Y-m-d H:i:m');
            //     // $this->mcommon->update('invoice_customers',array('customer_id'=>$postData['customer_id']),$updateData);

            //     // $this->mcommon->update('user_invoices',array('customer_id'=>$postData['customer_id']),$updateData);

            //     // $this->response_to_json(True, "Profile Image uploaded Successfully", array('customer_id'=>$postData['customer_id']));
                
            // }
        }else{

        }	
	}

    function account(){
		/*
		$this -> data['account_detail']  = $this -> Account_m -> get_row();
		$this -> data['main']='user/account';
		$this -> data['title']='My Account';
		$this -> load -> view('user/_layout', $this -> data);
		*/
	}

}