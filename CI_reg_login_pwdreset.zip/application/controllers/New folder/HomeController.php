<?php 
class HomeController extends CI_Controller{
	function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        $this->load->model('HomeModel');
    } 
	function viewUser(){
        $this->load->model('HomeModel');
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        // $this->load->view('viewaccount', $data);
        $this->load->view('ckeditor/samples/index', $data);
    }
	function editUser($userId){
       
        $this->load->model('HomeModel');
        $data['user'] = $this->HomeModel->getSingleUser($userId);
        $this->load->view('updateForm',$data);
    }

    function updateUser(){
        $this->load->model('HomeModel');
        
            $setArray = [
                'name' => $this->input->post('name'),
                'phone' => $this->input->post('phone'),
                'address' => $this->input->post('add'),
                // 'otp' => rand(1111,9999)
                 
            ];
            $userId = $this->input->post('userId');
            $status = $this->HomeModel->update_User($setArray,$userId);
            
            if($status == true){
                $data['message'] = "<font color='green'>
                Successfully Updated </font>";
            }else{
                $data['message'] = "<font color='red'> Not upadted,Please Try Again </font>";
            }
            $data['userinfo'] = $this->HomeModel->getAllUsers();
            $this->load->view('viewUsers',$data);
        
    }
}