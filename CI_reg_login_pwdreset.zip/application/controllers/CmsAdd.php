<?php
class CmsAdd extends CI_Controller{
	function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        $this->load->model('HomeModel');
    } 
	public function registration(){ 
		$data = $insertArray = array();
            $insertArray = array(
                'name'=> $this->input->post('name'),
                'slug'=> $this->input->post('slug')
            );
            $data['user'] = $insertArray;

        $status = $this->HomeModel->register($insertArray);
        if($status == true){
                redirect('Cms');
            }
        $this->load->view("addCms");
    }
}