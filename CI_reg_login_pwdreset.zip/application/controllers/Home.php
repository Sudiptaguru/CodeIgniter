<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('User_m');
		$this -> load -> model('Home_m');

	}

	
	public function index(){
		        
		$this -> data['main']='index';
	    $this -> data['title']='Home';
	    $this -> load -> view('_layout', $this -> data);
				
	}

    public function register(){
		if (empty($this ->input ->get('utype'))){
			show_404();
		}
		
		$type = $this ->input ->get('utype');

		
		$this -> data['error'] = '';
		$this->form_validation->set_rules('first_name','First name','trim|required');
		$this->form_validation->set_rules('last_name','Last name','trim|required');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|is_unique[user.email]');
		$this->form_validation->set_rules('contact_no','Contact no','trim|required|numeric');
		$this->form_validation->set_rules('password','Password','trim|required|matches[confirm_password]');
		$this->form_validation->set_rules('confirm_password','Confirm password','trim|required|matches[password]');
		$this->form_validation->set_rules('agree','Terms & Conditions','required');
		if ($this->form_validation->run() === TRUE) {
		  
			$postData = array();		
			$postData = $this->input->post();
			$array	= array(
								'first_name' => $postData['first_name'],
								'mobile' => $postData['contact_no'],
								'last_name' => $postData['last_name'],
								'email'	=>	$postData['email'],
								// 'password'	=>	md5($postData['password'])
								'password'	=>	password_hash($postData['password'],PASSWORD_BCRYPT)
								
			
		                   );

				if ($type == 'user'){
				$array['group_id']  = '3';	

			}

			else {
				$array['group_id'] =  '2';
			}
		

			$this->db->insert('user', $array);

			if ($this -> db -> insert_id()){
				$this -> session -> set_flashdata('success','Registered successfully!');
				redirect('/register?utype='.$type,'refresh');
			}
			$this->data['error'] = 'Problem resgistering. Try again';
		}
		
		
	    $this -> data['title'] = 'Register';
	    $this -> load -> view('register', $this -> data);
				
	}

	public function login(){
			
		$this->data['error'] = "";
		$this->data['success'] = "";
		
		if ($this->session->userdata('success')){

			$this->data['success']	=	$this->session->userdata('success');
			$this->session->unset_userdata('success');
		}	
	 


		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		$this->form_validation->set_rules('password','Password','required');
		
		if ($this->form_validation->run() === TRUE) {
			
			$email	=	$this->input->post('email');
			$password	=	$this->input->post('password');
			$status	=	$this->User_m->validate($email, $password);
			if ($status == 1){
				
				$this->session->set_userdata('success','You are successfully logged in!');
			//	echo '<pre>';print_r($_SESSION);die;
				
					redirect('/provider/Dashboard','refresh');	
			} 
			else 
			{
				$this->data['error'] = 'Wrong password';
			}
		}
		


	$this -> data['title'] = 'Login';
	$this -> load -> view('login', $this -> data);

}



public function logout(){ 
      
        $this->session->sess_destroy(); 
        redirect('/Home','refresh');
    }


public function search() {
	$sql = "";
   
	if (empty($_GET)){
		redirect('Home','refresh');
	}

	$sql = "SELECT * FROM truck_details t
			JOIN foodtruck_schedule s
			ON  t.user_id = s.truck_owner_id";
	
	if (!($_GET['truck_name'])){
		$truck_name =	strtolower($_GET['truck_name']);
		$sql .= " AND LOWER(truck_name) LIKE '%$truck_name%'";

	}

	if (!empty($_GET['s'])){
		$city =	strtolower($_GET['city']);
		$sql .= " AND LOWER(s.location) LIKE '%$city%'";

	}

	if (isset($_GET['state'])){
		$state =	strtolower($_GET['state']);
		$sql .= " AND LOWER(s.location) LIKE '%$state%'";

	}
	
	$sql .= " GROUP BY t.user_id";
	$this -> data['result'] =  $this -> Home_m -> get_search_result($sql);
 	////echo '<pre>';print_r($this -> data['result']);die;	
	$this -> data['main'] = 'search_result';
	$this -> data['title'] ='Search Result';
	$this -> load -> view('_layout', $this -> data);
}

public function search_detail() {
	if (empty($_GET) && empty($_GET['d'])){
		redirect('Home','refresh');
	}

	$uid = base64_decode($_GET['d']);
	
	$this -> data['result'] =  $this -> Home_m -> get_search_detail($uid);
	$this -> data['user_id'] =  $uid;
 	////echo '<pre>';print_r($this -> data['result']);die;	
	$this -> data['main'] = 'search_detail';
	$this -> data['title'] ='Search Result';
	$this -> load -> view('_layout', $this -> data);
}

}