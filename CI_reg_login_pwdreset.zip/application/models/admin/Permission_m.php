<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Permission_m extends CI_Model
{
	

	public function __construct()
	{
		parent::__construct();
		
	}

	function get($rid = '') {
		
		$this -> db -> where('parent_id','0');
		$parent_menu =	$this -> db -> get('menu') -> result_array();

		$arr = array();
		foreach ($parent_menu as $k => $p){
			  $arr[$k] = $p;

			  
			  $m = $p['menu_id'];

			  $result =  $this -> db
			  				   -> query("select * from menu where parent_id = '$m'")
			  				   -> result_array();
		    
			  if (count($result)){

			  	$arr[$k]['submenu'] = $result;	

			  }
			  else {
			  	$arr[$k]['submenu'] = array();
			  }
			  
		}
        return $arr;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
	
	}

	function get_assigned_menu($role_id){
		$this -> db -> where('role_id',$role_id);
		return $this -> db -> get('role_menu') -> result_array();
	}
}
