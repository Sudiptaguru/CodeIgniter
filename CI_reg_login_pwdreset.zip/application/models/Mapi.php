<?php
 class Mapi extends CI_Model {
    function __construct(){
        parent::__construct(); 
    }
    public function insert($table,$data){
        $this->db->insert($table,$data);
		//echo $this->db->last_query();
        return $this->db->insert_id();
    }
	
	public function total_count($table){
		$query=$this->db->get($table);
        return $query->num_rows();
	}
	public function batch_insert($table,$data){
        $this->db->insert_batch($table,$data);
        return 1;
    } 
    public function getDetails($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        return $query->result_array(); 
    }
	
	public function getspecificDetails($table,$condition){
		//$this->db->select('driver_customer_ride');
		$this->db->select('paypal_invoice, paid_by_customer, status');    
		$this->db->get('driver_customer_ride');
        $this->db->where($condition);
        $query=$this->db->get($table);
        return $query->result_array(); 
    }
	
    public function getRow($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        //echo $this->db->last_query();exit();
        return $query->row_array();
    }  
	
	public function getRowCustomer($condition)
	{
		$this->db->from('customer');
        $this->db->join('driver_customer', 'driver_customer.customer_id = customer.customer_id');
		$this->db->where($condition);
		$query=$this->db->get();		
        return $query->row_array();
	}
	
	public function getRidelist($condition) {
		
	$this->db->from('driver_customer_ride'); 	
	if(!empty($condition))
		{ 
	    $this->db->where("DATE_FORMAT(date_time,'%Y-%m-%d %H:%i')>=",$condition['start_date']);
	    $this->db->where("DATE_FORMAT(date_time,'%Y-%m-%d %H:%i')<=",$condition['end_date']);				
	    } 
		if($condition['is_paid']){ $this->db->where("is_paid",$condition['is_paid']); }
		$this->db->where("driver_id",$condition['driver_id']);
		
		$query=$this->db->get();
	//	echo $this->db->last_query(); exit() ; 
        return $query->result_array();
	}
	
	public function getRides($condition)
	{
		$this->db->select('driver_customer_ride.*, SUM(driver_customer_ride.total_amount) as total_amount , SUM(driver_customer_ride.driver_comm) as driver_comm , SUM(driver_customer_ride.taxi_fare) as taxi_fare');
		
		$this->db->group_by('driver_customer_ride.paypal_invoice');
		
		$this->db->from('driver_customer_ride'); 
		
		if(!empty($condition))
		{			
			if(!isset($condition['start_date']) || !isset($condition['end_date']))
			{
				if($condition['is_paid'] == 0 || $condition['is_paid'] == 1)
				{
					$this->db->where("paid_by_customer",$condition['paid_by_customer']);	
				}				
				$this->db->where("driver_id",$condition['driver_id']);
				$this->db->where("status !=","DRAFT");
				//$this->db->where("status !=","PP INVOICED");
				
			}else{
				$this->db->where("DATE_FORMAT(date_time,'%Y-%m-%d')>=",$condition['start_date']);
				$this->db->where("DATE_FORMAT(date_time,'%Y-%m-%d')<=",$condition['end_date']);
				
				if($condition['is_paid'] == 0 || $condition['is_paid'] == 1)
				{
					$this->db->where("paid_by_customer",$condition['paid_by_customer']);	
				}				
				$this->db->where("driver_id",$condition['driver_id']);
				$this->db->where("status !=","DRAFT");
				
				//$this->db->where("status !=","PP INVOICED");
			
			}
			
		} 
		
		//$this->db->where("is_paid",0);	
		$this->db->order_by('date_time','DESC');
		$query=$this->db->get();
		//echo $this->db->last_query(); exit() ; 
        return $query->result_array();
	}
	
	
	
	public function getDriverRides($condition)
	{
		$this->db->from('driver_customer_ride');  
		if(!empty($condition))
		{			
			if(!isset($condition['start_date']) || !isset($condition['end_date']))
			{
				if($condition['is_paid'] == 0 || $condition['is_paid'] == 1)
				{
					$this->db->where("paid_by_customer",$condition['paid_by_customer']);
                    $this->db->where("is_paid",$condition['is_paid']);					
				}				
				$this->db->where("driver_id",$condition['driver_id']);
				$this->db->where("status !=","DRAFT");
				$this->db->where("status !=","PP INVOICED");
				$this->db->where("status !=","DECLINED");
				
			}else{
				$this->db->where("DATE_FORMAT(date_time,'%Y-%m-%d')>=",$condition['start_date']);
				$this->db->where("DATE_FORMAT(date_time,'%Y-%m-%d')<=",$condition['end_date']);
				
				if($condition['is_paid'] == 0 || $condition['is_paid'] == 1)
				{
					$this->db->where("paid_by_customer",$condition['paid_by_customer']);
                    $this->db->where("is_paid",$condition['is_paid']);						
				}				
				$this->db->where("driver_id",$condition['driver_id']);
				$this->db->where("status !=","DRAFT");
				$this->db->where("status !=","PP INVOICED");
				$this->db->where("status !=","DECLINED");
			
			}
			
		}
		
		//$this->db->where("is_paid",0);	
		$this->db->order_by('date_time','DESC');
		
		$query=$this->db->get();
		//echo $this->db->last_query(); exit() ; 
        return $query->result_array();
	}
	
	public function getCustomers($condition)
	{		
		$this->db->from('driver_customer');
        $this->db->join('customer', 'customer.customer_id = driver_customer.customer_id');
		$this->db->where($condition);
		$query=$this->db->get();
        return $query->result_array();
	}
    public function checkUser($condition){
        $this->db->where($condition);
        $query=$this->db->get('users');
        return $query->row_array(); 
    } 
    public function update($table,$condition,$data){
        $this->db->where($condition);
        $this->db->update($table,$data);
        return 1;
    }
	public function getRows($table,$condition,$order_col=null,$order_type=null){
        $this->db->where($condition);
		
		if(isset($limit)){
          $this->db->limit($limit);      
        }
        if(!empty($order_col) && !empty($order_type)){
            $this->db->order_by($order_col,$order_type);
        }
        $query=$this->db->get($table);
		//echo $this->db->last_query();exit;
        return $query->result_array();
    }
	
	public function totalAmountOfSavePaymentList($condition)
	{
		$this->db->from('driver_customer_ride');  
		if(!empty($condition))
		{			
			$this->db->where("paid_by_customer",$condition['paid_by_customer']);	
			$this->db->where("is_paid",$condition['is_paid']);				
			$this->db->where("driver_id",$condition['driver_id']);
			$this->db->where("status !=","DRAFT");
			$this->db->where("status !=","PP INVOICED");
			$this->db->where("status !=","DECLINED");		
			
		}
		
		$query=$this->db->get();
		//echo $this->db->last_query();exit;
        return $query->result_array();
	}
	public function delete($table,$condition){
        $this->db->where($condition);  
        $this->db->delete($table); 
        return true;
    }   

	public function getTokenDetailsByDeviceToken($ap){
        $condition=array('token_owner'=>$ap['device_token']);
        $this->db->where($condition);
        $this->db->order_by('token_id','desc');
        $this->db->limit(1);
        $query=$this->db->get('api_token');
        return $query->row_array();
    }

	public function getTokenDetailsByTokenkey($token_key){
        $condition=array('token_key'=>$token_key);
        $this->db->where($condition);
        $this->db->order_by('token_id','desc');
        $this->db->limit(1);
        $query=$this->db->get('api_token');
        return $query->row_array();
    }

    public function getinvoicestatus(){
	$this->db->select('paypal_invoice , paid_by_customer , status');
	$this->db->from('driver_customer_ride');
	$condition=array('paypal_invoice!='=>'' , 'paid_by_customer' => 0 );
	$this->db->where($condition);
    $result = $this->db->get();
    return $result->result();	
		
	}

   public function get_service_rate_details($condition){
	    $this->db->select('users.driver_incentive,user_card_type.rate');
	    $this->db->from('users');
        $this->db->join('user_card_type', 'users.user_id = user_card_type.user_id','left');
		$this->db->where($condition);
		$query=$this->db->get();
        return $query->result_array();
	   
   }

   public function get_groupby_values($table,$condition,$order_col=null,$order_type=null){
		$this->db->select('driver_customer_ride.*, SUM(driver_customer_ride.total_amount) as total_amount , SUM(driver_customer_ride.driver_comm) as driver_comm');
		$this->db->group_by('driver_customer_ride.paypal_invoice');
        $this->db->where($condition);
		
		if(isset($limit)){
          $this->db->limit($limit);      
        }
        if(!empty($order_col) && !empty($order_type)){
            $this->db->order_by($order_col,$order_type);
        }
        $query=$this->db->get($table);		
       return $query->row_array();
    }
	
	public function get_val($table, $match_field, $match_value, $find_field){

		$this->db->select($find_field);
		$this->db->where($match_field, $match_value);
		$this->db->from($table);
		$query = $this->db->get();		
		$row = $query->row_array();		
	   // $temp_value = $row[$find_field];
		//echo $this->db->last_query(); exit();	
		//return $temp_value;
		return $row ; 
	}


	/////////////////////////////Get Shift by Date /////////////////////////////////

	public function getShiftByDate($condition) {
		
	$this->db->from('shift_details'); 	
	if(!empty($condition['start_date']))
		{ 
	    $this->db->where("DATE_FORMAT(start_time,'%Y-%m-%d %H:%i') >= ",$condition['start_date']);
		}
		if(!empty($condition['end_date']))
		{
	    $this->db->where("DATE_FORMAT(start_time,'%Y-%m-%d %H:%i') <= ",$condition['end_date']);				
	    } 
		$this->db->where("driver_id",$condition['driver_id']);
		
		$query=$this->db->get();
		//echo $this->db->last_query(); exit() ; 
        return $query->result_array();
	}

	///////////////////////////total shift amount///////////////////////////////////////////
	public function get_shift_total($shift_id)
	{
		$this->db->select('SUM(driver_customer_ride.total_amount) as total_amount , SUM(driver_customer_ride.driver_comm) as driver_comm');
		 $this->db->group_by('driver_customer_ride.shift_id');
        $this->db->from('driver_customer_ride');	
		$this->db->where('shift_id',$shift_id);
		$query=$this->db->get();		
        return $query->row_array();
	}
	
    	
}
