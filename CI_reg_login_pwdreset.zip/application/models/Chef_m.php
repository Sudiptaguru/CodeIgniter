<?php
class Chef_m extends CI_Model
{
	public $_table = 'chef';
	function __construct ()
	{
		parent::__construct();
	}

	public function get_chef_detail()
	{
		$d = array();
		
		$id = $_SESSION['user_id'];
		
		$sql = "SELECT * 
				FROM chef WHERE uid = '$id'";
				
		$d =  $this -> db -> query($sql) -> result_array();
				
		return $d;
	   	
	}
	
	 
}