<?php
class Truck_m extends CI_Model
{
	public $_table = 'truck_details';
	function __construct ()
	{
		parent::__construct();
	}

	public function get_truck_detail()
	{
		$d = array();
		
		$id = $_SESSION['user_id'];
		$sql = "SELECT * 
				FROM user LEFT JOIN truck_details 
				ON  user.user_id = truck_details.user_id 
				WHERE user.status = '1' AND user.user_id = '$id'";
				
		$d =  $this -> db -> query($sql) -> row_array();
		$this -> db -> where('user_id' , $id);
		$d['images'] = $this -> db -> get('truck_images') -> result_array();
		
		return $d;
	   	
	}
	
	 
}